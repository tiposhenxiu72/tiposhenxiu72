--<ScriptOptions statementTerminator=";"/>

CREATE VIEW "VW005001" AS
--�ʓYVW005001.sql�Q�ƁB;

