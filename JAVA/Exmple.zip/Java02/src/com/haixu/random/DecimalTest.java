package com.haixu.random;

import java.math.BigDecimal;

public class DecimalTest {

	
	public static void main(String[] args) {
		System.out.println(0.05+0.01);
		System.out.println(1.0-0.42);
		System.out.println(123.2/100);
		System.out.println(1.23*100);
		
		//BigDecimal
		BigDecimal f1 = new BigDecimal("0.05");
		BigDecimal f2 = BigDecimal.valueOf(0.05);
		BigDecimal f3 = new BigDecimal(0.05);
		
		System.out.println(f1);
		System.out.println(f2);
		System.out.println(f3);
		
		
	}
}
