package com.haixu.random;

import java.util.Random;
/*
 * �������ѧϰRandom
 * */
public class MathTest {

	public static void main(String[] args) throws InterruptedException {
		Random random = new Random();
		
		//�������boolean 
		Boolean bool = random.nextBoolean();
		System.out.println(bool);
		
		int i = random.nextInt();
		System.out.println(i);
		
		double d = random.nextDouble();
		System.out.println(d);
		
		//�������5���ڵ������
		int i1 = random.nextInt(5);
		System.out.println(i1);
		
		Class<? extends Random> str = random.getClass();
		System.out.println(str);
		
	    double i2 = random.nextGaussian();	
	    System.out.println(i2);
	}
	
}
