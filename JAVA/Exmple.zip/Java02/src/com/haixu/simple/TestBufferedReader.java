package com.haixu.simple;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class TestBufferedReader {
 
	public static void main(String[] args) throws Exception{
		BufferedReader br = new BufferedReader(
				new InputStreamReader(System.in));
		while((br.readLine())!=null){
			System.out.println("��������������ǣ�"+br.readLine());
		}
	}

}
