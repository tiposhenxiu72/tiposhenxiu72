package com.haixu.string;
/*
 * StringBuilder�ķ���ѧϰ
 * ��ɾ�Ĳ�
 * */
public class TestStringBuilder {

	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder();
		sb.append("java");
		
		sb.insert(0,"hello ");
		
		sb.delete(5,6);
		
		sb.replace(3, 4, "//");
		
		sb.reverse();
		
		System.out.println(sb);
	}
}
