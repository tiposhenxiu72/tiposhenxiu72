package com.haixu.date;

import java.util.Calendar;
/*
 * Date���ڲ�����ѧϰ
 * */
public class DateTest {
	
	public static void main(String[] args) {
		 
	    System.out.println(System.currentTimeMillis());
	    
	    
	  //  System.out.println(Date( 3600));
	    Calendar calendar = Calendar.getInstance();
	    java.util.Date date = calendar.getTime();
	    Calendar calendar2 = Calendar.getInstance();
	    calendar2.setTime(date);
	    System.out.println(date);
	    
	    
	    
	    
	}	

}
