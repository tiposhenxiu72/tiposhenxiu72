package com.haixu.tostring;

public class ToStringTest {
    public static void main(String[] args) {
		
	}

}
