package com.haixu.tostring;

public class TestInstanceOf {
	/*
	 * instanceOfѧϰʵ��
	 * ��Object����ת����String ����
	 * 
	 * */
	public static void main(String[] args) {
		
		Object obj = "hello";
		
		if (obj instanceof String) {
			String str = (String) obj;
			System.out.println(str);
			
		}
		
	    String s = "123";
		if(s instanceof Object){
			Object o = (String) s;
			System.out.println(o);
		}
		
		Object bool = true;
		if(bool instanceof Boolean){
			boolean bo = (Boolean) bool;
			System.out.println(bo);
		}
		
		Boolean b = false;
		if(b instanceof Object){
			Object ob= (Object) b;
			System.out.println(ob);
		}
		
	}
	

}

