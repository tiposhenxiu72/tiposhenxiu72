package com.haixu.math;

import java.lang.Math;
import java.util.Random;
public class MathTest {
	
	public static void main(String[] args) {
	
		System.out.println(Math.PI);
		System.out.println(Math.E);
		
		System.out.println(Math.abs(2.0));
		System.out.println(Math.sin(2.0));
		System.out.println(Math.cos(1.0));
		System.out.println(Math.tan(0.5));
		
		System.out.println(Math.log(100));
		System.out.println(Math.sqrt(100));
		System.out.println(Math.cbrt(1000));
		System.out.println(Math.IEEEremainder(2, 8));
		
		System.out.println(Math.ceil(-0.12));
		
		System.out.println(Math.round(4.2f));
		System.out.println(Math.round(4.2));
		
		for(int i=0;i<10;i++){
			System.out.println(Math.random());
			Random random =  new Random();
		    System.out.println(random.nextBoolean());
		    System.out.println(random.nextDouble());
		    System.out.println(random.nextGaussian());
		    System.out.println(random.nextInt());
		}
		
		for(int j=0;j<4;j++){
			Random random = new Random();
			System.out.println(random.nextGaussian());
			System.out.println(random.nextInt());
		}
	}

}
