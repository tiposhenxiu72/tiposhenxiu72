package jp.co.sraw.dto;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

public class KjBoardDto implements Serializable {

	private String boardGroupKey;

	private String boardName;

	private String commonFlag;

	private String publicFlag;

	private String adminUserKey;

	private String userKey;

	private Timestamp updDate;

	private String updUserKey;

	private int thredCount;

	private int unRead;

	private List<KjBoardRelUserDto> kjRelUsers;

	private List<KjGroupCommonFileDto> kGroupCommonFiles;

	private List<KjThredDto> kjThreds;

	public String getBoardGroupKey() {
		return boardGroupKey;
	}

	public void setBoardGroupKey(String boardGroupKey) {
		this.boardGroupKey = boardGroupKey;
	}

	public String getBoardName() {
		return boardName;
	}

	public void setBoardName(String boardName) {
		this.boardName = boardName;
	}

	public String getCommonFlag() {
		return commonFlag;
	}

	public void setCommonFlag(String commonFlag) {
		this.commonFlag = commonFlag;
	}

	public String getPublicFlag() {
		return publicFlag;
	}

	public void setPublicFlag(String publicFlag) {
		this.publicFlag = publicFlag;
	}

	public String getAdminUserKey() {
		return adminUserKey;
	}

	public void setAdminUserKey(String adminUserKey) {
		this.adminUserKey = adminUserKey;
	}

	public String getUserKey() {
		return userKey;
	}

	public void setUserKey(String userKey) {
		this.userKey = userKey;
	}

	public Timestamp getUpdDate() {
		return updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdUserKey() {
		return updUserKey;
	}

	public void setUpdUserKey(String updUserKey) {
		this.updUserKey = updUserKey;
	}

	public int getThredCount() {
		return thredCount;
	}

	public void setThredCount(int thredCount) {
		this.thredCount = thredCount;
	}

	public int getUnRead() {
		return unRead;
	}

	public void setUnRead(int unRead) {
		this.unRead = unRead;
	}

	public List<KjBoardRelUserDto> getKjRelUsers() {
		return kjRelUsers;
	}

	public void setKjRelUsers(List<KjBoardRelUserDto> kjRelUsers) {
		this.kjRelUsers = kjRelUsers;
	}

	public List<KjGroupCommonFileDto> getkGroupCommonFiles() {
		return kGroupCommonFiles;
	}

	public void setkGroupCommonFiles(List<KjGroupCommonFileDto> kGroupCommonFiles) {
		this.kGroupCommonFiles = kGroupCommonFiles;
	}

	public List<KjThredDto> getKjThreds() {
		return kjThreds;
	}

	public void setKjThreds(List<KjThredDto> kjThreds) {
		this.kjThreds = kjThreds;
	}


}
