/*
* ファイル名：OthersForm.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.portfolio.form;

import org.hibernate.validator.constraints.NotBlank;

import jp.co.sraw.entity.GyCommonTbl;
import jp.co.sraw.entity.GyResearchAreaTbl;
import jp.co.sraw.util.StringUtil;

/**
 * <B>GyResearchAreaFormクラス</B>
 * <P>
 * Formのメソッドを提供する
 */
public class GyResearchAreaForm extends PortfolioForm {

	public GyResearchAreaForm() {
		super();
	}

	public String getResearchAreaLanguage() {
		return this.getLanguage();
	}

	public void setResearchAreaLanguage(String researchAreaLanguage) {
		this.setLanguage(researchAreaLanguage);
	}

	@NotBlank
	private String fieldid;

	private String fieldname;

	@NotBlank
	private String subjectid;

	private String subjectname;

	private String summaryName;

	@NotBlank
	private String summaryid;

	public String getFieldid() {
		return getContent(this.fieldid, "0221");
	}

	public void setFieldid(String fieldid) {
		this.fieldid = fieldid;
	}

	public String getFieldname() {
		if (StringUtil.isNull(this.fieldname)) {
			String viewtype = this.viewType;
			this.viewType = this.VIEW_TYPE_FORM;
			this.fieldname = this.getFieldid();
			this.viewType = viewtype;
		}
		return this.fieldname;
	}

	public void setFieldname(String fieldname) {
		this.fieldname = fieldname;
	}

	public String getSubjectid() {
		return getContent(this.subjectid, "0222");
	}

	public void setSubjectid(String subjectid) {
		this.subjectid = subjectid;
	}

	public String getSubjectname() {
		if (StringUtil.isNull(this.subjectname)) {
			String viewtype = this.viewType;
			this.viewType = this.VIEW_TYPE_FORM;
			this.subjectname = this.getSubjectid();
			this.viewType = viewtype;
		}
		return this.subjectname;
	}

	public void setSubjectname(String subjectname) {
		this.subjectname = subjectname;
	}

	public String getSummaryName() {
		return summaryName;
	}

	public void setSummaryName(String summaryName) {
		this.summaryName = summaryName;
	}

	public String getSummaryid() {
		return this.summaryid;
	}

	public void setSummaryid(String summaryid) {
		this.summaryid = summaryid;
	}

	@Override
	public GyCommonTbl getNewTbl() {
		// TODO 自動生成されたメソッド・スタブ
		return new GyResearchAreaTbl();
	}

}
