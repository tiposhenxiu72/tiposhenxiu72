package jp.co.sraw.controller.portfolio.excel;

import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Service;

import jp.co.sraw.common.CommonForm;
import jp.co.sraw.controller.portfolio.form.GySocietyForm;
import jp.co.sraw.util.PoiBook;

@Service
public class SocietyExcelHelper extends PortfolioExcelHelper<GySocietyForm> {

	public SocietyExcelHelper() {
		this.DATA_SHEET_NAME = "SOCIETY";
	}

	@Override
	public void buildExcelDocument(PoiBook workbook, List<GySocietyForm> list) {
		workbook.activeSheet = workbook.book.getSheet(DATA_SHEET_NAME);

		for (int i = 0; i < list.size(); i++) {
			GySocietyForm form = list.get(i);
			form.setViewType(CommonForm.VIEW_TYPE_EXCEL);
			int rowno = i + 1;
			// 言語区分
			// workbook.changeValue(rowno, 0, form.getLanguage());
			// 所属学協会名
			workbook.changeValue(rowno, 0, form.getTitle());
			// 公開範囲
			workbook.changeValue(rowno, 1, form.getPublicFlag());
		}
	}

	@Override
	public Sheet getSheet(Workbook workbook) {
		return workbook.getSheet(DATA_SHEET_NAME);
	}

	@Override
	public GySocietyForm getForm(Row row) {
		GySocietyForm form = new GySocietyForm();

		// 言語区分
		// form.setLanguage(getCellValue(row, 0));
		// 所属学協会名
		form.setTitle(getCellValue(row, 0));
		// 公開範囲
		form.setPublicFlag(getCellValue(row, 1));

		return form;
	}

}