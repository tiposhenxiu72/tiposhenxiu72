package jp.co.sraw.controller.skill;

import java.sql.Timestamp;
import java.util.Date;

import jp.co.sraw.entity.NrAchievementReportBkupTbl;

public class ReportForm {

	private Date wholeInputDate;
	private Date wholeDueDate;
	private String wholeTarget;
	private Date annualInputDate;
	private Date annualDueDate;
	private String annualTarget;

	public ReportForm() {
	}

	public ReportForm(NrAchievementReportBkupTbl repo) {
		wholeInputDate = repo.getAllInputDate();
		wholeTarget = repo.getAllAchievement();
		annualInputDate = repo.getYearlyInputDate();
		annualTarget = repo.getYearlyAchievement();
	}

	private Timestamp getDateInTS(Date d) {
		if (d == null) {
			return null;
		}
		return new Timestamp(d.getTime());
	}

	public Timestamp getWholeInputDateInTS() {
		return getDateInTS(wholeInputDate);
	}

	public Timestamp getWholeDueDateInTS() {
		return getDateInTS(wholeDueDate);
	}

	public Timestamp getAnnualInputDateInTS() {
		return getDateInTS(annualInputDate);
	}

	public Timestamp getAnnualDueDateInTS() {
		return getDateInTS(annualDueDate);
	}

	public Date getWholeInputDate() {
		return wholeInputDate;
	}

	public void setWholeInputDate(Date wholeInputDate) {
		this.wholeInputDate = wholeInputDate;
	}

	public String getWholeTarget() {
		return wholeTarget;
	}

	public void setWholeTarget(String wholeTarget) {
		this.wholeTarget = wholeTarget;
	}

	public Date getAnnualInputDate() {
		return annualInputDate;
	}

	public void setAnnualInputDate(Date annualInputDate) {
		this.annualInputDate = annualInputDate;
	}

	public String getAnnualTarget() {
		return annualTarget;
	}

	public void setAnnualTarget(String annualTarget) {
		this.annualTarget = annualTarget;
	}

	public Date getWholeDueDate() {
		return wholeDueDate;
	}

	public void setWholeDueDate(Date wholeDueDate) {
		this.wholeDueDate = wholeDueDate;
	}

	public Date getAnnualDueDate() {
		return annualDueDate;
	}

	public void setAnnualDueDate(Date annualDueDate) {
		this.annualDueDate = annualDueDate;
	}

}
