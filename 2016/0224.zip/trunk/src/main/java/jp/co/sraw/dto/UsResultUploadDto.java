package jp.co.sraw.dto;

import java.io.Serializable;
import java.sql.Timestamp;

public class UsResultUploadDto implements Serializable {

	private Timestamp insDate;

	public Timestamp getInsDate() {
		return this.insDate;
	}

	public void setInsDate(Timestamp insDate) {
		this.insDate = insDate;
	}

	private String title;

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	private String uploadName;

	public String getUploadName() {
		return this.uploadName;
	}

	public void setUploadName(String uploadName) {
		this.uploadName = uploadName;
	}

}