package jp.co.sraw.dto;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

public class KjThredContributionDto implements Serializable {

	private String thredKey;

	private int seqNo;

	private String thredName;

	private String userKey;

	private String memo;

	private String userName;

	private String affiliationName;

	private Timestamp updDate;

	private String updUserKey;

	private List<KjThredUploadDto> kjThredUploads;

	public String getThredKey() {
		return thredKey;
	}

	public void setThredKey(String thredKey) {
		this.thredKey = thredKey;
	}

	public int getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(int seqNo) {
		this.seqNo = seqNo;
	}

	public String getThredName() {
		return thredName;
	}

	public void setThredName(String thredName) {
		this.thredName = thredName;
	}

	public String getUserKey() {
		return userKey;
	}

	public void setUserKey(String userKey) {
		this.userKey = userKey;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getAffiliationName() {
		return affiliationName;
	}

	public void setAffiliationName(String affiliationName) {
		this.affiliationName = affiliationName;
	}

	public Timestamp getUpdDate() {
		return updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdUserKey() {
		return updUserKey;
	}

	public void setUpdUserKey(String updUserKey) {
		this.updUserKey = updUserKey;
	}

	public List<KjThredUploadDto> getKjThredUploads() {
		return kjThredUploads;
	}

	public void setKjThredUploads(List<KjThredUploadDto> kjThredUploads) {
		this.kjThredUploads = kjThredUploads;
	}
}
