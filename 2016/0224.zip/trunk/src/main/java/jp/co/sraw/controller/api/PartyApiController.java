/*
* ファイル名：MsPartyApiController.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/01/16   toishigawa  新規作成
*/
package jp.co.sraw.controller.api;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonController;
import jp.co.sraw.dto.PartyDto;
import jp.co.sraw.entity.MsPartyTbl;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.service.MsPartyServiceImpl;
import jp.co.sraw.util.StringUtil;

/**
* <B>MsPartyApiControllerクラス</B>
* <P>
* 組織APIのメソッドを提供する
*/
@RestController
@RequestMapping(CommonConst.PATH_API +"/party")
public class PartyApiController extends CommonController {
	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(PartyApiController.class);

	@Autowired
	private MsPartyServiceImpl msPartyServiceImpl;

	private static final String PARTY_KBN_LIST = "5,6"; // 組織区分 国立大学, 公私立大学

	@PostConstruct
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	/**
	 * 組織リストを取得(表示用)
	 *
	 * @param locale
	 * @return
	 */
	@RequestMapping({"/all"})
	protected List<PartyDto> msPartyAllList(Locale locale){

		logger.infoCode("I0001", "msPartyAllList"); // I0001=メソッド開始:{0}

		List<PartyDto> resultList = msPartyKbnList(null, locale);

		logger.infoCode("I0002", "msPartyAllList"); // I0002=メソッド終了:{0}
		return resultList;
	}

	/**
	 * 組織リストを取得(大学表示用)
	 *
	 * @param locale
	 * @return
	 */
	@RequestMapping({"/univ"})
	protected List<PartyDto> msPartyUnivList(Locale locale){

		logger.infoCode("I0001", "msPartyUnivList"); // I0001=メソッド開始:{0}

		List<PartyDto> resultList = msPartyKbnList(PARTY_KBN_LIST, locale);

		logger.infoCode("I0002", "msPartyUnivList"); // I0002=メソッド終了:{0}
		return resultList;
	}

	/**
	 * 組織区分の組織リストを取得(表示用)
	 *
	 * @param locale
	 * @return
	 */
	@RequestMapping("/kbn/{partyKbn}")
	protected List<PartyDto> msPartyKbnList(@PathVariable String partyKbn, Locale locale){

		logger.infoCode("I0001", "msPartyKbnList"); // I0001=メソッド開始:{0}

		List<String> kbnList = new ArrayList<String>();
		if (StringUtil.isNotNull(partyKbn)) {
			for (String s : partyKbn.split(",")) {
				if (StringUtil.isNotNull(s.trim())) {
					kbnList.add(s.trim());
				}
			}
		}
		String[] kbn = (String[])kbnList.toArray(new String[0]);
		List<MsPartyTbl> mList = msPartyServiceImpl.findAllByPartyKbn(kbn);
		List<PartyDto> resultList = new ArrayList<PartyDto>();
		for (MsPartyTbl m : mList) {
			String name = m.getPartyName();
			if (!CommonConst.DEFAULT_LOCALE.getLanguage().equals(locale.getLanguage())) {
				name = m.getPartyNameEn();
			}
			PartyDto dto = new PartyDto();
			dto.setCode(m.getPartyCode());
			dto.setName(name);
			dto.setKbn(m.getPartyKbn());
			dto.setDomain(m.getDomain());
			resultList.add(dto);
		}

		logger.infoCode("I0002", "msPartyKbnList"); // I0002=メソッド終了:{0}
		return resultList;
	}
}
