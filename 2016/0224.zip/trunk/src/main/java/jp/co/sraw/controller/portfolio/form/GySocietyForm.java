/*
* ファイル名：GySocietyForm.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.portfolio.form;

import org.hibernate.validator.constraints.NotBlank;

import org.maru.m4hv.extensions.constraints.CharLength;

import jp.co.sraw.entity.GyCommonTbl;
import jp.co.sraw.entity.GySocietyTbl;

/**
 * <B>GySocietyFormクラス</B>
 * <P>
 * Formのメソッドを提供する
 */
public class GySocietyForm extends GyHasTitleForm {

	public GySocietyForm() {
		super();
	}

	public String getSocietyLanguage() {
		return this.getLanguage();
	}

	public void setSocietyLanguage(String societyLanguage) {
		this.setLanguage(societyLanguage);
	}

	@Override
	public GyCommonTbl getNewTbl() {
		// TODO 自動生成されたメソッド・スタブ
		return new GySocietyTbl();
	}

}
