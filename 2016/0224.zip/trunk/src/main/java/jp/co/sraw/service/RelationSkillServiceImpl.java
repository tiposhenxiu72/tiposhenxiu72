/*
* ファイル名：RelateSubjectServiceImpl.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/01/05   etoh        新規作成
*/
package jp.co.sraw.service;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonService;
import jp.co.sraw.entity.EvEventRelSubjectTbl;
import jp.co.sraw.entity.EvEventRelSubjectTblPK;
import jp.co.sraw.entity.ItInternRelSubjectTbl;
import jp.co.sraw.entity.ItInternRelSubjectTblPK;
import jp.co.sraw.entity.NrLessonRelSubjectTbl;
import jp.co.sraw.entity.NrLessonRelSubjectTblPK;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.repository.EvEventRelSubjectTblRepository;
import jp.co.sraw.repository.ItInternRelSubjectTblRepository;
import jp.co.sraw.repository.NrLessonRelSubjectTblRepository;
import jp.co.sraw.util.DateUtil;
import jp.co.sraw.util.DbUtil;

/**
 * 養成科目紐付け関連のサービス
 * @author SRAW tsutsumi
 *
 */
@Service
public class RelationSkillServiceImpl extends CommonService {

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(RelationSkillServiceImpl.class);

	@Autowired
	private NrLessonRelSubjectTblRepository nrLessonRelSubjectTblRepository;
	@Autowired
	private ItInternRelSubjectTblRepository itInternRelSubjectTblRepository;
	@Autowired
	private EvEventRelSubjectTblRepository evEventRelSubjectTblRepository;

	// 定数区分/コード。
	private static final String JKBN_RKEY = "0044";
	private static final String JCODE_RKEY = "1";

	@Override
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	/**
	 * ルーブリックキーのデフォルト値を取得
	 * @param locale
	 * @return
	 */
	public String getDefaultRubricKey(Locale locale) {
		return DbUtil.getJosuName(JKBN_RKEY, JCODE_RKEY, locale);
	}

	// 各項目のひも付き情報を取得 ----------
	/**
	 * 紐付情報を取得する
	 * @param mode モード
	 * @param rkey ルーブリックキー
	 * @param key 項目ごとの検索キー
	 * @return
	 */
	public Map<String, String> searchRelationSkill (String mode, String key, Locale locale) {
		Map<String, String> skillMap = null;

		String rkey = getDefaultRubricKey(locale);
		return searchRelationSkill(mode, rkey, key);
	}

	/**
	 * 紐付情報を取得する
	 * @param mode モード
	 * @param rkey ルーブリックキー
	 * @param key 項目ごとの検索キー
	 * @return
	 */
	public Map<String, String> searchRelationSkill (String mode, String rkey, String key) {
		Map<String, String> skillMap = null;

		if (CommonConst.RELATION_KEY_NEW.equals(key)) {
			return new HashMap<String, String>();
		}

		// モードによって取得先が異なる
		if (CommonConst.RELATION_MODE_INTERN.equals(mode)) {
			skillMap = searchRelationSkillForIntern (rkey, key);
		} else if (CommonConst.RELATION_MODE_EVENT.equals(mode)) {
			skillMap = searchRelationSkillForEvent (rkey, key);
		} else if (CommonConst.RELATION_MODE_LESSON.equals(mode)) {
			skillMap = searchRelationSkillForLesson(rkey, key);
		}
		return skillMap;
	}

	public String searchRelationSkillStr (String mode, String key, Locale locale) {
		return convertSkill(searchRelationSkill(mode, key, locale));
	}

	public String searchRelationSkillStr (String mode, String rkey, String key) {
		return convertSkill(searchRelationSkill (mode, rkey, key));
	}

	// 各項目のひも付き情報を取得 ----------
	/**
	 * インターンシップの能力養成関連付け状態を取得
	 * @param rkey ルーブリックキー
	 * @param internKey インターンシップキー
	 * @return Map<能力コード, 関連レベル>
	 */
	private Map<String, String> searchRelationSkillForIntern (String rkey, String internKey) {
		Map<String, String> skillMap = new HashMap<>();

		// データ取得
		List<ItInternRelSubjectTbl> list = itInternRelSubjectTblRepository.findByIdRubricKeyAndIdInternshipKey(rkey, internKey);

		for (ItInternRelSubjectTbl item : list) {
			skillMap.put(item.getId().getSubjectCode(), item.getRelationLevel());
		}
		return skillMap;
	}

	/**
	 * イベントの能力養成関連付け状態を取得
	 * @param rkey ルーブリックキー
	 * @param internKey インターンシップキー
	 * @return Map<能力コード, 関連レベル>
	 */
	private Map<String, String> searchRelationSkillForEvent (String rkey, String eventKey) {
		Map<String, String> skillMap = new HashMap<>();

		// データ取得
		List<EvEventRelSubjectTbl> list = evEventRelSubjectTblRepository.findByIdRubricKeyAndIdEventKey(rkey, eventKey);

		for (EvEventRelSubjectTbl item : list) {
			skillMap.put(item.getId().getSubjectCode(), item.getRelationLevel());
		}
		return skillMap;
	}

	/**
	 * イベントの能力養成関連付け状態を取得
	 * @param rkey ルーブリックキー
	 * @param internKey インターンシップキー
	 * @return Map<能力コード, 関連レベル>
	 */
	private Map<String, String> searchRelationSkillForLesson (String rkey, String lessonKey) {
		Map<String, String> skillMap = new HashMap<>();

		// データ取得
		List<NrLessonRelSubjectTbl> list = nrLessonRelSubjectTblRepository.findByIdRubricKeyAndIdLessonKey(rkey, lessonKey);

		for (NrLessonRelSubjectTbl item : list) {
			skillMap.put(item.getId().getSubjectCode(), item.getRelationLevel());
		}
		return skillMap;
	}

	// JSON⇔Map変換 ----------
	/**
	 * JSON形式からMap形式に変換します。
	 * @param json
	 * @return Map型の紐付き状態
	 */
	public Map<String, String> convertSkill (String skillJson) {
		ObjectMapper mapper = new ObjectMapper();
		Map<String, String> skillMap = null;
		try {
			skillMap = mapper.readValue(skillJson, new TypeReference<Map<String, String>>(){});
		} catch (Exception e) {
			skillMap = new HashMap<String, String>();
		}
		return skillMap;
	}

	/**
	 * MAP形式からJson形式に変換します。
	 * @param json
	 * @return Map型の紐付き状態
	 */
	public String convertSkill (Map<String, String> skillMap) {
		ObjectMapper mapper = new ObjectMapper();
		String skillJson = null;
		try {
			skillJson = mapper.writeValueAsString(skillMap);
		} catch (Exception e) {
			skillJson = "{}";
		}
		return skillJson;
	}

	// チェック ----------
	/**
	 * 1つ以上の養成能力と紐付きが行われているかチェック
	 * @param skillMap
	 * @return true 紐付いている科目がある
	 */
	public boolean validateRelateSkill(String json) {
		return validateRelateSkill(convertSkill(json));
	}

	/**
	 * 1つ以上の養成能力と紐付きが行われているかチェック
	 * @param skillMap
	 * @return true 紐付いている科目がある
	 */
	public boolean validateRelateSkill(Map<String, String> skillMap) {
		if (skillMap == null || skillMap.size() == 0) {
			return false;
		}

		for (Map.Entry<String, String> item : skillMap.entrySet()) {
			if (CommonConst.RELATION_LEVEL_BEST.equals(item.getValue())
					|| CommonConst.RELATION_LEVEL_NORMAL.equals(item.getValue())) {
				return true;
			}
		}
		return false;
	}

	// ひも付けの登録
	/**
	 * ひも付け状態を登録する
	 * @param userKey ログインユーザキー
	 * @param mode モード
	 * @param key キー
	 * @param skillJson 紐付け状態(Json)
	 * @param locale
	 */
	public void save (String userKey, String mode, String key, String skillJson, Locale locale) {
		String rkey = getDefaultRubricKey(locale);
		save (userKey, mode, key, convertSkill(skillJson), rkey);
	}

	/**
	 * ひも付け状態を登録する
	 * @param userKey ログインユーザキー
	 * @param mode モード
	 * @param key キー
	 * @param skillMap 紐付け状態
	 * @param locale
	 */
	public void save (String userKey, String mode, String key, Map<String, String> skillMap, Locale locale) {
		String rkey = getDefaultRubricKey(locale);
		save (userKey, mode, key, skillMap, rkey);
	}

	// ひも付け状態を登録する
	public void save (String userKey, String mode, String key, String skillJson, String rkey) {
		save (userKey, mode, key, convertSkill(skillJson), rkey);
	}

	// ひも付け状態を登録する
	@Transactional
	public void save (String userKey, String mode, String key, Map<String, String> skillMap, String rkey) {
		// モードによって登録先が異なる
		if (CommonConst.RELATION_MODE_INTERN.equals(mode)) {
			saveForIntern(userKey, key, skillMap, rkey);
		} else if (CommonConst.RELATION_MODE_EVENT.equals(mode)) {
			saveForEvent(userKey, key, skillMap, rkey);
		} else if (CommonConst.RELATION_MODE_LESSON.equals(mode)) {
			saveForLesson(userKey, key, skillMap, rkey);
		}
	}

	/**
	 * インターンシップのひも付け状態を登録する
	 * @param userKey
	 * @param key
	 * @param skillMap
	 * @param rkey
	 */
	@Transactional
	private void saveForIntern (String userKey, String key, Map<String, String> skillMap, String rkey) {
		// 現在の状態をクリア
		List<ItInternRelSubjectTbl> list = itInternRelSubjectTblRepository.findByIdRubricKeyAndIdInternshipKey(rkey, key);
		itInternRelSubjectTblRepository.delete(list);

		if (skillMap == null) {
			return;
		}

		// 登録する内容
		for (Map.Entry<String, String> item : skillMap.entrySet()) {
			ItInternRelSubjectTbl entity = new ItInternRelSubjectTbl();
			entity.setId(new ItInternRelSubjectTblPK());
			entity.getId().setInternshipKey(key);
			entity.getId().setRubricKey(rkey);
			entity.getId().setSubjectCode(item.getKey());
			entity.setRelationLevel(item.getValue());
			entity.setUpdUserKey(userKey);
			entity.setUpdDate(DateUtil.getNowTimestamp());

			entity = itInternRelSubjectTblRepository.saveAndFlush(entity);
			if (entity == null) {
				throw new RuntimeException("failed to saveAndFlush().");
			}
		}
	}

	/**
	 * イベントのひも付け状態を登録する
	 * @param userKey
	 * @param key
	 * @param skillMap
	 * @param rkey
	 */
	@Transactional
	private void saveForEvent (String userKey, String key, Map<String, String> skillMap, String rkey) {
		// 現在の状態をクリア
		List<EvEventRelSubjectTbl> list = evEventRelSubjectTblRepository.findByIdRubricKeyAndIdEventKey(rkey, key);
		evEventRelSubjectTblRepository.delete(list);

		if (skillMap == null) {
			return;
		}

		// 登録する内容
		for (Map.Entry<String, String> item : skillMap.entrySet()) {
			EvEventRelSubjectTbl entity = new EvEventRelSubjectTbl();
			entity.setId(new EvEventRelSubjectTblPK());
			entity.getId().setEventKey(key);
			entity.getId().setRubricKey(rkey);
			entity.getId().setSubjectCode(item.getKey());
			entity.setRelationLevel(item.getValue());
			entity.setUpdUserKey(userKey);
			entity.setUpdDate(DateUtil.getNowTimestamp());

			entity = evEventRelSubjectTblRepository.saveAndFlush(entity);
			if (entity == null) {
				throw new RuntimeException("failed to saveAndFlush().");
			}
		}
	}


	/**
	 * 科目のひも付け状態を登録する
	 * @param userKey
	 * @param key
	 * @param skillMap
	 * @param rkey
	 */
	@Transactional
	private void saveForLesson (String userKey, String key, Map<String, String> skillMap, String rkey) {
		// 現在の状態をクリア
		List<NrLessonRelSubjectTbl> list = nrLessonRelSubjectTblRepository.findByIdRubricKeyAndIdLessonKey(rkey, key);
		nrLessonRelSubjectTblRepository.delete(list);

		if (skillMap == null) {
			return;
		}

		// 登録する内容
		for (Map.Entry<String, String> item : skillMap.entrySet()) {
			NrLessonRelSubjectTbl entity = new NrLessonRelSubjectTbl();
			entity.setId(new NrLessonRelSubjectTblPK());
			entity.getId().setLessonKey(key);
			entity.getId().setRubricKey(rkey);
			entity.getId().setSubjectCode(item.getKey());
			entity.setRelationLevel(item.getValue());
			entity.setUpdUserKey(userKey);
			entity.setUpdDate(DateUtil.getNowTimestamp());

			entity = nrLessonRelSubjectTblRepository.saveAndFlush(entity);
			if (entity == null) {
				throw new RuntimeException("failed to saveAndFlush().");
			}
		}
	}
}
