/*
* ファイル名：OthersForm.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.portfolio.form;

import java.sql.Timestamp;

import org.maru.m4hv.extensions.constraints.CharLength;

import jp.co.sraw.entity.GyCommonTbl;
import jp.co.sraw.entity.UsCompetitionTbl;

/**
 * <B>GyOthersFormクラス</B>
 * <P>
 * Formのメソッドを提供する
 */
public class CompetitionUploadForm extends GyUploadForm {

	public CompetitionUploadForm() {
		super();
	}

	private Timestamp insDate;

	private String insKbn;

	@CharLength(max = 2000)
	private String link;

	public Timestamp getInsDate() {
		return this.insDate;
	}

	public void setInsDate(Timestamp insDate) {
		this.insDate = insDate;
	}

	public String getInsKbn() {
		return this.insKbn;
	}

	public void setInsKbn(String insKbn) {
		this.insKbn = insKbn;
	}

	public String getLink() {
		return this.link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public boolean getUploadFileNotNull() {
		return this.insKbn.equals("1") ? true : false;
	}

	@Override
	public GyCommonTbl getNewTbl() {
		return new UsCompetitionTbl();
	}

}
