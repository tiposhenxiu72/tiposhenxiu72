/*
* ファイル名：IndexController.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonService;
import jp.co.sraw.dto.EmailDto;
import jp.co.sraw.entity.CmBatchTargetTbl;
import jp.co.sraw.entity.CmBatchTargetTblPK;
import jp.co.sraw.entity.CmInfoPublicTbl;
import jp.co.sraw.entity.CmInfoPublicTblPK;
import jp.co.sraw.entity.CmInfoTbl;
import jp.co.sraw.entity.CmSchedulePublicTbl;
import jp.co.sraw.entity.CmSchedulePublicTblPK;
import jp.co.sraw.entity.CmScheduleTbl;
import jp.co.sraw.entity.EvEventTbl;
import jp.co.sraw.entity.ItInternTbl;
import jp.co.sraw.entity.SpSupportTbl;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.mail.MailServiceImpl;
import jp.co.sraw.repository.CmBatchTargetTblRepository;
import jp.co.sraw.repository.CmInfoPublicTblRepository;
import jp.co.sraw.repository.CmInfoTblRepository;
import jp.co.sraw.repository.CmSchedulePublicTblRepository;
import jp.co.sraw.repository.CmScheduleTblRepository;
import jp.co.sraw.repository.EvEventTblRepository;
import jp.co.sraw.repository.ItInternTblRepository;
import jp.co.sraw.repository.SpSupportTblRepository;
import jp.co.sraw.util.DateUtil;

/**
 * <B>BatchTargetServiceクラス</B>
 * <P>
 */
@Scope("prototype")
@Service
@Transactional(readOnly = true)
public class BatchTargetService extends CommonService {

	@Override
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(BatchTargetService.class);

	@Autowired
	private ItInternTblRepository itInternTblRepository;

	@Autowired
	private SpSupportTblRepository spSupportTblRepository;

	@Autowired
	private EvEventTblRepository evEventTblRepository;

	@Autowired
	private CmBatchTargetTblRepository cmBatchTargetTblRepository;

	@Autowired
	private CmInfoTblRepository cmInfoTblRepository;

	@Autowired
	private CmInfoPublicTblRepository cmInfoPublicTblRepository;

	@Autowired
	private CmScheduleTblRepository cmScheduleTblRepository;

	@Autowired
	private CmSchedulePublicTblRepository cmSchedulePublicTblRepository;

	@Autowired
	private MailServiceImpl mailServiceImpl;

	@Autowired
	private EntityManager entityManager;

	// URL
	private static final String SUPPORT_URL = "/support/";
	private static final String EQUIPMENT_URL = "/equipment/";
	private static final String EVENT_URL = "/event/";
	private static final String INTERNSHIP_URL = "/internship/";
	private static final String INTERNSHIP_APPLICATION_URL = "/internship/application/";


	private static final String CMINFOTBL_IS_NULL = "CmInfoTbl is null.";
	private static final String CMINFOPUBLICTBL_IS_NULL = "CmInfoPublicTbl is null.";
	private static final String CMSCHEDULETBL_IS_NULL = "CmScheduleTbl is null.";
	private static final String CMSCHEDULEPUBLICTBL_IS_NULL = "CmSchedulePublicTbl is null.";
	private static final String CMBATCHTARGETTBL_IS_NULL = "CmBatchTargetTbl is null.";



	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * メール送信先ユーザー一覧取得
	 *
	 * @param mailSetting
	 * @return
	 */
	public List<EmailDto> findAllEmailUserList(String mailSetting) {
		logger.infoCode("I0001");

		String sqlName = "";
		if ("%03%".equals(mailSetting)) {
			sqlName = "UsUserTbl.nativeFindAllEmailBatchCase1";
		} else if ("%01%".equals(mailSetting) || "%02%".equals(mailSetting)) {
			sqlName = "UsUserTbl.nativeFindAllEmailBatchCase2";
		}

		Query query = entityManager.createNamedQuery(sqlName);
		query.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		query.setParameter("mailSetting", mailSetting);

		List<EmailDto> list = new ArrayList<>();
		 @SuppressWarnings({ "unchecked", "rawtypes" })
		List<Map> resultList = query.getResultList();

		for (int i = 0; i < resultList.size(); i++) {
			EmailDto dto = new EmailDto();
			dto = (EmailDto) objectUtil.setMapCopyValue(dto, resultList.get(i));
			list.add(dto);
		}

		logger.infoCode("I0002");
		return list;
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * 支援制度からのeメール送信
	 *
	 * @return
	 * @throws Exception
	 */
	@Transactional
	public boolean updateSupportBatchMail() throws Exception {
		logger.infoCode("I0001", "updateSupportBatchMail");

		String sqlName = "SpSupportTbl.nativeFindAllBatchSupportMail";
		String dateTime = DateUtil.getSysdate(messageSource.getMessage("format.ymd.date", null, CommonConst.DEFAULT_LOCALE));
		String mailSetting = "%03%";
		try {

			Query query = entityManager.createNamedQuery(sqlName);
			query.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			@SuppressWarnings({ "unchecked", "rawtypes" })
			List<Map> resultList = query.getResultList();
			// 送信済み
			Set<String> sendSupportSet = new HashSet<String>();

			// １－２．ユーザ情報の取得
			List<EmailDto> userList = findAllEmailUserList(mailSetting);

			// １－１．バッチ処理用抽出データ、支援制度からの情報抽出
			for (int i = 0; i < resultList.size(); i++) {
				@SuppressWarnings("rawtypes")
				Map obj = resultList.get(i);
				Timestamp makeDate = Timestamp.valueOf(getValue(obj.get("make_date")));
				String dataKbn = getValue(obj.get("data_kbn"));
				String refDataKey = getValue(obj.get("ref_data_key"));
				//String sendUserKey = getValue(obj.get("send_user_key"));
				//String sendRole = getValue(obj.get("send_role"));
				//String sendPartyCode = getValue(obj.get("send_party_code"));
				//String supportTitle = getValue(obj.get("support_title"));
				//Timestamp supportStartDate = Timestamp.valueOf(getValue(obj.get("support_start_date")));
				//String supportContent = getValue(obj.get("support_content"));

				// １－３－１．メールの編集
				String url = SUPPORT_URL.replaceFirst("/", "");
				String message = messageSource.getMessage("batch.mail.title.name.support", null, CommonConst.DEFAULT_LOCALE);
				String menuName = messageSource.getMessage("batch.mail.title.name.support", null, CommonConst.DEFAULT_LOCALE);
				// 設備機器
				if ("6".equals(dataKbn)) {
					url = EQUIPMENT_URL.replaceFirst("/", "");
					message = messageSource.getMessage("batch.mail.title.name.equipment", null, CommonConst.DEFAULT_LOCALE);
					menuName = messageSource.getMessage("batch.mail.title.name.equipment", null, CommonConst.DEFAULT_LOCALE);
				}
				for (EmailDto user : userList) {
					// メール送信済み
					if (sendSupportSet.contains(dataKbn +":"+ user.getUserKey())) {
						continue;
					} else {
						// １－３－２．メールを送信する
						if (mailServiceImpl.newsInformation(user.getUserFullName(), user.getPortalLoginId(), menuName, message, dateTime, url)) {
							sendSupportSet.add(dataKbn +":"+ user.getUserKey());
							if (logger.isDebugEnabled()) {
								logger.debugCode("I1010", CommonConst.USER_KEY_DUMMY, user.getPortalLoginId());
							}
						}
					}
				}

				// １－４．バッチ処理用抽出データの更新。
				CmBatchTargetTblPK batchTargetId = new CmBatchTargetTblPK();
				batchTargetId.setRefDataKey(refDataKey);
				batchTargetId.setMakeDate(makeDate);
				batchTargetId.setDataKbn(dataKbn);

				CmBatchTargetTbl batchTarget = cmBatchTargetTblRepository.findOne(batchTargetId);
				batchTarget.setMailMakeFlag("1"); // 固定 ステータス更新
				batchTarget.setUpdDate(DateUtil.getNowTimestamp());
				batchTarget.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
				CmBatchTargetTbl batchTargetResult = cmBatchTargetTblRepository.save(batchTarget);
				if (batchTargetResult == null) {
					throw new NullPointerException(CMBATCHTARGETTBL_IS_NULL);
				}
			}
			cmBatchTargetTblRepository.flush();

		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
			throw e;
		}

		logger.infoCode("I0002", "updateSupportBatchMail"); // I0002=メソッド終了:{0}
		return true;
	}

	/**
	 * イベントからのeメール送信
	 *
	 * @return
	 * @throws Exception
	 */
	@Transactional
	public boolean updateEventBatchMail() throws Exception {
		logger.infoCode("I0001", "updateEventBatchMail");

		String sqlName = "EvEventTbl.nativeFindAllBatchEventMail";
		String sqlNamePublic = "EvEventPublicTbl.nativeFindAllEventPublicBatch";
		String dateTime = DateUtil.getSysdate(messageSource.getMessage("format.ymd.date", null, CommonConst.DEFAULT_LOCALE));
		String mailSetting = "%01%";
		try {

			Query query = entityManager.createNamedQuery(sqlName);
			query.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			@SuppressWarnings({ "unchecked", "rawtypes" })
			List<Map> resultList = query.getResultList();
			// 送信済み
			Set<String> sendEventSet = new HashSet<String>();

			// ２－２．ユーザ情報の取得
			List<EmailDto> userList = findAllEmailUserList(mailSetting);

			// ２－１．バッチ処理用抽出データ、イベントからの情報抽出
			for (int i = 0; i < resultList.size(); i++) {
				@SuppressWarnings("rawtypes")
				Map obj = resultList.get(i);
				Timestamp makeDate = Timestamp.valueOf(getValue(obj.get("make_date")));
				String dataKbn = getValue(obj.get("data_kbn"));
				String refDataKey = getValue(obj.get("ref_data_key"));
				//String sendUserKey = getValue(obj.get("send_user_key"));
				String sendRole = getValue(obj.get("send_role"));
				//String sendPartyCode = getValue(obj.get("send_party_code"));
				//String supportTitle = getValue(obj.get("support_title"));
				//Timestamp supportStartDate = Timestamp.valueOf(getValue(obj.get("support_start_date")));
				//String supportContent = getValue(obj.get("support_content"));

				// ２－４－１．メールの編集
				String message = messageSource.getMessage("batch.mail.title.name.event", null, CommonConst.DEFAULT_LOCALE);
				String menuName = messageSource.getMessage("batch.mail.title.name.event", null, CommonConst.DEFAULT_LOCALE);

				// ２－３．イベント公開範囲の参照
				Query queryPublic = entityManager.createNamedQuery(sqlNamePublic);
				queryPublic.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
				queryPublic.setParameter("refDataKey", refDataKey);
				@SuppressWarnings({ "unchecked", "rawtypes" })
				List<Map> resultPublicList = queryPublic.getResultList();

				for (int j = 0; j < resultPublicList.size(); j++) {
					@SuppressWarnings({ "rawtypes" })
					Map objPublic = resultPublicList.get(j);
					//String eventKey = getValue(objPublic.get("event_key"));
					//int seqNo = Integer.valueOf(getValue(objPublic.get("seq_no")));
					String publicKbn = getValue(objPublic.get("public_kbn"));
					String role = getValue(objPublic.get("role"));
					String partyCode = getValue(objPublic.get("party_code"));

					for (EmailDto user : userList) {
						// メール送信済み
						if (sendEventSet.contains(dataKbn +":"+ user.getUserKey())) {
							continue;
						} else {
							boolean sendFlag = false;
							String url = EVENT_URL.replaceFirst("/", "");
							if ("1".equals(dataKbn)) {
								// データ区分＝1の場合
								// 公開区分が、1:ROLEの場合、ユーザ情報で取得したロールとイベント公開範囲で取得したロールが等しい。
								if ("1".equals(publicKbn) && user.getRole().equals(role)) {
									sendFlag = true;
								} else if ("2".equals(publicKbn) && user.getPartyCode().equals(partyCode)) {
									// 公開区分が、2:組織の場合、ユーザ情報で取得した組織コードとイベント公開範囲で取得した組織コードが等しい。
									sendFlag = true;
								}
							} else if ("11".equals(dataKbn) && user.getRole().equals(sendRole)) {
								// データ区分＝11の場合
								// 送信対象ロールが、設定されている場合、ユーザ情報で取得したロールが合致するユーザ
								url = CommonConst.PATH_MGMT.replaceFirst("/", "") +  EVENT_URL;
								sendFlag = true;
							}
							if (sendFlag) {
								// ２－４－２．メールを送信する
								if (mailServiceImpl.newsInformation(user.getUserFullName(), user.getPortalLoginId(), menuName, message, dateTime, url)) {
									sendEventSet.add(dataKbn +":"+ user.getUserKey());
									if (logger.isDebugEnabled()) {
										logger.debugCode("I1010", CommonConst.USER_KEY_DUMMY, user.getPortalLoginId());
									}
								}
							}
						}
					}
				}

				// ２－５．バッチ処理用抽出データの更新。
				CmBatchTargetTblPK batchTargetId = new CmBatchTargetTblPK();
				batchTargetId.setRefDataKey(refDataKey);
				batchTargetId.setMakeDate(makeDate);
				batchTargetId.setDataKbn(dataKbn);

				CmBatchTargetTbl batchTarget = cmBatchTargetTblRepository.findOne(batchTargetId);
				batchTarget.setMailMakeFlag("1"); // 固定 ステータス更新
				batchTarget.setUpdDate(DateUtil.getNowTimestamp());
				batchTarget.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
				CmBatchTargetTbl batchTargetResult = cmBatchTargetTblRepository.save(batchTarget);
				if (batchTargetResult == null) {
					throw new NullPointerException(CMBATCHTARGETTBL_IS_NULL);
				}
			}
			cmBatchTargetTblRepository.flush();

		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
			throw e;
		}

		logger.infoCode("I0002", "updateEventBatchMail"); // I0002=メソッド終了:{0}
		return true;
	}

	/**
	 * インターンシップからのeメール送信
	 *
	 * @return
	 * @throws Exception
	 */
	@Transactional
	public boolean updateInternshipBatchMail() throws Exception {
		logger.infoCode("I0001", "updateInternshipBatchMail");

		String sqlName = "ItInternTbl.nativeFindAllBatchInternshipMail";
		String sqlNamePublic = "ItInternPublicTbl.nativeFindAllInternshipPublicBatch";
		String dateTime = DateUtil.getSysdate(messageSource.getMessage("format.ymd.date", null, CommonConst.DEFAULT_LOCALE));
		String mailSetting = "%02%";
		try {

			Query query = entityManager.createNamedQuery(sqlName);
			query.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			@SuppressWarnings({ "unchecked", "rawtypes" })
			List<Map> resultList = query.getResultList();
			// 送信済み
			Set<String> sendInternshipSet = new HashSet<String>();

			// ３－２．ユーザ情報の取得
			List<EmailDto> userList = findAllEmailUserList(mailSetting);

			// ３－１．バッチ処理用抽出データ、インターンシップからの情報抽出
			for (int i = 0; i < resultList.size(); i++) {
				@SuppressWarnings("rawtypes")
				Map obj = resultList.get(i);
				Timestamp makeDate = Timestamp.valueOf(getValue(obj.get("make_date")));
				String dataKbn = getValue(obj.get("data_kbn"));
				String refDataKey = getValue(obj.get("ref_data_key"));
				String sendUserKey = getValue(obj.get("send_user_key"));
				String sendRole = getValue(obj.get("send_role"));
				String sendPartyCode = getValue(obj.get("send_party_code"));
				//String supportTitle = getValue(obj.get("support_title"));
				//Timestamp supportStartDate = Timestamp.valueOf(getValue(obj.get("support_start_date")));
				//String supportContent = getValue(obj.get("support_content"));

				// ３－４－１．メールの編集
				String message = messageSource.getMessage("batch.mail.title.name.internship", null, CommonConst.DEFAULT_LOCALE);
				String menuName = messageSource.getMessage("batch.mail.title.name.internship", null, CommonConst.DEFAULT_LOCALE);

				// ３－３．インターンシップ公開範囲の参照
				Query queryPublic = entityManager.createNamedQuery(sqlNamePublic);
				queryPublic.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
				queryPublic.setParameter("refDataKey", refDataKey);
				@SuppressWarnings({ "unchecked", "rawtypes" })
				List<Map> resultPublicList = queryPublic.getResultList();

				for (int j = 0; j < resultPublicList.size(); j++) {
					@SuppressWarnings({ "rawtypes" })
					Map objPublic = resultPublicList.get(j);
					//String internshipKey = getValue(objPublic.get("internship_key"));
					//int seqNo = Integer.valueOf(getValue(objPublic.get("seq_no")));
					String publicKbn = getValue(objPublic.get("public_kbn"));
					String role = getValue(objPublic.get("role"));
					String partyCode = getValue(objPublic.get("party_code"));

					for (EmailDto user : userList) {
						// メール送信済み
						if (sendInternshipSet.contains(dataKbn +":"+ user.getUserKey())) {
							continue;
						} else {
							boolean sendFlag = false;
							String url = INTERNSHIP_URL.replaceFirst("/", "");
							if ("2".equals(dataKbn)) {
								// データ区分＝2の場合
								// 公開区分が、1:ROLEの場合、ユーザ情報で取得したロールとイベント公開範囲で取得したロールが等しい。
								if ("1".equals(publicKbn) && user.getRole().equals(role)) {
									sendFlag = true;
								} else if ("2".equals(publicKbn) && user.getPartyCode().equals(partyCode)) {
									// 公開区分が、2:組織の場合、ユーザ情報で取得した組織コードとイベント公開範囲で取得した組織コードが等しい。
									sendFlag = true;
								}
							} else if ("21".equals(dataKbn) && user.getUserKey().equals(sendUserKey)) {
								// データ区分＝21の場合
								// 送信対象ユーザが、設定されている場合、ユーザ情報で取得したユーザキーが合致するユーザ
								url = CommonConst.PATH_MGMT.replaceFirst("/", "") +  INTERNSHIP_URL;
								sendFlag = true;
							} else if ("22".equals(dataKbn) && user.getRole().equals(sendRole) && user.getPartyCode().equals(sendPartyCode)) {
								// データ区分＝22の場合
								// 送信対象ロールと送信対象組織が、設定されている場合、ユーザ情報で取得したロールと組織コードが合致するユーザ
								url = CommonConst.PATH_MGMT.replaceFirst("/", "") +  INTERNSHIP_APPLICATION_URL;
								sendFlag = true;
							} else if ("23".equals(dataKbn) && user.getRole().equals(sendRole)) {
								// データ区分＝23の場合
								// 送信対象ロールが、設定されている場合、ユーザ情報で取得したロールが合致するユーザ
								url = INTERNSHIP_APPLICATION_URL.replaceFirst("/", "");
								sendFlag = true;
							}
							if (sendFlag) {
								// ３－４－２．メールを送信する
								if (mailServiceImpl.newsInformation(user.getUserFullName(), user.getPortalLoginId(), menuName, message, dateTime, url)) {
									sendInternshipSet.add(dataKbn +":"+ user.getUserKey());
									if (logger.isDebugEnabled()) {
										logger.debugCode("I1010", CommonConst.USER_KEY_DUMMY, user.getPortalLoginId());
									}
								}
							}
						}
					}
				}

				// ３－５．バッチ処理用抽出データの更新。
				CmBatchTargetTblPK batchTargetId = new CmBatchTargetTblPK();
				batchTargetId.setRefDataKey(refDataKey);
				batchTargetId.setMakeDate(makeDate);
				batchTargetId.setDataKbn(dataKbn);

				CmBatchTargetTbl batchTarget = cmBatchTargetTblRepository.findOne(batchTargetId);
				batchTarget.setMailMakeFlag("1"); // 固定 ステータス更新
				batchTarget.setUpdDate(DateUtil.getNowTimestamp());
				batchTarget.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
				CmBatchTargetTbl batchTargetResult = cmBatchTargetTblRepository.save(batchTarget);
				if (batchTargetResult == null) {
					throw new NullPointerException(CMBATCHTARGETTBL_IS_NULL);
				}
			}
			cmBatchTargetTblRepository.flush();

		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
			throw e;
		}

		logger.infoCode("I0002", "updateInternshipBatchMail"); // I0002=メソッド終了:{0}
		return true;
	}




	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * イベントからのスケジュール作成
	 *
	 * @return
	 * @throws Exception
	 */
	@Transactional
	public boolean updateEventBatchSchedule() throws Exception {

		logger.infoCode("I0001", "updateEventBatchSchedule");

		String sqlName = "EvEventTbl.nativeFindAllBatchEventSchedule";
		String sqlNamePublic = "EvEventPublicTbl.nativeFindAllEventPublicBatch";

		try {
			// ２－１．バッチ処理用抽出データ、イベントからの情報抽出
			Query query = entityManager.createNamedQuery(sqlName);
			query.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			@SuppressWarnings({ "unchecked", "rawtypes" })
			List<Map> resultList = query.getResultList();

			for (int i = 0; i < resultList.size(); i++) {
				@SuppressWarnings("rawtypes")
				Map obj = resultList.get(i);
				Timestamp makeDate = Timestamp.valueOf(getValue(obj.get("make_date")));
				String dataKbn = getValue(obj.get("data_kbn"));
				String refDataKey = getValue(obj.get("ref_data_key"));
				String eventTitle = getValue(obj.get("event_title"));
				//Timestamp eventSendDate = Timestamp.valueOf(getValue(obj.get("event_send_date")));
				Timestamp eventStartDate = Timestamp.valueOf(getValue(obj.get("event_start_date")));
				//String eventTelno = getValue(obj.get("event_telno"));
				//String eventPlace = getValue(obj.get("event_place"));
				//String partyName = getValue(obj.get("party_name"));
				//String eventMemo = getValue(obj.get("event_memo"));

				/////////////////////////////////////////////////////////////////////////////////////////
				// ２－２．スケジュールの取得
				// 取得条件：参照キー
				Specification<CmScheduleTbl> whereRefDataKey = new Specification<CmScheduleTbl>() {
							@Override
							public Predicate toPredicate(Root<CmScheduleTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
								return cb.equal(root.get("schduleRefKey"), refDataKey);
							}
						};
				// 取得条件：データ区分
				Specification<CmScheduleTbl> whereDataKbn = new Specification<CmScheduleTbl>() {
							@Override
							public Predicate toPredicate(Root<CmScheduleTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
								return cb.equal(root.get("dataKbn"), dataKbn);
							}
						};
				List<CmScheduleTbl> scheduleDeleteList = cmScheduleTblRepository.findAll(Specifications.where(whereRefDataKey).and(whereDataKbn));
				// ２－２－２．スケジュール公開範囲の削除
				for (CmScheduleTbl scheduleDelete : scheduleDeleteList) {
					cmSchedulePublicTblRepository.delete(scheduleDelete.getSuhduleKey());
				}
				// ２－２－１．スケジュールの削除
				cmScheduleTblRepository.delete(refDataKey, dataKbn);

				/////////////////////////////////////////////////////////////////////////////////////////
				// ２－３．イベント公開範囲の参照
				Query queryPublic = entityManager.createNamedQuery(sqlNamePublic);
				queryPublic.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
				queryPublic.setParameter("refDataKey", refDataKey);
				@SuppressWarnings({ "unchecked", "rawtypes" })
				List<Map> resultPublicList = queryPublic.getResultList();

				for (int j = 0; j < resultPublicList.size(); j++) {
					@SuppressWarnings({ "rawtypes" })
					Map objPublic = resultPublicList.get(j);
					//String eventKey = getValue(objPublic.get("event_key"));
					int seqNo = Integer.valueOf(getValue(objPublic.get("seq_no")));
					String publicKbn = getValue(objPublic.get("public_kbn"));
					String role = getValue(objPublic.get("role"));
					String partyCode = getValue(objPublic.get("party_code"));


					// ２－４－１．スケジュールの登録。
					// CmInfoTbl
					CmScheduleTbl schedule = new CmScheduleTbl();
					schedule.setSuhduleDate(DateUtil.formatTimestampStart(eventStartDate));
					schedule.setStartTime(null);
					schedule.setEndTime(null);
					schedule.setTitle(eventTitle);
					schedule.setDataKbn(dataKbn);
					schedule.setSchduleRefKey(refDataKey);
					schedule.setMakeUserKey(CommonConst.USER_KEY_DUMMY);
					schedule.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
					schedule.setUpdDate(DateUtil.getNowTimestamp());
					CmScheduleTbl scheduleResult = cmScheduleTblRepository.save(schedule);
					if (scheduleResult == null) {
						throw new NullPointerException(CMSCHEDULETBL_IS_NULL);
					}

					// ２－４－２．スケジュール公開範囲の登録。
					// CmSchedulePublicTbl
					CmSchedulePublicTbl schedulePublic = new CmSchedulePublicTbl();
					CmSchedulePublicTblPK schedulePublicId = new CmSchedulePublicTblPK();
					schedulePublicId.setSuhduleKey(schedule.getSuhduleKey());
					schedulePublicId.setSeqNo(seqNo);

					schedulePublic.setId(schedulePublicId);
					schedulePublic.setPublicKbn(publicKbn);
					schedulePublic.setRole(role);
					schedulePublic.setPartyCode(partyCode);

					schedulePublic.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
					schedulePublic.setUpdDate(DateUtil.getNowTimestamp());
					CmSchedulePublicTbl schedulePublicResult = cmSchedulePublicTblRepository.save(schedulePublic);
					if (schedulePublicResult == null) {
						throw new NullPointerException(CMSCHEDULEPUBLICTBL_IS_NULL);
					}

				}

				// ２－４－３．バッチ処理用抽出データの更新。
				CmBatchTargetTblPK batchTargetId = new CmBatchTargetTblPK();
				batchTargetId.setRefDataKey(refDataKey);
				batchTargetId.setMakeDate(makeDate);
				batchTargetId.setDataKbn(dataKbn);

				CmBatchTargetTbl batchTarget = cmBatchTargetTblRepository.findOne(batchTargetId);
				batchTarget.setScheduleMakeFlag("1"); // 固定 ステータス更新
				batchTarget.setUpdDate(DateUtil.getNowTimestamp());
				batchTarget.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
				CmBatchTargetTbl batchTargetResult = cmBatchTargetTblRepository.save(batchTarget);
				if (batchTargetResult == null) {
					throw new NullPointerException(CMBATCHTARGETTBL_IS_NULL);
				}
			}
			cmScheduleTblRepository.flush();
			cmSchedulePublicTblRepository.flush();
			cmBatchTargetTblRepository.flush();

		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
			throw e;
		}

		logger.infoCode("I0002", "updateEventBatchSchedule"); // I0002=メソッド終了:{0}
		return true;

	}

	/**
	 * インターンシップからのスケジュール作成
	 *
	 * @return
	 * @throws Exception
	 */
	@Transactional
	public boolean updateInternshipBatchSchedule() throws Exception {

		logger.infoCode("I0001", "updateInternshipBatchSchedule");

		String sqlName = "ItInternTbl.nativeFindAllBatchInternshipSchedule";
		String sqlNamePublic = "ItInternPublicTbl.nativeFindAllInternshipPublicBatch";

		try {
			// ３－１．バッチ処理用抽出データ、インターンシップからの情報抽出
			Query query = entityManager.createNamedQuery(sqlName);
			query.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			@SuppressWarnings({ "unchecked", "rawtypes" })
			List<Map> resultList = query.getResultList();

			for (int i = 0; i < resultList.size(); i++) {
				@SuppressWarnings("rawtypes")
				Map obj = resultList.get(i);
				Timestamp makeDate = Timestamp.valueOf(getValue(obj.get("make_date")));
				String dataKbn = getValue(obj.get("data_kbn"));
				String refDataKey = getValue(obj.get("ref_data_key"));
				String internshipTitle = getValue(obj.get("internship_title"));
				//Timestamp internshipSendDate = Timestamp.valueOf(getValue(obj.get("internship_send_date")));
				//String internshipPartyName = getValue(obj.get("internship_party_name"));
				//String internshipTelno = getValue(obj.get("internship_telno"));
				//String internshipRange = getValue(obj.get("internship_range"));
				Timestamp internshipStartDate = Timestamp.valueOf(getValue(obj.get("internship_start_date")));
				Timestamp internshipEndDate = Timestamp.valueOf(getValue(obj.get("internship_end_date")));
				//String internshipMemo = getValue(obj.get("internship_memo"));

				/////////////////////////////////////////////////////////////////////////////////////////
				// ３－２．.スケジュールの取得
				// 取得条件：参照キー
				Specification<CmScheduleTbl> whereRefDataKey = new Specification<CmScheduleTbl>() {
							@Override
							public Predicate toPredicate(Root<CmScheduleTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
								return cb.equal(root.get("schduleRefKey"), refDataKey);
							}
						};
				// 取得条件：データ区分
				Specification<CmScheduleTbl> whereDataKbn = new Specification<CmScheduleTbl>() {
							@Override
							public Predicate toPredicate(Root<CmScheduleTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
								return cb.equal(root.get("dataKbn"), dataKbn);
							}
						};
				List<CmScheduleTbl> scheduleDeleteList = cmScheduleTblRepository.findAll(Specifications.where(whereRefDataKey).and(whereDataKbn));
				// ３－２－２．スケジュール公開範囲の削除
				for (CmScheduleTbl scheduleDelete : scheduleDeleteList) {
					cmSchedulePublicTblRepository.delete(scheduleDelete.getSuhduleKey());
				}
				// ３－２－１．スケジュールの削除
				cmScheduleTblRepository.delete(refDataKey, dataKbn);

				/////////////////////////////////////////////////////////////////////////////////////////
				// ３－３．インターンシップ公開範囲の参照
				Query queryPublic = entityManager.createNamedQuery(sqlNamePublic);
				queryPublic.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
				queryPublic.setParameter("refDataKey", refDataKey);
				@SuppressWarnings({ "unchecked", "rawtypes" })
				List<Map> resultPublicList = queryPublic.getResultList();

				for (int j = 0; j < resultPublicList.size(); j++) {
					@SuppressWarnings({ "rawtypes" })
					Map objPublic = resultPublicList.get(j);
					//String internshipKey = getValue(objPublic.get("internship_key"));
					int seqNo = Integer.valueOf(getValue(objPublic.get("seq_no")));
					String publicKbn = getValue(objPublic.get("public_kbn"));
					String role = getValue(objPublic.get("role"));
					String partyCode = getValue(objPublic.get("party_code"));

					// ３－４－１．スケジュールの登録。
					// CmScheduleTbl
					// ＜応募期間（FROM用）＞
					CmScheduleTbl scheduleFrom = new CmScheduleTbl();
					scheduleFrom.setSuhduleDate(DateUtil.formatTimestampStart(internshipStartDate));
					scheduleFrom.setStartTime(null);
					scheduleFrom.setEndTime(null);
					scheduleFrom.setTitle(internshipTitle);
					scheduleFrom.setDataKbn(dataKbn);
					scheduleFrom.setSchduleRefKey(refDataKey);
					scheduleFrom.setMakeUserKey(CommonConst.USER_KEY_DUMMY);
					scheduleFrom.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
					scheduleFrom.setUpdDate(DateUtil.getNowTimestamp());

					// ＜応募期間（TO用）＞
					CmScheduleTbl scheduleTo = new CmScheduleTbl();
					scheduleTo.setSuhduleDate(DateUtil.formatTimestampStart(internshipEndDate));
					scheduleTo.setStartTime(null);
					scheduleTo.setEndTime(null);
					scheduleTo.setTitle(internshipTitle);
					scheduleTo.setDataKbn(dataKbn);
					scheduleTo.setSchduleRefKey(refDataKey);
					scheduleTo.setMakeUserKey(CommonConst.USER_KEY_DUMMY);
					scheduleTo.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
					scheduleTo.setUpdDate(DateUtil.getNowTimestamp());

					CmScheduleTbl scheduleFromResult = cmScheduleTblRepository.save(scheduleFrom);
					CmScheduleTbl scheduleToResult = cmScheduleTblRepository.save(scheduleTo);
					if (scheduleFromResult == null || scheduleToResult == null) {
						throw new NullPointerException(CMSCHEDULETBL_IS_NULL);
					}

					// ３－４－２．スケジュール公開範囲の登録。
					// ＜応募期間（FROM用）＞
					// CmSchedulePublicTbl
					CmSchedulePublicTbl scheduleFromPublic = new CmSchedulePublicTbl();
					CmSchedulePublicTblPK scheduleFromPublicId = new CmSchedulePublicTblPK();
					scheduleFromPublicId.setSuhduleKey(scheduleFromResult.getSuhduleKey());
					scheduleFromPublicId.setSeqNo(seqNo);
					scheduleFromPublic.setId(scheduleFromPublicId);
					scheduleFromPublic.setPublicKbn(publicKbn);
					scheduleFromPublic.setRole(role);
					scheduleFromPublic.setPartyCode(partyCode);
					scheduleFromPublic.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
					scheduleFromPublic.setUpdDate(DateUtil.getNowTimestamp());

					// ＜応募期間（TO用）＞
					CmSchedulePublicTbl scheduleToPublic = new CmSchedulePublicTbl();
					CmSchedulePublicTblPK scheduleToPublicId = new CmSchedulePublicTblPK();
					scheduleToPublicId.setSuhduleKey(scheduleToResult.getSuhduleKey());
					scheduleToPublicId.setSeqNo(seqNo);
					scheduleToPublic.setId(scheduleToPublicId);
					scheduleToPublic.setPublicKbn(publicKbn);
					scheduleToPublic.setRole(role);
					scheduleToPublic.setPartyCode(partyCode);
					scheduleToPublic.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
					scheduleToPublic.setUpdDate(DateUtil.getNowTimestamp());

					CmSchedulePublicTbl scheduleFromPublicResult = cmSchedulePublicTblRepository.save(scheduleFromPublic);
					CmSchedulePublicTbl scheduleToPublicResult = cmSchedulePublicTblRepository.save(scheduleToPublic);
					if (scheduleFromPublicResult == null || scheduleToPublicResult == null) {
						throw new NullPointerException(CMSCHEDULEPUBLICTBL_IS_NULL);
					}
				}

				// ３－４－３．バッチ処理用抽出データの更新。
				CmBatchTargetTblPK batchTargetId = new CmBatchTargetTblPK();
				batchTargetId.setRefDataKey(refDataKey);
				batchTargetId.setMakeDate(makeDate);
				batchTargetId.setDataKbn(dataKbn);

				CmBatchTargetTbl batchTarget = cmBatchTargetTblRepository.findOne(batchTargetId);
				batchTarget.setScheduleMakeFlag("1"); // 固定 ステータス更新
				batchTarget.setUpdDate(DateUtil.getNowTimestamp());
				batchTarget.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
				CmBatchTargetTbl batchTargetResult = cmBatchTargetTblRepository.save(batchTarget);
				if (batchTargetResult == null) {
					throw new NullPointerException(CMBATCHTARGETTBL_IS_NULL);
				}
			}
			cmScheduleTblRepository.flush();
			cmSchedulePublicTblRepository.flush();
			cmBatchTargetTblRepository.flush();

		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
			throw e;
		}

		logger.infoCode("I0002", "updateInternshipBatchSchedule"); // I0002=メソッド終了:{0}
		return true;

	}


	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// お知らせ情報作成
	/**
	 * 支援制度からのお知らせ情報作成
	 *
	 * @return
	 * @throws Exception
	 */
	@Transactional
	public boolean updateSupportBatchNewsInfo() throws Exception {
		logger.infoCode("I0001", "updateSupportBatchNewsInfo");

		String sqlName = "SpSupportTbl.nativeFindAllBatchSupportInfo";

		try {

			Query query = entityManager.createNamedQuery(sqlName);
			query.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			@SuppressWarnings({ "unchecked", "rawtypes" })
			List<Map> resultList = query.getResultList();

			// １－１．バッチ処理用抽出データ、支援制度からの情報抽出
			for (int i = 0; i < resultList.size(); i++) {
				@SuppressWarnings("rawtypes")
				Map obj = resultList.get(i);
				Timestamp makeDate = Timestamp.valueOf(getValue(obj.get("make_date")));
				String dataKbn = getValue(obj.get("data_kbn"));
				String refDataKey = getValue(obj.get("ref_data_key"));
				String supportTitle = getValue(obj.get("support_title"));
				Timestamp supportStartDate = Timestamp.valueOf(getValue(obj.get("support_start_date")));
				//String supportContent = getValue(obj.get("support_content"));

				String opeKbn = CommonConst.OP_ACTION_ADDED;
				String url = SUPPORT_URL;
				if ("6".equals(dataKbn)) {
					url = EQUIPMENT_URL;
				}

				// １－３－１．お知らせ情報の登録。
				// CmInfoTbl
				CmInfoTbl info = new CmInfoTbl();
				info.setSendDate(DateUtil.formatTimestampStart(supportStartDate));
				info.setTitle(supportTitle);
				info.setDataKbn(dataKbn);
				info.setOpeKbn(opeKbn);
				info.setInfoRefKey(refDataKey);
				info.setUrl(url);
				info.setMakeUserKey(CommonConst.USER_KEY_DUMMY);
				info.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
				info.setUpdDate(DateUtil.getNowTimestamp());
				CmInfoTbl infoResult = cmInfoTblRepository.save(info);
				if (infoResult == null) {
					throw new NullPointerException(CMINFOTBL_IS_NULL);
				}

				// １－３－２．お知らせ情報公開範囲の登録。
				// CmInfoPublicTbl
				CmInfoPublicTbl infoPublic = new CmInfoPublicTbl();
				CmInfoPublicTblPK infoPublicId = new CmInfoPublicTblPK();
				infoPublicId.setInfoKey(infoResult.getInfoKey());
				infoPublicId.setSeqNo(1); // 固定

				infoPublic.setId(infoPublicId);
				infoPublic.setPublicKbn("4"); // 固定
				infoPublic.setRole(null); // 固定
				infoPublic.setPartyCode(null); // 固定

				infoPublic.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
				infoPublic.setUpdDate(DateUtil.getNowTimestamp());
				CmInfoPublicTbl infoPublicResult = cmInfoPublicTblRepository.save(infoPublic);
				if (infoPublicResult == null) {
					throw new NullPointerException(CMINFOPUBLICTBL_IS_NULL);
				}

				// １－３－３．バッチ処理用抽出データの更新。
				CmBatchTargetTblPK batchTargetId = new CmBatchTargetTblPK();
				batchTargetId.setRefDataKey(refDataKey);
				batchTargetId.setMakeDate(makeDate);
				batchTargetId.setDataKbn(dataKbn);

				CmBatchTargetTbl batchTarget = cmBatchTargetTblRepository.findOne(batchTargetId);
				batchTarget.setInfoMakeFlag("1"); // 固定 ステータス更新
				batchTarget.setUpdDate(DateUtil.getNowTimestamp());
				batchTarget.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
				CmBatchTargetTbl batchTargetResult = cmBatchTargetTblRepository.save(batchTarget);
				if (batchTargetResult == null) {
					throw new NullPointerException(CMBATCHTARGETTBL_IS_NULL);
				}
			}

			cmInfoTblRepository.flush();
			cmInfoPublicTblRepository.flush();
			cmBatchTargetTblRepository.flush();

		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
			throw e;
		}

		logger.infoCode("I0002", "updateSupportBatchNewsInfo"); // I0002=メソッド終了:{0}
		return true;
	}

	/**
	 * イベントからのお知らせ情報作成
	 *
	 * @return
	 * @throws Exception
	 */
	@Transactional
	public boolean updateEventBatchNewsInfo() throws Exception {

		logger.infoCode("I0001", "updateEventBatchNewsInfo");

		String sqlName = "EvEventTbl.nativeFindAllBatchEventInfo";
		String sqlNamePublic = "EvEventPublicTbl.nativeFindAllEventPublicBatch";

		try {

			// ２－１．バッチ処理用抽出データ、イベントからの情報抽出
			Query query = entityManager.createNamedQuery(sqlName);
			query.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			@SuppressWarnings({ "unchecked", "rawtypes" })
			List<Map> resultList = query.getResultList();

			for (int i = 0; i < resultList.size(); i++) {
				@SuppressWarnings("rawtypes")
				Map obj = resultList.get(i);
				Timestamp makeDate = Timestamp.valueOf(getValue(obj.get("make_date")));
				String dataKbn = getValue(obj.get("data_kbn"));
				String refDataKey = getValue(obj.get("ref_data_key"));
				String eventTitle = getValue(obj.get("event_title"));
				Timestamp eventSendDate = Timestamp.valueOf(getValue(obj.get("event_send_date")));
				//Timestamp eventStartDate = Timestamp.valueOf(getValue(obj.get("event_start_date")));
				//String eventTelno = getValue(obj.get("event_telno"));
				//String eventPlace = getValue(obj.get("event_place"));
				//String partyName = getValue(obj.get("party_name"));
				//String eventMemo = getValue(obj.get("event_memo"));
				String opeKbn = CommonConst.OP_ACTION_ADDED;
				String url = EVENT_URL;

				// ２－３．イベント公開範囲の参照
				Query queryPublic = entityManager.createNamedQuery(sqlNamePublic);
				queryPublic.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
				queryPublic.setParameter("refDataKey", refDataKey);
				@SuppressWarnings({ "unchecked", "rawtypes" })
				List<Map> resultPublicList = queryPublic.getResultList();

				for (int j = 0; j < resultPublicList.size(); j++) {
					@SuppressWarnings({ "rawtypes" })
					Map objPublic = resultPublicList.get(j);
					//String eventKey = getValue(objPublic.get("event_key"));
					int seqNo = Integer.valueOf(getValue(objPublic.get("seq_no")));
					String publicKbn = getValue(objPublic.get("public_kbn"));
					String role = getValue(objPublic.get("role"));
					String partyCode = getValue(objPublic.get("party_code"));

					// ２－４－１．お知らせ情報の登録。
					// CmInfoTbl
					CmInfoTbl info = new CmInfoTbl();
					info.setSendDate(DateUtil.formatTimestampStart(eventSendDate));
					info.setTitle(eventTitle);
					info.setDataKbn(dataKbn);
					info.setOpeKbn(opeKbn);
					info.setInfoRefKey(refDataKey);
					info.setUrl(url);
					info.setMakeUserKey(CommonConst.USER_KEY_DUMMY);
					info.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
					info.setUpdDate(DateUtil.getNowTimestamp());
					CmInfoTbl infoResult = cmInfoTblRepository.save(info);
					if (infoResult == null) {
						throw new NullPointerException(CMINFOTBL_IS_NULL);
					}

					// ２－４－２．お知らせ情報公開範囲の登録。
					// CmInfoPublicTbl
					CmInfoPublicTbl infoPublic = new CmInfoPublicTbl();
					CmInfoPublicTblPK infoPublicId = new CmInfoPublicTblPK();
					infoPublicId.setInfoKey(infoResult.getInfoKey());

					infoPublicId.setSeqNo(seqNo);
					infoPublic.setId(infoPublicId);
					infoPublic.setPublicKbn(publicKbn);
					infoPublic.setRole(role);
					infoPublic.setPartyCode(partyCode);

					infoPublic.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
					infoPublic.setUpdDate(DateUtil.getNowTimestamp());
					CmInfoPublicTbl infoPublicResult = cmInfoPublicTblRepository.save(infoPublic);
					if (infoPublicResult == null) {
						throw new NullPointerException(CMINFOPUBLICTBL_IS_NULL);
					}
				}

				// ２－４－３．バッチ処理用抽出データの更新。
				CmBatchTargetTblPK batchTargetId = new CmBatchTargetTblPK();
				batchTargetId.setRefDataKey(refDataKey);
				batchTargetId.setMakeDate(makeDate);
				batchTargetId.setDataKbn(dataKbn);

				CmBatchTargetTbl batchTarget = cmBatchTargetTblRepository.findOne(batchTargetId);
				batchTarget.setInfoMakeFlag("1"); // 固定 ステータス更新
				batchTarget.setUpdDate(DateUtil.getNowTimestamp());
				batchTarget.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
				CmBatchTargetTbl batchTargetResult = cmBatchTargetTblRepository.save(batchTarget);
				if (batchTargetResult == null) {
					throw new NullPointerException(CMBATCHTARGETTBL_IS_NULL);
				}
			}
			cmInfoTblRepository.flush();
			cmInfoPublicTblRepository.flush();
			cmBatchTargetTblRepository.flush();

		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
			throw e;
		}

		logger.infoCode("I0002", "updateEventBatchNewsInfo"); // I0002=メソッド終了:{0}
		return true;
	}

	/**
	 * インターンシップからのお知らせ情報作成
	 *
	 * @return
	 * @throws Exception
	 */
	@Transactional
	public boolean updateInternshipBatchNewsInfo() throws Exception {
		logger.infoCode("I0001", "updateInternshipBatchNewsInfo");

		String sqlName = "ItInternTbl.nativeFindAllBatchInternshipInfo";
		String sqlNamePublic = "ItInternPublicTbl.nativeFindAllInternshipPublicBatch";

		try {

			// ３－１．バッチ処理用抽出データ、インターンシップからの情報抽出
			Query query = entityManager.createNamedQuery(sqlName);
			query.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			 @SuppressWarnings({ "unchecked", "rawtypes" })
			List<Map> resultList = query.getResultList();

			for (int i = 0; i < resultList.size(); i++) {
				@SuppressWarnings("rawtypes")
				Map obj = resultList.get(i);
				Timestamp makeDate = Timestamp.valueOf(getValue(obj.get("make_date")));
				String dataKbn = getValue(obj.get("data_kbn"));
				String refDataKey = getValue(obj.get("ref_data_key"));
				String internshipTitle = getValue(obj.get("internship_title"));
				Timestamp internshipSendDate = Timestamp.valueOf(getValue(obj.get("internship_send_date")));
				//String internshipPartyName = getValue(obj.get("internship_party_name"));
				//String internshipTelno = getValue(obj.get("internship_telno"));
				//String internshipRange = getValue(obj.get("internship_range"));
				//Timestamp internshipStartDate = Timestamp.valueOf(getValue(obj.get("internship_start_date")));
				//Timestamp internshipEndDate = Timestamp.valueOf(getValue(obj.get("internship_end_date")));
				//String internshipMemo = getValue(obj.get("internship_memo"));

				String opeKbn = CommonConst.OP_ACTION_END_ANNOUNCE;
				// 処理日付と配信日の日付が等しい場合
				if (DateUtil.formatTimestampStart(makeDate).equals(DateUtil.formatTimestampStart(internshipSendDate))) {
					opeKbn = CommonConst.OP_ACTION_ADDED;
				}

				// ３－３．インターンシップ公開範囲の参照
				Query queryPublic = entityManager.createNamedQuery(sqlNamePublic);
				queryPublic.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
				queryPublic.setParameter("refDataKey", refDataKey);
				@SuppressWarnings({ "unchecked", "rawtypes" })
				List<Map> resultPublicList = queryPublic.getResultList();

				for (int j = 0; j < resultPublicList.size(); j++) {
					@SuppressWarnings({ "rawtypes" })
					Map objPublic = resultPublicList.get(j);
					//String internshipKey = getValue(objPublic.get("internship_key"));
					int seqNo = Integer.valueOf(getValue(objPublic.get("seq_no")));
					String publicKbn = getValue(objPublic.get("public_kbn"));
					String role = getValue(objPublic.get("role"));
					String partyCode = getValue(objPublic.get("party_code"));
					String url = INTERNSHIP_URL;

					// ３－４－１．お知らせ情報の登録。
					// CmInfoTbl
					CmInfoTbl info = new CmInfoTbl();
					info.setSendDate(DateUtil.formatTimestampStart(internshipSendDate));
					info.setTitle(internshipTitle);
					info.setDataKbn(dataKbn);
					info.setOpeKbn(opeKbn);
					info.setInfoRefKey(refDataKey);
					info.setUrl(url);
					info.setMakeUserKey(CommonConst.USER_KEY_DUMMY);
					info.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
					info.setUpdDate(DateUtil.getNowTimestamp());
					CmInfoTbl infoResult = cmInfoTblRepository.save(info);
					if (infoResult == null) {
						throw new NullPointerException(CMINFOTBL_IS_NULL);
					}

					// ３－４－２．お知らせ情報公開範囲の登録。
					// CmInfoPublicTbl
					CmInfoPublicTbl infoPublic = new CmInfoPublicTbl();
					CmInfoPublicTblPK infoPublicId = new CmInfoPublicTblPK();
					infoPublicId.setInfoKey(infoResult.getInfoKey());

					infoPublicId.setSeqNo(seqNo);
					infoPublic.setId(infoPublicId);
					infoPublic.setPublicKbn(publicKbn);
					infoPublic.setRole(role);
					infoPublic.setPartyCode(partyCode);

					infoPublic.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
					infoPublic.setUpdDate(DateUtil.getNowTimestamp());
					CmInfoPublicTbl infoPublicResult = cmInfoPublicTblRepository.save(infoPublic);
					if (infoPublicResult == null) {
						throw new NullPointerException(CMINFOPUBLICTBL_IS_NULL);
					}
				}
				// ３－４－３．バッチ処理用抽出データの更新。
				CmBatchTargetTblPK batchTargetId = new CmBatchTargetTblPK();
				batchTargetId.setRefDataKey(refDataKey);
				batchTargetId.setMakeDate(makeDate);
				batchTargetId.setDataKbn(dataKbn);

				CmBatchTargetTbl batchTarget = cmBatchTargetTblRepository.findOne(batchTargetId);
				batchTarget.setInfoMakeFlag("1"); // 固定 ステータス更新
				batchTarget.setUpdDate(DateUtil.getNowTimestamp());
				batchTarget.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
				CmBatchTargetTbl batchTargetResult = cmBatchTargetTblRepository.save(batchTarget);
				if (batchTargetResult == null) {

					throw new NullPointerException(CMBATCHTARGETTBL_IS_NULL);
				}
			}

			cmInfoTblRepository.flush();
			cmInfoPublicTblRepository.flush();
			cmBatchTargetTblRepository.flush();

		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
			throw e;
		}

		logger.infoCode("I0002", "updateInternshipBatchNewsInfo"); // I0002=メソッド終了:{0}
		return true;
	}

	// バッチ処理用抽出データの編集
	/**
	 * 支援制度からの情報抽出
	 *
	 * @param targetDay
	 * @return
	 * @throws Exception
	 */
	@Transactional
	public boolean updateSupportBatchTarget(String targetDay) throws Exception {
		logger.infoCode("I0001", "updateSupportBatchTarget");

		Date targetDate = DateUtil.getDate(targetDay, "yyyyMMdd");

		// 取得条件：公開
		Specification<SpSupportTbl> wherePublicFlag = new Specification<SpSupportTbl>() {
					@Override
					public Predicate toPredicate(Root<SpSupportTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("publicFlag"), "1");
					}
				};
		// 取得条件：バッチステータス
		Specification<SpSupportTbl> whereBatchStatus = new Specification<SpSupportTbl>() {
					@Override
					public Predicate toPredicate(Root<SpSupportTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("batchStatus"), "0");
					}
				};
		// 取得条件：日付
		Specification<SpSupportTbl> whereTargetDay = new Specification<SpSupportTbl>() {
					@Override
					public Predicate toPredicate(Root<SpSupportTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("supportStartDate").as(Date.class), targetDate);
					}
				};

		List<SpSupportTbl> list = spSupportTblRepository.findAll(Specifications.where(wherePublicFlag).and(whereBatchStatus).and(whereTargetDay));

		if (list.size() == 0) {
			logger.infoCode("I0002", "updateSupportBatchTarget"); // I0002=メソッド終了:{0}
			return true;
		}
		try {
			List<CmBatchTargetTbl> entityList = new ArrayList<>();
			for (SpSupportTbl tbl : list) {
				CmBatchTargetTbl entity = new CmBatchTargetTbl();
				CmBatchTargetTblPK id = new CmBatchTargetTblPK();
				id.setMakeDate(DateUtil.getNowTimestamp());
				if ("1".equals(tbl.getSupportSpkikiKbn())) {
					id.setDataKbn("5");
				} else {
					id.setDataKbn("6");
				}
				id.setRefDataKey(tbl.getSupportKey());
				entity.setId(id);
				entity.setUpdUserKey(tbl.getUpdUserKey());
				entity.setInfoMakeFlag("0");
				entity.setScheduleMakeFlag("1");
				entity.setMailMakeFlag("0");
				entity.setSendUserKey(null);
				entity.setSendRole(null);
				entity.setSendPartyCode(null);
				entity.setUpdDate(DateUtil.getNowTimestamp());
				entity.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
				entityList.add(entity);

				//
				tbl.setBatchStatus("1"); // バッチステータス更新
			}
			entityList = cmBatchTargetTblRepository.save(entityList);
			list = spSupportTblRepository.save(list);
			if (entityList != null) {
				logger.infoCode("I0002", "updateSupportBatchTarget"); // I0002=メソッド終了:{0}
				return true;
			}
		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
			throw e;
		}
		logger.errorCode("E1013", "updateSupportBatchTarget"); // E1013=エラーとなりました。{0}
		return false;
	}

	/**
	 * イベントからの情報抽出
	 *
	 * @param targetDay
	 * @return
	 * @throws Exception
	 */
	@Transactional
	public boolean updateEventBatchTarget(String targetDay) throws Exception {
		logger.infoCode("I0001", "updateEventBatchTarget");

		Date targetDate = DateUtil.getDate(targetDay, "yyyyMMdd");

		// 取得条件：公開
		Specification<EvEventTbl> wherePublicFlag = new Specification<EvEventTbl>() {
					@Override
					public Predicate toPredicate(Root<EvEventTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("publicFlag"), "1");
					}
				};
		// 取得条件：バッチステータス
		Specification<EvEventTbl> whereBatchStatus = new Specification<EvEventTbl>() {
					@Override
					public Predicate toPredicate(Root<EvEventTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("batchStatus"), "0");
					}
				};
		// 取得条件：日付
		Specification<EvEventTbl> whereTargetDay = new Specification<EvEventTbl>() {
					@Override
					public Predicate toPredicate(Root<EvEventTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("eventSendDate").as(Date.class), targetDate);
					}
				};

		List<EvEventTbl> list = evEventTblRepository.findAll(Specifications.where(wherePublicFlag).and(whereBatchStatus).and(whereTargetDay));

		if (list.size() == 0) {
			logger.infoCode("I0002", "updateEventBatchTarget"); // I0002=メソッド終了:{0}
			return true;
		}
		try {
			List<CmBatchTargetTbl> entityList = new ArrayList<>();
			for (EvEventTbl tbl : list) {
				CmBatchTargetTbl entity = new CmBatchTargetTbl();
				CmBatchTargetTblPK id = new CmBatchTargetTblPK();
				id.setMakeDate(DateUtil.getNowTimestamp());
				id.setDataKbn("1");
				id.setRefDataKey(tbl.getEventKey());
				entity.setId(id);
				entity.setUpdUserKey(tbl.getUpdUserKey());
				entity.setInfoMakeFlag("0");
				entity.setScheduleMakeFlag("0");
				entity.setMailMakeFlag("0");
				entity.setSendUserKey(null);
				entity.setSendRole(null);
				entity.setSendPartyCode(null);
				entity.setUpdDate(DateUtil.getNowTimestamp());
				entity.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
				entityList.add(entity);

				//
				tbl.setBatchStatus("1"); // バッチステータス更新
			}
			entityList = cmBatchTargetTblRepository.save(entityList);
			list = evEventTblRepository.save(list);
			if (entityList != null) {
				logger.infoCode("I0002", "updateEventBatchTarget"); // I0002=メソッド終了:{0}
				return true;
			}
		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
			throw e;
		}
		logger.errorCode("E1013", "updateEventBatchTarget"); // E1013=エラーとなりました。{0}
		return false;
	}

	/**
	 * インターンシップからの情報抽出
	 *
	 * @param targetDay
	 * @param adjustment
	 * @return
	 * @throws Exception
	 */
	@Transactional
	public boolean updateInternshipBatchTarget(String targetDay, int adjustment) throws Exception {
		logger.infoCode("I0001", "updateInternshipBatchTarget");

		Date targetDate = DateUtil.getDate(targetDay, "yyyyMMdd");
		Date adjustmentDate = DateUtil.getDate(DateUtil.addDay(targetDay, -(adjustment)), "yyyyMMdd");

		// 取得条件：公開
		Specification<ItInternTbl> wherePublicFlag = new Specification<ItInternTbl>() {
					@Override
					public Predicate toPredicate(Root<ItInternTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("publicFlag"), "1");
					}
				};
		// 取得条件：バッチステータス
		Specification<ItInternTbl> whereBatchStatus = new Specification<ItInternTbl>() {
					@Override
					public Predicate toPredicate(Root<ItInternTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("batchStatus"), "0");
					}
				};
		// 取得条件：日付
		Specification<ItInternTbl> whereTargetDay = new Specification<ItInternTbl>() {
					@Override
					public Predicate toPredicate(Root<ItInternTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						Predicate predicate = cb.disjunction();
						predicate = cb.or(predicate, cb.equal(root.get("internshipStartDate").as(Date.class), targetDate));
						predicate = cb.or(predicate, cb.equal(root.get("internshipEndDate").as(Date.class), adjustmentDate));
						return predicate;
					}
				};

		List<ItInternTbl> list = itInternTblRepository.findAll(Specifications.where(wherePublicFlag).and(whereBatchStatus).and(whereTargetDay));

		if (list.size() == 0) {
			logger.infoCode("I0002", "updateInternshipBatchTarget"); // I0002=メソッド終了:{0}
			return true;
		}
		try {
			List<CmBatchTargetTbl> entityList = new ArrayList<>();
			for (ItInternTbl tbl : list) {
				CmBatchTargetTbl entity = new CmBatchTargetTbl();
				CmBatchTargetTblPK id = new CmBatchTargetTblPK();
				id.setMakeDate(DateUtil.getNowTimestamp());
				id.setDataKbn("2");
				id.setRefDataKey(tbl.getInternshipKey());
				entity.setId(id);
				entity.setUpdUserKey(tbl.getUpdUserKey());
				entity.setInfoMakeFlag("0");
				entity.setScheduleMakeFlag("0");
				entity.setMailMakeFlag("0");
				entity.setSendUserKey(null);
				entity.setSendRole(null);
				entity.setSendPartyCode(null);
				entity.setUpdDate(DateUtil.getNowTimestamp());
				entity.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
				entityList.add(entity);

				//
				tbl.setBatchStatus("1"); // バッチステータス更新
			}
			entityList = cmBatchTargetTblRepository.save(entityList);
			list = itInternTblRepository.save(list);
			if (entityList != null) {
				logger.infoCode("I0002", "updateInternshipBatchTarget"); // I0002=メソッド終了:{0}
				return true;
			}
		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
			throw e;
		}

		logger.errorCode("E1013", "updateInternshipBatchTarget"); // E1013=エラーとなりました。{0}
		return false;
	}


	/**
	 * Null判定して文字列を返す
	 *
	 * @param str
	 * @return
	 */
	private String getValue(Object str) {
		return str == null ? null : String.valueOf(str);
	}

}
