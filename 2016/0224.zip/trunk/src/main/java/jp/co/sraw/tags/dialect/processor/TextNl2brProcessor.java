/*
* ファイル名：TextNl2brProcessor2.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/02/04   toishigawa  新規作成
*/
package jp.co.sraw.tags.dialect.processor;

import org.thymeleaf.Arguments;
import org.thymeleaf.Configuration;
import org.thymeleaf.dom.Element;
import org.thymeleaf.processor.attr.AbstractUnescapedTextChildModifierAttrProcessor;
import org.thymeleaf.standard.expression.IStandardExpression;
import org.thymeleaf.standard.expression.IStandardExpressionParser;
import org.thymeleaf.standard.expression.StandardExpressions;
import org.unbescape.html.HtmlEscape;

import jp.co.sraw.util.StringUtil;

/**
* <B>TextNl2brProcessor2クラス</B>
* <P>
* Textの改行から<br/>変換を提供する
*/
public class TextNl2brProcessor extends AbstractUnescapedTextChildModifierAttrProcessor {

	public static final int ATTR_PRECEDENCE = 1350;
	public static final String ATTR_NAME = "textNl2br";

	public TextNl2brProcessor() {
		super(ATTR_NAME);
	}

	protected TextNl2brProcessor(String attributeName) {
		super(attributeName);
	}

	@Override
	public int getPrecedence() {
		return ATTR_PRECEDENCE;
	}

	@Override
	public String getText(Arguments arguments, Element element, String attributeName) {
		final String attributeValue = element.getAttributeValue(attributeName);

		final Configuration configuration = arguments.getConfiguration();
		final IStandardExpressionParser expressionParser = StandardExpressions.getExpressionParser(configuration);

		final IStandardExpression expression = expressionParser.parseExpression(configuration, arguments,
				attributeValue);

		final Object result = expression.execute(configuration, arguments);

		String t = result == null ? "" : result.toString();
		// 内容をエスケープしてから改行を<br/>変換
		return StringUtil.nl2br(HtmlEscape.escapeHtml4Xml(t));
	}
}
