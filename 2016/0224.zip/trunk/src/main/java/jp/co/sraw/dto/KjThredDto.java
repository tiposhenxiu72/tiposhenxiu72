package jp.co.sraw.dto;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

public class KjThredDto implements Serializable {

	private String thredKey;

	private String thredName;

	private String insUserKey;

	private String insUserName;

	private String insUserNameEn;

	private Timestamp updDate;

	private String updUserKey;

	private String boardGroupKey;

	private String boardName;

	private String adminUserKey;

	private Timestamp contributionUpdDate;

	private int thredCount;

	private int readCount;

	private int unReadCount;

	private int contributionCount;

	private String commonFlag;

	private List<KjThredContributionDto> kjThredContributions;

	private List<KjThredReadDto> kjThredReads;

	public KjThredDto() {
		super();
	}

	public KjThredDto(String boardGroupKey, String boardName, String thredKey, String thredName,
			String insUserName, String insUserNameEn, Timestamp updDate, int contributionCount, int readCount, int thredCount, int unReadCount ) {
		super();
		setBoardGroupKey(boardGroupKey);
		setBoardName(boardName);
		setThredKey(thredKey);
		setThredName(thredName);
		setInsUserName(insUserName);
		setInsUserNameEn(insUserNameEn);
		setUpdDate(updDate);
		setContributionCount(contributionCount);
		setReadCount(readCount);
		setThredCount(thredCount);
		setUnReadCount(unReadCount);
	}

	public String getThredKey() {
		return thredKey;
	}

	public void setThredKey(String thredKey) {
		this.thredKey = thredKey;
	}

	public String getThredName() {
		return thredName;
	}

	public void setThredName(String thredName) {
		this.thredName = thredName;
	}

	public String getInsUserKey() {
		return insUserKey;
	}

	public void setInsUserKey(String insUserKey) {
		this.insUserKey = insUserKey;
	}

	public String getInsUserName() {
		return insUserName;
	}

	public void setInsUserName(String insUserName) {
		this.insUserName = insUserName;
	}

	public String getInsUserNameEn() {
		return insUserNameEn;
	}

	public void setInsUserNameEn(String insUserNameEn) {
		this.insUserNameEn = insUserNameEn;
	}

	public Timestamp getUpdDate() {
		return updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdUserKey() {
		return updUserKey;
	}

	public void setUpdUserKey(String updUserKey) {
		this.updUserKey = updUserKey;
	}

	public String getBoardGroupKey() {
		return boardGroupKey;
	}

	public void setBoardGroupKey(String boardGroupKey) {
		this.boardGroupKey = boardGroupKey;
	}

	public String getBoardName() {
		return boardName;
	}

	public void setBoardName(String boardName) {
		this.boardName = boardName;
	}

	public String getAdminUserKey() {
		return adminUserKey;
	}

	public void setAdminUserKey(String adminUserKey) {
		this.adminUserKey = adminUserKey;
	}

	public Timestamp getContributionUpdDate() {
		return contributionUpdDate;
	}

	public void setContributionUpdDate(Timestamp contributionUpdDate) {
		this.contributionUpdDate = contributionUpdDate;
	}

	public int getThredCount() {
		return thredCount;
	}

	public void setThredCount(int thredCount) {
		this.thredCount = thredCount;
	}

	public int getReadCount() {
		return readCount;
	}

	public void setReadCount(int readCount) {
		this.readCount = readCount;
	}

	public int getUnReadCount() {
		return unReadCount;
	}

	public void setUnReadCount(int unReadCount) {
		this.unReadCount = unReadCount;
	}

	public int getContributionCount() {
		return contributionCount;
	}

	public void setContributionCount(int contributionCount) {
		this.contributionCount = contributionCount;
	}

	public String getCommonFlag() {
		return commonFlag;
	}

	public void setCommonFlag(String commonFlag) {
		this.commonFlag = commonFlag;
	}

	public List<KjThredContributionDto> getKjThredContributions() {
		return kjThredContributions;
	}

	public void setKjThredContributions(List<KjThredContributionDto> kjThredContributions) {
		this.kjThredContributions = kjThredContributions;
	}

	public List<KjThredReadDto> getKjThredReads() {
		return kjThredReads;
	}

	public void setKjThredReads(List<KjThredReadDto> kjThredReads) {
		this.kjThredReads = kjThredReads;
	}



}
