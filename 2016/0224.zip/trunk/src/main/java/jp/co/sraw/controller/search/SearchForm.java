/*
* ファイル名：SupportForm.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.search;

import org.maru.m4hv.extensions.constraints.CharLength;

import jp.co.sraw.common.CommonForm;

/**
 * <B>SupportFormクラス</B>
 * <P>
 * Formのメソッドを提供する
 */
public class SearchForm extends CommonForm {

	// 検索済み判定
	private String searched; // 検索済み:1

	// 表示用(ポートフォリオ表示共有のため)
	private String baseInfoFlag;

	// 検索条件
	@CharLength(max = 1000)
	private String searchKeyword;             // 検索条件：キーワード

	private String searchPartyCode;           // 検索条件：所属機関
	private String searchResearchAreaField;   // 検索条件：研究分野（大分類）
	private String searchResearchAreaSubject; // 検索条件：研究分野（中分類）
	private String searchResearchAreaCode;    // 検索条件：研究分野（小分類）

	private String userKey;

	/**
	 * @return searchKeyword
	 */
	public String getSearchKeyword() {
		return searchKeyword;
	}

	/**
	 * @param searchKeyword セットする searchKeyword
	 */
	public void setSearchKeyword(String searchKeyword) {
		this.searchKeyword = searchKeyword;
	}

	/**
	 * @return searchPartyCode
	 */
	public String getSearchPartyCode() {
		return searchPartyCode;
	}

	/**
	 * @param searchPartyCode セットする searchPartyCode
	 */
	public void setSearchPartyCode(String searchPartyCode) {
		this.searchPartyCode = searchPartyCode;
	}

	/**
	 * @return searchResearchAreaField
	 */
	public String getSearchResearchAreaField() {
		return searchResearchAreaField;
	}

	/**
	 * @param searchResearchAreaField セットする searchResearchAreaField
	 */
	public void setSearchResearchAreaField(String searchResearchAreaField) {
		this.searchResearchAreaField = searchResearchAreaField;
	}

	/**
	 * @return searchResearchAreaSubject
	 */
	public String getSearchResearchAreaSubject() {
		return searchResearchAreaSubject;
	}

	/**
	 * @param searchResearchAreaSubject セットする searchResearchAreaSubject
	 */
	public void setSearchResearchAreaSubject(String searchResearchAreaSubject) {
		this.searchResearchAreaSubject = searchResearchAreaSubject;
	}

	/**
	 * @return searchResearchAreaCode
	 */
	public String getSearchResearchAreaCode() {
		return searchResearchAreaCode;
	}

	/**
	 * @param searchResearchAreaCode セットする searchResearchAreaCode
	 */
	public void setSearchResearchAreaCode(String searchResearchAreaCode) {
		this.searchResearchAreaCode = searchResearchAreaCode;
	}

	/**
	 * @return userKey
	 */
	public String getUserKey() {
		return userKey;
	}

	/**
	 * @param userKey セットする userKey
	 */
	public void setUserKey(String userKey) {
		this.userKey = userKey;
	}

	/**
	 * @return searched
	 */
	public String getSearched() {
		return searched;
	}

	/**
	 * @param searched セットする searched
	 */
	public void setSearched(String searched) {
		this.searched = searched;
	}

	/**
	 * @return baseInfoFlag
	 */
	public String getBaseInfoFlag() {
		return baseInfoFlag;
	}

	/**
	 * @param baseInfoFlag セットする baseInfoFlag
	 */
	public void setBaseInfoFlag(String baseInfoFlag) {
		this.baseInfoFlag = baseInfoFlag;
	}
}
