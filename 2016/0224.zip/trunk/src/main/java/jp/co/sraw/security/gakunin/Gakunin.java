
package jp.co.sraw.security.gakunin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
* <B>Gakuninクラス</B>
* <P>
* Gakuninのメソッドを提供する
* json用のクラス生成: http://www.jsonschema2pojo.org/
*
*/
@JsonInclude(JsonInclude.Include.NON_NULL)
//@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
    "entityID",
    "DisplayNames",
    "SAML1SSOurl",
    "InformationURLs",
    "Keywords",
    "PrivacyStatementURLs",
    "Logos"
})
@JsonIgnoreProperties(ignoreUnknown=true)
public class Gakunin {

    @JsonProperty("entityID")
    private String entityID;
    @JsonProperty("DisplayNames")
    private List<DisplayName> DisplayNames = new ArrayList<DisplayName>();
    @JsonProperty("SAML1SSOurl")
    private String SAML1SSOurl;
    @JsonProperty("InformationURLs")
    private List<InformationURL> InformationURLs = new ArrayList<InformationURL>();
    @JsonProperty("Keywords")
    private List<Keyword> Keywords = new ArrayList<Keyword>();
    @JsonProperty("PrivacyStatementURLs")
    private List<PrivacyStatementURL> PrivacyStatementURLs = new ArrayList<PrivacyStatementURL>();
    @JsonProperty("Logos")
    private List<Logo> Logos = new ArrayList<Logo>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     *
     * @return
     *     The entityID
     */
    @JsonProperty("entityID")
    public String getEntityID() {
        return entityID;
    }

    /**
     *
     * @param entityID
     *     The entityID
     */
    @JsonProperty("entityID")
    public void setEntityID(String entityID) {
        this.entityID = entityID;
    }

    /**
    *
    * @return
    *     The SAML1SSOurl
    */
   @JsonProperty("SAML1SSOurl")
   public String getSAML1SSOurl() {
       return SAML1SSOurl;
   }

   /**
    *
    * @param SAML1SSOurl
    *     The SAML1SSOurl
    */
   @JsonProperty("SAML1SSOurl")
   public void setSAML1SSOurl(String SAML1SSOurl) {
       this.SAML1SSOurl = SAML1SSOurl;
   }

    /**
     *
     * @return
     *     The DisplayNames
     */
    @JsonProperty("DisplayNames")
    public List<DisplayName> getDisplayNames() {
        return DisplayNames;
    }

    /**
     *
     * @param DisplayNames
     *     The DisplayNames
     */
    @JsonProperty("DisplayNames")
    public void setDisplayNames(List<DisplayName> DisplayNames) {
        this.DisplayNames = DisplayNames;
    }

    /**
     *
     * @return
     *     The InformationURLs
     */
    @JsonProperty("InformationURLs")
    public List<InformationURL> getInformationURLs() {
        return InformationURLs;
    }

    /**
     *
     * @param InformationURLs
     *     The InformationURLs
     */
    @JsonProperty("InformationURLs")
    public void setInformationURLs(List<InformationURL> InformationURLs) {
        this.InformationURLs = InformationURLs;
    }

    /**
     *
     * @return
     *     The Keywords
     */
    @JsonProperty("Keywords")
    public List<Keyword> getKeywords() {
        return Keywords;
    }

    /**
     *
     * @param Keywords
     *     The Keywords
     */
    @JsonProperty("Keywords")
    public void setKeywords(List<Keyword> Keywords) {
        this.Keywords = Keywords;
    }

    /**
     *
     * @return
     *     The PrivacyStatementURLs
     */
    @JsonProperty("PrivacyStatementURLs")
    public List<PrivacyStatementURL> getPrivacyStatementURLs() {
        return PrivacyStatementURLs;
    }

    /**
     *
     * @param PrivacyStatementURLs
     *     The PrivacyStatementURLs
     */
    @JsonProperty("PrivacyStatementURLs")
    public void setPrivacyStatementURLs(List<PrivacyStatementURL> PrivacyStatementURLs) {
        this.PrivacyStatementURLs = PrivacyStatementURLs;
    }

    /**
     *
     * @return
     *     The Logos
     */
    @JsonProperty("Logos")
    public List<Logo> getLogos() {
        return Logos;
    }

    /**
     *
     * @param Logos
     *     The Logos
     */
    @JsonProperty("Logos")
    public void setLogos(List<Logo> Logos) {
        this.Logos = Logos;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
