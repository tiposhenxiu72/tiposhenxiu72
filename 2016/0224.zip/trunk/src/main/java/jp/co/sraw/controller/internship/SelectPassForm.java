/*
* ファイル名：SelectPassForm.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.internship;

import org.hibernate.validator.constraints.NotBlank;

import jp.co.sraw.common.CommonForm;

/**
 * <B>SelectPassFormクラス</B>
 * <P>
 * Formのメソッドを提供する
 */
public class SelectPassForm extends CommonForm {

	@NotBlank
	private String internshipKey;

	private String description;

	@NotBlank
	public String passUser;

	public String getPassUser() {
		return passUser;
	}

	public void setPassUser(String passUser) {
		this.passUser = passUser;
	}

	public String getInternshipKey() {
		return internshipKey;
	}

	public void setInternshipKey(String internshipKey) {
		this.internshipKey = internshipKey;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String[] getPassUserArray() {
		String[] array = new String[] {};
		if (this.passUser != null)
			array = this.passUser.replace("，", ",").split(",");
		return array;
	}

}
