package jp.co.sraw.dto;

import java.io.Serializable;
import java.sql.Timestamp;

public class KjGroupCommonFileDto implements Serializable {

	private String boardGroupKey;

	private String uploadKey;

	private String title;

	private Timestamp updDate;

	private String updUserKey;

	private String fileKbn;

	private String fileName;

	private String filePutPath;

	public KjGroupCommonFileDto() {
		super();
	}

	public KjGroupCommonFileDto(String boardGroupKey, String uploadKey, String title,
								String fileKbn, String fileName, String filePutPath) {
		super();
		setBoardGroupKey(boardGroupKey);
		setUploadKey(uploadKey);
		setTitle(title);
		setFileKbn(fileKbn);
		setFileName(fileName);
		setFilePutPath(filePutPath);
	}

	public String getBoardGroupKey() {
		return boardGroupKey;
	}

	public void setBoardGroupKey(String boardGroupKey) {
		this.boardGroupKey = boardGroupKey;
	}

	public String getUploadKey() {
		return uploadKey;
	}

	public void setUploadKey(String uploadKey) {
		this.uploadKey = uploadKey;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Timestamp getUpdDate() {
		return updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdUserKey() {
		return updUserKey;
	}

	public void setUpdUserKey(String updUserKey) {
		this.updUserKey = updUserKey;
	}

	public String getFileKbn() {
		return fileKbn;
	}

	public void setFileKbn(String fileKbn) {
		this.fileKbn = fileKbn;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFilePutPath() {
		return filePutPath;
	}

	public void setFilePutPath(String filePutPath) {
		this.filePutPath = filePutPath;
	}


}
