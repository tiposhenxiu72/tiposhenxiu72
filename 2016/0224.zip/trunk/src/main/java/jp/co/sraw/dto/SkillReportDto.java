package jp.co.sraw.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import jp.co.sraw.controller.skill.AnswerForm;
import jp.co.sraw.entity.NrAchievementReportBkupTbl;
import jp.co.sraw.entity.NrAchievementReportTbl;
import jp.co.sraw.oxm.rubric.Rubric;

/**
 * 自己評価レポートに必要な情報を格納する。
 *
 */
public class SkillReportDto implements Serializable {
	private static final long serialVersionUID = 1L;

	private Rubric rubric;
	private Rubric rubricAll;
	private List<AnswerForm> answers;
	private String lensName;
	private boolean canEditDone;
	private NrAchievementReportTbl report;
	private NrAchievementReportBkupTbl savedReport;
	private String userName;
	private String degreeName;
	private String partyName;
	private String majorName;
	private Map<String, List<SkillLessonTakenDto>> lessonMap;
	private Map<String, Boolean> achievementMap;

	public Rubric getRubric() {
		return rubric;
	}

	public void setRubric(Rubric rubric) {
		this.rubric = rubric;
	}

	public List<AnswerForm> getAnswers() {
		return answers;
	}

	public void setAnswers(List<AnswerForm> answers) {
		this.answers = answers;
	}

	public String getLensName() {
		return lensName;
	}

	public void setLensName(String lensName) {
		this.lensName = lensName;
	}

	public String getDegreeName() {
		return degreeName;
	}

	public void setDegreeName(String degreeName) {
		this.degreeName = degreeName;
	}

	public boolean canEditDone() {
		return canEditDone;
	}

	public void setCanEditDone(boolean canEditDone) {
		this.canEditDone = canEditDone;
	}

	public NrAchievementReportTbl getReport() {
		return report;
	}

	public void setReport(NrAchievementReportTbl report) {
		this.report = report;
	}

	public NrAchievementReportBkupTbl getSavedReport() {
		return savedReport;
	}

	public void setSavedReport(NrAchievementReportBkupTbl savedReport) {
		this.savedReport = savedReport;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPartyName() {
		return partyName;
	}

	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}

	public String getMajorName() {
		return majorName;
	}

	public void setMajorName(String majorName) {
		this.majorName = majorName;
	}

	public Map<String, List<SkillLessonTakenDto>> getLessonMap() {
		return lessonMap;
	}

	public void setLessonMap(Map<String, List<SkillLessonTakenDto>> lessonMap) {
		this.lessonMap = lessonMap;
	}

	public Rubric getRubricAll() {
		return rubricAll;
	}

	public void setRubricAll(Rubric rubricAll) {
		this.rubricAll = rubricAll;
	}

	public Map<String, Boolean> getAchievementMap() {
		return achievementMap;
	}

	public void setAchievementMap(Map<String, Boolean> achievementMap) {
		this.achievementMap = achievementMap;
	}

}
