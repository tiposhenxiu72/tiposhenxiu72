/*
* ファイル名：RelationMgmtController.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/02/22   tsutsumi    新規作成
*/
package jp.co.sraw.controller.skill;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonController;
import jp.co.sraw.dto.RelationAnswerDto;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.oxm.rubric.Rubric;
import jp.co.sraw.oxm.rubric.RubricCategory;
import jp.co.sraw.service.RelationSkillServiceImpl;
import jp.co.sraw.service.RubricServiceImpl;

/**
 * 養成能力紐付き機能Controller
 *
 */
@Controller
@RequestMapping("/mgmt/skill")
public class RelationMgmtController extends CommonController {

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(RelationMgmtController.class);

	// 遷移先
	private static final String RELATE_PAGE = "skill/build/mgmt/relate";

	@Autowired
	private RubricServiceImpl rubricService;
	@Autowired
	private RelationSkillServiceImpl relationSkillServiceImpl;

	@Override
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	// 養成科目紐付け画面 ----------------------------------------

	/**
	 * ひも付け画面の初期表示（ルーブリックデフォルト）
	 * @param request
	 * @param mode 画面モード（インターンシップ:intern / イベント:event / 科目:lesson）
	 * @param key 画面モードに対応したキー
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping("/relation")
	public String relationInit (HttpServletRequest request
			, Model model, Locale locale) {

		String rkey = relationSkillServiceImpl.getDefaultRubricKey(locale);

		return relationInit(request, rkey, model, locale);
	}

	/**
	 * ひも付け画面の初期表示
	 * @param request
	 * mode 画面モード（インターンシップ:intern / イベント:event / 科目:lesson）
	 * @param key 画面モードに対応したキー
	 * @param rkey ルーブリックキー
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping("/relation/{rkey}")
	public String relationInit (HttpServletRequest request
			, @PathVariable("rkey") String rkey
			, Model model, Locale locale) {

		// ルーブリック内容取得
		Rubric rub = rubricService.findOne(rkey);

		// 画面表示用に変換
		SKillBuildRelateForm form = populateRelateForm(rub);

		model.addAttribute(CommonConst.FORM_NAME, form);
		model.addAttribute("rkey", rkey);

		return RELATE_PAGE;
	}

	/**
	 * ひも付け画面 完了
	 * @param request
	 * @param selForm
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping(value="/relateFix", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public RelationAnswerDto relateFix(HttpServletRequest request
			, @ModelAttribute(CommonConst.FORM_NAME) SKillBuildRelateForm selForm
			, Model model, Locale locale) {

		// 能力と関連レベルMap化
		Map<String, String> skillMap = new HashMap<>();
		checkRelationiStatus(selForm.getRelationList(), skillMap);

		RelationAnswerDto rtnAns = new RelationAnswerDto();
		rtnAns.setSkillMap(skillMap);

		model.addAttribute("skillJson", relationSkillServiceImpl.convertSkill(skillMap));

		return rtnAns;
	}

	// 紐付け画面関連 ----------
	/**
	 * @param rub
	 * @return
	 */
	private SKillBuildRelateForm populateRelateForm (Rubric rub) {
		SKillBuildRelateForm form = new SKillBuildRelateForm();
		// フォームの形に入れ替え
		List<SkillBuildRelateSubjectForm> relationList = formatRelateForm(rub.getCategoryList());

		form.setRelationList(relationList);
		return form;
	}

	/**
	 * カテゴリ情報をひも付け一覧の表示フォームに変換
	 * @param catList
	 * @param subjectMap
	 * @return
	 */
	private List<SkillBuildRelateSubjectForm> formatRelateForm(List<RubricCategory> catList) {
		if (catList == null) {
			return null;
		}
		List<SkillBuildRelateSubjectForm> parentList = new ArrayList<SkillBuildRelateSubjectForm>();
		for (RubricCategory cat : catList) {
			SkillBuildRelateSubjectForm item = new SkillBuildRelateSubjectForm();
			item.setSubjectCode(cat.getAbilityCode());
			item.setSubjectName(cat.getName());

			// 子カテゴリをセット
			item.setChildList (formatRelateForm(cat.getChildList()));

			parentList.add(item);
		}
		return parentList;
	}

	/**
	 * 紐付きのチェック状態を調べる
	 * @param inList 紐付き画面の一覧情報リスト
	 * @param outMap 結果格納用Map
	 */
	private void checkRelationiStatus (List<SkillBuildRelateSubjectForm> inList, Map<String, String> outMap) {
		if (inList == null) {
			return;
		}
		for (SkillBuildRelateSubjectForm item: inList) {
			if (item.getSubjectCode() == null || item.getRelation() == null) {
				// 紐付きが設定されていない場合は、更に下層をチェックしに行く
				checkRelationiStatus (item.getChildList(), outMap);
			}
			if (CommonConst.RELATION_LEVEL_BEST.equals(item.getRelation())
					|| CommonConst.RELATION_LEVEL_NORMAL.equals(item.getRelation())) {
				outMap.put(item.getSubjectCode(), item.getRelation());
			}
		}
	}

}
