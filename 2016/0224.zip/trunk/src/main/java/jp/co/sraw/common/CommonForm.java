/*
* ファイル名：CommonForm.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.common;

import java.io.Serializable;
import java.util.Locale;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * <B>CommonFormクラス</B>
 * <P>
 * Formのメソッドを提供する
 */
public class CommonForm implements Serializable {

	public final static String VIEW_TYPE_FORM = "VIEW_TYPE_FORM";
	public final static String VIEW_TYPE_DB = "VIEW_TYPE_DB";
	public final static String VIEW_TYPE_EXCEL = "VIEW_TYPE_EXCEL";

	// 定数区分
	public static final String CODE_USER_KBN = "0035"; // 定数区分[0035] 学年／職位

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	private String pageActionUrl;

	private String pageMode;

	private String confirmMessageRegist; // regist確認ダイアログ表示メッセージ

	private String confirmMessageUpdate; // update確認ダイアログ表示メッセージ

	private String confirmMessageDelete; // delete確認ダイアログ表示メッセージ

	@Override
	public String toString() {
		// return new ToStringCreator(this).toString();
		return ToStringBuilder.reflectionToString(this, ToStringStyle.DEFAULT_STYLE);
	}

	/**
	 * @return pageActionUrl
	 */
	public String getPageActionUrl() {
		return pageActionUrl;
	}

	/**
	 * @param pageActionUrl
	 *            セットする pageActionUrl
	 */
	public void setPageActionUrl(String pageActionUrl) {
		this.pageActionUrl = pageActionUrl;
	}

	/**
	 * @return pageMode
	 */
	public String getPageMode() {
		return pageMode;
	}

	/**
	 * @param pageMode
	 *            セットする pageMode
	 */
	public void setPageMode(String pageMode) {
		this.pageMode = pageMode;
	}

	/**
	 * @return confirmMessageRegist
	 */
	public String getConfirmMessageRegist() {
		return confirmMessageRegist;
	}

	/**
	 * @param confirmMessageRegist
	 *            セットする confirmMessageRegist
	 */
	public void setConfirmMessageRegist(String confirmMessageRegist) {
		this.confirmMessageRegist = confirmMessageRegist;
	}

	/**
	 * @return confirmMessageDelete
	 */
	public String getConfirmMessageDelete() {
		return confirmMessageDelete;
	}

	/**
	 * @param confirmMessageDelete
	 *            セットする confirmMessageDelete
	 */
	public void setConfirmMessageDelete(String confirmMessageDelete) {
		this.confirmMessageDelete = confirmMessageDelete;
	}

	protected String viewType = VIEW_TYPE_DB;

	public String getViewType() {
		return viewType;
	}

	public void setViewType(String viewType) {
		this.viewType = viewType;
	}

	protected Locale locale;

	public Locale getLocale() {
		if (locale == null)
			return Locale.getDefault();
		return locale;
	}

	public void setLocale(Locale locale) {
		this.locale = locale;
	}

	/**
	 * @return confirmMessageUpdate
	 */
	public String getConfirmMessageUpdate() {
		return confirmMessageUpdate;
	}

	/**
	 * @param confirmMessageUpdate
	 *            セットする confirmMessageUpdate
	 */
	public void setConfirmMessageUpdate(String confirmMessageUpdate) {
		this.confirmMessageUpdate = confirmMessageUpdate;
	}

	/**
	 *
	 * @param setValue
	 * @param limitValue
	 * @return
	 */
	protected String isCan(String setValue, String limitValue) {
		try {
			int setInt = Integer.parseInt(setValue);
			int limitInt = Integer.parseInt(limitValue);
			if (setInt >= limitInt) {
				return "1";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "0";
	}
}
