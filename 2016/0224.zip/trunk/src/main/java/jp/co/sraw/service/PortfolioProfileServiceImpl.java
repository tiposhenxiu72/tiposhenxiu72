/*
* ファイル名：PortfolioServiceImpl.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.sraw.common.CommonService;
import jp.co.sraw.controller.portfolio.service.ResultUploadServiceImpl;
import jp.co.sraw.entity.UsCompetitionTbl;
import jp.co.sraw.entity.UsPrmovieUploadTbl;
import jp.co.sraw.entity.UsUserTbl;
import jp.co.sraw.file.FileService;
import jp.co.sraw.file.GyosekiFileDto;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.repository.UsCompetitionTblRepository;
import jp.co.sraw.repository.UsPrmovieUploadTblRepository;
import jp.co.sraw.repository.UsUserTblRepository;

/**
 * <B>PortfolioServiceImplクラス</B>
 * <P>
 * ユーザーサービスのメソッドを提供する
 */
@Scope("prototype")
@Service
@Transactional(readOnly = true)
public class PortfolioProfileServiceImpl extends CommonService {

	@Autowired
	private UsUserTblRepository usUserTblRepository;

	@Autowired
	private FileService fileService;

	@Autowired
	private UsCompetitionTblRepository usCompetitionTblRepository;

	@Autowired
	private ResultUploadServiceImpl resultUploadServiceImpl;

	@Autowired
	private UsPrmovieUploadTblRepository usPrmovieUploadTblRepository;

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(UserServiceImpl.class);

	@PostConstruct
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	// ユーザ情報テーブル
	public List<UsUserTbl> findAllUser() {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		List<UsUserTbl> list = usUserTblRepository.findAll();

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return list;
	}

	public UsUserTbl findOneUser(String userKey) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		UsUserTbl u = usUserTblRepository.findOne(userKey);

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return u;
	}

	// コンペティションファイルVIEW
	public List<GyosekiFileDto> findAllUsCompetition(String searchUserKey, String[] publicFlags) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		//
		Specification<UsCompetitionTbl> whereUserKey = new Specification<UsCompetitionTbl>() {
			public Predicate toPredicate(Root<UsCompetitionTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.get("usUserTbl").get("userKey"), searchUserKey);
			}
		};

		// 取得条件：
		Specification<UsCompetitionTbl> wherePublicFlags = publicFlags == null ? null : new Specification<UsCompetitionTbl>() {
			@Override
			public Predicate toPredicate(Root<UsCompetitionTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				Predicate predicate = cb.conjunction();
				for (int i = 0; i < publicFlags.length; i++) {
					String keyword = publicFlags[i];
					if (i == 0) {
						predicate = cb.and(predicate, cb.equal(root.get("publicFlag"), keyword));
					} else {
						predicate = cb.or(predicate, cb.equal(root.get("publicFlag"), keyword));
					}
				}
				return predicate;
			}
		};

		List<UsCompetitionTbl> list = (List<UsCompetitionTbl>) usCompetitionTblRepository
				.findAll((Specification<UsCompetitionTbl>) Specifications.where(whereUserKey).and(wherePublicFlags), orderBy());

		List<GyosekiFileDto> fileList = new ArrayList<>();
		for (UsCompetitionTbl tbl : list) {
			GyosekiFileDto dto = new GyosekiFileDto(fileService.getFileUploadDto(tbl.getUploadKey()));
			dto.setTitle(tbl.getTitle());
			dto.setGyosekiKey(tbl.getGyosekiKey());
			dto.setLink(tbl.getLink());
			dto.setInsKbn(tbl.getInsKbn());
			fileList.add(dto);
		}

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return fileList;
	}

	private Sort orderBy() {
		// 登録日昇順
		return new Sort(Sort.Direction.ASC, "insDate");
	}

	/**
	 * PR動画ファイル取得
	 *
	 * @param userKey
	 * @return
	 */
	public List<UsPrmovieUploadTbl> findAllPrFile(String userKey) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		// 取得条件：ユーザキー
		Specification<UsPrmovieUploadTbl> whereUserKey =
			new Specification<UsPrmovieUploadTbl>() {
				@Override
				public Predicate toPredicate(Root<UsPrmovieUploadTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
					return cb.equal(root.get("id").get("userKey"), userKey);
				}
			};

		List<UsPrmovieUploadTbl> list = usPrmovieUploadTblRepository.findAll(Specifications.where(whereUserKey));

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return list;
	}

}
