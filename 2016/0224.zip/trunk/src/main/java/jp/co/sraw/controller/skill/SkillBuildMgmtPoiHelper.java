package jp.co.sraw.controller.skill;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.BidiMap;
import org.apache.commons.collections.bidimap.DualHashBidiMap;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.poi.hssf.usermodel.DVConstraint;
import org.apache.poi.hssf.usermodel.HSSFDataValidation;
import org.apache.poi.hssf.usermodel.HSSFName;
import org.apache.poi.hssf.util.CellRangeAddressList;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Service;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.oxm.rubric.Rubric;
import jp.co.sraw.oxm.rubric.RubricCategory;
import jp.co.sraw.util.PoiBook;
import jp.co.sraw.util.PoiHelper;
import jp.co.sraw.util.StringUtil;

/**
 * 能力養成科目管理 Excel入出力ヘルパー
 *
 */
@SuppressWarnings("deprecation")
@Service
public class SkillBuildMgmtPoiHelper extends PoiHelper<CurriculumForm> {

	private final String SHEET_NAME_1 = "能力養成科目";
	private final String SHEET_NAME_2 = "DATA";

	private final int FORMULA_SETTING_MAX_ROW = 500;
	private final int FORMULA_PARTY_COL = 1;
	private final int FORMULA_TARGET_COL = 3;
	private final int FORMULA_LISTEN_COL = 5;
	private final int FORMULA_RELAY_COL = 7;
	private final int FORMULA_KBN_COL = 9;
	private final int FORMULA_COMPULSOR_COL = 11;
	private final Map<Integer, String> FORMULA_CLM_NAME = new HashMap<Integer, String>() {
		{
			put(1, "B");
			put(3, "D");
			put(5, "F");
			put(7, "H");
			put(9, "J");
			put(11, "L");
		}
	};

	@Override
	public Sheet getSheet(Workbook workbook) {
		return workbook.getSheet(SHEET_NAME_1);
	}

	static public final String DATE_PATTERN ="yyyy/MM/dd";

	/**
	 * ヘッダ部の能力養成科目を設定する
	 * @param workbook Excel
	 * @param rinfo ルーブリック情報
	 */
	public void buildExcelDocumentHeader(PoiBook workbook, Rubric rinfo) {
		workbook.activeSheet = workbook.book.getSheet(SHEET_NAME_1);

		int mainPos = 0;
		int mainSize = 0;
		int subPos = 0;
		int subSize = 0;
		int colNum = 0;
		for (RubricCategory mainCt : rinfo.getCategoryList()) {
			// 能力養成名
			workbook.changeValue(2, mainPos + 22, mainCt.getName());

			for (RubricCategory subCt : mainCt.getChildList()) {
				// 中項目
				// 能力養成名
				workbook.changeValue(3, subPos + 22, subCt.getName());

				for (RubricCategory item : subCt.getChildList()) {
					// 小項目
					// RDF No.
					workbook.changeValue(4, colNum + 22, item.getAbilityCode());
					// 能力養成名
					workbook.changeValue(5, colNum + 22, item.getName());

					colNum++;
					subSize++;
					mainSize++;
				}
				// 中項目のセルを結合
				workbook.mergeCell(3, 22 + subPos, 0, subSize - 1);
				subPos = subPos + subSize;
				subSize = 0;
			}
			// 大項目のセルを結合
			workbook.mergeCell(2, mainPos + 22, 0, mainSize - 1);
			mainPos = mainPos + mainSize;
			mainSize = 0;
		}
		workbook.mergeCell(1, 22, 0, mainPos - 1);
	}

	/**
	 * エクセルファイル出力
	 * @see jp.co.sraw.util.PoiHelper#buildExcelDocument(jp.co.sraw.util.PoiBook, java.util.List)
	 */
	public void buildExcelDocument(PoiBook workbook, List<CurriculumForm> list
			, Map<String, String> partyMap, Map<String, String> targetMap
			, Map<String, String> listenMap, Map<String, String> relayMap
			, Map<String, String> kbnMap, Map<String, String> compulsorMap) {
		workbook.activeSheet = workbook.book.getSheet(SHEET_NAME_1);
		// データ部
		for (int i = 0; i < list.size(); i++) {
			CurriculumForm form = list.get(i);
			int rowno = i + 6;
			// No.
			workbook.changeValue(rowno, 0, form.getLessonKey());
			// 機関名
			workbook.changeValue(rowno, 1, partyMap.get(form.getPartyCode()));
			// 期間内講義コード
			workbook.changeValue(rowno, 2, form.getLessonCode());
			// 開講部局
			workbook.changeValue(rowno, 3, form.getLessonDepartment());
			// 授業科目・プログラム名
			workbook.changeValue(rowno, 4, form.getLessonName());
			// 担当教員名
			workbook.changeValue(rowno, 5, form.getUserName());
			// 学内聴講対象者
			workbook.changeValue(rowno, 6, targetMap.get(form.getLessonTarget()));
			// 外学聴講/傍聴の可否
			workbook.changeValue(rowno, 7, listenMap.get(form.getListenFlag()));
			// 開講期
			workbook.changeValue(rowno, 8, form.getLessonDate());
			// 曜日時限
			workbook.changeValue(rowno, 9, form.getLessonPeriod());
			// 中継の有無
			workbook.changeValue(rowno, 10, relayMap.get(form.getRelayFlag()));
			// 中継聴講場所
			workbook.changeValue(rowno, 11, form.getRelayPlace());
			// 授業形態
			workbook.changeValue(rowno, 12, kbnMap.get(form.getLessonKbn()));
			// 単位数
			workbook.changeValue(rowno, 13, form.getUnit());
			// 学外受講生の単位互換
			workbook.changeValue(rowno, 14, form.getUnitInterchangeable());
			// 必修選択の別
			workbook.changeValue(rowno, 15, compulsorMap .get(form.getLessonCompulsory()));
			// 成績評価基準
			workbook.changeValue(rowno, 16, form.getLessonBase());
			// 授業の目的・概要
			workbook.changeValue(rowno, 17, form.getLessonIntention());
			// 授業計画
			workbook.changeValue(rowno, 18, form.getLessonPlan());
			// 備考
			workbook.changeValue(rowno, 19, form.getLessonMemo());
			// eラーニングリンク
			workbook.changeValue(rowno, 20, form.geteLink());
			// シラバスリンク
			workbook.changeValue(rowno, 21, form.getsLink());

			// RDF Noの行のデータを取得
			int colNum = 0;
			Row headRow = workbook.activeSheet.getRow(4);
			while (getCellValue(headRow,  22 + colNum) != null && getCellValue(headRow,  22 + colNum).length() != 0) {
				String val = getCellValue(headRow, 22 + colNum);
				if (form.getLinkageMap().containsKey(val)) {
					workbook.changeValue(rowno, 22 + colNum, getRelationLvVal(form.getLinkageMap().get(val)));
				}
				colNum++;
			}
		}
	}

	public void setFormula (PoiBook workbook, int lastRow
			, Map<String, String> partyMap, Map<String, String> targetMap
			, Map<String, String> listenMap, Map<String, String> relayMap
			, Map<String, String> kbnMap, Map<String, String> compulsorMap) {

		setFormula(workbook, 5, lastRow, 1, FORMULA_PARTY_COL, partyMap);
		setFormula(workbook, 5, lastRow, 6, FORMULA_TARGET_COL, targetMap);
		setFormula(workbook, 5, lastRow, 7, FORMULA_LISTEN_COL, listenMap);
		setFormula(workbook, 5, lastRow, 10, FORMULA_RELAY_COL, relayMap);
		setFormula(workbook, 5, lastRow, 12, FORMULA_KBN_COL, kbnMap);
		setFormula(workbook, 5, lastRow, 15, FORMULA_COMPULSOR_COL, compulsorMap);

		// データシートを非表示
		workbook.book.setSheetHidden(1, true);
	}

	@SuppressWarnings("deprecation")
	private void setFormula (PoiBook workbook, int sRow, int eRow, int col, int type, Map<String, String> map) {
		workbook.activeSheet = workbook.book.getSheet(SHEET_NAME_1);

		int maxRow = eRow;
		if (FORMULA_SETTING_MAX_ROW > eRow) {
			maxRow = FORMULA_SETTING_MAX_ROW;
		}

		// 入力規則を設定するセル
		CellRangeAddressList addressList = new CellRangeAddressList(sRow, maxRow, col, col);
		String cellName = "list_" + FORMULA_CLM_NAME.get(type);

		HSSFName namedRange = workbook.book.createName();
		namedRange.setNameName(cellName);
		String formula = String.format("'%s'!$%s$1:$%s$%d", SHEET_NAME_2, FORMULA_CLM_NAME.get(type), FORMULA_CLM_NAME.get(type), map.size());
		namedRange.setRefersToFormula(formula);

		// リストの値
		DVConstraint dvConstraint = DVConstraint.createFormulaListConstraint(cellName);

		// 定義する
		HSSFDataValidation dataValidation = new HSSFDataValidation(addressList, dvConstraint);
		dataValidation.setSuppressDropDownArrow(false);

		workbook.activeSheet.addValidationData(dataValidation);

		// 2シート目にデータの設定
		workbook.activeSheet = workbook.book.getSheet(SHEET_NAME_2);

		int rowno = 0;
		// 組織名
		rowno = 0;
		for (Map.Entry<String, String> item : map.entrySet()) {
			workbook.changeValue(rowno, type - 1, item.getKey());
			workbook.changeValue(rowno, type, item.getValue());
			rowno++;
		}
	}

	/**
	 * Excelファイル読み込み（データ部のみ）
	 * @see jp.co.sraw.util.PoiHelper#getForm(org.apache.poi.ss.usermodel.Row)
	 */
	public CurriculumForm getForm(Row row
			, Map<String, String> partyMap, Map<String, String> targetMap, Map<String, String> listenMap
			, Map<String, String> relayMap, Map<String, String> kbnMap, Map<String, String> compulsorMap) {
		CurriculumForm form = new CurriculumForm();

		BidiMap bPartyMap = new DualHashBidiMap(partyMap);
		BidiMap bTargetMap = new DualHashBidiMap(targetMap);
		BidiMap bListenMap = new DualHashBidiMap(listenMap);
		BidiMap bRelayMap = new DualHashBidiMap(relayMap);
		BidiMap bKbnMap = new DualHashBidiMap(kbnMap);
		BidiMap bCompulsorMap = new DualHashBidiMap(compulsorMap);

		// 科目キー
		form.setLessonKey((String) bPartyMap.getKey(getCellValue(row, 0)));
		// 機関名
		form.setPartyCode((String) bPartyMap.getKey(getCellValue(row, 1)));
		// 期間内講義コード
		form.setLessonKey(getCellValue(row, 2));
		// 開講部局
		form.setLessonDepartment(getCellValue(row, 3));
		// 授業科目・プログラム名
		form.setLessonName(getCellValue(row, 4));
		// 担当教員名
		form.setUserName(getCellValue(row, 5));
		// 学内聴講対象者
		form.setLessonTarget((String) bTargetMap.getKey(getCellValue(row, 6)));
		// 外学聴講/傍聴の可否
		form.setListenFlag((String) bListenMap.getKey(getCellValue(row, 7)));
		// 開講期
		form.setLessonDate(getCellValue(row, 8));
		// 曜日時限
		form.setLessonPeriod(getCellValue(row, 9));
		// 中継の有無
		form.setRelayFlag((String) bRelayMap.getKey(getCellValue(row, 10)));
		// 中継聴講場所
		form.setRelayPlace(getCellValue(row, 11));
		// 授業形態
		form.setLessonKbn((String) bKbnMap.getKey(getCellValue(row, 12)));
		// 単位数
		form.setUnit(getCellValue(row, 13));
		// 学外受講生の単位互換
		form.setUnitInterchangeable(getCellValue(row, 14));
		// 必修選択の別
		form.setLessonCompulsory((String) bCompulsorMap.getKey(getCellValue(row, 15)));
		// 成績評価基準
		form.setLessonBase(getCellValue(row, 16));
		// 授業の目的・概要
		form.setLessonIntention(getCellValue(row, 17));
		// 授業計画
		form.setLessonPlan(getCellValue(row, 18));
		// 備考
		form.setLessonMemo(getCellValue(row, 19));
		// eラーニングリンク
		form.seteLink(getCellValue(row, 20));
		// シラバスリンク
		form.setsLink(getCellValue(row, 21));

		return form;
	}


	/**
	 * 科目情報を読み込む
	 * @param workbook Excelブック
	 * @return 読み込んだデータ一覧
	 */
	public List<CurriculumForm> getLinkageLessonAbilityCode (PoiBook workbook
			, Map<String, String> partyMap, Map<String, String> targetMap, Map<String, String> listenMap
			, Map<String, String> relayMap, Map<String, String> kbnMap, Map<String, String> compulsorMap) {
		Row headRow = workbook.activeSheet.getRow(4);

		List<CurriculumForm> list = new ArrayList<CurriculumForm>();


		int rowNum = 6;	// データは6行目から
		do {
			Map<String, String> map = new HashMap<String, String>();
			Row dataRow = workbook.activeSheet.getRow(rowNum);
			if (dataRow == null || getCellValue(dataRow, 4) == null || getCellValue(dataRow, 4).length() == 0) {
				break;
			}
			CurriculumForm form = getForm(dataRow
					, partyMap, targetMap, listenMap, relayMap, kbnMap, compulsorMap);

			int colNum = 0;
			while (getCellValue(headRow, 22 + colNum) != null) {
				String relationLv = getCellValue(dataRow, 22 + colNum);
				if (StringUtil.isNotNull(relationLv)) {
					map.put(getCellValue(headRow, 22 + colNum), getRelationLvCode(relationLv));
				}
				colNum++;
			}
			form.setLinkageMap(map);

			if (!validationExcelFile(form)) {
				return null;
			}

			list.add(form);
			rowNum++;
		} while(true);

		return list;
	}

	public boolean validationExcelFile (CurriculumForm form) {
		boolean rtn = true;

		// 科目名
		if (!(isNotNull(form.getLessonName()) && isMaxLength(form.getLessonName(), 100))) {
			rtn = false;
		}

		// 開講大学
		if (!(isNotNull(form.getPartyCode()) && isMaxLength(form.getPartyCode(), 100))) {
			rtn = false;
		}

		// 開講科目コード
		if (!(isMaxLength(form.getLessonCode(), 100))) {
			rtn = false;
		}

		// 開講部局
		if (!(isNotNull(form.getLessonDepartment()) && isMaxLength(form.getLessonDepartment(), 100))) {
			rtn = false;
		}
		// 担当教員
		if (!(isNotNull(form.getUserName()) && isMaxLength(form.getUserName(), 100))) {
			rtn = false;
		}
		// 受講対象者
		if (!(isNotNull(form.getLessonTarget()) && isMaxLength(form.getLessonTarget(), 100))) {
			rtn = false;
		}

		// 曜日時限
		if (!(isMaxLength(form.getLessonTarget(), 100))) {
			rtn = false;
		}
		// 中継の有無
		if (!(isMaxLength(form.getRelayFlag(), 100))) {
			rtn = false;
		}
		// 中継聴講場所
		if (!(isMaxLength(form.getRelayPlace(), 100))) {
			rtn = false;
		}
		// 単位
		if (!(isMaxLength(form.getUnit(), 100) && (StringUtil.isNull(form.getUnit()) || isNumber(form.getUnit())))) {
			rtn = false;
		}
		// 成績評価基準
		if (!(isMaxLength(form.getLessonBase(), 100))) {
			rtn = false;
		}

		// 授業の目的概要
		if (!(isMaxLength(form.getLessonIntention(), 100))) {
			rtn = false;
		}
		// 授業計画
		if (!(isMaxLength(form.getLessonPlan(), 100))) {
			rtn = false;
		}

		// 備考
		if (!(isMaxLength(form.getLessonMemo(), 100))) {
			rtn = false;
		}

		// eラーニングリンク
		if (!(isMaxLength(form.geteLink(), 100))) {
			rtn = false;
		}

		// シラバスリンク
		if (!(isMaxLength(form.getLessonMemo(), 100))) {
			rtn = false;
		}

		// 開講期
		if (!(form.getLessonDate() == null || form.getLessonDate().length() == 0 || isDate(form.getLessonDate(), CommonConst.DEFAULT_YYYYMMDD))) {
			rtn = false;
		}

		// 養成能力
		if (form.getLinkageMap().isEmpty()) {
			rtn = false;
		}

		return rtn;
	}

	private boolean isNotNull (String str) {
		return StringUtil.isNotNull(str);
	}
	private boolean isMaxLength (String str, int len) {
		return isNotNull(str) ? str.length() <= len : true;
	}
	private boolean isNumber (String str) {
		try {
			Integer.parseInt(str);
			return true;
		} catch (NumberFormatException nfex) {
			return false;
		}
	}

	@Override
	public CurriculumForm getForm(Row row) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	/**
	 * 紐付きレベルを画面表示用からシステム内用のコードに変換する
	 * @param relationLvVal 画面表示用文字列
	 * @return システム用コード
	 */
	private String getRelationLvCode (String relationLvVal) {
		return CommonConst.RELATION_LEVEL_BEST_V.equals(relationLvVal) ? CommonConst.RELATION_LEVEL_BEST
				: CommonConst.RELATION_LEVEL_NORMAL_V.equals(relationLvVal) ? CommonConst.RELATION_LEVEL_NORMAL
						: null;
	}

	/**
	 * 紐付きレベルを画面表示用からシステム内用のコードに変換する
	 * @param relationLbStr 画面表示用文字列
	 * @return システム用コード
	 */
	private String getRelationLvVal (String relationLvCd) {
		return CommonConst.RELATION_LEVEL_BEST.equals(relationLvCd) ? CommonConst.RELATION_LEVEL_BEST_V
				: CommonConst.RELATION_LEVEL_NORMAL.equals(relationLvCd) ? CommonConst.RELATION_LEVEL_NORMAL_V
						: null;
	}

	private boolean isDate(String strDate, String format) {
		boolean rtn = true;
		try {
			DateUtils.parseDateStrictly(strDate, new String[] {format});
		} catch (ParseException e) {
			rtn = false;
		}
		return rtn;
	}
}
