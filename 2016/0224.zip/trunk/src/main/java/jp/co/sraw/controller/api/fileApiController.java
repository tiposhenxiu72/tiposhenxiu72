/*
* ファイル名：fileApiController.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/02/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.api;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.Locale;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import eu.medsea.mimeutil.MimeType;
import eu.medsea.mimeutil.MimeUtil;
import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonController;
import jp.co.sraw.controller.portfolio.service.CompetitionUploadServiceImpl;
import jp.co.sraw.controller.portfolio.service.ResultUploadServiceImpl;
import jp.co.sraw.entity.UsUserTbl;
import jp.co.sraw.file.FileDto;
import jp.co.sraw.file.FileService;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.service.UserServiceImpl;
import jp.co.sraw.util.StringUtil;

/**
 * <B>fileApiControllerクラス</B>
 * <P>
 * ファイルAPIのメソッドを提供する
 */
@RestController
@RequestMapping(CommonConst.PATH_API + "/file")
public class fileApiController extends CommonController {
	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(fileApiController.class);

	private static String DUMMY_PHOT_MAN = "/static/img/face.gif";
	private static String DUMMY_PHOT_WOMAN = "/static/img/face2.gif";
	private static String DUMMY_PHOT_PARTY = "/static/img/party.gif";

	private static final String[] PUBLIC_FLAG_ALL = new String[]{"0", "1", "2"}; // 全て表示

	private static final String[] PUBLIC_FLAG_INSIDE = new String[]{"1", "2"}; // 内部、全公開

	private static final String[] PUBLIC_FLAG_OUTSIDE = new String[]{"2"}; // 内部、全公開

	private static final String DOWNLOAD_COMPETITION_MOVE = "download_competition_move"; // ３分間コンペティションファイル取得
	private static final String DOWNLOAD_RESULT = "download_result"; // その他成果物ファイル取得

	@Autowired
	private UserServiceImpl userServiceImpl;

	@Autowired
	private ResultUploadServiceImpl resultUploadServiceImpl;

	@Autowired
	private CompetitionUploadServiceImpl competitionUploadServiceImpl;

	@Autowired
	private FileService fileService;

	@PostConstruct
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	/**
	 * 顔写真を取得(表示、自分、公開判定)
	 *
	 * @param userKey
	 * @param userPublicFlag
	 *            公開設定
	 * @param mode
	 *            オプション 表示モード(1:常に表示)
	 * @param locale
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = { "/user/{userKey}/photo/{userPublicFlag}", "/user/{userKey}/photo/{userPublicFlag}/{mode}" },
			headers = "Accept=image/jpeg, image/jpg, image/png, image/gif, image/bmp", method = RequestMethod.GET)
	public void userMyPhoto(@PathVariable("userKey") String userKey,
			@PathVariable("userPublicFlag") String userPublicFlag, @PathVariable("mode") Optional<String> mode,
			HttpServletResponse response, Locale locale) throws IOException {

		logger.infoCode("I0001", "userMyPhoto"); // I0001=メソッド開始:{0}

		ServletOutputStream responseOutputStream = null;
		InputStream in = null;
		// ダミー画像取得
		in = fileApiController.class.getResourceAsStream(DUMMY_PHOT_MAN);
		// 女性の場合
		if (userInfo != null && CommonConst.SEX_WOMAN.equals(userInfo.getTargetSex())) {
			in = fileApiController.class.getResourceAsStream(DUMMY_PHOT_WOMAN);
		}
		// 大学・企業
		if (userInfo != null && Arrays.asList(CommonConst.USER_KBN_PARTY_LIST).contains(userInfo.getTargetUserKbn())) {
			in = fileApiController.class.getResourceAsStream(DUMMY_PHOT_PARTY);
		}
		//
		try {
			// ユーザーキーと対象者が同じ場合
			if (userInfo != null && userInfo.getTargetUserKey().equals(userKey)) {
				// userInfoから画像データ取得
				UsUserTbl u = userServiceImpl.findOne(userInfo.getTargetUserKey());
				// buttonFlag:1の場合、メニューなどの顔写真
				// userPublicFlag:非公開指定の場合＝全て公開、内部公開指定＝内部公開＆全公開、全公開の場合＝全公開
				if (u != null && StringUtil.isNotNull(u.getUploadKey()) && ((mode.isPresent() && "1".equals(mode.get()))
						|| isPortfolioPublicFlag(u.getUserPublicFlag(), userPublicFlag))) {
					FileDto fileDto = fileService.getFile(u.getUploadKey());
					if (fileDto == null) {
						throw new Exception("fileDto is null.");
					}
					File downloadFile = new File(fileDto.getUploadPath());
					in = new FileInputStream(downloadFile);
				}
			}

			byte[] imgByte = IOUtils.toByteArray(in);
			setResponseOutputStream(responseOutputStream, response, imgByte);

			logger.infoCode("I0002", "userMyPhoto"); // I0002=メソッド終了:{0}

		} catch (Exception e) {
			if (logger.isDebugEnabled()) {
				//e.printStackTrace();
			}

			byte[] imgByte = IOUtils.toByteArray(in);
			setResponseOutputStream(responseOutputStream, response, imgByte);

			logger.infoCode("I0002", "userMyPhoto"); // I0002=メソッド終了:{0}

		} finally {
			try {
				if (responseOutputStream != null) {
					responseOutputStream.close();
				}
				IOUtils.closeQuietly(in);
				if (in != null) {
					in.close();
				}
			} catch (IOException e) {
				;
			}
		}
	}

	/**
	 * 顔写真を取得(内部表示向け、ユーザー指定)
	 *
	 *
	 * @param userKey
	 *            ユーザーキー
	 * @param locale
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = { "/user/{userKey}/photo" },
			headers = "Accept=image/jpeg, image/jpg, image/png, image/gif, image/bmp", method = RequestMethod.GET)
	public void userPhoto(@PathVariable("userKey") String userKey, HttpServletResponse response, Locale locale)
			throws IOException {

		logger.infoCode("I0001", "userPhoto"); // I0001=メソッド開始:{0}

		ServletOutputStream responseOutputStream = null;
		InputStream in = null;
		// ダミー画像取得(男性)
		in = fileApiController.class.getResourceAsStream(DUMMY_PHOT_MAN);
		//
		try {
			// userKeyから画像データ取得(内部公開判定)
			UsUserTbl u = userServiceImpl.findOne(userKey);
			// ダミー画像取得(女性)の場合
			if (u != null && CommonConst.SEX_WOMAN.equals(u.getSex())) {
				in = fileApiController.class.getResourceAsStream(DUMMY_PHOT_WOMAN);
			}
			// 大学・企業
			if (u != null && Arrays.asList(CommonConst.USER_KBN_PARTY_LIST).contains(u.getUserKbn())) {
				in = fileApiController.class.getResourceAsStream(DUMMY_PHOT_PARTY);
			}
			// 画像
			if (u != null && StringUtil.isNotNull(u.getUploadKey()) && isPublicFlagInside(u.getUserPublicFlag())) {
				FileDto fileDto = fileService.getFile(u.getUploadKey());
				if (fileDto == null) {
					throw new Exception("fileDto is null.");
				}
				File downloadFile = new File(fileDto.getUploadPath());
				in = new FileInputStream(downloadFile);
			}

			byte[] imgByte = IOUtils.toByteArray(in);
			setResponseOutputStream(responseOutputStream, response, imgByte);

			logger.infoCode("I0002", "userPhoto"); // I0002=メソッド終了:{0}

		} catch (Exception e) {
			if (logger.isDebugEnabled()) {
				//e.printStackTrace();
			}

			byte[] imgByte = IOUtils.toByteArray(in);
			setResponseOutputStream(responseOutputStream, response, imgByte);

			logger.infoCode("I0002", "userPhoto"); // I0002=メソッド終了:{0}

		} finally {
			try {
				if (responseOutputStream != null) {
					responseOutputStream.close();
				}
				IOUtils.closeQuietly(in);
				if (in != null) {
					in.close();
				}
			} catch (IOException e) {
				;
			}
		}
	}


	/**
	 * 検索、基本情報表示向けその他成果物ファイル取得(内部表示向け)
	 *
	 * @param userKey
	 * @param gyosekiKey
	 * @param request
	 * @param response
	 * @param locale
	 */
	@RequestMapping(value = {"/user/{userKey}/result/{gyosekiKey}", "/user/{userKey}/result/{gyosekiKey}/{publicFlag}"})
	public void downloadResult(@PathVariable("userKey") String userKey, @PathVariable("gyosekiKey") String gyosekiKey, HttpServletRequest request,
			@PathVariable("publicFlag") Optional<String> publicFlag,
			HttpServletResponse response, Locale locale) {

		logger.infoCode("I0001", "downloadResult"); // I0001=メソッド開始:{0}

		download(userKey, gyosekiKey, publicFlag, request, response, locale, DOWNLOAD_RESULT);

		logger.infoCode("I0002", "downloadResult"); // I0002=メソッド終了:{0}
	}


	/**
	 * 検索、基本情報表示向け３分間コンペティションファイル取得(内部表示向け)
	 *
	 * @param userKey
	 * @param gyosekiKey
	 * @param request
	 * @param response
	 * @param model
	 * @param attributes
	 * @param locale
	 */
	@RequestMapping(value = {"/user/{userKey}/competitionMove/{gyosekiKey}", "/user/{userKey}/competitionMove/{gyosekiKey}/{publicFlag}"})
	public void downloadCompetitionMove(@PathVariable("userKey") String userKey, @PathVariable("gyosekiKey") String gyosekiKey, HttpServletRequest request,
			@PathVariable("publicFlag") Optional<String> publicFlag,
			HttpServletResponse response, Locale locale) {

		logger.infoCode("I0001", "downloadCompetitionMove"); // I0001=メソッド開始:{0}

		download(userKey, gyosekiKey, publicFlag, request, response, locale, DOWNLOAD_COMPETITION_MOVE);

		logger.infoCode("I0002", "downloadCompetitionMove"); // I0002=メソッド終了:{0}
	}

	/**
	 * 検索、基本情報表示向け共通ファイル取得(内部表示向け)
	 *
	 * @param userKey
	 * @param gyosekiKey
	 * @param request
	 * @param response
	 * @param locale
	 * @param kbn
	 */
	private void download(String userKey, String gyosekiKey, Optional<String> publicFlag, HttpServletRequest request,
			HttpServletResponse response, Locale locale, String kbn) {
		logger.infoCode("I0001", "download"); // I0001=メソッド開始:{0}

		ServletOutputStream responseOutputStream = null;
		InputStream in = null;
		try {

			UsUserTbl u = userServiceImpl.findOne(userKey);

			if (u == null) {
				// 存在しなければ404を返す。
				response.sendError(HttpServletResponse.SC_NOT_FOUND);
				return;
			}

			String[] publicFlags = PUBLIC_FLAG_INSIDE; // 公開判定
			// ユーザーキーと対象者が同じ場合
			if (userInfo != null && userInfo.getTargetUserKey().equals(userKey)) {
				if(publicFlag.isPresent()){
					if (isPublicFlagNot(publicFlag.get())) {
						publicFlags = PUBLIC_FLAG_ALL; // 全て表示
					} else if (isPublicFlagInside(publicFlag.get())) {
						publicFlags = PUBLIC_FLAG_INSIDE; // 内部公開判定
					} else if (isPublicFlagOutside(publicFlag.get())) {
						publicFlags = PUBLIC_FLAG_OUTSIDE; // 外部公開
					}
				}
			} else {
				// 表示しようとしている人がコンソーシアム外の場合
				if (userInfo.isOther()) {
					publicFlags = PUBLIC_FLAG_OUTSIDE;
					if (!isPublicFlagOutside(u.getUserPublicFlag())) {
						// 外部公開でなければ404を返す。
						response.sendError(HttpServletResponse.SC_NOT_FOUND);
						return;
					}
				} else {
					if (!isPublicFlagInside(u.getUserPublicFlag())) {
						// 非公開の場合は404を返す。
						response.sendError(HttpServletResponse.SC_NOT_FOUND);
						return;
					}
				}
			}

			FileDto fileChkDto = null;
			if (DOWNLOAD_COMPETITION_MOVE.equals(kbn)) {
				// ３分間コンペティションファイル取得
				fileChkDto = competitionUploadServiceImpl.findOneFile(userKey, gyosekiKey, publicFlags);
			} else if (DOWNLOAD_RESULT.equals(kbn))  {
				// その他成果物ファイル取得
				fileChkDto = resultUploadServiceImpl.findOneFile(userKey, gyosekiKey, publicFlags);
			}

			if (fileChkDto == null) {
				// ファイルが見つかれなければ404を返す。
				response.sendError(HttpServletResponse.SC_NOT_FOUND);
				return;
			}

			// 物理ファイル取得
			FileDto fileDto = fileService.getFile(fileChkDto.getUploadKey());

			if (fileDto != null) {
				in = new FileInputStream(fileDto.getUploadPath());
				byte[] fileByte = IOUtils.toByteArray(in);

				if (fileByte == null) { // 失敗?
					// 500エラーとする。
					logger.errorCode("E0014", "failed to prepare file");
					throw new RuntimeException();
				}
				// safariの場合
				if (request.getHeader("User-Agent").toUpperCase().indexOf("SAFARI") > -1) {
					response.setHeader(HttpHeaders.CONTENT_DISPOSITION,
							"attachment; filename=" + new String(fileDto.getUploadName().getBytes(), "ISO-8859-1"));
				} else {
					response.setHeader(HttpHeaders.CONTENT_DISPOSITION,
							"attachment; filename=" + fileDto.getUploadName() + ";filename*=utf-8''"
									+ URLEncoder.encode(fileDto.getUploadName(), "UTF-8"));
				}
				setResponseOutputStream(responseOutputStream, response, fileByte);
			}

		} catch (Exception e) {
			;
		} finally {
			try {
				if (responseOutputStream != null) {
					responseOutputStream.close();
				}
				IOUtils.closeQuietly(in);
				if (in != null) {
					in.close();
				}
			} catch (IOException e) {
				;
			}
		}

		logger.infoCode("I0002", "download"); // I0002=メソッド終了:{0}
	}


	/**
	 * ファイルデータ(byte[])をMimeTpe判定してレスポンス設定
	 *
	 * @param responseOutputStream
	 * @param response
	 * @param fileByte
	 * @throws IOException
	 */
	private void setResponseOutputStream(ServletOutputStream responseOutputStream, HttpServletResponse response,
			byte[] fileByte) throws IOException {

		// MimeTpe判定
		MimeUtil.registerMimeDetector("eu.medsea.mimeutil.detector.MagicMimeMimeDetector");
		Collection<?> mimeTypes = MimeUtil.getMimeTypes(fileByte);
		String contentType = "application/octet-stream";
		if (!mimeTypes.isEmpty()) {
			Iterator<?> iterator = mimeTypes.iterator();
			MimeType mimeType = (MimeType) iterator.next();
			contentType = mimeType.getMediaType() + "/" + mimeType.getSubType();
		}

		// レスポンスに設定
		response.setHeader("Cache-Control", "no-store");
		response.setHeader("Pragma", "no-cache");
		response.setDateHeader("Expires", 0);
		response.setContentType(contentType);
		response.setCharacterEncoding("utf-8");
		responseOutputStream = response.getOutputStream();
		responseOutputStream.write(fileByte);
		responseOutputStream.flush();

	}
}
