/*
* ファイル名：ProfileCommonController.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.portfolio;

import java.util.List;
import java.util.Locale;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonController;
import jp.co.sraw.controller.portfolio.form.PortfolioProfileForm;
import jp.co.sraw.controller.portfolio.service.AcademicServiceImpl;
import jp.co.sraw.controller.portfolio.service.BiblioServiceImpl;
import jp.co.sraw.controller.portfolio.service.CareerServiceImpl;
import jp.co.sraw.controller.portfolio.service.CompetitionServiceImpl;
import jp.co.sraw.controller.portfolio.service.CompetitionUploadServiceImpl;
import jp.co.sraw.controller.portfolio.service.ConferenceServiceImpl;
import jp.co.sraw.controller.portfolio.service.DegreeServiceImpl;
import jp.co.sraw.controller.portfolio.service.OthersServiceImpl;
import jp.co.sraw.controller.portfolio.service.PaperServiceImpl;
import jp.co.sraw.controller.portfolio.service.PatentServiceImpl;
import jp.co.sraw.controller.portfolio.service.PrizeServiceImpl;
import jp.co.sraw.controller.portfolio.service.ResearchAreaServiceImpl;
import jp.co.sraw.controller.portfolio.service.ResearchKeywordServiceImpl;
import jp.co.sraw.controller.portfolio.service.ResultUploadServiceImpl;
import jp.co.sraw.controller.portfolio.service.SocietyServiceImpl;
import jp.co.sraw.controller.portfolio.service.WorksServiceImpl;
import jp.co.sraw.dto.MsCodeDto;
import jp.co.sraw.entity.MsPartyTbl;
import jp.co.sraw.entity.UsCompetitionTbl;
import jp.co.sraw.file.FileDto;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.service.MsPartyServiceImpl;
import jp.co.sraw.service.PortfolioProfileServiceImpl;
import jp.co.sraw.service.ResultUploadImpl;
import jp.co.sraw.util.DbUtil;
import jp.co.sraw.util.StringUtil;

/**
 * <B>ProfileCommonControllerクラス</B>
 * <P>
 * Controllerのメソッドを提供する
 */
public class ProfileCommonController extends CommonController {

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(ProfileCommonController.class);

	@Autowired
	private PortfolioProfileServiceImpl portfolioProfileServiceImpl;

	@Autowired
	private PaperServiceImpl paperServiceImpl;

	@Autowired
	private ConferenceServiceImpl conferenceServiceImpl;

	@Autowired
	private BiblioServiceImpl biblioServiceImpl;

	@Autowired
	private ResearchKeywordServiceImpl researchKeywordServiceImpl;

	@Autowired
	private ResearchAreaServiceImpl researchAreaServiceImpl;

	@Autowired
	private SocietyServiceImpl societyServiceImpl;

	@Autowired
	private WorksServiceImpl worksServiceImpl;

	@Autowired
	private PatentServiceImpl patentServiceImpl;

	@Autowired
	private AcademicServiceImpl academicServiceImpl;

	@Autowired
	private CareerServiceImpl careerServiceImpl;

	@Autowired
	private PrizeServiceImpl prizeServiceImpl;

	@Autowired
	private OthersServiceImpl othersServiceImpl;

	@Autowired
	private DegreeServiceImpl degreeServiceImpl;

	@Autowired
	private CompetitionServiceImpl competitionServiceImpl;

	@Autowired
	private ResultUploadImpl resultUploadImpl;

	@Autowired
	private MsPartyServiceImpl msPartyServiceImpl;

	@Autowired
	private ResultUploadServiceImpl resultUploadServiceImpl;

	@Autowired
	private CompetitionUploadServiceImpl competitionUploadServiceImpl;

	// 表示
	protected static final String LIST_SHOWDOCTOR_PAGE = "portfolio/profile/showDoctor"; // 若手研究者
	protected static final String LIST_SHOWTEACHER_PAGE = "portfolio/profile/showTeacher"; // 教職員
	protected static final String LIST_SHOWCONSUL_PAGE = "portfolio/profile/showConsul"; // 相談員
	protected static final String LIST_SHOWMGMT_PAGE = "portfolio/profile/showMgmt"; // 事務局
	protected static final String LIST_SHOWPARTY_PAGE = "portfolio/profile/showParty"; // 企業


	@PostConstruct
	protected void init() {
		logger.setMessageSource(messageSource);
	}


	protected void setListToModel(Model model, String listName, Locale locale) {
		List<MsCodeDto> list = DbUtil.getJosuList(listName, locale);
		model.addAttribute("list" + listName, list);
	}

	protected void setListToModel(@ModelAttribute(CommonConst.FORM_NAME) PortfolioProfileForm form, Model model,
			String searchUserKey) {

		//logger.infoCode("I0001", "setListToModel"); // I0001=メソッド開始:{0}

		// 公開フラグ
		String[] publicFlag = null;
		if (StringUtil.isNull(form.getPublicFlag())) {
			form.setPublicFlag("0");
		}

		// 全公開
		if (form.getPublicFlag().equals("2")) {
			publicFlag = new String[] { "2" };
		}

		// 内部公開
		if (form.getPublicFlag().equals("1")) {
			publicFlag = new String[] { "2", "1" };
		}

		// 全て表示
		if (form.getPublicFlag().equals("0")) {
			publicFlag = new String[] { "2", "1", "0" };
		}

		List<MsPartyTbl> listParty = msPartyServiceImpl.findAllByPartyKbn(publicFlag);
		model.addAttribute("listParty", listParty);

		// 業績情報・論文
		model.addAttribute("gyPaperTblList", paperServiceImpl.findAllProfileView(searchUserKey, publicFlag));
		// 業績情報・講演・口頭発表等
		model.addAttribute("gyConferenceTblList", conferenceServiceImpl.findAllProfileView(searchUserKey, publicFlag));
		// 業績情報・書籍
		model.addAttribute("gyBiblioTblList", biblioServiceImpl.findAllProfileView(searchUserKey, publicFlag));
		// 業績情報・研究キーワード
		model.addAttribute("gyResearchKeywordTblList",
				researchKeywordServiceImpl.findAllProfileView(searchUserKey, publicFlag));
		// 業績情報・研究分野
		model.addAttribute("gyResearchAreaTblList",
				researchAreaServiceImpl.findAllProfileView(searchUserKey, publicFlag));
		// 業績情報・所属学協会
		model.addAttribute("gySocietyTblList", societyServiceImpl.findAllProfileView(searchUserKey, publicFlag));
		// 業績情報・Works
		model.addAttribute("gyWorksTblList", worksServiceImpl.findAllProfileView(searchUserKey, publicFlag));
		// 業績情報・特許
		model.addAttribute("gyPatentTblList", patentServiceImpl.findAllProfileView(searchUserKey, publicFlag));
		// 業績情報・学歴
		model.addAttribute("gyAcademicTblList", academicServiceImpl.findAllProfileView(searchUserKey, publicFlag));
		// 業績情報・経歴
		model.addAttribute("gyCareerTblList", careerServiceImpl.findAllProfileView(searchUserKey, publicFlag));
		// 業績情報・受賞
		model.addAttribute("gyPrizeTblList", prizeServiceImpl.findAllProfileView(searchUserKey, publicFlag));
		// 業績情報・その他
		model.addAttribute("gyOthersTblList", othersServiceImpl.findAllProfileView(searchUserKey, publicFlag));
		// 業績情報・学位
		model.addAttribute("gyDegreeTblList", degreeServiceImpl.findAllProfileView(searchUserKey, publicFlag));
		// 業績情報・競争的資金等の研究課題
		model.addAttribute("GyCompetitionTblList",
				competitionServiceImpl.findAllProfileView(searchUserKey, publicFlag));

		// 成果物ファイル
		List<FileDto> usResultUploadTblList = resultUploadServiceImpl.findAll(searchUserKey, publicFlag);
		model.addAttribute("usResultUploadTblList", usResultUploadTblList);

		// コンペティションファイルVIEW
		List<UsCompetitionTbl> usCompetitionTblList = portfolioProfileServiceImpl.findAllUsCompetition(searchUserKey,
				publicFlag);
		model.addAttribute("usCompetitionTblList", usCompetitionTblList);

		// PR動画ファイル
		List<FileDto> usPrmovieUploadTblList = competitionUploadServiceImpl.findAll(searchUserKey, publicFlag);
		model.addAttribute("usPrmovieUploadTblList", usPrmovieUploadTblList);

		//logger.infoCode("I0002", "setListToModel"); // I0002=メソッド終了:{0}

	}
}
