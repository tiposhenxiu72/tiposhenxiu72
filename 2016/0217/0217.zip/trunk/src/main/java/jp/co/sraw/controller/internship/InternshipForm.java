/*
* ファイル名：InternshipForm.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.internship;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.validator.constraints.NotBlank;
import org.maru.m4hv.extensions.constraints.CharLength;

import jp.co.sraw.common.CommonForm;
import jp.co.sraw.file.FileDto;
import jp.co.sraw.validation.AlphaNumberSymbol;

/**
 * <B>InternshipFormクラス</B>
 * <P>
 * Formのメソッドを提供する
 */
public class InternshipForm extends CommonForm {

	private String searchDateType; // 検索条件：期間

	private String searchPublicFlag; // 検索条件：公開フラグ

	private String internshipKey;

	@CharLength(max = 100)
	private String eventUnit;

	@NotBlank
	private String internshipSendDate;

	@NotBlank
	private String internshipEndDate;

	private String internshipGkFileNeedKbn;

	@NotBlank
	private String internshipKbn;

	@NotBlank
	@CharLength(max = 10000)
	private String internshipMemo;

	@NotBlank
	@CharLength(max = 100)
	private String internshipPartyName;

	@NotBlank
	@CharLength(max = 100)
	private String internshipRange;

	@CharLength(max = 256)
	private String internshipRcFile;

	@CharLength(max = 256)
	private String internshipGkFile;

	private String internshipRcFileNeedKbn;

	@NotBlank
	private String internshipStartDate;

	@NotBlank
	@AlphaNumberSymbol
	@CharLength(max = 100)
	private String internshipTelno;

	@NotBlank
	@CharLength(max = 100)
	private String internshipTitle;

	private String partyCode;

	private String publicFlag;

	private String publicKbn;

	private String subjectInsKbn;

	private Timestamp updDate;

	private String updUserKey;

	private List<FileDto> uploadFileList = new ArrayList<FileDto>();

	public List<FileDto> getUploadFileList() {
		return uploadFileList;
	}

	/**
	 * 応募文書の場合、’１’。合格文書の場合、’２’。
	 *
	 * @param uploadFileList
	 */
	public void setUploadFileList(List<FileDto> uploadFileList) {
		if (uploadFileList != null) {
			this.uploadFileList = uploadFileList;
		} else {
			this.uploadFileList = new ArrayList<FileDto>();
		}
	}

	public void setUploadFileListFromDB(List<FileDto> uploadFileList) {
		if (uploadFileList != null && uploadFileList.size() > 0)
			for (FileDto dto : uploadFileList) {
				// 応募文書の場合、’１’。
				if (dto.getFileKbn().equals("1")) {
					dto.setFieldName("rcFiles");
				}
				// 合格文書の場合、’２’。
				if (dto.getFileKbn().equals("2")) {
					dto.setFieldName("gkFiles");
				}
			}
		this.uploadFileList = uploadFileList;
	}

//	public void setUploadFileListFromHtml(List<FileDto> uploadFileList) {
//		if (uploadFileList != null && uploadFileList.size() > 0)
//			for (FileDto dto : uploadFileList) {
//				// 応募文書の場合、’１’。
//				if (dto.getFieldName().equals("gkFiles")) {
//					dto.SetFileKbn("1");
//				}
//				// 合格文書の場合、’２’。
//				if (dto.getFieldName().equals("rcFiles")) {
//					dto.SetFileKbn("2");
//				}
//			}
//		this.uploadFileList = uploadFileList;
//	}

	public String getInternshipKey() {
		return internshipKey;
	}

	public void setInternshipKey(String internshipKey) {
		this.internshipKey = internshipKey;
	}

	public String getEventUnit() {
		return eventUnit;
	}

	public void setEventUnit(String eventUnit) {
		this.eventUnit = eventUnit;
	}

	public String getInternshipSendDate() {
		return internshipSendDate;
	}

	public void setInternshipSendDate(String internshipSendDate) {
		this.internshipSendDate = internshipSendDate;
	}

	public String getInternshipEndDate() {
		return internshipEndDate;
	}

	public void setInternshipEndDate(String internshipEndDate) {
		this.internshipEndDate = internshipEndDate;
	}

	public String getInternshipGkFileNeedKbn() {
		return internshipGkFileNeedKbn;
	}

	public void setInternshipGkFileNeedKbn(String internshipGkFileNeedKbn) {
		this.internshipGkFileNeedKbn = internshipGkFileNeedKbn;
	}

	public String getInternshipGkFile() {
		String gkSplit = "";
		if (this.uploadFileList.size() > 0) {
			String gpFile = "";
			for (FileDto dto : this.uploadFileList) {
				if (dto.getFileKbn().equals("1")) {
					gpFile = gpFile + gkSplit + dto.getUploadName();
					gkSplit = ",";
				}
			}
			return gpFile;
		}
		return internshipGkFile;
	}

	public void setInternshipGkFile(String internshipGkFile) {
		this.internshipGkFile = internshipGkFile;
	}

	public String getInternshipKbn() {
		return internshipKbn;
	}

	public void setInternshipKbn(String internshipKbn) {
		this.internshipKbn = internshipKbn;
	}

	public String getInternshipMemo() {
		return internshipMemo;
	}

	public void setInternshipMemo(String internshipMemo) {
		this.internshipMemo = internshipMemo;
	}

	public String getInternshipPartyName() {
		return internshipPartyName;
	}

	public void setInternshipPartyName(String internshipPartyName) {
		this.internshipPartyName = internshipPartyName;
	}

	public String getInternshipRange() {
		return internshipRange;
	}

	public void setInternshipRange(String internshipRange) {
		this.internshipRange = internshipRange;
	}

	public String getInternshipRcFileNeedKbn() {
		return internshipRcFileNeedKbn;
	}

	public void setInternshipRcFileNeedKbn(String internshipRcFileNeedKbn) {
		this.internshipRcFileNeedKbn = internshipRcFileNeedKbn;
	}

	public String getInternshipRcFile() {
		String rcSplit = "";
		if (this.uploadFileList.size() > 0) {
			String rcFile = "";
			for (FileDto dto : this.uploadFileList) {
				if (dto.getFileKbn().equals("1")) {
					rcFile = rcFile + rcSplit + dto.getUploadName();
					rcSplit = ",";
				}
			}
			return rcFile;
		}
		return internshipRcFile;
	}

	public void setInternshipRcFile(String internshipRcFile) {
		this.internshipRcFile = internshipRcFile;
	}

	public String getInternshipStartDate() {
		return internshipStartDate;
	}

	public void setInternshipStartDate(String internshipStartDate) {
		this.internshipStartDate = internshipStartDate;
	}

	public String getInternshipTelno() {
		return internshipTelno;
	}

	public void setInternshipTelno(String internshipTelno) {
		this.internshipTelno = internshipTelno;
	}

	public String getInternshipTitle() {
		return internshipTitle;
	}

	public void setInternshipTitle(String internshipTitle) {
		this.internshipTitle = internshipTitle;
	}

	public String getPartyCode() {
		return partyCode;
	}

	public void setPartyCode(String partyCode) {
		this.partyCode = partyCode;
	}

	public String getPublicFlag() {
		return publicFlag;
	}

	public void setPublicFlag(String publicFlag) {
		this.publicFlag = publicFlag;
	}

	public String getPublicKbn() {
		return publicKbn;
	}

	public void setPublicKbn(String publicKbn) {
		this.publicKbn = publicKbn;
	}

	public String getSubjectInsKbn() {
		return subjectInsKbn;
	}

	public void setSubjectInsKbn(String subjectInsKbn) {
		this.subjectInsKbn = subjectInsKbn;
	}

	public Timestamp getUpdDate() {
		return updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUpdUserKey() {
		return updUserKey;
	}

	public void setUpdUserKey(String updUserKey) {
		this.updUserKey = updUserKey;
	}

	public String getSearchPublicFlag() {
		return searchPublicFlag;
	}

	public void setSearchPublicFlag(String searchPublicFlag) {
		this.searchPublicFlag = searchPublicFlag;
	}

	public String getSearchDateType() {
		return searchDateType;
	}

	public void setSearchDateType(String searchDateType) {
		this.searchDateType = searchDateType;
	}

	private String publicItemArray;

	/**
	 * @return publicItemArray
	 */
	public String[] getPublicItemArray() {
		String[] array = new String[] {};
		if (this.publicItemArray != null)
			array = this.publicItemArray.replace("，", ",").split(",");
		return array;
	}

	/**
	 * @param publicItemArray
	 *            セットする publicItemArray
	 */
	public void setPublicItemArray(String[] publicItemArray) {
		String separator = "";
		String sybCode = "";
		for (int i = 0; i < publicItemArray.length; i++) {
			sybCode = sybCode + separator + publicItemArray[i];
			separator = ",";
		}
		this.publicItemArray = sybCode;
	}

	public boolean checkHasPublicItem(String kbh) {
		return this.publicItemArray.contains(kbh);
	}

	private String publicPartyList;

	public void setPublicPartyList(String publicPartyList) {
		this.publicPartyList = publicPartyList;
	}

	public String[] getPublicPartyList() {
		String[] array = new String[] {};
		if (this.publicPartyList != null)
			array = this.publicPartyList.replace("，", ",").split(",");
		return array;
	}
}
