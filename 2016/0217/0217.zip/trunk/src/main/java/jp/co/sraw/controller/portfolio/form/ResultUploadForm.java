/*
* ファイル名：OthersForm.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.portfolio.form;

import java.sql.Timestamp;

import jp.co.sraw.entity.GyCommonTbl;
import jp.co.sraw.entity.UsResultUploadTbl;

/**
 * <B>GyOthersFormクラス</B>
 * <P>
 * Formのメソッドを提供する
 */
public class ResultUploadForm extends GyUploadForm {

	public ResultUploadForm() {
		super();
	}

	private Timestamp insDate;

	public Timestamp getInsDate() {
		return this.insDate;
	}

	public void setInsDate(Timestamp insDate) {
		this.insDate = insDate;
	}

	@Override
	public GyCommonTbl getNewTbl() {
		return new UsResultUploadTbl();
	}

}
