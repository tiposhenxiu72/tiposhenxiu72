/*
* ファイル名：fileApiController.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/02/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.api;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;
import java.util.Iterator;
import java.util.Locale;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import eu.medsea.mimeutil.MimeType;
import eu.medsea.mimeutil.MimeUtil;
import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonController;
import jp.co.sraw.entity.UsUserTbl;
import jp.co.sraw.file.FileDto;
import jp.co.sraw.file.FileService;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.service.UserServiceImpl;
import jp.co.sraw.util.StringUtil;

/**
 * <B>fileApiControllerクラス</B>
 * <P>
 * ファイルAPIのメソッドを提供する
 */
@RestController
@RequestMapping(CommonConst.PATH_API + "/file")
public class fileApiController extends CommonController {
	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(fileApiController.class);

	private static String DUMMY_PHOT_MAN = "/static/img/face.gif";
	private static String DUMMY_PHOT_WOMAN = "/static/img/face2.gif";

	@Autowired
	private UserServiceImpl userServiceImpl;

	@Autowired
	private FileService fileService;

	@PostConstruct
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	/**
	 * 顔写真を取得(表示、自分、公開判定)
	 *
	 * @param userKey
	 * @param userPublicFlag
	 *            公開設定
	 * @param mode
	 *            オプション 表示モード(1:常に表示)
	 * @param locale
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = { "/user/{userKey}/photo/{userPublicFlag}", "/user/{userKey}/photo/{userPublicFlag}/{mode}" },
			headers = "Accept=image/jpeg, image/jpg, image/png, image/gif, image/bmp", method = RequestMethod.GET)
	public void userMyPhoto(@PathVariable("userKey") String userKey,
			@PathVariable("userPublicFlag") String userPublicFlag, @PathVariable("mode") Optional<String> mode,
			HttpServletResponse response, Locale locale) throws IOException {

		logger.infoCode("I0001", "userMyPhoto"); // I0001=メソッド開始:{0}

		ServletOutputStream responseOutputStream = null;
		InputStream in = null;
		// ダミー画像取得
		in = fileApiController.class.getResourceAsStream(DUMMY_PHOT_MAN);
		// 女性の場合
		if (userInfo != null && CommonConst.SEX_WOMAN.equals(userInfo.getTargetSex())) {
			in = fileApiController.class.getResourceAsStream(DUMMY_PHOT_WOMAN);
		}
		//
		try {
			// ユーザーキーと対象者が同じ場合
			if (userInfo != null && userInfo.getTargetUserKey().equals(userKey)) {
				// userInfoから画像データ取得
				UsUserTbl u = userServiceImpl.findOne(userInfo.getTargetUserKey());
				// buttonFlag:1の場合、メニューなどの顔写真
				// userPublicFlag:非公開指定の場合＝全て公開、内部公開指定＝内部公開＆全公開、全公開の場合＝全公開
				if (u != null && StringUtil.isNotNull(u.getUploadKey()) && ((mode.isPresent() && "1".equals(mode.get()))
						|| isPortfolioPublicFlag(u.getUserPublicFlag(), userPublicFlag))) {
					FileDto fileDto = fileService.getFile(u.getUploadKey());
					if (fileDto == null) {
						throw new Exception("fileDto is null.");
					}
					File downloadFile = new File(fileDto.getUploadPath());
					in = new FileInputStream(downloadFile);
				}
			}

			byte[] imgByte = IOUtils.toByteArray(in);
			setResponseOutputStream(responseOutputStream, response, imgByte);

			logger.infoCode("I0002", "userMyPhoto"); // I0002=メソッド終了:{0}

		} catch (Exception e) {
			if (logger.isDebugEnabled()) {
				//e.printStackTrace();
			}

			byte[] imgByte = IOUtils.toByteArray(in);
			setResponseOutputStream(responseOutputStream, response, imgByte);

			logger.infoCode("I0002", "userMyPhoto"); // I0002=メソッド終了:{0}

		} finally {
			try {
				if (responseOutputStream != null) {
					responseOutputStream.close();
				}
				IOUtils.closeQuietly(in);
				if (in != null) {
					in.close();
				}
			} catch (IOException e) {
				;
			}
		}
	}

	/**
	 * 顔写真を取得(内部表示向け、ユーザー指定)
	 *
	 *
	 * @param userKey
	 *            ユーザーキー
	 * @param locale
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = { "/user/{userKey}/photo" },
			headers = "Accept=image/jpeg, image/jpg, image/png, image/gif, image/bmp", method = RequestMethod.GET)
	public void userPhoto(@PathVariable("userKey") String userKey, HttpServletResponse response, Locale locale)
			throws IOException {

		logger.infoCode("I0001", "userPhoto"); // I0001=メソッド開始:{0}

		ServletOutputStream responseOutputStream = null;
		InputStream in = null;
		// ダミー画像取得(男性)
		in = fileApiController.class.getResourceAsStream(DUMMY_PHOT_MAN);
		//
		try {
			// userKeyから画像データ取得(内部公開判定)
			UsUserTbl u = userServiceImpl.findOne(userKey);
			// ダミー画像取得(女性)の場合
			if (u != null && CommonConst.SEX_WOMAN.equals(u.getSex())) {
				in = fileApiController.class.getResourceAsStream(DUMMY_PHOT_WOMAN);
			}
			// 画像
			if (u != null && StringUtil.isNotNull(u.getUploadKey()) && isPublicFlagInside(u.getUserPublicFlag())) {
				FileDto fileDto = fileService.getFile(u.getUploadKey());
				if (fileDto == null) {
					throw new Exception("fileDto is null.");
				}
				File downloadFile = new File(fileDto.getUploadPath());
				in = new FileInputStream(downloadFile);
			}

			byte[] imgByte = IOUtils.toByteArray(in);
			setResponseOutputStream(responseOutputStream, response, imgByte);

			logger.infoCode("I0002", "userPhoto"); // I0002=メソッド終了:{0}

		} catch (Exception e) {
			if (logger.isDebugEnabled()) {
				//e.printStackTrace();
			}

			byte[] imgByte = IOUtils.toByteArray(in);
			setResponseOutputStream(responseOutputStream, response, imgByte);

			logger.infoCode("I0002", "userPhoto"); // I0002=メソッド終了:{0}

		} finally {
			try {
				if (responseOutputStream != null) {
					responseOutputStream.close();
				}
				IOUtils.closeQuietly(in);
				if (in != null) {
					in.close();
				}
			} catch (IOException e) {
				;
			}
		}
	}

	/**
	 * ファイルデータ(byte[])をMimeTpe判定してレスポンス設定
	 *
	 * @param responseOutputStream
	 * @param response
	 * @param imgByte
	 * @throws IOException
	 */
	private void setResponseOutputStream(ServletOutputStream responseOutputStream, HttpServletResponse response,
			byte[] imgByte) throws IOException {

		// MimeTpe判定
		MimeUtil.registerMimeDetector("eu.medsea.mimeutil.detector.MagicMimeMimeDetector");
		Collection<?> mimeTypes = MimeUtil.getMimeTypes(imgByte);
		String contentType = "application/octet-stream";
		if (!mimeTypes.isEmpty()) {
			Iterator<?> iterator = mimeTypes.iterator();
			MimeType mimeType = (MimeType) iterator.next();
			contentType = mimeType.getMediaType() + "/" + mimeType.getSubType();
		}

		// レスポンスに設定
		response.setHeader("Cache-Control", "no-store");
		response.setHeader("Pragma", "no-cache");
		response.setDateHeader("Expires", 0);
		response.setContentType(contentType);
		responseOutputStream = response.getOutputStream();
		responseOutputStream.write(imgByte);
		responseOutputStream.flush();

	}
}
