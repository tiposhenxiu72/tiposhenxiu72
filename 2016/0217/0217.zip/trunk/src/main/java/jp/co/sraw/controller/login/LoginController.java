/*
* ファイル名：LoginController.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.login;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationDetailsSource;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.security.web.authentication.rememberme.TokenBasedRememberMeServices;
import org.springframework.security.web.savedrequest.HttpSessionRequestCache;
import org.springframework.security.web.savedrequest.SavedRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonController;
import jp.co.sraw.common.UserInfo;
import jp.co.sraw.config.WebSecurityConfig;
import jp.co.sraw.dto.PartyDto;
import jp.co.sraw.entity.MsPartyTbl;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.security.gakunin.Gakunin;
import jp.co.sraw.service.MsPartyServiceImpl;
import jp.co.sraw.service.UserInfoServiceImpl;
import jp.co.sraw.util.StringUtil;

/**
* <B>LoginControllerクラス</B>
* <P>
* Controllerのメソッドを提供する
*/
@Controller
@RequestMapping("/")
public class LoginController extends CommonController {

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(LoginController.class);

	/** SSOページ用URL */
	private static final String ACTION_SSO_URL = "/ssologin";

	@Autowired
	private UserInfoServiceImpl userInfoServiceImpl;

	@Autowired
	private MsPartyServiceImpl msPartyServiceImpl;

	@PostConstruct
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	/**
	 * DB認証画面遷移＆クッキー認証
	 *
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/login")
	public String login(HttpServletRequest request, HttpServletResponse response, Model model, Locale locale) {
		logger.infoCode("I0001");

		// 有効な remember-me Cookie が存在する場合にはログイン画面を表示させず自動ログインさせる
		TokenBasedRememberMeServices rememberMeServices = new TokenBasedRememberMeServices(
				WebSecurityConfig.REMEMBERME_KEY, userInfoServiceImpl);
		// クッキー取得
		rememberMeServices.setCookieName(WebSecurityConfig.COOKIE_NAME);
		//
		Authentication rememberMeAuth = rememberMeServices.autoLogin(request, response);
		if (rememberMeAuth != null) {
			SecurityContextHolder.getContext().setAuthentication(rememberMeAuth);

			logger.infoCode("I0002", "login"); // I0002=メソッド終了:{0}
			return "redirect:" + WebSecurityConfig.DEFAULT_SUCCESS_URL;
		}

		// 学認するドメイン一覧取得
		Map<String, String> idpMap = new HashMap<String, String>();
		// 機関一覧取得
		List<PartyDto> partyList = getPartyList(locale);
		// 学認するドメインとidpのURLを設定
		for (Gakunin gakunin : super.getGakuninList()) {
			try {
				URL url = new URL(gakunin.getEntityID());
				for (PartyDto p : partyList) {
					String domain = p.getDomain();
					if (StringUtil.isNotNull(domain) && url.getHost().endsWith(domain)) {
						idpMap.put(domain, gakunin.getEntityID());
						break;
					}
				}
			} catch (Exception e) {
				if (logger.isDebugEnabled()) {
					e.printStackTrace();
				}
			}
		}
		//
		model.addAttribute("idpMap", idpMap);

		logger.infoCode("I0002", "login"); // I0002=メソッド終了:{0}
		return "login/login";
	}

	/**
	 * ログアウト
	 *
	 * @return
	 */
	@RequestMapping("/logout")
	public String logout() {
		logger.infoCode("I0001");
		return "login/login";
	}


	/**
	 * SSO認証(暫定)
	 *
	 * @param request
	 * @return
	 */
	@RequestMapping("/ssologin")
	public String urllogin(HttpServletRequest request, HttpServletResponse response) {
		logger.infoCode("I0001");

		boolean gakuninFlag = systemSetting.isGakuninFlag();
		String gakuninLoginId = systemSetting.getGakuninLoginId();
		if (gakuninFlag && StringUtil.isNotNull(gakuninLoginId)) {
			try {

				// ヘッダーパラメータ取得
				String username = request.getHeader(gakuninLoginId);

				if (StringUtil.isNotNull(username)) {
					// username パラメータで指定されたメールアドレスのユーザが user_info テーブルに存在するかチェックする
					UserInfo lendingUserInfo = userInfoServiceImpl.loadUserByUsername(username);
					if (lendingUserInfo != null) {
						// UsernamePasswordAuthenticationToken を生成して SecurityContext にセットする
						UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(lendingUserInfo, null,
								lendingUserInfo.getAuthorities());

						// org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter
						// setDetails メソッドを見て実装しています
						AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource = new WebAuthenticationDetailsSource();
						token.setDetails(authenticationDetailsSource.buildDetails(request));
						SecurityContextHolder.getContext().setAuthentication(token);

						// 認証前のリクエストURL取得
						// SavedRequest
						HttpSessionRequestCache httpSession = new HttpSessionRequestCache();
						SavedRequest savedRequest = httpSession.getRequest(request, response);
						String requestUrl = WebSecurityConfig.DEFAULT_SUCCESS_URL;
						if (savedRequest != null) {
							if (StringUtil.isNotNull(savedRequest.getRedirectUrl())) {
								requestUrl = savedRequest.getRedirectUrl();
							}
						}

						logger.infoCode("I0002", "ssologin"); // I0002=メソッド終了:{0}
						return "redirect:"+ requestUrl;
					}
				}
			} catch (UsernameNotFoundException e) {
				logger.infoCode("I0002", "ssologin"); // I0002=メソッド終了:{0}
				return "redirect:"+ WebSecurityConfig.DEFAULT_LOGIN_ERROR_URL;
			}
		}
		return "redirect:"+ WebSecurityConfig.DEFAULT_LOGIN_URL;
	}

	/**
	 * 組織一覧を取得
	 *
	 * @param locale
	 * @return
	 */
	private List<PartyDto> getPartyList(Locale locale){

		logger.infoCode("I0001", "partyList"); // I0001=メソッド開始:{0}

		List<MsPartyTbl> mList = msPartyServiceImpl.findAllByPartyKbn(null);
		List<PartyDto> resultList = new ArrayList<PartyDto>();
		for (MsPartyTbl m : mList) {
			String name = m.getPartyName();
			if (!CommonConst.DEFAULT_LOCALE.getLanguage().equals(locale.getLanguage())) {
				name = m.getPartyNameEn();
			}
			PartyDto dto = new PartyDto();
			dto.setCode(m.getPartyCode());
			dto.setName(name);
			dto.setKbn(m.getPartyKbn());
			dto.setDomain(m.getDomain());
			resultList.add(dto);
		}

		logger.infoCode("I0002", "partyList"); // I0002=メソッド終了:{0}
		return resultList;
	}

}
