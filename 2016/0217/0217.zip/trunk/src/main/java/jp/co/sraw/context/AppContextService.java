package jp.co.sraw.context;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

@Service
public class AppContextService {

	@Autowired
	private ApplicationContext context;

	public RoleObject getRole(String roleId) throws Exception {
		String[] roleList = context.getBeanNamesForType(RoleObject.class);
		for (String beanName : roleList) {
			if (beanName.contains("role_" + roleId)) {
				return (RoleObject) context.getBean(beanName);
			}
		}
		throw new Exception();
	}

}
