package jp.co.sraw.controller.skill;

import java.sql.Timestamp;
import java.util.Map;

import org.hibernate.validator.constraints.NotBlank;
import org.maru.m4hv.extensions.constraints.CharLength;

import jp.co.sraw.common.CommonForm;

public class CurriculumForm extends CommonForm {

	/** 能力養成科目キー */
	private String lessonKey;

	/** 能力養成科目名称 */
	@NotBlank
	@CharLength(min=1, max=100)
	private String lessonName;

	/** 組織コード */
	@CharLength(max=100)
	private String partyCode;

	/** 組織名称 */
	@CharLength(max=100)
	private String partyName;

	/** 開講部局 */
	@CharLength(max=100)
	private String lessonCode;

	/** 開講部局 */
	@CharLength(max=100)
	private String lessonDepartment;

	/**  担当教員名 */
	@CharLength(max=100)
	private String userName;

	/** 受講対象者 */
	@CharLength(max=100)
	private String lessonTarget;

	/** 学外聴講・傍聴の可否 */
	@CharLength(max=100)
	private String listenFlag;

	/** 開講期 */
	@CharLength(max=10)
	private String lessonDate;

	/** 曜日時限 */
	@CharLength(max=100)
	private String lessonPeriod;

	/** 中継の有無 */
	@CharLength(max=100)
	private String relayFlag;

	/** 中継聴講場所 */
	@CharLength(max=100)
	private String relayPlace;

	/** 授業形態 */
	@CharLength(max=100)
	private String lessonKbn;

	/** 単位 */
	@CharLength(max=100)
	private String unit;

	/** 学外受講生の単位互換 */
	@CharLength(max=100)
	private String unitInterchangeable;

	/** 必修選択の別 */
	@CharLength(max=100)
	private String lessonCompulsory;

	/** 成績評価基準 */
	@CharLength(max=100)
	private String lessonBase;

	/** 授業の目的概要 */
	@CharLength(max=10000)
	private String lessonIntention;

	/** 授業計画 */
	@CharLength(max=100)
	private String lessonPlan;

	/** 備考 */
	@CharLength(max=10000)
	private String lessonMemo;

	/** eラーニングリンク */
	@CharLength(max=10000)
	private String eLink;

	/** シラバスリンク */
	private String sLink;
	@CharLength(max=10000)

	/** 履修状況 */
	private String courseStatus;

	/** 更新日時 */
	private Timestamp updDate;

	/** 紐付け(能力ベースでのひも付け情報) */
	private Map<String, String> linkageMap;

	/** 科目ベースのひも付け情報 */
	private String skillJson;



	public CurriculumForm() {
		super();
	}

	public CurriculumForm(String lessonKey, String lessonName, String lessonCode, String lessonDepartment, String userName, String lessonTarget, String listenFlag, String lessonDate, String lessonPeriod, String relayFlag, String relayPlace, String lessonKbn, String unit, String unitInterchangeable, String lessonCompulsory, String lessonBase, String lessonIntention, String lessonPlan, String lessonMemo, String eLink, String sLink, String courseStatus, String partyCode, String partyName) {
		super();
		this.lessonKey = lessonKey;
		this.lessonName = lessonName;
		this.lessonCode = lessonCode;
		this.lessonDepartment = lessonDepartment;
		this.userName = userName;
		this.lessonTarget = lessonTarget;
		this.listenFlag = listenFlag;
		this.lessonDate = lessonDate;
		this.lessonPeriod = lessonPeriod;
		this.relayFlag = relayFlag;
		this.relayPlace = relayPlace;
		this.lessonKbn = lessonKbn;
		this.unit = unit;
		this.unitInterchangeable = unitInterchangeable;
		this.lessonCompulsory = lessonCompulsory;
		this.lessonBase = lessonBase;
		this.lessonIntention = lessonIntention;
		this.lessonPlan = lessonPlan;
		this.lessonMemo = lessonMemo;
		this.eLink = eLink;
		this.sLink = sLink;
		this.courseStatus = courseStatus;
		this.partyCode = partyCode;
		this.partyName = partyName;
	}

	public String getLessonKey() {
		return lessonKey;
	}

	public void setLessonKey(String lessonKey) {
		this.lessonKey = lessonKey;
	}

	public String getLessonName() {
		return lessonName;
	}

	public void setLessonName(String lessonName) {
		this.lessonName = lessonName;
	}

	public String getPartyCode() {
		return partyCode;
	}

	public void setPartyCode(String partyCode) {
		this.partyCode = partyCode;
	}

	public String getPartyName() {
		return partyName;
	}

	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}

	public String getLessonCode() {
		return lessonCode;
	}

	public void setLessonCode(String lessonCode) {
		this.lessonCode = lessonCode;
	}

	public String getLessonDepartment() {
		return lessonDepartment;
	}

	public void setLessonDepartment(String lessonDepartment) {
		this.lessonDepartment = lessonDepartment;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getLessonTarget() {
		return lessonTarget;
	}

	public void setLessonTarget(String lessonTarget) {
		this.lessonTarget = lessonTarget;
	}

	public String getListenFlag() {
		return listenFlag;
	}

	public void setListenFlag(String listenFlag) {
		this.listenFlag = listenFlag;
	}

	public String getLessonDate() {
		return lessonDate;
	}

	public void setLessonDate(String lessonDate) {
		this.lessonDate = lessonDate;
	}

	public String getLessonPeriod() {
		return lessonPeriod;
	}

	public void setLessonPeriod(String lessonPeriod) {
		this.lessonPeriod = lessonPeriod;
	}

	public String getRelayFlag() {
		return relayFlag;
	}

	public void setRelayFlag(String relayFlag) {
		this.relayFlag = relayFlag;
	}

	public String getRelayPlace() {
		return relayPlace;
	}

	public void setRelayPlace(String relayPlace) {
		this.relayPlace = relayPlace;
	}

	public String getLessonKbn() {
		return lessonKbn;
	}

	public void setLessonKbn(String lessonKbn) {
		this.lessonKbn = lessonKbn;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public String getUnitInterchangeable() {
		return unitInterchangeable;
	}

	public void setUnitInterchangeable(String unitInterchangeable) {
		this.unitInterchangeable = unitInterchangeable;
	}

	public String getLessonCompulsory() {
		return lessonCompulsory;
	}

	public void setLessonCompulsory(String lessonCompulsory) {
		this.lessonCompulsory = lessonCompulsory;
	}

	public String getLessonBase() {
		return lessonBase;
	}

	public void setLessonBase(String lessonBase) {
		this.lessonBase = lessonBase;
	}

	public String getLessonIntention() {
		return lessonIntention;
	}

	public void setLessonIntention(String lessonIntention) {
		this.lessonIntention = lessonIntention;
	}

	public String getLessonPlan() {
		return lessonPlan;
	}

	public void setLessonPlan(String lessonPlan) {
		this.lessonPlan = lessonPlan;
	}

	public String getLessonMemo() {
		return lessonMemo;
	}

	public void setLessonMemo(String lessonMemo) {
		this.lessonMemo = lessonMemo;
	}

	public String geteLink() {
		return eLink;
	}

	public void seteLink(String eLink) {
		this.eLink = eLink;
	}

	public String getsLink() {
		return sLink;
	}

	public void setsLink(String sLink) {
		this.sLink = sLink;
	}

	public String getCourseStatus() {
		return courseStatus;
	}

	public void setCourseStatus(String courseStatus) {
		this.courseStatus = courseStatus;
	}

	public Timestamp getUpdDate() {
		return updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public Map<String, String> getLinkageMap() {
		return linkageMap;
	}

	public void setLinkageMap(Map<String, String> linkageMap) {
		this.linkageMap = linkageMap;
	}

	public String getSkillJson() {
		return skillJson;
	}

	public void setSkillJson(String skillJson) {
		this.skillJson = skillJson;
	}
}
