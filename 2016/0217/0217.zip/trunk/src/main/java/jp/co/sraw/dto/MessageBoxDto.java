package jp.co.sraw.dto;

import java.io.Serializable;
import java.sql.Timestamp;

public class MessageBoxDto implements Serializable {

	private String messageKey;

	private String userKey; // 持ち主

	private String userFullName; // 持ち主

	private String fromUserKey; // 送信者キー

	private String fromUserFullName; // 送信者名

	private String toUserKey; // 受信者キー

	private String toUserFullName; // 受信者名

	private String messageContents;

	private String messageTitle;

	private String refMessageKey;

	private Timestamp sendDate;

	private Timestamp updDate;

	private String updUserKey;

	/**
	 * @return messageKey
	 */
	public String getMessageKey() {
		return messageKey;
	}

	/**
	 * @param messageKey セットする messageKey
	 */
	public void setMessageKey(String messageKey) {
		this.messageKey = messageKey;
	}

	/**
	 * @return userKey
	 */
	public String getUserKey() {
		return userKey;
	}

	/**
	 * @param userKey セットする userKey
	 */
	public void setUserKey(String userKey) {
		this.userKey = userKey;
	}

	/**
	 * @return userFullName
	 */
	public String getUserFullName() {
		return userFullName;
	}

	/**
	 * @param userFullName セットする userFullName
	 */
	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	/**
	 * @return fromUserKey
	 */
	public String getFromUserKey() {
		return fromUserKey;
	}

	/**
	 * @param fromUserKey セットする fromUserKey
	 */
	public void setFromUserKey(String fromUserKey) {
		this.fromUserKey = fromUserKey;
	}

	/**
	 * @return fromUserFullName
	 */
	public String getFromUserFullName() {
		return fromUserFullName;
	}

	/**
	 * @param fromUserFullName セットする fromUserFullName
	 */
	public void setFromUserFullName(String fromUserFullName) {
		this.fromUserFullName = fromUserFullName;
	}

	/**
	 * @return toUserKey
	 */
	public String getToUserKey() {
		return toUserKey;
	}

	/**
	 * @param toUserKey セットする toUserKey
	 */
	public void setToUserKey(String toUserKey) {
		this.toUserKey = toUserKey;
	}

	/**
	 * @return toUserFullName
	 */
	public String getToUserFullName() {
		return toUserFullName;
	}

	/**
	 * @param toUserFullName セットする toUserFullName
	 */
	public void setToUserFullName(String toUserFullName) {
		this.toUserFullName = toUserFullName;
	}

	/**
	 * @return messageContents
	 */
	public String getMessageContents() {
		return messageContents;
	}

	/**
	 * @param messageContents セットする messageContents
	 */
	public void setMessageContents(String messageContents) {
		this.messageContents = messageContents;
	}

	/**
	 * @return messageTitle
	 */
	public String getMessageTitle() {
		return messageTitle;
	}

	/**
	 * @param messageTitle セットする messageTitle
	 */
	public void setMessageTitle(String messageTitle) {
		this.messageTitle = messageTitle;
	}

	/**
	 * @return refMessageKey
	 */
	public String getRefMessageKey() {
		return refMessageKey;
	}

	/**
	 * @param refMessageKey セットする refMessageKey
	 */
	public void setRefMessageKey(String refMessageKey) {
		this.refMessageKey = refMessageKey;
	}

	/**
	 * @return sendDate
	 */
	public Timestamp getSendDate() {
		return sendDate;
	}

	/**
	 * @param sendDate セットする sendDate
	 */
	public void setSendDate(Timestamp sendDate) {
		this.sendDate = sendDate;
	}

	/**
	 * @return updDate
	 */
	public Timestamp getUpdDate() {
		return updDate;
	}

	/**
	 * @param updDate セットする updDate
	 */
	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	/**
	 * @return updUserKey
	 */
	public String getUpdUserKey() {
		return updUserKey;
	}

	/**
	 * @param updUserKey セットする updUserKey
	 */
	public void setUpdUserKey(String updUserKey) {
		this.updUserKey = updUserKey;
	}

}
