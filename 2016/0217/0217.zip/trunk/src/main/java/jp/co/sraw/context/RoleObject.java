package jp.co.sraw.context;

public class RoleObject {

	public String getDetailPageUrl() {
		return detailPageUrl;
	}

	public void setDetailPageUrl(String detailPageUrl) {
		this.detailPageUrl = detailPageUrl;
	}

	private String detailPageUrl;
}
