package jp.co.sraw.repository;

import java.sql.Timestamp;

import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import jp.co.sraw.entity.UsRequestTbl;

@Scope("prototype")
@Repository
public interface UsRequestTblRepository extends JpaRepository<UsRequestTbl, String>, JpaSpecificationExecutor<UsRequestTbl> {

	public UsRequestTbl findByRequestIdAndLimitDateGreaterThan(String requestId, Timestamp limitDate);
}
