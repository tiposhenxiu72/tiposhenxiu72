package jp.co.sraw.dto;

import java.io.Serializable;

public class KjThredReadDto implements Serializable {

	private String thredKey;

	private String userKey;

	private String readDate;

	private String updDate;

	private String updUserKey;

	public String getThredKey() {
		return thredKey;
	}

	public void setThredKey(String thredKey) {
		this.thredKey = thredKey;
	}

	public String getUserKey() {
		return userKey;
	}

	public void setUserKey(String userKey) {
		this.userKey = userKey;
	}

	public String getReadDate() {
		return readDate;
	}

	public void setReadDate(String readDate) {
		this.readDate = readDate;
	}

	public String getUpdDate() {
		return updDate;
	}

	public void setUpdDate(String updDate) {
		this.updDate = updDate;
	}

	public String getUpdUserKey() {
		return updUserKey;
	}

	public void setUpdUserKey(String updUserKey) {
		this.updUserKey = updUserKey;
	}

}
