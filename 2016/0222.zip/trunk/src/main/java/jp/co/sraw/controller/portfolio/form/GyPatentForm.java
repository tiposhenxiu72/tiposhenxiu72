/*
* ファイル名：OthersForm.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.portfolio.form;

import org.hibernate.validator.constraints.NotBlank;
import org.maru.m4hv.extensions.constraints.CharLength;

import jp.co.sraw.entity.GyCommonTbl;
import jp.co.sraw.entity.GyPatentTbl;
import jp.co.sraw.util.StringUtil;
import jp.co.sraw.validation.Date468;

/**
 * <B>GyPatentFormクラス</B>
 * <P>
 * Formのメソッドを提供する
 */
public class GyPatentForm extends PortfolioForm {

	public GyPatentForm() {
		super();
	}

	public String getPatentLanguage() {
		return this.getLanguage();
	}

	public void setPatentLanguage(String patentLanguage) {
		this.setLanguage(patentLanguage);
	}

	@Date468
	@CharLength(max = 8)
	private String applicationdate;

	@CharLength(max = 64)
	private String applicationid;

	@CharLength(max = 255)
	private String applicationperson;

	@CharLength(max = 1200)
	private String author;

	@Date468
	@CharLength(max = 8)
	private String patentdate;

	@CharLength(max = 64)
	private String patentid;

	@Date468
	@CharLength(max = 8)
	private String publicdate;

	private String publicid;

	@Date468
	@CharLength(max = 8)
	private String translationdate;

	@CharLength(max = 64)
	private String translationid;

	private String kbn;

	// 変更前保持
	private String oldApplicationid;
	private String oldApplicationdate;
	private String oldPublicid;
	private String oldPublicdate;
	private String oldTranslationid;
	private String oldTranslationdate;
	private String oldPatentid;
	private String oldPatentdate;

	// 出願、公開、公表、特許のどれかの組合わせは必須
	@NotBlank
	public String getPatentRequiredData() {
		String rlt = "";
		if (StringUtil.isNotNull(applicationid) && StringUtil.isNotNull(applicationdate)) {
			rlt = applicationid;
		}
		if (StringUtil.isNotNull(patentid) && StringUtil.isNotNull(patentdate)) {
			rlt = patentid;
		}
		if (StringUtil.isNotNull(publicid) && StringUtil.isNotNull(publicdate)) {
			rlt = publicid;
		}
		if (StringUtil.isNotNull(translationid) && StringUtil.isNotNull(translationdate)) {
			rlt = translationid;
		}

		return rlt;
	}

	public String getKbn() {
		return getContent(this.kbn, "0017");
	}

	public void setKbn(String kbn) {
		this.kbn = kbn;
	}

	@CharLength(max = 64)
	private String bango;

	public String getBango() {
		return this.bango;
	}

	public void setBango(String bango) {
		this.bango = bango;
	}

	@Date468
	private String busday;

	public String getBusday() {
		return this.busday;
	}

	public void setBusday(String busday) {
		this.busday = busday;
	}

	@NotBlank
	@CharLength(max = 1200)
	private String title;

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getApplicationdate() {
		if (this.applicationdate == null) {
			return "";
		}
		return this.applicationdate;
	}

	public void setApplicationdate(String applicationdate) {
		this.applicationdate = applicationdate;
	}

	public String getApplicationid() {
		return this.applicationid;
	}

	public void setApplicationid(String applicationid) {
		this.applicationid = applicationid;
	}

	public String getApplicationperson() {
		return this.applicationperson;
	}

	public void setApplicationperson(String applicationperson) {
		this.applicationperson = applicationperson;
	}

	public String getAuthor() {
		return this.author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getPatentdate() {
		if (this.patentdate == null) {
			return "";
		}
		return this.patentdate;
	}

	public void setPatentdate(String patentdate) {
		this.patentdate = patentdate;
	}

	public String getPatentid() {
		return this.patentid;
	}

	public void setPatentid(String patentid) {
		this.patentid = patentid;
	}

	public String getPublicdate() {
		if (this.publicdate == null) {
			return "";
		}
		return this.publicdate;
	}

	public void setPublicdate(String publicdate) {
		this.publicdate = publicdate;
	}

	public String getPublicid() {
		return this.publicid;
	}

	public void setPublicid(String publicid) {
		this.publicid = publicid;
	}

	public String getTranslationdate() {
		if (this.translationdate == null) {
			return "";
		}
		return this.translationdate;
	}

	public void setTranslationdate(String translationdate) {
		this.translationdate = translationdate;
	}

	public String getTranslationid() {
		return this.translationid;
	}

	public void setTranslationid(String translationid) {
		this.translationid = translationid;
	}

	@Override
	public GyCommonTbl getNewTbl() {
		// TODO 自動生成されたメソッド・スタブ
		return new GyPatentTbl();
	}

	/**
	 * @return oldApplicationid
	 */
	public String getOldApplicationid() {
		return oldApplicationid;
	}

	/**
	 * @param oldApplicationid セットする oldApplicationid
	 */
	public void setOldApplicationid(String oldApplicationid) {
		this.oldApplicationid = oldApplicationid;
	}

	/**
	 * @return oldApplicationdate
	 */
	public String getOldApplicationdate() {
		return oldApplicationdate;
	}

	/**
	 * @param oldApplicationdate セットする oldApplicationdate
	 */
	public void setOldApplicationdate(String oldApplicationdate) {
		this.oldApplicationdate = oldApplicationdate;
	}

	/**
	 * @return oldPublicid
	 */
	public String getOldPublicid() {
		return oldPublicid;
	}

	/**
	 * @param oldPublicid セットする oldPublicid
	 */
	public void setOldPublicid(String oldPublicid) {
		this.oldPublicid = oldPublicid;
	}

	/**
	 * @return oldPublicdate
	 */
	public String getOldPublicdate() {
		return oldPublicdate;
	}

	/**
	 * @param oldPublicdate セットする oldPublicdate
	 */
	public void setOldPublicdate(String oldPublicdate) {
		this.oldPublicdate = oldPublicdate;
	}

	/**
	 * @return oldTranslationid
	 */
	public String getOldTranslationid() {
		return oldTranslationid;
	}

	/**
	 * @param oldTranslationid セットする oldTranslationid
	 */
	public void setOldTranslationid(String oldTranslationid) {
		this.oldTranslationid = oldTranslationid;
	}

	/**
	 * @return oldTranslationdate
	 */
	public String getOldTranslationdate() {
		return oldTranslationdate;
	}

	/**
	 * @param oldTranslationdate セットする oldTranslationdate
	 */
	public void setOldTranslationdate(String oldTranslationdate) {
		this.oldTranslationdate = oldTranslationdate;
	}

	/**
	 * @return oldPatentid
	 */
	public String getOldPatentid() {
		return oldPatentid;
	}

	/**
	 * @param oldPatentid セットする oldPatentid
	 */
	public void setOldPatentid(String oldPatentid) {
		this.oldPatentid = oldPatentid;
	}

	/**
	 * @return oldPatentdate
	 */
	public String getOldPatentdate() {
		return oldPatentdate;
	}

	/**
	 * @param oldPatentdate セットする oldPatentdate
	 */
	public void setOldPatentdate(String oldPatentdate) {
		this.oldPatentdate = oldPatentdate;
	}

}
