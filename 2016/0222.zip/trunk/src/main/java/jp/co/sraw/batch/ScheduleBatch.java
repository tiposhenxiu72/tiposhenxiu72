package jp.co.sraw.batch;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import jp.co.sraw.dto.BatchPublicDto;
import jp.co.sraw.dto.NewsDto;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.service.BatchTargetService;

@Component
public class ScheduleBatch implements BatchRunner  {
	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(ScheduleBatch.class);

	@Autowired
	private BatchTargetService batchTargetService;

	public boolean run(Map<String, String> parameters) throws Exception {

		String targetDays = parameters.get("targetdays");
		int smallint = 0;
			try {
				smallint = Integer.parseInt(targetDays);
			} catch (Exception e) {
				throw e;
			}

			String opeKbn = null;
			String url = null;
			String eventBatchFlag = "2";
			String internshipBatchFlag = "3";
			String newsOrScheduleFlag = "2";

			//////////////////////////////////////////////////////////////////////////////////////////////////////////////
			List<NewsDto> batchEventList = batchTargetService.findAllBatchEventSchedule();

			for (NewsDto dto : batchEventList) {
				Timestamp makeDate = dto.getMakeDate();
				String infoRefKey = dto.getRefDataKey();
				Timestamp sendDate =  dto.getEventSendDate();
				String title = dto.getEventTitle();
				String dataKbn = dto.getDataKbn();
				List<BatchPublicDto> evnetPublicResultList = batchTargetService.findAllEventPublicBatch(infoRefKey);
				//スケジュールの削除、スケジュール公開範囲の削除
				batchTargetService.deleteScheduleBatch(infoRefKey, dataKbn);

				try {
					for (BatchPublicDto pDto : evnetPublicResultList) {
						int seqNo = pDto.getSeqNo();
						String publicKbn = pDto.getPublicKbn();
						String role = pDto.getRole();
						String partyCode = pDto.getPartyCode();
						//スケジュールの登録、スケジュール公開範囲の登録
						batchTargetService.insertNewsBatch(sendDate, title, dataKbn, opeKbn, infoRefKey, url, eventBatchFlag,
								seqNo, publicKbn, role, partyCode, newsOrScheduleFlag, smallint);
					}
				} catch (Exception e) {
					throw e;
				}
				//バッチ処理用抽出データの更新
				batchTargetService.updateScheduleBatch(makeDate, infoRefKey,dataKbn);
			}


			//////////////////////////////////////////////////////////////////////////////////////////////////////////////
			List<NewsDto> batchInternshipList = batchTargetService.findAllBatchInternshipSchedule();

			for (NewsDto dto : batchInternshipList) {
				Timestamp makeDate = dto.getMakeDate();
				String infoRefKey = dto.getRefDataKey();
				Timestamp sendDate =  dto.getInternshipSendDate();
				String title = dto.getInternshipTitle();
				String dataKbn = dto.getDataKbn();
				List<BatchPublicDto> internshipPublicResultList = batchTargetService.findAllInternshipPublicBatch(infoRefKey);
				//スケジュールの削除、スケジュール公開範囲の削除
				batchTargetService.deleteScheduleBatch(infoRefKey, dataKbn);

				try {
					for (BatchPublicDto pDto : internshipPublicResultList) {
						int seqNo = pDto.getSeqNo();
						String publicKbn = pDto.getPublicKbn();
						String role = pDto.getRole();
						String partyCode = pDto.getPartyCode();
						newsOrScheduleFlag = "3";
						////スケジュールの登録、スケジュール公開範囲の登録
						batchTargetService.insertNewsBatch(sendDate, title, dataKbn, opeKbn, infoRefKey, url,
								internshipBatchFlag, seqNo, publicKbn, role, partyCode, newsOrScheduleFlag, smallint);
					}
				} catch (Exception e) {
					throw e;
				}
				//バッチ処理用抽出データの更新
				batchTargetService.updateScheduleBatch(makeDate, infoRefKey,dataKbn);
			}

			return true;
		}
	}
