/*
* ファイル名：ScheduleApiController.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/01/19               新規作成
*/
package jp.co.sraw.controller.api;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonController;
import jp.co.sraw.dto.CmScheduleDto;
import jp.co.sraw.entity.CmScheduleInfoView;
import jp.co.sraw.entity.CmScheduleTbl;
import jp.co.sraw.entity.UsScheduleTbl;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.service.HomeServiceImpl;
import jp.co.sraw.util.StringUtil;

/**
* <B>ScheduleApiControllerクラス</B>
* <P>
* ポータルのスケジュールAPIのメソッドを提供する
*/
@RestController
@RequestMapping(CommonConst.PATH_API +"/schedule")
public class ScheduleApiController extends CommonController {
	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(PartyApiController.class);

	@Autowired
	private HomeServiceImpl homeServiceImpl;

	@PostConstruct
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	/**
	 * ポータル用スケジュールを取得(表示用)
	 *
	 * @param locale
	 * @return
	 */
	@RequestMapping("/{dateRange}")
	protected List<CmScheduleDto> scheduleList(@PathVariable String dateRange, Locale locale){

		logger.infoCode("I0001", "scheduleList"); // I0001=メソッド開始:{0}

		String[] dateArray = new String[]{"",""};
		if (StringUtil.isNotNull(dateRange)) {
			dateArray = dateRange.split(",");
		}

		List<UsScheduleTbl> usScheduleList = homeServiceImpl.findAllUsSchedule(dateArray, userInfo.getTargetUserKey());
		List<CmScheduleTbl> cmScheduleList = homeServiceImpl.findAllCmSchedule(dateArray, userInfo.getTargetPartyCode(), userInfo.getTargetRole().getAuthority());

		//取得した情報をマージする。
		List<CmScheduleDto> resultList = new ArrayList<CmScheduleDto>();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		for (UsScheduleTbl usScheduleTbl : usScheduleList){
			CmScheduleDto cmScheduleDto = new CmScheduleDto();
			String suhduleDate = sdf.format(usScheduleTbl.getSuhduleDate());
			CmScheduleInfoView detail = homeServiceImpl.findOneCmScheduleInfoView(usScheduleTbl.getDataKbn(), usScheduleTbl.getSchduleRefKey());

			cmScheduleDto.setTitle(usScheduleTbl.getTitle());
			if (usScheduleTbl.getStartTime() != null && StringUtil.isNotNull(usScheduleTbl.getStartTime())) {
				// 時分チェック
				String[] time = usScheduleTbl.getStartTime().split(":");
				if (time.length > 1) {
					String hour = String.format("%2s", time[0]).replace(" ", "0"); // 0埋め
					String minute = String.format("%2s", time[1]).replace(" ", "0"); // 0埋め
					cmScheduleDto.setStart(suhduleDate + " " + hour +":"+ minute);
				} else {
					cmScheduleDto.setStart(suhduleDate);
				}
			} else {
				cmScheduleDto.setStart(suhduleDate);
			}
			if (usScheduleTbl.getEndTime() != null && StringUtil.isNotNull(usScheduleTbl.getEndTime())) {
				// 時分チェック
				String[] time = usScheduleTbl.getEndTime().split(":");
				if (time.length > 1) {
					String hour = String.format("%2s", time[0]).replace(" ", "0"); // 0埋め
					String minute = String.format("%2s", time[1]).replace(" ", "0"); // 0埋め
					cmScheduleDto.setEnd(suhduleDate + " " + hour +":"+ minute);
				} else {
					cmScheduleDto.setEnd(suhduleDate);
				}
			} else {
				cmScheduleDto.setEnd(suhduleDate);
			}
			cmScheduleDto.setDataKbn(usScheduleTbl.getDataKbn());
			cmScheduleDto.setBackgroundColor(messageSource.getMessage("portal.schedule.backgroundColor.default", null, locale));
			cmScheduleDto.setBorderColor(messageSource.getMessage("portal.schedule.borderColor.default", null, locale));
			if (StringUtil.isNotNull(usScheduleTbl.getDataKbn())) {
				cmScheduleDto.setBackgroundColor(messageSource.getMessage("portal.schedule.backgroundColor."+ usScheduleTbl.getDataKbn(), null, locale));
				cmScheduleDto.setBorderColor(messageSource.getMessage("portal.schedule.borderColor."+ usScheduleTbl.getDataKbn(), null, locale));
			}
			if (detail != null) {
				cmScheduleDto.setScheduleTitle(StringUtil.isNotNull(detail.getScheduleTitle()) ? detail.getScheduleTitle() : "");
				cmScheduleDto.setScheduleTelno(StringUtil.isNotNull(detail.getScheduleTelno()) ? detail.getScheduleTelno() : "");
				cmScheduleDto.setScheduleMemo(StringUtil.isNotNull(detail.getScheduleMemo()) ? detail.getScheduleMemo() : "");
				cmScheduleDto.setUrl(StringUtil.isNotNull(detail.getScheduleUrl()) ? detail.getScheduleUrl() : "");
			} else {
				cmScheduleDto.setScheduleTitle("");
				cmScheduleDto.setScheduleTelno("");
				cmScheduleDto.setScheduleMemo("");
				cmScheduleDto.setUrl("");
			}
			resultList.add(cmScheduleDto);
		}
		for (CmScheduleTbl cmScheduleTbl : cmScheduleList){
			CmScheduleDto cmScheduleDto = new CmScheduleDto();
			String suhduleDate = sdf.format(cmScheduleTbl.getSuhduleDate());
			CmScheduleInfoView detail = homeServiceImpl.findOneCmScheduleInfoView(cmScheduleTbl.getDataKbn(), cmScheduleTbl.getSchduleRefKey());

			cmScheduleDto.setTitle(cmScheduleTbl.getTitle());
			if (cmScheduleTbl.getStartTime() != null && StringUtil.isNotNull(cmScheduleTbl.getStartTime())) {
				// 時分チェック
				String[] time = cmScheduleTbl.getStartTime().split(":");
				if (time.length > 1) {
					String hour = String.format("%2s", time[0]).replace(" ", "0"); // 0埋め
					String minute = String.format("%2s", time[1]).replace(" ", "0"); // 0埋め
					cmScheduleDto.setStart(suhduleDate + " " + hour +":"+ minute);
				} else {
					cmScheduleDto.setStart(suhduleDate);
				}
			} else {
				cmScheduleDto.setStart(suhduleDate);
			}
			if (cmScheduleTbl.getEndTime() != null && StringUtil.isNotNull(cmScheduleTbl.getEndTime())) {
				// 時分チェック
				String[] time = cmScheduleTbl.getEndTime().split(":");
				if (time.length > 1) {
					String hour = String.format("%2s", time[0]).replace(" ", "0"); // 0埋め
					String minute = String.format("%2s", time[1]).replace(" ", "0"); // 0埋め
					cmScheduleDto.setEnd(suhduleDate + " " + hour +":"+ minute);
				} else {
					cmScheduleDto.setEnd(suhduleDate);
				}
			} else {
				cmScheduleDto.setEnd(suhduleDate);
			}
			cmScheduleDto.setDataKbn(cmScheduleTbl.getDataKbn());
			cmScheduleDto.setBackgroundColor(messageSource.getMessage("portal.schedule.backgroundColor.default", null, locale));
			cmScheduleDto.setBorderColor(messageSource.getMessage("portal.schedule.borderColor.default", null, locale));
			if (StringUtil.isNotNull(cmScheduleTbl.getDataKbn())) {
				cmScheduleDto.setBackgroundColor(messageSource.getMessage("portal.schedule.backgroundColor."+ cmScheduleTbl.getDataKbn(), null, locale));
				cmScheduleDto.setBorderColor(messageSource.getMessage("portal.schedule.borderColor."+ cmScheduleTbl.getDataKbn(), null, locale));
			}
			if (detail != null) {
				cmScheduleDto.setScheduleTitle(detail.getScheduleTitle());
				cmScheduleDto.setScheduleTelno(detail.getScheduleTelno());
				cmScheduleDto.setScheduleMemo(detail.getScheduleMemo());
				cmScheduleDto.setUrl(detail.getScheduleUrl());
			} else {
				cmScheduleDto.setScheduleTitle("");
				cmScheduleDto.setScheduleTelno("");
				cmScheduleDto.setScheduleMemo("");
				cmScheduleDto.setUrl("");
			}
			resultList.add(cmScheduleDto);
		}

		logger.infoCode("I0002", "scheduleList"); // I0002=メソッド終了:{0}
		return resultList;
	}

}
