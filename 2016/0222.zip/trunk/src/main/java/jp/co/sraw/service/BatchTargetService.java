/*
* ファイル名：IndexController.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonService;
import jp.co.sraw.dto.BatchPublicDto;
import jp.co.sraw.dto.EmailDto;
import jp.co.sraw.dto.NewsDto;
import jp.co.sraw.entity.CmBatchTargetTbl;
import jp.co.sraw.entity.CmBatchTargetTblPK;
import jp.co.sraw.entity.CmInfoPublicTbl;
import jp.co.sraw.entity.CmInfoPublicTblPK;
import jp.co.sraw.entity.CmInfoTbl;
import jp.co.sraw.entity.CmSchedulePublicTbl;
import jp.co.sraw.entity.CmSchedulePublicTblPK;
import jp.co.sraw.entity.CmScheduleTbl;
import jp.co.sraw.entity.EvEventTbl;
import jp.co.sraw.entity.ItInternTbl;
import jp.co.sraw.entity.SpSupportTbl;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.repository.CmBatchTargetTblRepository;
import jp.co.sraw.repository.CmInfoPublicTblRepository;
import jp.co.sraw.repository.CmInfoTblRepository;
import jp.co.sraw.repository.CmSchedulePublicTblRepository;
import jp.co.sraw.repository.CmScheduleTblRepository;
import jp.co.sraw.repository.EvEventTblRepository;
import jp.co.sraw.repository.ItInternTblRepository;
import jp.co.sraw.repository.SpSupportTblRepository;
import jp.co.sraw.util.DateUtil;

/**
 * <B>BatchTargetServiceクラス</B>
 * <P>
 */
@Scope("prototype")
@Service
@Transactional(readOnly = true)
public class BatchTargetService extends CommonService {

	@Override
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(BatchTargetService.class);

	@Autowired
	private ItInternTblRepository itInternTblRepository;

	@Autowired
	private SpSupportTblRepository spSupportTblRepository;

	@Autowired
	private EvEventTblRepository evEventTblRepository;

	@Autowired
	private CmBatchTargetTblRepository cmBatchTargetTblRepository;

	@Autowired
	private CmInfoTblRepository cmInfoTblRepository;

	@Autowired
	private CmInfoPublicTblRepository cmInfoPublicTblRepository;

	@Autowired
	private CmScheduleTblRepository cmScheduleTblRepository;

	@Autowired
	private CmSchedulePublicTblRepository cmSchedulePublicTblRepository;

	@Autowired
	private EntityManager entityManager;

	// URL
	private static final String SUPPORT_URL = "/support/";
	private static final String EQUIPMENT_URL = "/equipment/";
	private static final String EVENT_URL = "/event/";
	private static final String INTERNSHIP_URL = "/internship/";

	private static final String CMINFOTBL_IS_NULL = "CmInfoTbl is null.";
	private static final String CMINFOPUBLICTBL_IS_NULL = "CmInfoPublicTbl is null.";
	private static final String CMBATCHTARGETTBL_IS_NULL = "CmBatchTargetTbl is null.";

	/**
	 *
	 *
	 * @param infoKey
	 * @return
	 */
	@Deprecated
	public List<EmailDto> findAllEmailBatch(String infoKey) {
		logger.infoCode("I0001");

		String sqlName = "";
		if ("%03%".equals(infoKey)) {
			sqlName = "UsUserTbl.nativeFindAllEmailBatchCase1";
		} else if ("%01%".equals(infoKey) || "%02%".equals(infoKey)) {
			sqlName = "UsUserTbl.nativeFindAllEmailBatchCase2";
		}

		Query query = entityManager.createNamedQuery(sqlName);
		query.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		query.setParameter("infoKey", infoKey);

		List<EmailDto> list = new ArrayList<>();
		List<Map> resultList = new ArrayList<>();
		resultList = query.getResultList();

		for (int i = 0; i < resultList.size(); i++) {
			EmailDto dto = new EmailDto();
			dto = (EmailDto) objectUtil.setMapCopyValue(dto, resultList.get(i));
			list.add(dto);
		}

		logger.infoCode("I0002");
		return list;
	}

	/**
	 *
	 *
	 * @param infoRefKey
	 * @return
	 */
	@Deprecated
	public List<BatchPublicDto> findAllEventPublicBatch(String infoRefKey) {
		logger.infoCode("I0001");

		String sqlName = "EvEventPublicTbl.nativeFindAllEventPublicBatch";

		Query query = entityManager.createNamedQuery(sqlName);
		query.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		query.setParameter("infoRefKey", infoRefKey);

		List<BatchPublicDto> list = new ArrayList<>();
		List<Map> resultList = new ArrayList<>();
		resultList = query.getResultList();

		for (int i = 0; i < resultList.size(); i++) {
			BatchPublicDto dto = new BatchPublicDto();
			dto = (BatchPublicDto) objectUtil.setMapCopyValue(dto, resultList.get(i));
			list.add(dto);
		}

		logger.infoCode("I0002");
		return list;
	}

	/**
	 *
	 * @param infoRefKey
	 * @return
	 */
	@Deprecated
	public List<BatchPublicDto> findAllInternshipPublicBatch(String infoRefKey) {
		logger.infoCode("I0001");

		String sqlName = "ItInternPublicTbl.nativeFindAllInternshipPublicBatch";

		Query query = entityManager.createNamedQuery(sqlName);
		query.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		query.setParameter("infoRefKey", infoRefKey);

		List<BatchPublicDto> list = new ArrayList<>();
		List<Map> resultList = new ArrayList<>();
		resultList = query.getResultList();

		for (int i = 0; i < resultList.size(); i++) {
			BatchPublicDto dto = new BatchPublicDto();
			dto = (BatchPublicDto) objectUtil.setMapCopyValue(dto, resultList.get(i));
			list.add(dto);
		}

		logger.infoCode("I0002");
		return list;
	}

	/**
	 * メール作成（支援制度）の一覧取得
	 *
	 * @return
	 */
	@Deprecated
	public List<NewsDto> findAllBatchSupportMail() {
		logger.infoCode("I0001");

		String sqlName = "SpSupportTbl.nativeFindAllBatchSupportMail";

		List<NewsDto> list = new ArrayList<>();
		List<Map> resultList = new ArrayList<>();
		Query query = entityManager.createNamedQuery(sqlName);
		query.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		resultList = query.getResultList();

		for (int i = 0; i < resultList.size(); i++) {
			NewsDto dto = new NewsDto();
			dto = (NewsDto) objectUtil.setMapCopyValue(dto, resultList.get(i));
			list.add(dto);
		}

		logger.infoCode("I0002");
		return list;
	}

	/**
	 * スケジュール情報作成（イベント）の一覧取得
	 *
	 * @return
	 */
	@Deprecated
	public List<NewsDto> findAllBatchEventSchedule() {
		logger.infoCode("I0001");

		String sqlName = "EvEventTbl.nativeFindAllBatchEventSchedule";

		Query query = entityManager.createNamedQuery(sqlName);
		query.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);

		List<NewsDto> list = new ArrayList<>();
		List<Map> resultList = new ArrayList<>();
		resultList = query.getResultList();

		for (int i = 0; i < resultList.size(); i++) {
			NewsDto dto = new NewsDto();
			dto = (NewsDto) objectUtil.setMapCopyValue(dto, resultList.get(i));
			list.add(dto);
		}

		logger.infoCode("I0002");
		return list;
	}

	/**
	 * メール作成（イベント）の一覧取得
	 *
	 * @return
	 */
	@Deprecated
	public List<NewsDto> findAllBatchEventMail() {
		logger.infoCode("I0001");

		String sqlName = "EvEventTbl.nativeFindAllBatchEventMail";

		Query query = entityManager.createNamedQuery(sqlName);
		query.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);

		List<NewsDto> list = new ArrayList<>();
		List<Map> resultList = new ArrayList<>();
		resultList = query.getResultList();

		for (int i = 0; i < resultList.size(); i++) {
			NewsDto dto = new NewsDto();
			dto = (NewsDto) objectUtil.setMapCopyValue(dto, resultList.get(i));
			list.add(dto);
		}

		logger.infoCode("I0002");
		return list;
	}

	/**
	 * スケジュール情報作成（インターンシップ）の一覧取得
	 *
	 * @return
	 */
	@Deprecated
	public List<NewsDto> findAllBatchInternshipSchedule() {
		logger.infoCode("I0001");

		String sqlName = "ItInternTbl.nativeFindAllBatchInternshipSchedule";

		Query query = entityManager.createNamedQuery(sqlName);
		query.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);

		List<NewsDto> list = new ArrayList<>();
		List<Map> resultList = new ArrayList<>();
		resultList = query.getResultList();

		for (int i = 0; i < resultList.size(); i++) {
			NewsDto dto = new NewsDto();
			dto = (NewsDto) objectUtil.setMapCopyValue(dto, resultList.get(i));
			list.add(dto);
		}

		logger.infoCode("I0002");
		return list;
	}

	/**
	 * メール作成（インターンシップ）の一覧取得
	 *
	 * @return
	 */
	@Deprecated
	public List<NewsDto> findAllBatchInternshipMail() {
		logger.infoCode("I0001");

		String sqlName = "ItInternTbl.nativeFindAllBatchInternshipMail";

		Query query = entityManager.createNamedQuery(sqlName);
		query.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);

		List<NewsDto> list = new ArrayList<>();
		List<Map> resultList = new ArrayList<>();
		resultList = query.getResultList();

		for (int i = 0; i < resultList.size(); i++) {
			NewsDto dto = new NewsDto();
			dto = (NewsDto) objectUtil.setMapCopyValue(dto, resultList.get(i));
			list.add(dto);
		}

		logger.infoCode("I0002");
		return list;
	}

	/**
	 *
	 *
	 * @param sendDate
	 * @param title
	 * @param dataKbn
	 * @param opeKbn
	 * @param refKey
	 * @param batchFlag
	 * @param seqNo
	 * @param publicKbn
	 * @param role
	 * @param partyCode
	 * @param newsOrScheduleFlag
	 * @param smallint
	 * @return
	 * @throws Exception
	 */
	@Deprecated
	@Transactional
	public boolean insertNewsBatch(Timestamp sendDate, String title, String dataKbn, String opeKbn, String refKey, String url,
			String batchFlag, int seqNo, String publicKbn, String role, String partyCode, String newsOrScheduleFlag,
			int smallint) throws Exception {

		logger.infoCode("I0001", "insertNewsBatch");

		boolean result = false;

		if (refKey.isEmpty()) {
			return false;
		}
		try {
			// スケジュール作成
			if ("2".equals(newsOrScheduleFlag)) {
				// CmInfoTbl
				CmScheduleTbl info = new CmScheduleTbl();
				info.setSuhduleDate(DateUtil.formatTimestampStart(sendDate));
				info.setStartTime(null);
				info.setEndTime(null);
				info.setTitle(title);
				info.setDataKbn(dataKbn);
				info.setSchduleRefKey(refKey);
				info.setMakeUserKey(CommonConst.USER_KEY_DUMMY);
				info.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
				info.setUpdDate(DateUtil.getNowTimestamp());
				CmScheduleTbl infoResult = cmScheduleTblRepository.save(info);

				// CmSchedulePublicTbl
				CmSchedulePublicTbl infoPublic = new CmSchedulePublicTbl();
				CmSchedulePublicTblPK infoPublicId = new CmSchedulePublicTblPK();
				infoPublicId.setSuhduleKey(infoResult.getSuhduleKey());

				// supportの場合
				if ("1".equals(batchFlag)) {
					infoPublicId.setSeqNo(1);
					infoPublic.setId(infoPublicId);
					infoPublic.setPublicKbn("4");
					infoPublic.setRole(null);
					infoPublic.setPartyCode(null);
					// eventの場合 と intershipの場合
				} else if ("2".equals(batchFlag) || "3".equals(batchFlag)) {
					infoPublicId.setSeqNo(seqNo);
					infoPublic.setId(infoPublicId);
					infoPublic.setPublicKbn(publicKbn);
					infoPublic.setRole(role);
					infoPublic.setPartyCode(partyCode);
				}

				infoPublic.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
				infoPublic.setUpdDate(DateUtil.getNowTimestamp());
				CmSchedulePublicTbl infoPublicResult = cmSchedulePublicTblRepository.save(infoPublic);
				cmScheduleTblRepository.flush();
				cmSchedulePublicTblRepository.flush();
				result = true;
				// スケジュール作成 応募期間（FROM）と応募期間（TO）用の２セット作成用
			} else if ("3".equals(newsOrScheduleFlag)) {

				// CmScheduleTbl
				CmScheduleTbl infoFrom = new CmScheduleTbl();
				CmScheduleTbl infoTo = new CmScheduleTbl();
				infoFrom.setSuhduleDate(DateUtil.formatTimestampStart(sendDate));
				infoFrom.setStartTime(null);
				infoFrom.setEndTime(null);
				infoFrom.setTitle(title);
				infoFrom.setDataKbn(dataKbn);
				infoFrom.setSchduleRefKey(refKey);
				infoFrom.setMakeUserKey(CommonConst.USER_KEY_DUMMY);
				infoFrom.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
				infoFrom.setUpdDate(DateUtil.getNowTimestamp());

				infoTo.setSuhduleDate(DateUtil.formatTimestampStart(DateUtil.getTimestamp(DateUtil.addDay(DateUtil.getDate(sendDate, "yyyyMMdd"), smallint), "yyyyMMdd")));
				infoTo.setStartTime(null);
				infoTo.setEndTime(null);
				infoTo.setTitle(title);
				infoTo.setDataKbn(dataKbn);
				infoTo.setSchduleRefKey(refKey);
				infoTo.setMakeUserKey(CommonConst.USER_KEY_DUMMY);
				infoTo.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
				infoTo.setUpdDate(DateUtil.getNowTimestamp());

				CmScheduleTbl infoFromResult = cmScheduleTblRepository.save(infoFrom);
				CmScheduleTbl infoToResult = cmScheduleTblRepository.save(infoTo);

				// CmSchedulePublicTbl
				CmSchedulePublicTbl infoFromPublic = new CmSchedulePublicTbl();
				CmSchedulePublicTbl infoToPublic = new CmSchedulePublicTbl();
				CmSchedulePublicTblPK infoFromPublicId = new CmSchedulePublicTblPK();
				CmSchedulePublicTblPK infoToPublicId = new CmSchedulePublicTblPK();
				infoFromPublicId.setSuhduleKey(infoFromResult.getSuhduleKey());
				infoToPublicId.setSuhduleKey(infoToResult.getSuhduleKey());

				// supportの場合
				if ("1".equals(batchFlag)) {
					infoFromPublicId.setSeqNo(1);
					infoFromPublic.setId(infoFromPublicId);
					infoFromPublic.setPublicKbn("4");
					infoFromPublic.setRole(null);
					infoFromPublic.setPartyCode(null);

					infoToPublicId.setSeqNo(1);
					infoToPublic.setId(infoToPublicId);
					infoToPublic.setPublicKbn("4");
					infoToPublic.setRole(null);
					infoToPublic.setPartyCode(null);
					// eventの場合 と intershipの場合
				} else if ("2".equals(batchFlag) || "3".equals(batchFlag)) {
					infoFromPublicId.setSeqNo(seqNo);
					infoFromPublic.setId(infoFromPublicId);
					infoFromPublic.setPublicKbn(publicKbn);
					infoFromPublic.setRole(role);
					infoFromPublic.setPartyCode(partyCode);

					infoToPublicId.setSeqNo(seqNo);
					infoToPublic.setId(infoToPublicId);
					infoToPublic.setPublicKbn(publicKbn);
					infoToPublic.setRole(role);
					infoToPublic.setPartyCode(partyCode);
				}

				infoFromPublic.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
				infoFromPublic.setUpdDate(DateUtil.getNowTimestamp());
				infoToPublic.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
				infoToPublic.setUpdDate(DateUtil.getNowTimestamp());
				CmSchedulePublicTbl infoFromPublicResult = cmSchedulePublicTblRepository.save(infoFromPublic);
				CmSchedulePublicTbl infoToPublicResult = cmSchedulePublicTblRepository.save(infoToPublic);
				cmScheduleTblRepository.flush();
				cmSchedulePublicTblRepository.flush();
				//
				result = true;
			}
		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
			throw e;
		}
		return result;
	}

	/**
	 * E-mail更新
	 *
	 * @param refKey
	 * @param dataKbn
	 * @return
	 * @throws Exception
	 */
	@Deprecated
	@Transactional
	public boolean updateEmailBatch(Timestamp makeDate, String refKey, String dataKbn) throws Exception {
		logger.infoCode("I0001");
		if (refKey.isEmpty()) {
			return true;
		}
		try {
			CmBatchTargetTblPK id = new CmBatchTargetTblPK();
			id.setRefDataKey(refKey);
			id.setMakeDate(makeDate);
			id.setDataKbn(dataKbn);

			CmBatchTargetTbl entity = cmBatchTargetTblRepository.findOne(id);

			entity.setId(id);
			entity.setMailMakeFlag("1");
			entity.setUpdDate(DateUtil.getNowTimestamp());
			entity.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
			entity = cmBatchTargetTblRepository.saveAndFlush(entity);
			if (entity != null) {
				logger.infoCode("I0002");
				return true;
			}
		} catch (Exception e) {
			logger.errorCode("E1008", e); // E1008=更新に失敗しました。{0}
			throw e;
		}
		return false;
	}

	/**
	 * スケジュール更新
	 *
	 * @param refKey
	 * @param dataKbn
	 * @return
	 * @throws Exception
	 */
	@Deprecated
	@Transactional
	public boolean updateScheduleBatch(Timestamp makeDate, String refKey, String dataKbn) throws Exception {
		logger.infoCode("I0001");
		if (refKey.isEmpty()) {
			return true;
		}
		try {
			CmBatchTargetTblPK id = new CmBatchTargetTblPK();
			id.setRefDataKey(refKey);
			id.setMakeDate(makeDate);
			id.setDataKbn(dataKbn);

			CmBatchTargetTbl entity = cmBatchTargetTblRepository.findOne(id);

			entity.setScheduleMakeFlag("1");
			entity.setUpdDate(DateUtil.getNowTimestamp());
			entity.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
			entity = cmBatchTargetTblRepository.saveAndFlush(entity);
			if (entity != null) {
				logger.infoCode("I0002");
				return true;
			}
		} catch (Exception e) {
			logger.errorCode("E1008", e); // E1008=更新に失敗しました。{0}
			throw e;
		}
		return false;
	}



	// お知らせ情報作成
	/**
	 * 支援制度からのお知らせ情報作成
	 *
	 * @return
	 * @throws Exception
	 */
	@Transactional
	public boolean updateSupportBatchNewsInfo() throws Exception {
		logger.infoCode("I0001", "updateSupportBatchNewsInfo");

		String sqlName = "SpSupportTbl.nativeFindAllBatchSupportInfo";

		try {

			Query query = entityManager.createNamedQuery(sqlName);
			query.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			@SuppressWarnings({ "unchecked", "rawtypes" })
			List<Map> resultList = query.getResultList();

			if (resultList.size() == 0) {
				return true;
			}

			// １－１．バッチ処理用抽出データ、支援制度からの情報抽出
			for (int i = 0; i < resultList.size(); i++) {
				@SuppressWarnings("rawtypes")
				Map obj = resultList.get(i);
				Timestamp makeDate = Timestamp.valueOf(String.valueOf(obj.get("make_date")));
				String dataKbn = String.valueOf(obj.get("data_kbn"));
				String refDataKey = String.valueOf(obj.get("ref_data_key"));
				String supportTitle = String.valueOf(obj.get("support_title"));
				Timestamp supportStartDate = Timestamp.valueOf(String.valueOf(obj.get("support_start_date")));
				//String supportContent = String.valueOf(obj.get("support_content"));

				String opeKbn = CommonConst.OP_ACTION_ADDED;
				String url = SUPPORT_URL;
				if ("6".equals(dataKbn)) {
					url = EQUIPMENT_URL;
				}

				// １－３－１．お知らせ情報の登録。
				// CmInfoTbl
				CmInfoTbl info = new CmInfoTbl();
				info.setSendDate(DateUtil.formatTimestampStart(supportStartDate));
				info.setTitle(supportTitle);
				info.setDataKbn(dataKbn);
				info.setOpeKbn(opeKbn);
				info.setInfoRefKey(refDataKey);
				info.setUrl(url);
				info.setMakeUserKey(CommonConst.USER_KEY_DUMMY);
				info.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
				info.setUpdDate(DateUtil.getNowTimestamp());
				CmInfoTbl infoResult = cmInfoTblRepository.save(info);
				if (infoResult == null) {
					throw new NullPointerException(CMINFOTBL_IS_NULL);
				}

				// １－３－２．お知らせ情報公開範囲の登録。
				// CmInfoPublicTbl
				CmInfoPublicTbl infoPublic = new CmInfoPublicTbl();
				CmInfoPublicTblPK infoPublicId = new CmInfoPublicTblPK();
				infoPublicId.setInfoKey(infoResult.getInfoKey());
				infoPublicId.setSeqNo(1); // 固定

				infoPublic.setId(infoPublicId);
				infoPublic.setPublicKbn("4"); // 固定
				infoPublic.setRole(null); // 固定
				infoPublic.setPartyCode(null); // 固定

				infoPublic.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
				infoPublic.setUpdDate(DateUtil.getNowTimestamp());
				CmInfoPublicTbl infoPublicResult = cmInfoPublicTblRepository.save(infoPublic);
				if (infoPublicResult == null) {
					throw new NullPointerException(CMINFOPUBLICTBL_IS_NULL);
				}

				// １－３－３．バッチ処理用抽出データの更新。
				CmBatchTargetTblPK batchTargetId = new CmBatchTargetTblPK();
				batchTargetId.setRefDataKey(refDataKey);
				batchTargetId.setMakeDate(makeDate);
				batchTargetId.setDataKbn(dataKbn);

				CmBatchTargetTbl batchTarget = cmBatchTargetTblRepository.findOne(batchTargetId);
				batchTarget.setInfoMakeFlag("1"); // 固定 ステータス更新
				batchTarget.setUpdDate(DateUtil.getNowTimestamp());
				batchTarget.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
				CmBatchTargetTbl batchTargetResult = cmBatchTargetTblRepository.save(batchTarget);
				if (batchTargetResult == null) {
					throw new NullPointerException(CMBATCHTARGETTBL_IS_NULL);
				}
			}

			cmInfoTblRepository.flush();
			cmInfoPublicTblRepository.flush();
			cmBatchTargetTblRepository.flush();

		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
			throw e;
		}

		return true;
	}

	/**
	 * イベントからのお知らせ情報作成
	 *
	 * @return
	 * @throws Exception
	 */
	@Transactional
	public boolean updateEventBatchNewsInfo() throws Exception {

		logger.infoCode("I0001", "updateEventBatchNewsInfo");

		String sqlName = "EvEventTbl.nativeFindAllBatchEventInfo";
		String sqlNamePublic = "EvEventPublicTbl.nativeFindAllEventPublicBatch";

		try {

			// ２－１．バッチ処理用抽出データ、イベントからの情報抽出
			Query query = entityManager.createNamedQuery(sqlName);
			query.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			@SuppressWarnings({ "unchecked", "rawtypes" })
			List<Map> resultList = query.getResultList();

			for (int i = 0; i < resultList.size(); i++) {
				@SuppressWarnings("rawtypes")
				Map obj = resultList.get(i);
				Timestamp makeDate = Timestamp.valueOf(String.valueOf(obj.get("make_date")));
				String dataKbn = String.valueOf(obj.get("data_kbn"));
				String refDataKey = String.valueOf(obj.get("ref_data_key"));
				String eventTitle = String.valueOf(obj.get("event_title"));
				Timestamp eventSendDate = Timestamp.valueOf(String.valueOf(obj.get("event_send_date")));
				//Timestamp eventStartDate = Timestamp.valueOf(String.valueOf(obj.get("event_start_date")));
				//String eventTelno = String.valueOf(obj.get("event_telno"));
				//String eventPlace = String.valueOf(obj.get("event_place"));
				//String partyName = String.valueOf(obj.get("party_name"));
				//String eventMemo = String.valueOf(obj.get("event_memo"));
				String opeKbn = CommonConst.OP_ACTION_ADDED;
				String url = EVENT_URL;

				// ２－３．イベント公開範囲の参照
				Query queryPublic = entityManager.createNamedQuery(sqlNamePublic);
				queryPublic.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
				queryPublic.setParameter("infoRefKey", refDataKey);
				@SuppressWarnings({ "unchecked", "rawtypes" })
				List<Map> resultPublicList = queryPublic.getResultList();

				for (int j = 0; j < resultPublicList.size(); j++) {
					@SuppressWarnings({ "rawtypes" })
					Map objPublic = resultPublicList.get(j);
					//String eventKey = String.valueOf(objPublic.get("event_key"));
					int seqNo = Integer.valueOf(String.valueOf(objPublic.get("seq_no")));
					String publicKbn = String.valueOf(objPublic.get("public_kbn"));
					String role = String.valueOf(objPublic.get("role"));
					String partyCode = String.valueOf(objPublic.get("party_code"));

					// ２－４－１．お知らせ情報の登録。
					// CmInfoTbl
					CmInfoTbl info = new CmInfoTbl();
					info.setSendDate(DateUtil.formatTimestampStart(eventSendDate));
					info.setTitle(eventTitle);
					info.setDataKbn(dataKbn);
					info.setOpeKbn(opeKbn);
					info.setInfoRefKey(refDataKey);
					info.setUrl(url);
					info.setMakeUserKey(CommonConst.USER_KEY_DUMMY);
					info.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
					info.setUpdDate(DateUtil.getNowTimestamp());
					CmInfoTbl infoResult = cmInfoTblRepository.save(info);
					if (infoResult == null) {
						throw new NullPointerException(CMINFOTBL_IS_NULL);
					}

					// ２－４－２．お知らせ情報公開範囲の登録。
					// CmInfoPublicTbl
					CmInfoPublicTbl infoPublic = new CmInfoPublicTbl();
					CmInfoPublicTblPK infoPublicId = new CmInfoPublicTblPK();
					infoPublicId.setInfoKey(infoResult.getInfoKey());

					infoPublicId.setSeqNo(seqNo);
					infoPublic.setId(infoPublicId);
					infoPublic.setPublicKbn(publicKbn);
					infoPublic.setRole(role);
					infoPublic.setPartyCode(partyCode);

					infoPublic.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
					infoPublic.setUpdDate(DateUtil.getNowTimestamp());
					CmInfoPublicTbl infoPublicResult = cmInfoPublicTblRepository.save(infoPublic);
					if (infoPublicResult == null) {
						throw new NullPointerException(CMINFOPUBLICTBL_IS_NULL);
					}
				}

				// ２－４－３．バッチ処理用抽出データの更新。
				CmBatchTargetTblPK batchTargetId = new CmBatchTargetTblPK();
				batchTargetId.setRefDataKey(refDataKey);
				batchTargetId.setMakeDate(makeDate);
				batchTargetId.setDataKbn(dataKbn);

				CmBatchTargetTbl batchTarget = cmBatchTargetTblRepository.findOne(batchTargetId);
				batchTarget.setInfoMakeFlag("1"); // 固定 ステータス更新
				batchTarget.setUpdDate(DateUtil.getNowTimestamp());
				batchTarget.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
				CmBatchTargetTbl batchTargetResult = cmBatchTargetTblRepository.save(batchTarget);
				if (batchTargetResult == null) {
					throw new NullPointerException(CMBATCHTARGETTBL_IS_NULL);
				}
			}
			cmInfoTblRepository.flush();
			cmInfoPublicTblRepository.flush();
			cmBatchTargetTblRepository.flush();

		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
			throw e;
		}

		return true;
	}

	/**
	 * インターンシップからのお知らせ情報作成
	 *
	 * @return
	 * @throws Exception
	 */
	@Transactional
	public boolean updateInternshipBatchNewsInfo() throws Exception {

		logger.infoCode("I0001", "updateInternshipBatchNewsInfo");

		String sqlName = "ItInternTbl.nativeFindAllBatchInternshipInfo";
		String sqlNamePublic = "ItInternPublicTbl.nativeFindAllInternshipPublicBatch";

		try {

			// ３－１．バッチ処理用抽出データ、インターンシップからの情報抽出
			Query query = entityManager.createNamedQuery(sqlName);
			query.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			 @SuppressWarnings({ "unchecked", "rawtypes" })
			List<Map> resultList = query.getResultList();

			for (int i = 0; i < resultList.size(); i++) {
				@SuppressWarnings("rawtypes")
				Map obj = resultList.get(i);
				Timestamp makeDate = Timestamp.valueOf(String.valueOf(obj.get("make_date")));
				String dataKbn = String.valueOf(obj.get("data_kbn"));
				String refDataKey = String.valueOf(obj.get("ref_data_key"));
				String internshipTitle = String.valueOf(obj.get("internship_title"));
				Timestamp internshipSendDate = Timestamp.valueOf(String.valueOf(obj.get("internship_send_date")));
				//String internshipPartyName = String.valueOf(obj.get("internship_party_name"));
				//String internshipTelno = String.valueOf(obj.get("internship_telno"));
				//String internshipRange = String.valueOf(obj.get("internship_range"));
				//Timestamp internshipStartDate = Timestamp.valueOf(String.valueOf(obj.get("internship_start_date")));
				//Timestamp internshipEndDate = Timestamp.valueOf(String.valueOf(obj.get("internship_end_date")));
				//String internshipMemo = String.valueOf(obj.get("internship_memo"));

				String opeKbn = CommonConst.OP_ACTION_END_ANNOUNCE;
				// 処理日付と配信日の日付が等しい場合
				if (DateUtil.formatTimestampStart(makeDate).equals(DateUtil.formatTimestampStart(internshipSendDate))) {
					opeKbn = CommonConst.OP_ACTION_ADDED;
				}

				// ３－３．インターンシップ公開範囲の参照
				Query queryPublic = entityManager.createNamedQuery(sqlNamePublic);
				queryPublic.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
				queryPublic.setParameter("infoRefKey", refDataKey);
				@SuppressWarnings({ "unchecked", "rawtypes" })
				List<Map> resultPublicList = queryPublic.getResultList();

				for (int j = 0; j < resultPublicList.size(); j++) {
					@SuppressWarnings({ "rawtypes" })
					Map objPublic = resultPublicList.get(j);
					//String internshipKey = String.valueOf(objPublic.get("internship_key"));
					int seqNo = Integer.valueOf(String.valueOf(objPublic.get("seq_no")));
					String publicKbn = String.valueOf(objPublic.get("public_kbn"));
					String role = String.valueOf(objPublic.get("role"));
					String partyCode = String.valueOf(objPublic.get("party_code"));
					String url = INTERNSHIP_URL;

					// ３－４－１．お知らせ情報の登録。
					// CmInfoTbl
					CmInfoTbl info = new CmInfoTbl();
					info.setSendDate(DateUtil.formatTimestampStart(internshipSendDate));
					info.setTitle(internshipTitle);
					info.setDataKbn(dataKbn);
					info.setOpeKbn(opeKbn);
					info.setInfoRefKey(refDataKey);
					info.setUrl(url);
					info.setMakeUserKey(CommonConst.USER_KEY_DUMMY);
					info.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
					info.setUpdDate(DateUtil.getNowTimestamp());
					CmInfoTbl infoResult = cmInfoTblRepository.save(info);
					if (infoResult == null) {
						throw new NullPointerException(CMINFOTBL_IS_NULL);
					}

					// ３－４－２．お知らせ情報公開範囲の登録。
					// CmInfoPublicTbl
					CmInfoPublicTbl infoPublic = new CmInfoPublicTbl();
					CmInfoPublicTblPK infoPublicId = new CmInfoPublicTblPK();
					infoPublicId.setInfoKey(infoResult.getInfoKey());

					infoPublicId.setSeqNo(seqNo);
					infoPublic.setId(infoPublicId);
					infoPublic.setPublicKbn(publicKbn);
					infoPublic.setRole(role);
					infoPublic.setPartyCode(partyCode);

					infoPublic.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
					infoPublic.setUpdDate(DateUtil.getNowTimestamp());
					CmInfoPublicTbl infoPublicResult = cmInfoPublicTblRepository.save(infoPublic);
					if (infoPublicResult == null) {
						throw new NullPointerException(CMINFOPUBLICTBL_IS_NULL);
					}
				}
				// ３－４－３．バッチ処理用抽出データの更新。
				CmBatchTargetTblPK batchTargetId = new CmBatchTargetTblPK();
				batchTargetId.setRefDataKey(refDataKey);
				batchTargetId.setMakeDate(makeDate);
				batchTargetId.setDataKbn(dataKbn);

				CmBatchTargetTbl batchTarget = cmBatchTargetTblRepository.findOne(batchTargetId);
				batchTarget.setInfoMakeFlag("1"); // 固定 ステータス更新
				batchTarget.setUpdDate(DateUtil.getNowTimestamp());
				batchTarget.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
				CmBatchTargetTbl batchTargetResult = cmBatchTargetTblRepository.save(batchTarget);
				if (batchTargetResult == null) {

					throw new NullPointerException(CMBATCHTARGETTBL_IS_NULL);
				}
			}

			cmInfoTblRepository.flush();
			cmInfoPublicTblRepository.flush();
			cmBatchTargetTblRepository.flush();

		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
			throw e;
		}

		return true;
	}

	// バッチ処理用抽出データの編集
	/**
	 * 支援制度からの情報抽出
	 *
	 * @param targetDay
	 * @return
	 * @throws Exception
	 */
	@Transactional
	public boolean updateSupportBatchTarget(String targetDay) throws Exception {
		logger.infoCode("I0001");

		Date targetDate = DateUtil.getDate(targetDay, "yyyyMMdd");

		// 取得条件：公開
		Specification<SpSupportTbl> wherePublicFlag = new Specification<SpSupportTbl>() {
					@Override
					public Predicate toPredicate(Root<SpSupportTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("publicFlag"), "1");
					}
				};
		// 取得条件：バッチステータス
		Specification<SpSupportTbl> whereBatchStatus = new Specification<SpSupportTbl>() {
					@Override
					public Predicate toPredicate(Root<SpSupportTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("batchStatus"), "0");
					}
				};
		// 取得条件：日付
		Specification<SpSupportTbl> whereTargetDay = new Specification<SpSupportTbl>() {
					@Override
					public Predicate toPredicate(Root<SpSupportTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("supportStartDate").as(Date.class), targetDate);
					}
				};

		List<SpSupportTbl> list = spSupportTblRepository.findAll(Specifications.where(wherePublicFlag).and(whereBatchStatus).and(whereTargetDay));

		if (list.size() == 0) {
			return true;
		}
		try {
			List<CmBatchTargetTbl> entityList = new ArrayList<>();
			for (SpSupportTbl tbl : list) {
				CmBatchTargetTbl entity = new CmBatchTargetTbl();
				CmBatchTargetTblPK id = new CmBatchTargetTblPK();
				id.setMakeDate(DateUtil.getNowTimestamp());
				if ("1".equals(tbl.getSupportSpkikiKbn())) {
					id.setDataKbn("5");
				} else {
					id.setDataKbn("6");
				}
				id.setRefDataKey(tbl.getSupportKey());
				entity.setId(id);
				entity.setUpdUserKey(tbl.getUpdUserKey());
				entity.setInfoMakeFlag("0");
				entity.setScheduleMakeFlag("1");
				entity.setMailMakeFlag("0");
				entity.setSendUserKey(null);
				entity.setSendRole(null);
				entity.setSendPartyCode(null);
				entity.setUpdDate(DateUtil.getNowTimestamp());
				entity.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
				entityList.add(entity);

				//
				tbl.setBatchStatus("1"); // バッチステータス更新
			}
			entityList = cmBatchTargetTblRepository.save(entityList);
			list = spSupportTblRepository.save(list);
			if (entityList != null) {
				logger.infoCode("I0002");
				return true;
			}
		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
			throw e;
		}
		return false;
	}

	/**
	 * イベントからの情報抽出
	 *
	 * @param targetDay
	 * @return
	 * @throws Exception
	 */
	@Transactional
	public boolean updateEventBatchTarget(String targetDay) throws Exception {
		logger.infoCode("I0001");

		Date targetDate = DateUtil.getDate(targetDay, "yyyyMMdd");

		// 取得条件：公開
		Specification<EvEventTbl> wherePublicFlag = new Specification<EvEventTbl>() {
					@Override
					public Predicate toPredicate(Root<EvEventTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("publicFlag"), "1");
					}
				};
		// 取得条件：バッチステータス
		Specification<EvEventTbl> whereBatchStatus = new Specification<EvEventTbl>() {
					@Override
					public Predicate toPredicate(Root<EvEventTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("batchStatus"), "0");
					}
				};
		// 取得条件：日付
		Specification<EvEventTbl> whereTargetDay = new Specification<EvEventTbl>() {
					@Override
					public Predicate toPredicate(Root<EvEventTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("eventSendDate").as(Date.class), targetDate);
					}
				};

		List<EvEventTbl> list = evEventTblRepository.findAll(Specifications.where(wherePublicFlag).and(whereBatchStatus).and(whereTargetDay));

		if (list.size() == 0) {
			return true;
		}
		try {
			List<CmBatchTargetTbl> entityList = new ArrayList<>();
			for (EvEventTbl tbl : list) {
				CmBatchTargetTbl entity = new CmBatchTargetTbl();
				CmBatchTargetTblPK id = new CmBatchTargetTblPK();
				id.setMakeDate(DateUtil.getNowTimestamp());
				id.setDataKbn("1");
				id.setRefDataKey(tbl.getEventKey());
				entity.setId(id);
				entity.setUpdUserKey(tbl.getUpdUserKey());
				entity.setInfoMakeFlag("0");
				entity.setScheduleMakeFlag("0");
				entity.setMailMakeFlag("0");
				entity.setSendUserKey(null);
				entity.setSendRole(null);
				entity.setSendPartyCode(null);
				entity.setUpdDate(DateUtil.getNowTimestamp());
				entity.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
				entityList.add(entity);

				//
				tbl.setBatchStatus("1"); // バッチステータス更新
			}
			entityList = cmBatchTargetTblRepository.save(entityList);
			list = evEventTblRepository.save(list);
			if (entityList != null) {
				logger.infoCode("I0002");
				return true;
			}
		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
			throw e;
		}
		return false;
	}

	/**
	 * インターンシップからの情報抽出
	 *
	 * @param targetDay
	 * @param adjustment
	 * @return
	 * @throws Exception
	 */
	@Transactional
	public boolean updateInternshipBatchTarget(String targetDay, int adjustment) throws Exception {
		logger.infoCode("I0001");

		Date targetDate = DateUtil.getDate(targetDay, "yyyyMMdd");
		Date adjustmentDate = DateUtil.getDate(DateUtil.addDay(targetDay, -(adjustment)), "yyyyMMdd");

		// 取得条件：公開
		Specification<ItInternTbl> wherePublicFlag = new Specification<ItInternTbl>() {
					@Override
					public Predicate toPredicate(Root<ItInternTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("publicFlag"), "1");
					}
				};
		// 取得条件：バッチステータス
		Specification<ItInternTbl> whereBatchStatus = new Specification<ItInternTbl>() {
					@Override
					public Predicate toPredicate(Root<ItInternTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("batchStatus"), "0");
					}
				};
		// 取得条件：日付
		Specification<ItInternTbl> whereTargetDay = new Specification<ItInternTbl>() {
					@Override
					public Predicate toPredicate(Root<ItInternTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						Predicate predicate = cb.disjunction();
						predicate = cb.or(predicate, cb.equal(root.get("internshipStartDate").as(Date.class), targetDate));
						predicate = cb.or(predicate, cb.equal(root.get("internshipEndDate").as(Date.class), adjustmentDate));
						return predicate;
					}
				};

		List<ItInternTbl> list = itInternTblRepository.findAll(Specifications.where(wherePublicFlag).and(whereBatchStatus).and(whereTargetDay));

		if (list.size() == 0) {
			return true;
		}
		try {
			List<CmBatchTargetTbl> entityList = new ArrayList<>();
			for (ItInternTbl tbl : list) {
				CmBatchTargetTbl entity = new CmBatchTargetTbl();
				CmBatchTargetTblPK id = new CmBatchTargetTblPK();
				id.setMakeDate(DateUtil.getNowTimestamp());
				id.setDataKbn("2");
				id.setRefDataKey(tbl.getInternshipKey());
				entity.setId(id);
				entity.setUpdUserKey(tbl.getUpdUserKey());
				entity.setInfoMakeFlag("0");
				entity.setScheduleMakeFlag("0");
				entity.setMailMakeFlag("0");
				entity.setSendUserKey(null);
				entity.setSendRole(null);
				entity.setSendPartyCode(null);
				entity.setUpdDate(DateUtil.getNowTimestamp());
				entity.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
				entityList.add(entity);

				//
				tbl.setBatchStatus("1"); // バッチステータス更新
			}
			entityList = cmBatchTargetTblRepository.save(entityList);
			list = itInternTblRepository.save(list);
			if (entityList != null) {
				logger.infoCode("I0002");
				return true;
			}
		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
			throw e;
		}
		return false;
	}

	/**
	 *
	 *
	 * @param refKey
	 * @param dataKbn
	 * @return
	 * @throws Exception
	 */
	@Transactional
	public boolean deleteScheduleBatch(String refKey, String dataKbn) throws Exception {
		logger.infoCode("I0001");
		if (refKey.isEmpty()) {
			return true;
		}
		try {
			int c1 = cmScheduleTblRepository.delete(refKey, dataKbn);
			int c2 = cmSchedulePublicTblRepository.delete(refKey);

			if (c1 > 0 && c2 > 0) {
				cmScheduleTblRepository.flush();
				cmSchedulePublicTblRepository.flush();
				logger.infoCode("I0002"); // I0002=メソッド終了:{0}
				return true;
			}
		} catch (Exception e) {
			logger.errorCode("E1009", e); // E1009=削除に失敗しました。{0}
			throw e;
		}
		return false;
	}

	// TODO
	@Transactional
	public boolean sendMailBatch(String title) throws Exception {
		logger.infoCode("I0001");
		if (title.isEmpty()) {
			return true;
		}
		try {
			// TODO発信の処理を呼び出す、成功なら、DB更新、失敗なら、ロールバック(ROLLBACK)
			// int c1 =sendMail();
			// if (c1 > 0 )
			// TblRepository.flush();
			// 発信成功
			logger.infoCode("I0002"); // I0002=メソッド終了:{0}
			return true;
			// }
		} catch (Exception e) {
			logger.errorCode("E1009", e); // E1009=発信に失敗しました。{0}
			throw e;
		}
	}

}
