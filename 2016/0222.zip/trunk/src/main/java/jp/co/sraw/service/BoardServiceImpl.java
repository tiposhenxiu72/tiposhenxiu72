/*
* ファイル名：BoardServiceImpl.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/01/21   mizoguchi      新規作成
*/
package jp.co.sraw.service;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonService;
import jp.co.sraw.common.UserInfo;
import jp.co.sraw.controller.board.BoardForm;
import jp.co.sraw.dto.KjBoardDto;
import jp.co.sraw.dto.KjBoardRelUserDto;
import jp.co.sraw.dto.KjGroupCommonFileDto;
import jp.co.sraw.dto.KjThredContributionDto;
import jp.co.sraw.dto.KjThredDto;
import jp.co.sraw.dto.KjThredUploadDto;
import jp.co.sraw.entity.KjBoardGroupTbl;
import jp.co.sraw.entity.KjBoardRelUser;
import jp.co.sraw.entity.KjBoardRelUserPK;
import jp.co.sraw.entity.KjGroupCommonFileTbl;
import jp.co.sraw.entity.KjGroupCommonFileTblPK;
import jp.co.sraw.entity.KjThredContributionTbl;
import jp.co.sraw.entity.KjThredContributionTblPK;
import jp.co.sraw.entity.KjThredReadTbl;
import jp.co.sraw.entity.KjThredReadTblPK;
import jp.co.sraw.entity.KjThredTbl;
import jp.co.sraw.entity.KjThredUploadTbl;
import jp.co.sraw.entity.KjThredUploadTblPK;
import jp.co.sraw.entity.UsInfoTbl;
import jp.co.sraw.entity.UsLoginInfoTbl;
import jp.co.sraw.entity.UsUserTbl;
import jp.co.sraw.file.FileDto;
import jp.co.sraw.file.FileService;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.mail.MailServiceImpl;
import jp.co.sraw.repository.KjBoardGroupTblRepository;
import jp.co.sraw.repository.KjBoardRelUserRepository;
import jp.co.sraw.repository.KjGroupCommonFileTblRepository;
import jp.co.sraw.repository.KjThredContributionTblRepository;
import jp.co.sraw.repository.KjThredReadTblRepository;
import jp.co.sraw.repository.KjThredTblRepository;
import jp.co.sraw.repository.KjThredUploadTblRepository;
import jp.co.sraw.repository.UsInfoTblRepository;
import jp.co.sraw.repository.UsLoginInfoTblRepository;
import jp.co.sraw.repository.UsUserTblRepository;
import jp.co.sraw.util.DateUtil;
import jp.co.sraw.util.StringUtil;

/**
* <B>BoardServiceImplクラス</B>
* <P>
* 掲示板サービスのメソッドを提供する
*/
@Service
@Transactional(readOnly = true)
public class BoardServiceImpl extends CommonService {

	@Autowired
	private EntityManager entityManager;

	@Autowired
	private KjBoardGroupTblRepository kjBoardGroupTblRepository;

	@Autowired
	private KjBoardRelUserRepository kjBoardRelUserRepository;

	@Autowired
	private KjGroupCommonFileTblRepository kjGroupCommonFileTblRepository;

	@Autowired
	private KjThredTblRepository kjThredTblRepository;

	@Autowired
	private KjThredContributionTblRepository kjThredContributionTblRepository;

	@Autowired
	private KjThredReadTblRepository kjThredReadTblRepository;

	@Autowired
	private KjThredUploadTblRepository kjThredUploadTblRepository;

	@Autowired
	private UsUserTblRepository usUserTblRepository;

	@Autowired
	private UsInfoTblRepository usInfoTblRepository;

	@Autowired
	private MailServiceImpl mailServiceImpl;

	@Autowired
	private UsLoginInfoTblRepository usLoginInfoTblRepository;

	@Autowired
	private FileService fileService;

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(BoardServiceImpl.class);

	private static final String CODE_PUBLIC_FLG_0 = "0";  // 公開フラグ = 0：公開しない

	private static final String CODE_STATUSKBN_0 = "0";  //ユーザ状態区分 = 1：承認待ち
	private static final String CODE_STATUSKBN_1 = "1";  //ユーザ状態区分 = 1：承認済み
	private static final String CODE_STATUSKBN_2 = "2";  //ユーザ状態区分 = 2：承認拒否

	private static final String UPLOAD_FLG_0 = "0";  //アップロードフラグ = 0：未処理
	private static final String UPLOAD_FLG_1 = "1";  //アップロードフラグ = 1：アップロード済み

	private static final String URL_BOARD = "board/thread";

	private static final String SEPARATOR = "/";

	@PostConstruct
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	/**
	 * ユーザー情報取得
	 *
	 * @param userInfo
	 * @return
	 */
	public UsUserTbl findUser(UserInfo userInfo) {
		return usUserTblRepository.getOne(userInfo.getTargetUserKey());
	}

	/***
	 * 掲示板グループ一覧取得
	 *
	 * @param userInfo
	 * @return
	 */
	public List <KjBoardGroupTbl> findBoardGroupList(UserInfo userInfo) {
		return kjBoardGroupTblRepository.findAllThred(userInfo.getTargetUserKey());
	}

	/***
	 * メンバー検索用
	 *
	 * @param partyName
	 * @param affiliationName
	 * @param userName
	 * @return
	 */
	public List <KjBoardRelUserDto> findSearchMemberList(String partyName, String affiliationName, String userName) {
		return kjBoardRelUserRepository.findSearchMemberList(partyName, affiliationName, userName);
	}

	/**
	 * 掲示板グループ新規追加、更新
	 *
	 * @param userInfo
	 * @param form
	 * @param locale
	 * @return
	 */
	@Transactional
	public boolean update(UserInfo userInfo, BoardForm form, Locale locale) throws Exception {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}
		KjBoardGroupTbl kjGroupEntity = new KjBoardGroupTbl();
		// 更新の場合
		if (CommonConst.PAGE_MODE_EDIT.equals(form.getPageMode())) {
			kjGroupEntity = findOne(form);
			if (kjGroupEntity.getBoardGroupKey() == null) {
				throw new Exception();
			}
		}
		kjGroupEntity.setBoardName(form.getBoardName());
		kjGroupEntity.setCommonFlag(form.getCommonFlag());
		kjGroupEntity.setPublicFlag(form.getPublicFlag());
		kjGroupEntity.setAdminUserKey(form.getAdminUserKey());
		kjGroupEntity.setOutline(form.getOutline());
		kjGroupEntity.setUpdUserKey(userInfo.getLoginUserKey());
		kjGroupEntity.setUpdDate(DateUtil.getNowTimestamp());
		// 掲示板グループ作成
		kjGroupEntity = kjBoardGroupTblRepository.save(kjGroupEntity);

		if (kjGroupEntity.getBoardGroupKey() != null) {
			// 掲示板ユーザーリレーションデータ取得
			List<KjBoardRelUser> relUser = findRelUser(kjGroupEntity.getBoardGroupKey());

			// 登録されているユーザーをセット
			Map<String, String> member = new HashMap<String, String>();
			if (relUser.size() != 0) {
				for (int i = 0; i < relUser.size(); i++) {
					member.put(relUser.get(i).getId().getUserKey(), relUser.get(i).getUserStatusKbn());
				}
			}
			List<KjBoardRelUser> relUserAdd = new ArrayList<>(); // 追加ユーザー用
			List<KjBoardRelUser> relUserDel = new ArrayList<>(); // 削除ユーザー用
			List<KjBoardRelUserDto> sendMailList = new ArrayList<>(); // メール送信用

			boolean addFlg= false;
			for (int i = 0; i < form.getRelUserKey().length; i++) {
				addFlg = false;
				if (!member.containsKey(form.getRelUserKey()[i])) {
					// ユーザーキーが存在しない場合、追加対象
					addFlg = true;
				} else {
					// ユーザーキーが存在する場合、状態区分が異なる場合は追加対象
					if (!member.get(form.getRelUserKey()[i]).equals(form.getRelUserStatusKbn()[i])) {
						addFlg = true;
					}
				}

				if (addFlg == true) {
					//追加対象ユーザー
					KjBoardRelUser tbl = new KjBoardRelUser();
					KjBoardRelUserPK pk = new KjBoardRelUserPK();
					pk.setBoardGroupKey(kjGroupEntity.getBoardGroupKey());
					pk.setUserKey(form.getRelUserKey()[i]);
					tbl.setId(pk);
					if (form.getRelUserKey()[i].equals(userInfo.getTargetUserKey())) {
						tbl.setUserStatusKbn(CODE_STATUSKBN_1); // 対象ユーザー本人の場合＝「1:承認済」
					} else {
						tbl.setUserStatusKbn(CODE_STATUSKBN_0); // 対象ユーザー本人以外＝「0:承認待ち」
					}
					tbl.setUpdDate(DateUtil.getNowTimestamp());
					tbl.setUpdUserKey(userInfo.getLoginUserKey());
					relUserAdd.add(tbl);

					//メール送信用(対象ユーザー除く)
					if (!form.getRelUserKey()[i].equals(userInfo.getTargetUserKey())) {
						KjBoardRelUserDto dto = new KjBoardRelUserDto();
						dto = getUserInfo(form.getRelUserKey()[i], kjGroupEntity.getBoardGroupKey(), locale);
						sendMailList.add(dto);
					}
				}
			}

			// メール送信リストをフォームにセット
			form.setSendMailList(sendMailList);

			//フォームから取得したユーザーをセット
			Map<String, String> user = new HashMap<String, String>();
			for (int i = 0; i < form.getRelUserKey().length; i++) {
				user.put(form.getRelUserKey()[i], form.getRelUserStatusKbn()[i]);
			}
			boolean delFlg= false;
			if (relUser.size() != 0) {
				for (int i = 0; i < relUser.size(); i++) {
					delFlg = false;
					if (!user.containsKey(relUser.get(i).getId().getUserKey())){
						// ユーザーキーが存在しない場合、削除対象
						delFlg = true;
					} else {
						// ユーザーキーが存在する場合、状態区分が異なる場合は削除対象
						if (!user.get(relUser.get(i).getId().getUserKey()).equals(relUser.get(i).getUserStatusKbn())) {
							delFlg = true;
						}
					}
					if (delFlg == true) {
						//削除対象ユーザー
						KjBoardRelUser tbl = new KjBoardRelUser();
						KjBoardRelUserPK pk = new KjBoardRelUserPK();
						pk.setBoardGroupKey(kjGroupEntity.getBoardGroupKey());
						pk.setUserKey(relUser.get(i).getId().getUserKey());
						tbl.setId(pk);
						relUserDel.add(tbl);
					}
				}
			}
			// 削除ユーザーを削除
			kjBoardRelUserRepository.delete(relUserDel);
			// 追加ユーザーを登録
			kjBoardRelUserRepository.save(relUserAdd);

			// お知らせ情報にセットするタイトルのデータ(
			String title = "";
			if (form.getBoardName().length() > 80) {
				title = form.getBoardName().substring(0, 80);
			} else {
				title = form.getBoardName();
			}
			title = messageSource.getMessage("operation.function.board.group", null, locale) + "(" + title + ")";

			// ユーザお知らせ情報(追加ユーザーのみ、対象ユーザー本人は除く)
			List<UsInfoTbl> usInfoEntity = new ArrayList<>();
			for (int i = 0; i < relUserAdd.size(); i++) {
				if (!relUserAdd.get(i).getId().getUserKey().equals(userInfo.getTargetUserKey())) {
					// ユーザお知らせ情報
					UsInfoTbl usTbl = new UsInfoTbl();
					UsUserTbl usUserTbl = new UsUserTbl();
					usUserTbl.setUserKey(relUserAdd.get(i).getId().getUserKey());
					usTbl.setUsUserTbl(usUserTbl);
					usTbl.setSendDate(DateUtil.getNowTimestamp());
					usTbl.setTitle(title);
					usTbl.setDataKbn(CommonConst.INFO_DATA_KBN_BOARD);
					usTbl.setOpeKbn(CommonConst.OP_ACTION_INVITATION);
					usTbl.setInfoRefKey(kjGroupEntity.getBoardGroupKey());
					usTbl.setUrl(URL_BOARD);
					usTbl.setMakeUserKey(userInfo.getLoginUserKey());
					usTbl.setUpdDate(DateUtil.getNowTimestamp());
					usTbl.setUpdUserKey(userInfo.getLoginUserKey());
					usInfoEntity.add(usTbl);
				}
			}
			usInfoEntity = usInfoTblRepository.save(usInfoEntity);

			kjBoardGroupTblRepository.flush();
			kjBoardRelUserRepository.flush();
			usInfoTblRepository.flush();

			logger.infoCode("I0002"); // I0002=メソッド終了:{0}
			return true;
		}
	return false;
	}


	/**
	 * ユーザー情報取得
	 * @param userKey
	 * @param boardGroupKey
	 * @param locale
	 * @return
	 */
	public KjBoardRelUserDto getUserInfo(String userKey, String boardGroupKey, Locale locale){

		KjBoardRelUserDto dto = new KjBoardRelUserDto();
		UsUserTbl entity = new UsUserTbl();
		entity = usUserTblRepository.getOne(userKey);

		UsLoginInfoTbl usLoginDto = new UsLoginInfoTbl();
		usLoginDto = findUser(userKey);

		if (entity.getUserKey() != null) {
			dto.setBoardGroupKey(boardGroupKey);
			dto.setUserKey(entity.getUserKey());
			dto.setMailAddress(usLoginDto.getPortalLoginId());
			if (CommonConst.DEFAULT_LOCALE.getLanguage().equals(locale.getLanguage())) {
				dto.setUserName(StringUtil.nvl(entity.getUserFamilyName(), "") +
								StringUtil.nvl(entity.getUserMiddleName(), "") +
								StringUtil.nvl(entity.getUserName(), ""));
			} else {
				dto.setUserName(StringUtil.nvl(entity.getUserFamilyNameEn(), "") +
								StringUtil.nvl(entity.getUserMiddleNameEn(), "") +
								StringUtil.nvl(entity.getUserNameEn(), ""));
			}
		}
		return dto;
	}


	/**
	 * メール送信（掲示板グループ招待）
	 * @param list
	 * @param locale
	 * @return
	 */
	public boolean sendMailKjGroupInvitation(List<KjBoardRelUserDto> list, Locale locale){
		// メール送信
		for (int i = 0; i < list.size(); i++) {
			// パラメータ生成
			String userName = "";
			String toMailAddress = "";
			String requestId = "";

			userName = list.get(i).getUserName();
			toMailAddress = list.get(i).getMailAddress();
			requestId = list.get(i).getBoardGroupKey() + SEPARATOR + list.get(i).getUserKey();

			// メール送信処理
			if (!mailServiceImpl.kjGroupInvitation(userName, toMailAddress, requestId, locale)) {
				return false;
			}
		}
		return true;
	}


	/**
	 * ログインユーザー情報
	 *
	 * @param userKey
	 * @return
	 */
	public UsLoginInfoTbl findUser(String userKey) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		Specification<UsLoginInfoTbl> whereUserKey = StringUtil.isNull(userKey) ? null
				: new Specification<UsLoginInfoTbl>() {
					@Override
					public Predicate toPredicate(Root<UsLoginInfoTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("usUserTbl").get("userKey"), userKey);
					}
				};
		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return usLoginInfoTblRepository.findOne(Specifications.where(whereUserKey));
	}


	/**
	 * 削除処理(掲示板グループ全体)
	 *
	 * @param userInfo
	 * @param form
	 * @return
	 */
	@Transactional
	public boolean delete(UserInfo userInfo, BoardForm form) throws Exception {
		logger.infoCode("I0001", "delete"); // I0001=メソッド開始:{0}

		KjBoardGroupTbl entity = findOne(form);

		if (entity.getBoardGroupKey() == null) {
			throw new Exception();
		}

		// 掲示板ユーザリレーション削除
		kjBoardRelUserRepository.delete(entity.getKjBoardRelUsers());

		// アップロードファイルの削除
		for (KjGroupCommonFileTbl tbl : entity.getKjGroupCommonFileTbls()) {
			int res = fileService.deleteUploadFile(tbl.getId().getUploadKey());
		}

		// 掲示板グループ共有ファイル削除
		kjGroupCommonFileTblRepository.delete(entity.getKjGroupCommonFileTbls());

		for (KjThredTbl thred : entity.getKjThredTbls()){
			for (KjThredContributionTbl contribution : thred.getKjThredContributionTbls()){
				// アップロードファイルの削除
				for (KjThredUploadTbl upload : contribution.getKjThredUploadTbls()){
					fileService.deleteUploadFile(upload.getId().getUploadKey());
				}
				// 掲示板スレッド添付ファイルの削除
				kjThredUploadTblRepository.delete(contribution.getKjThredUploadTbls());
			}
			// 掲示板スレッド投稿実績の削除
			kjThredContributionTblRepository.delete(thred.getKjThredContributionTbls());
			// 掲示板スレッド参照実績の削除
			kjThredReadTblRepository.delete(thred.getKjThredReadTbls());
		}

		// 掲示板スレッド情報の削除
		kjThredTblRepository.delete(entity.getKjThredTbls());

		// 掲示板グループの削除
		int res = kjBoardGroupTblRepository.delete(entity.getBoardGroupKey(), entity.getUpdDate());

		if (res == 0) {
			throw new Exception();
		}

		if (res > 0) {
			kjBoardRelUserRepository.flush();
			kjGroupCommonFileTblRepository.flush();
			kjThredTblRepository.flush();
			kjThredContributionTblRepository.flush();
			kjThredReadTblRepository.flush();
			kjThredUploadTblRepository.flush();
			kjBoardGroupTblRepository.flush();
			logger.infoCode("I0002", "delete");
			return true;
		}
		return false;
	}


	/**
	 * 掲示板グループキーとデータ更新日指定取得
	 *
	 * @param form
	 * @return
	 */
	public KjBoardGroupTbl findOne(BoardForm form) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		Specification<KjBoardGroupTbl> whereBoardGroupKey = StringUtil.isNull(form.getBoardGroupKey()) ? null
				: new Specification<KjBoardGroupTbl>() {
					@Override
					public Predicate toPredicate(Root<KjBoardGroupTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("boardGroupKey"), form.getBoardGroupKey());
					}
				};
		Specification<KjBoardGroupTbl> whereUpdDate = DateUtil.isNull(form.getUpdDate()) ? null
				: new Specification<KjBoardGroupTbl>() {
					@Override
					public Predicate toPredicate(Root<KjBoardGroupTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("updDate"), form.getUpdDate());
					}
				};

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return kjBoardGroupTblRepository.findOne(Specifications.where(whereBoardGroupKey).and(whereUpdDate));
	}


	/**
	 * ファイルアップロード処理実行(共有情報管理)
	 *
	 * @param userInfo
	 * @param form
	 * @return
	 */
	@Transactional
	public String fileUpload(UserInfo userInfo, BoardForm form) throws Exception {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		String uploadKey = null;
		if (CommonConst.PAGE_MODE_ADD.equals(form.getPageMode())) {
			if (form.getUploadFlg().equals(UPLOAD_FLG_1)) {
				//ファイルアップロードテーブル削除、ファイル削除
				int res = fileService.deleteUploadFile(form.getUploadKey());
			}
		}

		if (CommonConst.PAGE_MODE_EDIT.equals(form.getPageMode())) {
			if (form.getUploadFlgAfter().equals(UPLOAD_FLG_1)) {
				//ファイルアップロードテーブル削除、ファイル削除
				int res = fileService.deleteUploadFile(form.getUploadKeyAfter());
			}
		}

		// ファイルアップロード処理実行
		FileDto fileDto = new FileDto();
		fileDto.SetFileKbn(CommonConst.UPLOAD_FILE_KBN_BOARD);
		String fileName = new File(form.getDoc().getOriginalFilename()).getName();
		fileDto.setUploadName(fileName);
		fileDto.setFile(form.getDoc());
		// ファイルアップロード処理
		uploadKey = fileService.putUploadFile(fileDto, userInfo.getTargetUserKey(), userInfo.getLoginUserKey());

//		if (uploadKey == null) {
//			logger.errorCode("E1012"); // ファイルのアップロードに失敗しました。{0}
//			throw new Exception();
//		}
		return uploadKey;
	}


	/**
	 * 共有管理情報  登録、更新処理
	 *
	 * @param userInfo
	 * @param form
	 * @return
	 */
	@Transactional
	public boolean fileUpdate(UserInfo userInfo, BoardForm form) throws Exception {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		KjGroupCommonFileTbl entity = new KjGroupCommonFileTbl();

		if (CommonConst.PAGE_MODE_EDIT.equals(form.getPageMode())) {
			// 更新の場合
			if (form.getUploadFlg().equals(UPLOAD_FLG_1) && form.getUploadFlgAfter().equals(UPLOAD_FLG_0)) {
				// 掲示板共有ファイルのみ更新
				entity = new KjGroupCommonFileTbl();
				entity = findOneCommonFile(form);
				if (entity == null) {
					throw new Exception();
				}
				entity.setTitle(form.getTitle());
				entity.setUpdUserKey(userInfo.getLoginUserKey());
				entity.setUpdDate(DateUtil.getNowTimestamp());
				entity = kjGroupCommonFileTblRepository.save(entity);
			}

			if (form.getUploadFlg().equals(UPLOAD_FLG_1) && form.getUploadFlgAfter().equals(UPLOAD_FLG_1)) {
				// 掲示板共有ファイル 取得
				entity = new KjGroupCommonFileTbl();
				entity = findOneCommonFile(form);
				if (entity == null) {
					throw new Exception();
				}

				//ファイルアップロード実行処理(削除)
				int res = fileService.deleteUploadFile(form.getUploadKey());
				if (res != 0) {
					throw new Exception();
				}

				// 共有情報管理ファイル 削除
				int result = kjGroupCommonFileTblRepository.delete(form.getBoardGroupKey(), form.getUploadKey(), form.getUpdDate());

				if (result == 0) {
					throw new Exception();
				}

				// 共有情報管理ファイル 登録
				if (form.getUploadKeyAfter() == null) {
					throw new Exception();
				}
				entity = new KjGroupCommonFileTbl();
				KjGroupCommonFileTblPK pk = new KjGroupCommonFileTblPK();
				pk.setBoardGroupKey(form.getBoardGroupKey());
				pk.setUploadKey(form.getUploadKeyAfter());
				entity.setId(pk);
				entity.setTitle(form.getTitle());
				entity.setUpdUserKey(userInfo.getLoginUserKey());
				entity.setUpdDate(DateUtil.getNowTimestamp());
				entity = kjGroupCommonFileTblRepository.save(entity);
			}

			if (entity.getId().getBoardGroupKey() != null) {
				kjGroupCommonFileTblRepository.flush();
				logger.infoCode("I0002"); // I0002=メソッド終了:{0}
				return true;
			}
		}

		if (CommonConst.PAGE_MODE_ADD.equals(form.getPageMode())) {
			//新規登録の場合
			if (form.getUploadKey() == null) {
				throw new Exception();
			}
			entity = new KjGroupCommonFileTbl();
			KjGroupCommonFileTblPK pk = new KjGroupCommonFileTblPK();
			pk.setBoardGroupKey(form.getBoardGroupKey());
			pk.setUploadKey(form.getUploadKey());
			entity.setId(pk);
			entity.setTitle(form.getTitle());
			entity.setUpdUserKey(userInfo.getLoginUserKey());
			entity.setUpdDate(DateUtil.getNowTimestamp());
			entity = kjGroupCommonFileTblRepository.save(entity);

			if (entity.getId().getBoardGroupKey() != null) {
				kjGroupCommonFileTblRepository.flush();
				logger.infoCode("I0002"); // I0002=メソッド終了:{0}
				return true;
			}
		}
		return false;
	}


	/**
	 * 共有情報管理ファイル削除
	 *
	 * @param userInfo
	 * @param form
	 * @return
	 */
	@Transactional
	public boolean fileDelete(UserInfo userInfo, BoardForm form) throws Exception {
		logger.infoCode("I0001");

		KjGroupCommonFileTbl entity = new KjGroupCommonFileTbl();
		// 共有情報管理ファイル 取得
		entity = findOneCommonFile(form);

		if (entity == null) {
			throw new Exception();
		}

		//ファイルアップロードテーブル削除、ファイル削除
		int res = fileService.deleteUploadFile(entity.getId().getUploadKey());

		// 共有情報管理ファイル削除
		int result = kjGroupCommonFileTblRepository.delete(form.getBoardGroupKey(), form.getUploadKey(), form.getUpdDate());

		if (result > 0) {
			kjGroupCommonFileTblRepository.flush();
			logger.infoCode("I0002"); // I0002=メソッド終了:{0}
			return true;
		}
		return false;
	}


	/**
	 * 掲示板グループ取得(グループキー指定)
	 *
	 * @param boardGroupKey
	 * @return
	 */
	public KjBoardGroupTbl getOne(String boardGroupKey) {
		return kjBoardGroupTblRepository.getOne(boardGroupKey);
	}


	/**
	 * 掲示板スレッド取得(スレッドキー指定)
	 *
	 * @param thredKey
	 * @return
	 */
	public KjThredTbl getOneThred(String thredKey) {
		return kjThredTblRepository.getOne(thredKey);
	}


	/***
	 * 掲示板ユーザーリレーション取得(グループキー指定)
	 *
	 * @param boardGroupKey
	 * @return
	 */
	public List<KjBoardRelUser> findRelUser(String boardGroupKey) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		Specification<KjBoardRelUser> whereBoardGroupKey = StringUtil.isNull(boardGroupKey) ? null : new Specification<KjBoardRelUser>(){
			@Override
			public Predicate toPredicate(Root<KjBoardRelUser> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.get("id").get("boardGroupKey"), boardGroupKey);
			}
		};

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return kjBoardRelUserRepository.findAll(Specifications.where(whereBoardGroupKey));
	}


	/***
	 * 共有情報管理一覧取得
	 *
	 * @param form
	 * @return
	 */
	public List<KjGroupCommonFileTbl> findAllCommonFile(BoardForm form) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		Specification<KjGroupCommonFileTbl> whereBoardGroupKey = StringUtil.isNull(form.getBoardGroupKey()) ? null : new Specification<KjGroupCommonFileTbl>(){
			@Override
			public Predicate toPredicate(Root<KjGroupCommonFileTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.get("id").get("boardGroupKey"), form.getBoardGroupKey());
			}
		};
		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return kjGroupCommonFileTblRepository.findAll(Specifications.where(whereBoardGroupKey));
	}


	/**
	 * 共有情報管理ファイル取得(掲示板グループキー、アップロードキー)
	 *
	 * @param boardGroupKey
	 * @param uploadKey
	 * @return
	 */
	public KjGroupCommonFileDto findCommonFile(String boardGroupKey, String uploadKey) {
		return kjGroupCommonFileTblRepository.findCommonFile(boardGroupKey, uploadKey);
	}


	/**
	 * 共有情報管理ファイル取得(掲示板グループキー、アップロードキー、更新日)
	 *
	 * @param form
	 * @return
	 */
	public KjGroupCommonFileTbl findOneCommonFile(BoardForm form) {

		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		Specification<KjGroupCommonFileTbl> whereBoardGroupKey = StringUtil.isNull(form.getBoardGroupKey()) ? null
				: new Specification<KjGroupCommonFileTbl>() {
					@Override
					public Predicate toPredicate(Root<KjGroupCommonFileTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("id").get("boardGroupKey"), form.getBoardGroupKey());
					}
				};
		Specification<KjGroupCommonFileTbl> whereUploadKey = StringUtil.isNull(form.getUploadKey()) ? null
				: new Specification<KjGroupCommonFileTbl>() {
					@Override
					public Predicate toPredicate(Root<KjGroupCommonFileTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("id").get("uploadKey"), form.getUploadKey());
					}
				};
		Specification<KjGroupCommonFileTbl> whereUpdDate = DateUtil.isNull(form.getUpdDate()) ? null
				: new Specification<KjGroupCommonFileTbl>() {
					@Override
					public Predicate toPredicate(Root<KjGroupCommonFileTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("updDate"), form.getUpdDate());
					}
				};

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return kjGroupCommonFileTblRepository.findOne(Specifications.where(whereBoardGroupKey).and(whereUploadKey).and(whereUpdDate));
	}


	/***
	 * 掲示板一覧取得(検索用)
	 *
	 * @param userInfo
	 * @param form
	 * @param locale
	 * @return
	 */
	public List<KjBoardDto> findThredSearchList(UserInfo userInfo, BoardForm form, Locale locale) {
		logger.infoCode("I0001");

		String sqlName = "BoardService.getSearchThred";
		Query query = entityManager.createNamedQuery(sqlName);
		query.unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		query.setParameter("userKey", userInfo.getTargetUserKey());
		if (form.getSearchKeyword() == null) {
			query.setParameter("keyWord", "%");
		} else {
			query.setParameter("keyWord", "%"+form.getSearchKeyword()+"%");
		}

		List<KjThredDto> list = new ArrayList<>();
		List<Map> resultList = new ArrayList<>();
		resultList = query.getResultList();

		for (int i = 0; i < resultList.size(); i++) {
			KjThredDto dto = new KjThredDto();
			dto = (KjThredDto) objectUtil.setMapCopyValue(dto, resultList.get(i));
			list.add(dto);
		}
		logger.infoCode("I0002");
		return getSearchKjBoardDtoList(list, userInfo, locale);
	}


	/***
	 * 掲示板一覧DTO生成(検索用)
	 *
	 * @param list
	 * @param userInfo
	 * @param locale
	 * @return
	 */
	public List<KjBoardDto> getSearchKjBoardDtoList(List<KjThredDto> list, UserInfo userInfo, Locale locale) {

		List<KjBoardDto> boardList = new ArrayList<>();
		String boardGroupKey = "";

		// 掲示板グループをセット
		if (list.size() > 0) {
			for (KjThredDto thred : list) {
				if (!thred.getBoardGroupKey().equals(boardGroupKey)) {
					KjBoardDto boardDto = new KjBoardDto();
					// 掲示板グループキー
					boardDto.setBoardGroupKey(thred.getBoardGroupKey());
					// 掲示板名称
					boardDto.setBoardName(thred.getBoardName());
					// 管理者
					boardDto.setAdminUserKey(thred.getAdminUserKey());
					// スレッド件数
					//boardDto.setThredCount(thred.getThredCount());
					// 未読
					boardDto.setUnRead(thred.getUnReadCount());
					boardList.add(boardDto);

					boardGroupKey = thred.getBoardGroupKey();
				}
			}

			for (KjBoardDto dto : boardList) {
				List<KjThredDto> thredList = new ArrayList<>();
				int count = 0;
				for (KjThredDto thred : list) {
					if (dto.getBoardGroupKey().equals(thred.getBoardGroupKey())) {
						if (!thred.getThredKey().equals("")) {
							KjThredDto thredDto = new KjThredDto();
							count ++;
							// スレッドキー
							thredDto.setThredKey(thred.getThredKey());
							// スレッド名
							thredDto.setThredName(thred.getThredName());
							// スレッド最終更新日付
							thredDto.setUpdDate(thred.getUpdDate());
							// 作成者
							if (CommonConst.DEFAULT_LOCALE.getLanguage().equals(locale.getLanguage())) {
								thredDto.setInsUserName(thred.getInsUserName());
							} else {
								thredDto.setInsUserName(thred.getInsUserNameEn());
							}
							// 投稿件数(作成者のスレッドを除く件数)
							thredDto.setContributionCount(thred.getContributionCount());
							// 投稿実績最終更新日付
							thredDto.setContributionUpdDate(thred.getContributionUpdDate());
							// 未読
							thredDto.setReadCount(thred.getReadCount());
							thredList.add(thredDto);
						}
					}
				}
				// スレッド件数
				dto.setThredCount(count);

				dto.setKjThreds(thredList);
			}
		}
		return boardList;
	}


	/***
	 * 掲示板スレッドデータ取得
	 *
	 * @param thredKey
	 * @return
	 */
	public KjThredTbl findThredOne(String thredKey) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		Specification<KjThredTbl> whereThredKey = StringUtil.isNull(thredKey) ? null
				: new Specification<KjThredTbl>(){
					@Override
					public Predicate toPredicate(Root<KjThredTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("thredKey"), thredKey);
					}
				};
		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return kjThredTblRepository.findOne(Specifications.where(whereThredKey));
	}


	/***
	 * 掲示板スレッド表示・投稿データ取得
	 *
	 * @param userInfo
	 * @param thredKey
	 * @param locale
	 * @return
	 */
	public List<KjThredContributionDto> findThredDetail(UserInfo userInfo, String thredKey, Locale locale) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		List<KjThredContributionTbl> contributionList = new ArrayList<>();
		// スレッドキー
		Specification<KjThredContributionTbl> whereThredKey = StringUtil.isNull(thredKey) ? null
				: new Specification<KjThredContributionTbl>() {
					@Override
					public Predicate toPredicate(Root<KjThredContributionTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("id").get("thredKey"), thredKey);
					}
				};

		contributionList = kjThredContributionTblRepository.findAll(Specifications.where(whereThredKey), kjContributionOrderBy());
		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return getKjContributionDto(contributionList, userInfo, locale);
	}


	/**
	 * kjThredOrderBy
	 *
	 * @return
	 */
	private Sort kjContributionOrderBy() {
		// 投稿実績の連番、アップロードキー（昇順）
		return new Sort(Sort.Direction.ASC, "id.thredKey", "id.seqNo");
	}

	/***
	 * 掲示板スレッドDTO生成
	 *
	 * @param list
	 * @param userInfo
	 * @param locale
	 * @return
	 */
	public List<KjThredContributionDto> getKjContributionDto(List<KjThredContributionTbl> list, UserInfo userInfo, Locale locale) {

		List<KjThredContributionDto> contributionDtoList =  new ArrayList<>();
		for (KjThredContributionTbl conTbl : list) {
			KjThredContributionDto contributionDto = new KjThredContributionDto();
			// スレッドキー
			contributionDto.setThredKey(conTbl.getId().getThredKey());
			// スレッド名
			contributionDto.setThredName(conTbl.getKjThredTbl().getThredName());
			// 連番
			contributionDto.setSeqNo(conTbl.getId().getSeqNo());
			// ユーザーキー
			contributionDto.setUserKey(conTbl.getUserKey());
			// メモ
			contributionDto.setMemo(StringUtil.nl2br(StringUtil.htmlFilter(conTbl.getMemo())));
			// ユーザー名
			if (CommonConst.DEFAULT_LOCALE.getLanguage().equals(locale.getLanguage())) {
				contributionDto.setUserName(StringUtil.nvl(conTbl.getUsUserTbl().getUserFamilyName(), "")+
											StringUtil.nvl(conTbl.getUsUserTbl().getUserMiddleName(), "")+
											StringUtil.nvl(conTbl.getUsUserTbl().getUserName(), ""));
			} else {
				contributionDto.setUserName(StringUtil.nvl(conTbl.getUsUserTbl().getUserFamilyNameEn(), "")+
											StringUtil.nvl(conTbl.getUsUserTbl().getUserMiddleNameEn(), "")+
											StringUtil.nvl(conTbl.getUsUserTbl().getUserNameEn(), ""));
			}

			// 所属
			contributionDto.setAffiliationName(StringUtil.nvl(conTbl.getUsUserTbl().getAffiliationName(), "")+
									StringUtil.nvl(conTbl.getUsUserTbl().getResearchSubject(), "")+
									StringUtil.nvl(conTbl.getUsUserTbl().getResearchArea(), ""));
			// 更新日
			contributionDto.setUpdDate(conTbl.getUpdDate());

			List<KjThredUploadDto> uploadDtoList = new ArrayList<>();
			for (KjThredUploadTbl uploadTbl : conTbl.getKjThredUploadTbls()) {
				KjThredUploadDto uploadDto = new KjThredUploadDto();
				// アップロードキー
				uploadDto.setUploadKey(uploadTbl.getId().getUploadKey());

				FileDto dto = new FileDto();
				dto = fileService.getFileUploadDto(uploadTbl.getId().getUploadKey());

				//ファイル名
				uploadDto.setFileName(dto.getUploadName());
				uploadDtoList.add(uploadDto);
			}
			contributionDto.setKjThredUploads(uploadDtoList);
			contributionDtoList.add(contributionDto);
		}
		return contributionDtoList;
	}


	/***
	 * 掲示板グループメンバー取得(新規、編集時)
	 *
	 * @param form
	 * @param userInfo
	 * @param locale
	 * @return
	 */
	public List <KjBoardRelUserDto> findGroupMemberList(BoardForm form, UserInfo userInfo, Locale locale) {
		List <KjBoardRelUserDto> dtoList = new ArrayList<>();

		if (CommonConst.PAGE_MODE_ADD.equals(form.getPageMode())) {
			// 新規は対象ユーザー本人のみ作成
			UsUserTbl user = usUserTblRepository.getOne(userInfo.getTargetUserKey());
			if (user != null){
				KjBoardRelUserDto member = new KjBoardRelUserDto();
				member.setUserKey(user.getUserKey());
				member.setUserStatusKbn(CODE_STATUSKBN_1); // 対象ユーザーは「1：承認済」で作成
				member.setAffiliationName(StringUtil.nvl(user.getAffiliationName(), "") +
											StringUtil.nvl(user.getResearchSubject(),"") +
											StringUtil.nvl(user.getResearchArea(), ""));
				if (CommonConst.DEFAULT_LOCALE.getLanguage().equals(locale.getLanguage())) {
					member.setPartyName(StringUtil.nvl(userInfo.getTargetPartyName(), ""));
					member.setUserName(StringUtil.nvl(user.getUserFamilyName(),"") +
										StringUtil.nvl(user.getUserMiddleName(),"") +
										StringUtil.nvl(user.getUserName(),""));
				} else {
					member.setPartyName(StringUtil.nvl(userInfo.getTargetPartyNameEn(),""));
					member.setUserName(StringUtil.nvl(user.getUserFamilyNameEn(),"") +
										StringUtil.nvl(user.getUserMiddleNameEn(),"") +
										StringUtil.nvl(user.getUserNameEn(),""));
				}
				dtoList.add(member);
			}
		} else if (CommonConst.PAGE_MODE_EDIT.equals(form.getPageMode())) {
			// 編集はユーザーリレーションデータ全件を取得
			List <KjBoardRelUserDto> dtoListAll = new ArrayList<>();
			dtoListAll = kjBoardRelUserRepository.findGroupMemberList(form.getBoardGroupKey());

			for (KjBoardRelUserDto dto : dtoListAll) {
				if (CommonConst.DEFAULT_LOCALE.getLanguage().equals(locale.getLanguage())) {
					dto.setUserName(dto.getUserFamilyName() + dto.getUserMiddleName() + dto.getUserName());
					dto.setAffiliationName(dto.getAffiliationName() + dto.getResearchSubject() + dto.getResearchArea());
					dto.setPartyName(dto.getPartyName());
				} else {
					dto.setUserName(dto.getUserFamilyNameEn() + dto.getUserMiddleNameEn() + dto.getUserNameEn());
					dto.setAffiliationName(dto.getAffiliationName() + dto.getResearchSubject() + dto.getResearchArea());
					dto.setPartyName(dto.getPartyNameEn());
				}
			}

			KjBoardGroupTbl board = getOne(form.getBoardGroupKey());

			if (!userInfo.getTargetUserKey().equals(board.getAdminUserKey())) {
				// 対象ユーザーが掲示板グループの管理者でない場合、ユーザ状態区分 = 1：承認済のみ表示対象とする
				for (KjBoardRelUserDto dto : dtoListAll) {
					if (dto.getUserStatusKbn().equals(CODE_STATUSKBN_1)) {
						dtoList.add(dto);
					}
				}
			} else {
				// 対象ユーザーが掲示板グループの管理者の場合、全ユーザー表示対象
				dtoList = dtoListAll;
			}
		}
		return dtoList;
	}


	/***
	 * メンバー検索用一覧データ(組織コード)
	 *
	 * @param partyCode
	 * @param locale
	 * @return
	 */
	public List <KjBoardRelUserDto> findPartyMemberList(String partyCode ,Locale locale) {

		List <KjBoardRelUserDto> dtoList = new ArrayList<>();
		dtoList = kjBoardRelUserRepository.findPartyMemberList(partyCode);

		for (KjBoardRelUserDto dto : dtoList) {
			if (CommonConst.DEFAULT_LOCALE.getLanguage().equals(locale.getLanguage())) {
				// 氏名
				dto.setUserName(dto.getUserFamilyName() + dto.getUserMiddleName() + dto.getUserName());
				// 大学
				dto.setPartyName(dto.getPartyName());
			} else {
				// 氏名
				dto.setUserName(dto.getUserFamilyNameEn() + dto.getUserMiddleNameEn() + dto.getUserNameEn());
				// 大学
				dto.setPartyName(dto.getPartyNameEn());
			}
			// 所属
			dto.setAffiliationName(dto.getAffiliationName() + dto.getResearchSubject() + dto.getResearchArea());
		}
		return dtoList;
	}


	/***
	 * ユーザーが属している掲示板グループ取得(ユーザーキー)
	 *
	 * @param userInfo
	 * @return
	 */
	public List<KjBoardRelUser> findGroupList(UserInfo userInfo) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		// ユーザーキー
		Specification<KjBoardRelUser> whereUserKey = StringUtil.isNull(userInfo.getTargetUserKey()) ? null
				: new Specification<KjBoardRelUser>() {
					@Override
					public Predicate toPredicate(Root<KjBoardRelUser> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("id").get("userKey"), userInfo.getTargetUserKey());
					}
				};
		// 状態区分＝「1：承認済」
		Specification<KjBoardRelUser> whereUserStatusKbn = StringUtil.isNull(CODE_STATUSKBN_1) ? null
				: new Specification<KjBoardRelUser>() {
					@Override
					public Predicate toPredicate(Root<KjBoardRelUser> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("userStatusKbn"), CODE_STATUSKBN_1);
					}
				};
		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return kjBoardRelUserRepository.findAll(Specifications.where(whereUserKey).and(whereUserStatusKbn), kjBoardRelUserOrderBy());
	}

	/**
	 * kjBoardRelUserOrderBy
	 *
	 * @return
	 */
	private Sort kjBoardRelUserOrderBy() {
		// （昇順）
		return new Sort(Sort.Direction.ASC, "id.boardGroupKey");
	}


	/**
	 * スレッド参照実績の登録・更新
	 *
	 * @param thredKey
	 * @param userInfo
	 * @return
	 */
	@Transactional
	public boolean thredReadUpdate(String thredKey, UserInfo userInfo) throws Exception {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		KjThredReadTbl entity = findOneThredRead(thredKey, userInfo);

		if (entity == null) {
			KjThredReadTblPK pk = new KjThredReadTblPK();
			pk.setThredKey(thredKey);
			pk.setUserKey(userInfo.getTargetUserKey());

			KjThredReadTbl insEntity = new KjThredReadTbl();
			insEntity.setId(pk);
			insEntity.setReadDate(DateUtil.getNowTimestamp());
			insEntity.setUpdDate(DateUtil.getNowTimestamp());
			insEntity.setUpdUserKey(userInfo.getLoginUserKey());

			insEntity = kjThredReadTblRepository.save(insEntity);

			if (insEntity != null) {
				logger.infoCode("I0002"); // I0002=メソッド終了:{0}
				return true;
			}
		} else {
			entity.setReadDate(DateUtil.getNowTimestamp());
			entity.setUpdDate(DateUtil.getNowTimestamp());
			entity.setUpdUserKey(userInfo.getLoginUserKey());

			entity = kjThredReadTblRepository.save(entity);

			if (entity != null) {
				logger.infoCode("I0002"); // I0002=メソッド終了:{0}
				return true;
			}
		}
		return false;
	}


	/**
	 * 掲示板スレッド参照実績データ取得(スレッドキー、ユーザーキー)
	 *
	 * @param thredKey
	 * @param userInfo
	 * @return
	 */
	public KjThredReadTbl findOneThredRead(String thredKey, UserInfo userInfo) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		Specification<KjThredReadTbl> whereThredKey = StringUtil.isNull(thredKey) ? null
				: new Specification<KjThredReadTbl>() {
					@Override
					public Predicate toPredicate(Root<KjThredReadTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("id").get("thredKey"),thredKey);
					}
				};
		Specification<KjThredReadTbl> whereUserKey = StringUtil.isNull(userInfo.getTargetUserKey()) ? null
				: new Specification<KjThredReadTbl>() {
					@Override
					public Predicate toPredicate(Root<KjThredReadTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("id").get("userKey"), userInfo.getTargetUserKey());
					}
				};

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return kjThredReadTblRepository.findOne(Specifications.where(whereThredKey).and(whereUserKey));
	}


	/**
	 * ファイルアップロード処理実行(掲示板スレッド)
	 *
	 * @param userInfo
	 * @param form
	 * @return
	 */
	@Transactional
	public String thredUpload(UserInfo userInfo, BoardForm form) throws Exception {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}
		String uploadKey = null;

		if (form.getUploadFlg().equals(UPLOAD_FLG_1)) {
			//ファイルアップロードテーブル削除、ファイル削除
			int res = fileService.deleteUploadFile(form.getUploadKey());
		}
		// ファイルアップロード処理実行
		FileDto fileDto = new FileDto();
		fileDto.SetFileKbn(CommonConst.UPLOAD_FILE_KBN_BOARD);
		String fileName = new File(form.getDoc().getOriginalFilename()).getName();
		fileDto.setUploadName(fileName);
		fileDto.setFile(form.getDoc());
		// ファイルアップロード処理
		uploadKey = fileService.putUploadFile(fileDto, userInfo.getTargetUserKey(), userInfo.getLoginUserKey());

		if (uploadKey == null) {
			logger.errorCode("E1012"); // ファイルのアップロードに失敗しました。{0}
			throw new Exception();
		}
		return uploadKey;
	}


	/**
	 * スレッド新規登録
	 *
	 * @param userInfo
	 * @param form
	 * @return
	 */
	@Transactional
	public boolean thredInsert(UserInfo userInfo, BoardForm form) throws Exception {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		KjBoardGroupTbl kjBoardGroupTbl = new KjBoardGroupTbl();
		kjBoardGroupTbl.setBoardGroupKey(form.getBoardGroupKey());

		// 掲示板スレッド
		KjThredTbl entity = new KjThredTbl();
		entity.setThredName(form.getThredName());
		entity.setInsDate(DateUtil.getNowTimestamp());
		entity.setInsUserKey(userInfo.getTargetUserKey());
		entity.setKjBoardGroupTbl(kjBoardGroupTbl);
		entity.setPublicFlag(CODE_PUBLIC_FLG_0);
		entity.setUpdUserKey(userInfo.getLoginUserKey());
		entity.setUpdDate(DateUtil.getNowTimestamp());
		entity = kjThredTblRepository.save(entity);

		if (entity.getThredKey() == null) {
			throw new Exception();
		}

		// 掲示板スレッド投稿実績
		KjThredContributionTblPK pkcon = new KjThredContributionTblPK();
		pkcon.setThredKey(entity.getThredKey());
		pkcon.setSeqNo(0);
		KjThredContributionTbl kjThredContributionTbl = new KjThredContributionTbl();
		kjThredContributionTbl.setId(pkcon);
		kjThredContributionTbl.setUserKey(userInfo.getTargetUserKey());
		kjThredContributionTbl.setMemo(form.getMemo());
		kjThredContributionTbl.setUpdUserKey(userInfo.getLoginUserKey());
		kjThredContributionTbl.setUpdDate(DateUtil.getNowTimestamp());
		kjThredContributionTbl = kjThredContributionTblRepository.save(kjThredContributionTbl);

		// 掲示板スレッド参照実績
		KjThredReadTblPK pkRead = new KjThredReadTblPK();
		pkRead.setThredKey(entity.getThredKey());
		pkRead.setUserKey(userInfo.getTargetUserKey());
		KjThredReadTbl kjThredReadTbl = new KjThredReadTbl();
		kjThredReadTbl.setId(pkRead);
		kjThredReadTbl.setReadDate(DateUtil.getNowTimestamp());
		kjThredReadTbl.setUpdUserKey(userInfo.getLoginUserKey());
		kjThredReadTbl.setUpdDate(DateUtil.getNowTimestamp());
		kjThredReadTbl = kjThredReadTblRepository.save(kjThredReadTbl);

		logger.infoCode("I0002", "★★★★★getUploadFlg="+form.getUploadFlg()); // I0002=メソッド終了:{0}

		// 掲示板スレッド添付ファイル
		if (form.getUploadFlg().equals(UPLOAD_FLG_1)) {
			logger.infoCode("I0002", "ファイル添付"); // I0002=メソッド終了:{0}
			KjThredUploadTbl kjThredUploadTbl = new KjThredUploadTbl();
			KjThredUploadTblPK pkUpload = new KjThredUploadTblPK();
			pkUpload.setThredKey(entity.getThredKey());
			pkUpload.setSeqNo(0);
			pkUpload.setUploadKey(form.getUploadKey());
			kjThredUploadTbl.setId(pkUpload);
			kjThredUploadTbl.setUpdUserKey(userInfo.getLoginUserKey());
			kjThredUploadTbl.setUpdDate(DateUtil.getNowTimestamp());
			kjThredUploadTbl = kjThredUploadTblRepository.save(kjThredUploadTbl);
		}

		if (entity.getThredKey() != null) {
			kjThredTblRepository.flush();
			kjThredContributionTblRepository.flush();
			kjThredReadTblRepository.flush();
			kjThredUploadTblRepository.flush();
			logger.infoCode("I0002"); // I0002=メソッド終了:{0}
			return true;
		}
		return false;
	}


	/**
	 * スレッド投稿
	 *
	 * @param form
	 * @param userInfo
	 * @return
	 */
	@Transactional
	public boolean thredUpdate(BoardForm form, UserInfo userInfo) throws Exception {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		int maxSeqNo;
		List<KjThredContributionTbl> tbl = kjThredContributionTblRepository.findMaxseqno(form.getThredKey());

		if (tbl == null) {
			maxSeqNo = 0;
		} else {
			maxSeqNo = tbl.get(0).getId().getSeqNo();
			maxSeqNo += 1;
		}

		KjThredContributionTbl entity = new KjThredContributionTbl();
		KjThredContributionTblPK pk = new KjThredContributionTblPK();

		//掲示板投稿実績ファイル
		pk.setThredKey(form.getThredKey());
		pk.setSeqNo(maxSeqNo);
		entity.setId(pk);
		entity.setUserKey(userInfo.getTargetUserKey());
		entity.setMemo(form.getMemo());
		entity.setUpdUserKey(userInfo.getLoginUserKey());
		entity.setUpdDate(DateUtil.getNowTimestamp());
		entity = kjThredContributionTblRepository.save(entity);

		if (entity.getId().getThredKey() == null) {
			throw new Exception();
		}

		// 掲示板スレッド添付ファイル
		if (form.getUploadFlg().equals(UPLOAD_FLG_1)) {
			KjThredUploadTbl kjThredUploadTbl = new KjThredUploadTbl();
			KjThredUploadTblPK pkUpload = new KjThredUploadTblPK();
			pkUpload.setThredKey(form.getThredKey());
			pkUpload.setSeqNo(maxSeqNo);
			pkUpload.setUploadKey(form.getUploadKey());
			kjThredUploadTbl.setId(pkUpload);
			kjThredUploadTbl.setUpdUserKey(userInfo.getLoginUserKey());
			kjThredUploadTbl.setUpdDate(DateUtil.getNowTimestamp());
			kjThredUploadTbl = kjThredUploadTblRepository.save(kjThredUploadTbl);
		}

		if (entity.getId().getThredKey() != null) {
			kjThredContributionTblRepository.flush();
			kjThredUploadTblRepository.flush();
			logger.infoCode("I0002"); // I0002=メソッド終了:{0}
			return true;
		}
		return false;
	}


	/**
	 * 掲示板スレッド削除(全体)
	 *
	 * @param userInfo
	 * @param form
	 * @return
	 */
	@Transactional
	public boolean thredDelete(UserInfo userInfo, BoardForm form) throws Exception {
		logger.infoCode("I0001");

		KjThredTbl entity = new KjThredTbl();
		entity = findOneThred(form);
		if (entity.getThredKey() == null) {
			throw new Exception();
		}
		// 掲示板スレッド添付ファイル削除
		for (KjThredContributionTbl u : entity.getKjThredContributionTbls()) {
			kjThredUploadTblRepository.delete(u.getKjThredUploadTbls());

			for (KjThredUploadTbl file : u.getKjThredUploadTbls()) {
				//ファイルアップロードテーブル削除、ファイル削除
				int res = fileService.deleteUploadFile(file.getId().getUploadKey());
			}
		}
		// スレッド投稿実績削除
		kjThredContributionTblRepository.delete(entity.getKjThredContributionTbls());
		// スレッド参照実績
		kjThredReadTblRepository.delete(entity.getKjThredReadTbls());
		// 掲示板スレッド削除
		int res = 0;
		res = kjThredTblRepository.delete(form.getThredKey(), form.getUpdDate());

		if (res > 0) {
			kjThredContributionTblRepository.flush();
			kjThredReadTblRepository.flush();
			kjThredUploadTblRepository.flush();
			kjThredTblRepository.flush();
			logger.infoCode("I0002");
			return true;
		}
		return false;
	}


	/**
	 * 掲示板スレッドデータ取得(スレッドキー、更新日)
	 *
	 * @param form
	 * @return
	 */
	public KjThredTbl findOneThred(BoardForm form) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		Specification<KjThredTbl> whereThredKey = StringUtil.isNull(form.getThredKey()) ? null
				: new Specification<KjThredTbl>() {
					@Override
					public Predicate toPredicate(Root<KjThredTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("thredKey"), form.getThredKey());
					}
				};
		Specification<KjThredTbl> whereUpdDate = DateUtil.isNull(form.getUpdDate()) ? null
				: new Specification<KjThredTbl>() {
					@Override
					public Predicate toPredicate(Root<KjThredTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("updDate"), form.getUpdDate());
					}
				};

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return kjThredTblRepository.findOne(Specifications.where(whereThredKey).and(whereUpdDate));
	}


	/**
	 * 掲示板スレッド削除(投稿のみ)
	 *
	 * @param userInfo
	 * @param form
	 * @return
	 */
	@Transactional
	public boolean contributionDelete(UserInfo userInfo, BoardForm form) throws Exception {
		logger.infoCode("I0001");

		KjThredContributionTbl entity = new KjThredContributionTbl();
		entity = findOneContribution(form);
		if (entity == null) {
			throw new Exception();
		}

		// 掲示板スレッド添付ファイル削除
		kjThredUploadTblRepository.delete(entity.getKjThredUploadTbls());

		// テーブル削除、ファイル削除
		int res = 0;
		for (KjThredUploadTbl u : entity.getKjThredUploadTbls()) {
			res = fileService.deleteUploadFile(u.getId().getUploadKey());
		}

		// 掲示板投稿実績ファイル削除
		res = kjThredContributionTblRepository.delete(form.getThredKey(), form.getSeqNo(), form.getContributionUpdDate());

		if (res > 0) {
			kjThredUploadTblRepository.flush();
			kjThredContributionTblRepository.flush();
			logger.infoCode("I0002");
			return true;
		}
		return false;
	}


	/**
	 * 掲示板スレッド投稿実績データ取得(スレッドキー、連番、更新日)
	 *
	 * @param form
	 * @return
	 */
	public KjThredContributionTbl findOneContribution(BoardForm form) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		Specification<KjThredContributionTbl> whereThredKey = StringUtil.isNull(form.getThredKey()) ? null
				: new Specification<KjThredContributionTbl>() {
					@Override
					public Predicate toPredicate(Root<KjThredContributionTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("id").get("thredKey"), form.getThredKey());
					}
				};
		Specification<KjThredContributionTbl> whereSeqNo = new Specification<KjThredContributionTbl>() {
					@Override
					public Predicate toPredicate(Root<KjThredContributionTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("id").get("seqNo"), form.getSeqNo());
					}
				};
		Specification<KjThredContributionTbl> whereUpdDate = DateUtil.isNull(form.getContributionUpdDate()) ? null
				: new Specification<KjThredContributionTbl>() {
					@Override
					public Predicate toPredicate(Root<KjThredContributionTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("updDate"), form.getContributionUpdDate());
					}
				};

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return kjThredContributionTblRepository.findOne(Specifications.where(whereThredKey).and(whereSeqNo).and(whereUpdDate));
	}


	/**
	 * メンバー承認
	 *
	 * @param form
	 * @return
	 */
	@Transactional
	public boolean relUserUpdate(BoardForm form) throws Exception {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		KjBoardRelUser entity = new KjBoardRelUser();

		entity = findRelUserOne(form);
		if (entity == null) {
			throw new Exception();
		}

		if (CommonConst.PAGE_MODE_EDIT.equals(form.getPageMode())) {
			entity.setUserStatusKbn(CODE_STATUSKBN_1); // 承認
		} else {
			entity.setUserStatusKbn(CODE_STATUSKBN_2); // 取り下げ
		}
		entity.setUpdDate(DateUtil.getNowTimestamp());
		entity.setUpdUserKey(form.getUserKey());
		entity = kjBoardRelUserRepository.saveAndFlush(entity);

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return true;
	}


	/**
	 * 掲示板ユーザーリレーションデータ取得(掲示板グループキー、ユーザーキー指定)
	 *
	 * @param boardGroupKey
	 * @param userKey
	 * @return
	 */
	public KjBoardRelUser getOne(String boardGroupKey, String userKey) {

		// 掲示板グループキー
		Specification<KjBoardRelUser> whereBoardGroupKey = StringUtil.isNull(boardGroupKey) ? null
				: new Specification<KjBoardRelUser>() {
					@Override
					public Predicate toPredicate(Root<KjBoardRelUser> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("id").get("boardGroupKey"), boardGroupKey);
					}
				};
		// ユーザーキー
		Specification<KjBoardRelUser> whereUserKey = StringUtil.isNull(userKey) ? null
				: new Specification<KjBoardRelUser>() {
					@Override
					public Predicate toPredicate(Root<KjBoardRelUser> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("id").get("userKey"), userKey);
					}
				};

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return kjBoardRelUserRepository.findOne(Specifications.where(whereBoardGroupKey).and(whereUserKey));
	}


	/**
	 * 掲示板グループキー、ユーザーキー、更新日指定取得
	 *
	 * @param form
	 * @return
	 */
	public KjBoardRelUser findRelUserOne(BoardForm form) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		// 掲示板グループキー
		Specification<KjBoardRelUser> whereBoardGroupKey = StringUtil.isNull(form.getBoardGroupKey()) ? null
				: new Specification<KjBoardRelUser>() {
					@Override
					public Predicate toPredicate(Root<KjBoardRelUser> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("id").get("boardGroupKey"), form.getBoardGroupKey());
					}
				};
		// ユーザーキー
		Specification<KjBoardRelUser> whereUserKey = StringUtil.isNull(form.getUserKey()) ? null
				: new Specification<KjBoardRelUser>() {
					@Override
					public Predicate toPredicate(Root<KjBoardRelUser> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("id").get("userKey"), form.getUserKey());
					}
				};
		// データ更新日
		Specification<KjBoardRelUser> whereUpdDate = DateUtil.isNull(form.getUpdDate()) ? null
				: new Specification<KjBoardRelUser>() {
			@Override
			public Predicate toPredicate(Root<KjBoardRelUser> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.get("updDate"), form.getUpdDate());
			}
		};

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return kjBoardRelUserRepository.findOne(Specifications.where(whereBoardGroupKey).and(whereUserKey).and(whereUpdDate));
	}
}
