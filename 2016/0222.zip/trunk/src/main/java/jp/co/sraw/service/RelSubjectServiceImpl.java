/*
* ファイル名：RelateSubjectServiceImpl.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/01/05   etoh        新規作成
*/
package jp.co.sraw.service;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonService;
import jp.co.sraw.entity.NrLessonRelSubjectTbl;
import jp.co.sraw.entity.NrLessonRelSubjectTblPK;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.repository.NrLessonRelSubjectTblRepository;
import jp.co.sraw.util.DateUtil;
import jp.co.sraw.util.DbUtil;

/**
 * 養成科目紐付け関連のサービス
 * @author SRAW tsutsumi
 *
 */
@Service
public class RelSubjectServiceImpl extends CommonService {

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(RelSubjectServiceImpl.class);

	@Autowired
	private NrLessonRelSubjectTblRepository nrLessonRelSubjectTblRepository;

	// 定数区分/コード。
	private static final String JKBN_RKEY = "0044";
	private static final String JCODE_RKEY = "1";

	@Override
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	/**
	 * JSON形式からMap形式に変換します。
	 * @param json
	 * @return Map型の紐付き状態
	 */
	public Map<String, List<String>> convertSkill (String json) {
		ObjectMapper mapper = new ObjectMapper();
		Map<String, List<String>> skillMap = null;
		try {
			skillMap = mapper.readValue(json, new TypeReference<Map<String, List<String>>>(){});
		} catch (Exception e) {
			skillMap = new HashMap<String, List<String>>();
		}
		return skillMap;
	}

	/**
	 * 1つ以上の養成能力と紐付きが行われているかチェック
	 * @param skillMap
	 * @return true 紐付いている科目がある
	 */
	public boolean validateRelateSkill(String json) {
		return validateRelateSkill(convertSkill(json));
	}

	/**
	 * 1つ以上の養成能力と紐付きが行われているかチェック
	 * @param skillMap
	 * @return true 紐付いている科目がある
	 */
	public boolean validateRelateSkill(Map<String, List<String>> skillMap) {
		boolean rtn = true;
		if (rtn) {
			if (skillMap.containsKey(CommonConst.RELATION_LEVEL_BEST) && skillMap.containsKey(CommonConst.RELATION_LEVEL_NORMAL)) {
				if (!((skillMap.get(CommonConst.RELATION_LEVEL_BEST).size() + skillMap.get(CommonConst.RELATION_LEVEL_NORMAL).size()) > 0)) {
					rtn = false;
				}
			} else {
				rtn = false;
			}
		}
		return rtn;
	}

	/**
	 * 養成科目紐付け状態を登録する
	 * @param userKey ユーザキー
	 * @param lessonKey 科目キー
	 * @param skillMap ひも付け状態
	 * @param rKey ルーブリックキー
	 */
	@Transactional
	public void save(String userKey, String lessonKey, Map<String, List<String>> skillMap, String rKey) {
		if (skillMap != null) {
			for (String level : skillMap.keySet()) {
				for (String subjectCd : skillMap.get(level)) {
					NrLessonRelSubjectTbl inRelEntity = new NrLessonRelSubjectTbl();
					inRelEntity.setId(new NrLessonRelSubjectTblPK());
					inRelEntity.getId().setLessonKey(lessonKey);
					inRelEntity.getId().setRubricKey(rKey);
					inRelEntity.getId().setSubjectCode(subjectCd);
					inRelEntity.setRelationLevel(level);
					inRelEntity.setUpdUserKey(userKey);
					inRelEntity.setUpdDate(DateUtil.getNowTimestamp());

					inRelEntity = nrLessonRelSubjectTblRepository.saveAndFlush(inRelEntity);
					if (inRelEntity == null) {
						throw new RuntimeException("failed to saveAndFlush().");
					}
				}
			}
		}
	}

	public void save(String userKey, String lessonKey, String skillJson, String rKey) {
		save(userKey, lessonKey, convertSkill(skillJson), rKey);
	}

	/**
	 * 養成科目紐付け状態を登録する(ルーブリックキーデフォルト)
	 * @param userKey
	 * @param lessonKey
	 * @param skillMap
	 * @param locale
	 */
	public void save(String userKey, String lessonKey, Map<String, List<String>> skillMap, Locale locale) {
		String rKey = DbUtil.getJosuName(JKBN_RKEY, JCODE_RKEY, locale);
		save(userKey, lessonKey, skillMap, rKey);
	}

	public void save(String userKey, String lessonKey, String skillJson, Locale locale) {
		save(userKey, lessonKey, convertSkill(skillJson), locale);
	}



}
