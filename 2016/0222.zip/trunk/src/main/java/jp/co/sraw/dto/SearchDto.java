package jp.co.sraw.dto;

import java.io.Serializable;

public class SearchDto implements Serializable {

	private String userKey;

	private String userKbn;

	private String userFullName;

	private String userFullNameEn;

	private String partyKbn;

	private String partyCode;

	private String partyName;

	private String partyNameEn;

	private String userFamilyName;

	private String userFamilyNameEn;

	private String userMiddleName;

	private String userMiddleNameEn;

	private String userName;

	private String userNameEn;

	private String affiliationName;

	private String researchSubject;

	private String degree;

	private String degreeName;

	private String degreeNameEn;

	private String freeInput1;

	private String freeInput1cut;

	private String freeInput2;

	private String url;

	private boolean competitionMoveFlag;

	/**
	 * @return userKey
	 */
	public String getUserKey() {
		return userKey;
	}

	/**
	 * @param userKey セットする userKey
	 */
	public void setUserKey(String userKey) {
		this.userKey = userKey;
	}

	/**
	 * @return userKbn
	 */
	public String getUserKbn() {
		return userKbn;
	}

	/**
	 * @param userKbn セットする userKbn
	 */
	public void setUserKbn(String userKbn) {
		this.userKbn = userKbn;
	}

	/**
	 * @return userFullName
	 */
	public String getUserFullName() {
		return userFullName;
	}

	/**
	 * @param userFullName セットする userFullName
	 */
	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	/**
	 * @return userFullNameEn
	 */
	public String getUserFullNameEn() {
		return userFullNameEn;
	}

	/**
	 * @param userFullNameEn セットする userFullNameEn
	 */
	public void setUserFullNameEn(String userFullNameEn) {
		this.userFullNameEn = userFullNameEn;
	}

	/**
	 * @return partyKbn
	 */
	public String getPartyKbn() {
		return partyKbn;
	}

	/**
	 * @param partyKbn セットする partyKbn
	 */
	public void setPartyKbn(String partyKbn) {
		this.partyKbn = partyKbn;
	}

	/**
	 * @return partyCode
	 */
	public String getPartyCode() {
		return partyCode;
	}

	/**
	 * @param partyCode セットする partyCode
	 */
	public void setPartyCode(String partyCode) {
		this.partyCode = partyCode;
	}

	/**
	 * @return partyName
	 */
	public String getPartyName() {
		return partyName;
	}

	/**
	 * @param partyName セットする partyName
	 */
	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}

	/**
	 * @return partyNameEn
	 */
	public String getPartyNameEn() {
		return partyNameEn;
	}

	/**
	 * @param partyNameEn セットする partyNameEn
	 */
	public void setPartyNameEn(String partyNameEn) {
		this.partyNameEn = partyNameEn;
	}

	/**
	 * @return userFamilyName
	 */
	public String getUserFamilyName() {
		return userFamilyName;
	}

	/**
	 * @param userFamilyName セットする userFamilyName
	 */
	public void setUserFamilyName(String userFamilyName) {
		this.userFamilyName = userFamilyName;
	}

	/**
	 * @return userFamilyNameEn
	 */
	public String getUserFamilyNameEn() {
		return userFamilyNameEn;
	}

	/**
	 * @param userFamilyNameEn セットする userFamilyNameEn
	 */
	public void setUserFamilyNameEn(String userFamilyNameEn) {
		this.userFamilyNameEn = userFamilyNameEn;
	}

	/**
	 * @return userMiddleName
	 */
	public String getUserMiddleName() {
		return userMiddleName;
	}

	/**
	 * @param userMiddleName セットする userMiddleName
	 */
	public void setUserMiddleName(String userMiddleName) {
		this.userMiddleName = userMiddleName;
	}

	/**
	 * @return userMiddleNameEn
	 */
	public String getUserMiddleNameEn() {
		return userMiddleNameEn;
	}

	/**
	 * @param userMiddleNameEn セットする userMiddleNameEn
	 */
	public void setUserMiddleNameEn(String userMiddleNameEn) {
		this.userMiddleNameEn = userMiddleNameEn;
	}

	/**
	 * @return userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName セットする userName
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return userNameEn
	 */
	public String getUserNameEn() {
		return userNameEn;
	}

	/**
	 * @param userNameEn セットする userNameEn
	 */
	public void setUserNameEn(String userNameEn) {
		this.userNameEn = userNameEn;
	}

	/**
	 * @return affiliationName
	 */
	public String getAffiliationName() {
		return affiliationName;
	}

	/**
	 * @param affiliationName セットする affiliationName
	 */
	public void setAffiliationName(String affiliationName) {
		this.affiliationName = affiliationName;
	}

	/**
	 * @return researchSubject
	 */
	public String getResearchSubject() {
		return researchSubject;
	}

	/**
	 * @param researchSubject セットする researchSubject
	 */
	public void setResearchSubject(String researchSubject) {
		this.researchSubject = researchSubject;
	}

	/**
	 * @return degree
	 */
	public String getDegree() {
		return degree;
	}

	/**
	 * @param degree セットする degree
	 */
	public void setDegree(String degree) {
		this.degree = degree;
	}

	/**
	 * @return degreeName
	 */
	public String getDegreeName() {
		return degreeName;
	}

	/**
	 * @param degreeName セットする degreeName
	 */
	public void setDegreeName(String degreeName) {
		this.degreeName = degreeName;
	}

	/**
	 * @return degreeNameEn
	 */
	public String getDegreeNameEn() {
		return degreeNameEn;
	}

	/**
	 * @param degreeNameEn セットする degreeNameEn
	 */
	public void setDegreeNameEn(String degreeNameEn) {
		this.degreeNameEn = degreeNameEn;
	}

	/**
	 * @return freeInput1
	 */
	public String getFreeInput1() {
		return freeInput1;
	}

	/**
	 * @param freeInput1 セットする freeInput1
	 */
	public void setFreeInput1(String freeInput1) {
		this.freeInput1 = freeInput1;
	}

	/**
	 * @return freeInput2
	 */
	public String getFreeInput2() {
		return freeInput2;
	}

	/**
	 * @param freeInput2 セットする freeInput2
	 */
	public void setFreeInput2(String freeInput2) {
		this.freeInput2 = freeInput2;
	}

	/**
	 * @return url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url セットする url
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * @return competitionMoveFlag
	 */
	public boolean isCompetitionMoveFlag() {
		return competitionMoveFlag;
	}

	/**
	 * @param competitionMoveFlag セットする competitionMoveFlag
	 */
	public void setCompetitionMoveFlag(boolean competitionMoveFlag) {
		this.competitionMoveFlag = competitionMoveFlag;
	}

	/**
	 * @return freeInput1cut
	 */
	public String getFreeInput1cut() {
		return freeInput1cut;
	}

	/**
	 * @param freeInput1cut セットする freeInput1cut
	 */
	public void setFreeInput1cut(String freeInput1cut) {
		this.freeInput1cut = freeInput1cut;
	}

}
