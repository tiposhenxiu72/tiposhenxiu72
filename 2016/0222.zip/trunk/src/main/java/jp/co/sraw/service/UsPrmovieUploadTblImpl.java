/*
* ファイル名：UserServiceImpl.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.service;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.sraw.common.CommonService;
import jp.co.sraw.entity.UsPrmovieUploadTbl;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.repository.UsPrmovieUploadTblRepository;

/**
 * <B>UserServiceクラス</B>
 * <P>
 * ユーザーサービスのメソッドを提供する
 */
@Scope("prototype")
@Service
@Transactional(readOnly = true)
public class UsPrmovieUploadTblImpl extends CommonService {

	@Autowired
	private UsPrmovieUploadTblRepository repository;

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(UsPrmovieUploadTblImpl.class);

	@PostConstruct
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	public List<UsPrmovieUploadTbl> findAll(String userKey, String[] publicFlags) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		//
		Specification<UsPrmovieUploadTbl> whereUserKey = new Specification<UsPrmovieUploadTbl>() {
			@Override
			public Predicate toPredicate(Root<UsPrmovieUploadTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.get("usUserTbl").get("userKey"), userKey);
			}
		};

		@SuppressWarnings("unchecked")
		List<UsPrmovieUploadTbl> list = (List<UsPrmovieUploadTbl>) repository
				.findAll((Specification<UsPrmovieUploadTbl>) Specifications.where(whereUserKey));

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return list;
	}
}
