/*
* ファイル名：IndexController.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.event;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import jp.co.sraw.common.CommonController;
import jp.co.sraw.dto.EvEventViewDto;
import jp.co.sraw.dto.EventDto;
import jp.co.sraw.entity.EvEventTbl;
import jp.co.sraw.entity.EvEventUploadTbl;
import jp.co.sraw.file.DownloadService;
import jp.co.sraw.file.FileService;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.service.EventServiceImpl;

/**
 * <B>EventControllerクラス</B>
 * <P>
 * Controllerのメソッドを提供する
 */
@Controller
@RequestMapping("/event")
public class EventController extends CommonController {

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(EventController.class);

	private static final int BUFFER_SIZE = 4096;

	@PostConstruct
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	@Autowired
	private EventServiceImpl eventServiceImpl;

	@Autowired
	private DownloadService dowloadService;

	private static final String LIST_PAGE = "event/list";

	private static final String FORM_NAME = "form";

	@Autowired
	private FileService fileService;

	List<EventDto> slist = new ArrayList<>();

	/**
	 *
	 *
	 * @param name
	 * @param model
	 * @return
	 */
	@RequestMapping({ "", "/", "/list" })
	public String list(@ModelAttribute(FORM_NAME) final EventForm form, Model model, Locale locale) {

		logger.infoCode("I0001");

		List<EvEventViewDto> eventPresentList = new ArrayList<>();

		eventPresentList = eventServiceImpl.findAllEventViewDto(userInfo, locale);

		model.addAttribute("eventPresentList", eventPresentList);

		if (logger.isDebugEnabled()) {
			logger.debug("LoginUserKey=" + userInfo.getLoginUserKey());
			logger.debug("TargetUserKey=" + userInfo.getTargetUserKey());
		}

		// dump
		modelDump(logger, model, "index");

		return LIST_PAGE;
	}

	@RequestMapping({ "/download" })
	public void download(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute(FORM_NAME) final EventForm form) throws Exception {

		EvEventTbl eventTbl = eventServiceImpl.getOne(form.getEventKey());

		List<EvEventUploadTbl> uploadTabList = eventTbl.getEvEventUploadTbls();

		List<String> downloadList = new ArrayList<>();
		for (EvEventUploadTbl tbl : uploadTabList) {
			downloadList.add(tbl.getId().getUploadKey());
		}

		dowloadService.downloadZip(request, response, userInfo.getLoginUserKey(), eventTbl.getEventKey(), downloadList);

	}
}
