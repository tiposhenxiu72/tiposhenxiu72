/*
* ファイル名：RelateForm.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/01/27   tsutsumi    新規作成
*/
package jp.co.sraw.controller.skill;

import java.util.List;

import jp.co.sraw.common.CommonForm;

/**
 * 養成能力紐付画面のフォーム
 * @author SRAW tsutsumi
 */
public class SKillBuildRelateForm extends CommonForm {
	/** 科目コード */
	String lessonCode;

	/** 紐付きリスト */
	List<SkillBuildRelateSubjectForm> relationList;

	public List<SkillBuildRelateSubjectForm> getRelationList() {
		return relationList;
	}

	public void setRelationList(List<SkillBuildRelateSubjectForm> relationList) {
		this.relationList = relationList;
	}
}
