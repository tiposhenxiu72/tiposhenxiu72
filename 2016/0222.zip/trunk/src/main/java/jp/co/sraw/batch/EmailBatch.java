package jp.co.sraw.batch;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.dto.BatchPublicDto;
import jp.co.sraw.dto.EmailDto;
import jp.co.sraw.dto.NewsDto;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.service.BatchTargetService;

@Component
public class EmailBatch implements BatchRunner {
	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(EmailBatch.class);

	@Autowired
	private BatchTargetService batchTargetService;

	public boolean run(Map<String, String> parameters) throws Exception {
		String targetDays = parameters.get("targetdays");
		int smallint = 0;
		try {
			smallint = Integer.parseInt(targetDays);
		} catch (Exception e) {
			throw e;
		}
		String infoKey = null;
		String role = null;
		String partyCode = null;

		// バッチ処理用抽出データ、支援制度からの情報抽出
		List<NewsDto> batchSupportList = batchTargetService.findAllBatchSupportMail();

		for (NewsDto dto : batchSupportList) {
			Timestamp makeDate = dto.getMakeDate();
			String infoRefKey = dto.getRefDataKey();
			String dataKbn = dto.getDataKbn();
			infoKey = "%03%";
			// ユーザ情報の取得
			List<EmailDto> supportResultList = batchTargetService.findAllEmailBatch(infoKey);
			// 発信の処理
			batchTargetService.sendMailBatch(CommonConst.EMAIL_TITLE_SUPPORT);
			// バッチ処理用抽出データの更新
			batchTargetService.updateEmailBatch(makeDate, infoRefKey, dataKbn);
		}

		// バッチ処理用抽出データ、イベントからの情報抽出
		List<NewsDto> batchEventList = batchTargetService.findAllBatchEventMail();

		for (NewsDto dto : batchEventList) {
			Timestamp makeDate = dto.getMakeDate();
			String infoRefKey = dto.getRefDataKey();
			String dataKbn = dto.getDataKbn();

			infoKey = "%01%";
			// ユーザ情報の取得
			List<EmailDto> eventResultList = batchTargetService.findAllEmailBatch(infoKey);
			// イベント公開範囲の参照
			List<BatchPublicDto> evnetPublicResultList = batchTargetService.findAllEventPublicBatch(infoRefKey);

			for (BatchPublicDto pDto : evnetPublicResultList) {
				role = pDto.getRole();
				partyCode = pDto.getPartyCode();

				// 公開区分が、1:ROLEの場合、ユーザ情報で取得したロールとイベント公開範囲で取得したロールが等しい。
				if ("1".equals(dataKbn)) {
					for (EmailDto eDto : eventResultList) {
						if (role.equals(eDto.getRole())) {
							batchTargetService.sendMailBatch(CommonConst.EMAIL_TITLE_EVENT);
						}
					}

				// 公開区分が、2:組織の場合、ユーザ情報で取得した組織コードとイベント公開範囲で取得した組織コードが等しい。
				} else if ("2".equals(dataKbn)) {
					for (EmailDto eDto : eventResultList) {
						if (partyCode.equals(eDto.getPartyCode())) {
							batchTargetService.sendMailBatch(CommonConst.EMAIL_TITLE_EVENT);
						}
					}
				}
			}
			// バッチ処理用抽出データの更新
			batchTargetService.updateEmailBatch(makeDate, infoRefKey, dataKbn);
		}

		// バッチ処理用抽出データ、インターンシップからの情報抽出
		List<NewsDto> batchInternshipList = batchTargetService.findAllBatchInternshipMail();

		for (NewsDto dto : batchInternshipList) {
			Timestamp makeDate = dto.getMakeDate();
			String infoRefKey = dto.getRefDataKey();
			String dataKbn = dto.getDataKbn();
			infoKey = "%02%";
			// ユーザ情報の取得
			List<EmailDto> internshipResultList = batchTargetService.findAllEmailBatch(infoKey);
			// インターンシップ公開範囲の参照
			List<BatchPublicDto> internshipPublicResultList = batchTargetService.findAllInternshipPublicBatch(infoRefKey);

			for (BatchPublicDto pDto :  internshipPublicResultList) {
				role = pDto.getRole();
				partyCode = pDto.getPartyCode();
				// 公開区分が、1:ROLEの場合、ユーザ情報で取得したロールとイベント公開範囲で取得したロールが等しい
				if ("1".equals(dataKbn)) {
					for (EmailDto eDto : internshipResultList) {
						if (role.equals(eDto.getRole())) {
							batchTargetService.sendMailBatch(CommonConst.EMAIL_TITLE_INTERNSHIP);
						}
					}

					// 公開区分が、2:組織の場合、ユーザ情報で取得した組織コードとイベント公開範囲で取得した組織コードが等しい
				} else if ("2".equals(dataKbn)) {
					for (EmailDto eDto : internshipResultList) {
						if (partyCode.equals(eDto.getPartyCode())) {
							batchTargetService.sendMailBatch(CommonConst.EMAIL_TITLE_INTERNSHIP);
						}
					}
				}
			}
			// バッチ処理用抽出データの更新
			batchTargetService.updateEmailBatch(makeDate, infoRefKey, dataKbn);
		}
		return true;
	}
}
