/*
* ファイル名：UserServiceImpl.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.service;

import java.sql.Timestamp;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.security.crypto.password.StandardPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonService;
import jp.co.sraw.common.UserInfo;
import jp.co.sraw.controller.account.AccountForm;
import jp.co.sraw.controller.portfolio.form.ProfileForm;
import jp.co.sraw.entity.MsCodeTbl;
import jp.co.sraw.entity.MsPartyTbl;
import jp.co.sraw.entity.UsLoginInfoTbl;
import jp.co.sraw.entity.UsPrmovieUploadTbl;
import jp.co.sraw.entity.UsPrmovieUploadTblPK;
import jp.co.sraw.entity.UsRequestTbl;
import jp.co.sraw.entity.UsUserRelRoleTbl;
import jp.co.sraw.entity.UsUserRelRoleTblPK;
import jp.co.sraw.entity.UsUserTbl;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.repository.UsLoginInfoTblRepository;
import jp.co.sraw.repository.UsPrmovieUploadTblRepository;
import jp.co.sraw.repository.UsRequestTblRepository;
import jp.co.sraw.repository.UsUserRelRoleTblRepository;
import jp.co.sraw.repository.UsUserTblRepository;
import jp.co.sraw.util.DateUtil;
import jp.co.sraw.util.StringUtil;

/**
 * <B>UserServiceクラス</B>
 * <P>
 * ユーザーサービスのメソッドを提供する
 */
@Scope("prototype")
@Service
@Transactional(readOnly = true)
public class UserServiceImpl extends CommonService {

	@Autowired
	private UsUserTblRepository usUserTblRepository;

	@Autowired
	private UsRequestTblRepository usRequestTblRepository;

	@Autowired
	private UsLoginInfoTblRepository usLoginInfoTblRepository;

	@Autowired
	private UsUserRelRoleTblRepository usUserRelRoleTblRepository;

	@Autowired
	private MsCodeServiceImpl msCodeServiceImpl;

	@Autowired
	private MsPartyServiceImpl msPartyServiceImpl;

	@Autowired
	private UsPrmovieUploadTblRepository usPrmovieUploadTblRepository;

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(UserServiceImpl.class);

	// 定数区分
	private static final String CODE_REQUEST_ACCOUNT = "0033"; // 定数区分[0033]
	private static final String CODE_REQUEST_ACCOUNT_1 = "1"; // 定数区分[0033]
																// 有効期間(分)
	//
	private static final String REQUEST_ID_DELIMITER = "#"; // 申請IDの区切り文字

	@PostConstruct
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	public List<UsUserTbl> findAll() {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		List<UsUserTbl> list = usUserTblRepository.findAll();

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return list;
	}

	public UsUserTbl findOne(String userKey) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		UsUserTbl u = usUserTblRepository.findOne(userKey);

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return u;
	}

	/**
	 * アカウント本登録
	 *
	 * @param form
	 * @return
	 */
	public boolean addAccountSave(AccountForm form) throws Exception {
		boolean result = false;

		try {
			// 登録日時
			Timestamp now = DateUtil.getNowTimestamp();

			// ロール(学年/職位[0035])
			String roleCode = "";

			if (CommonConst.USER_KBN_USER3.equals(form.getUserKbn())) {
				// 任期付研究員
				roleCode = CommonConst.ROLE_CODE_USER3;

			} else if (CommonConst.USER_KBN_USER2.equals(form.getUserKbn())) {
				// 博士課程後期・一貫
				roleCode = CommonConst.ROLE_CODE_USER2;

			} else if (CommonConst.USER_KBN_USER1.equals(form.getUserKbn())) {
				// 博士課程前期
				roleCode = CommonConst.ROLE_CODE_USER1;

			} else if (CommonConst.USER_KBN_USER4.equals(form.getUserKbn())) {
				// 教職員
				roleCode = CommonConst.ROLE_CODE_USER4;

			}
			// 組織情報取得
			MsPartyTbl party = msPartyServiceImpl.findOne(form.getPartyCode());

			// ユーザー情報
			UsUserTbl usUserTblEntity = new UsUserTbl();
			if (party != null) {
				usUserTblEntity.setAffiliationName(party.getPartyName());
			}
			usUserTblEntity.setCountry(form.getCountry());
			// usUserTblEntity.setDegree(form.getDegree());
			usUserTblEntity.setDegree(form.getUserKbn()); // 学年／職位で選択した項目のコードを設定する。
			usUserTblEntity.setInsDate(now);
			usUserTblEntity.setMailAddress(null);
			usUserTblEntity.setMailSetting(form.getMailSetting());
			usUserTblEntity.setPartyCode(form.getPartyCode());
			usUserTblEntity.setResearchArea(form.getResearchArea());
			usUserTblEntity.setResearchSubject(form.getResearchSubject());
			usUserTblEntity.setSex(form.getSex());
			usUserTblEntity.setStudentId(form.getStudentId());
			usUserTblEntity.setTeacherName(form.getTeacherName());
			usUserTblEntity.setUpdDate(now);
			usUserTblEntity.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
			usUserTblEntity.setUserFamilyName(form.getUserFamilyName());
			usUserTblEntity.setUserFamilyNameEn(form.getUserFamilyNameEn());
			usUserTblEntity.setUserFamilyNameKn(form.getUserFamilyNameKn());
			usUserTblEntity.setUserKbn(form.getUserKbn());
			usUserTblEntity.setUserMiddleName(form.getUserMiddleName());
			usUserTblEntity.setUserMiddleNameEn(form.getUserMiddleNameEn());
			usUserTblEntity.setUserMiddleNameKn(form.getUserMiddleNameKn());
			usUserTblEntity.setUserName(form.getUserName());
			usUserTblEntity.setUserNameEn(form.getUserNameEn());
			usUserTblEntity.setUserNameKn(form.getUserNameKn());
			usUserTblEntity.setUserPublicFlag(CommonConst.USER_PUBLIC_FLAG_NOT); // 非公開

			UsUserTbl usUserTblResult = usUserTblRepository.save(usUserTblEntity);

			// ユーザーロール情報
			UsUserRelRoleTblPK usUserRelRoleTblPKEntity = new UsUserRelRoleTblPK();
			usUserRelRoleTblPKEntity.setUserKey(usUserTblResult.getUserKey());
			usUserRelRoleTblPKEntity.setRoleCode(roleCode);

			UsUserRelRoleTbl usUserRelRoleTblEntity = new UsUserRelRoleTbl();
			usUserRelRoleTblEntity.setId(usUserRelRoleTblPKEntity);
			usUserRelRoleTblEntity.setUpdDate(now);
			usUserRelRoleTblEntity.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
			UsUserRelRoleTbl usUserRelRoleTblResult = usUserRelRoleTblRepository.save(usUserRelRoleTblEntity);

			// ログイン情報
			UsLoginInfoTbl usLoginInfoTblEntity = new UsLoginInfoTbl();
			usLoginInfoTblEntity.setPortalLoginId(form.getMailAddress());
			usLoginInfoTblEntity.setUsUserTbl(usUserTblResult);
			usLoginInfoTblEntity.setUseFlag(CommonConst.USE_FALG_ACTIVE);
			usLoginInfoTblEntity.setUpdDate(now);
			usLoginInfoTblEntity.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
			if (StringUtil.isNotNull(form.getPassword())) {
				//
				StandardPasswordEncoder passwordEncoder = new StandardPasswordEncoder(CommonConst.SECRET_KEY);
				usLoginInfoTblEntity.setPassword(passwordEncoder.encode(form.getPassword()));
			}
			UsLoginInfoTbl usLoginInfoTblResult = usLoginInfoTblRepository.save(usLoginInfoTblEntity);

			usUserTblRepository.flush();
			usUserRelRoleTblRepository.flush();
			usLoginInfoTblRepository.flush();

			//
			if (usUserTblResult != null && usUserRelRoleTblResult != null && usLoginInfoTblResult != null) {
				result = true;
			}

		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
			throw e;
		}

		return result;
	}

	/**
	 * アカウント登録（申請）
	 *
	 * @param mailAddress
	 * @return
	 */
	public String requestAccountSave(String mailAddress) {
		String result = null;

		try {
			// 申請日
			Timestamp now = DateUtil.getNowTimestamp();
			// 申請ID
			String requestId = "";
			// 有効期間(分)
			long appendLimit = 30; // 初期値: 30分
			Timestamp limit = now;

			// アカウント申請[0033] 有効期間(分)
			MsCodeTbl m = msCodeServiceImpl.findOne(CODE_REQUEST_ACCOUNT, CODE_REQUEST_ACCOUNT_1);
			if (m != null && m.getSntaZksei1Num() != null) {
				appendLimit = m.getSntaZksei1Num().longValue();
			}
			// 有効期間(分)を加算
			limit = new Timestamp(limit.getTime() + (1000 * 60 * appendLimit));

			// 申請ID生成
			requestId = requestIdEncoder(mailAddress, now.getTime());

			UsRequestTbl entity = new UsRequestTbl();
			//
			entity.setRequestId(requestId);
			entity.setRequestDate(now);
			entity.setMailAddress(mailAddress);
			entity.setLimitDate(limit);
			entity.setUpdDate(now);

			UsRequestTbl rlt = usRequestTblRepository.saveAndFlush(entity);

			if (rlt != null) {
				result = rlt.getRequestId();
			}

		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
		}

		return result;
	}

	/**
	 * 申請情報取得
	 *
	 * @param requestId
	 * @return
	 */
	public UsRequestTbl findRequest(String requestId) {
		try {
			// 申請日
			Timestamp now = DateUtil.getNowTimestamp();

			UsRequestTbl rlt = usRequestTblRepository.findByRequestIdAndLimitDateGreaterThan(requestId, now);

			return rlt;

		} catch (Exception e) {
			logger.errorCode("E1013", e); // E1013=エラーとなりました。{0}
		}

		return null;
	}

	/**
	 * 申請ID生成
	 *
	 * @param str
	 * @return
	 */
	public String requestIdEncoder(String mailAddress, long time) {

		StandardPasswordEncoder s = new StandardPasswordEncoder(CommonConst.ACCOUNT_SECRET_KEY);
		String raw = mailAddress + REQUEST_ID_DELIMITER + time;

		return s.encode(raw);
	}

	public String getUploadKey(ProfileForm form, UserInfo userInfo, String fileKen) {
		String uploadKey = null;
		if (fileKen.equals("0")) {
			UsUserTbl entity = getUserTbl(userInfo.getTargetUserKey(), form.getUpdDate());
			if (entity != null) {
				uploadKey = entity.getUploadKey();
			}
		} else {
			UsPrmovieUploadTbl tbl = getUsPrmovieUploadTbl(userInfo.getTargetUserKey(), fileKen);
			if (tbl != null) {
				uploadKey = tbl.getId().getUploadKey();
			}
		}
		return uploadKey;
	}

	public UsUserTbl getUserTbl(String userKey, Timestamp updDate) {
		// 取得条件：ユーザキー
		Specification<UsUserTbl> whereUserKey = new Specification<UsUserTbl>() {
			@Override
			public Predicate toPredicate(Root<UsUserTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.get("userKey"), userKey);
			}
		};

		// 取得条件：更新日付
		Specification<UsUserTbl> whereUpdDate = new Specification<UsUserTbl>() {
			@Override
			public Predicate toPredicate(Root<UsUserTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.get("updDate"), updDate);
			}
		};

		UsUserTbl entity = usUserTblRepository.findOne(Specifications.where(whereUserKey).and(whereUpdDate));
		return entity;
	}

	/**
	 * 更新
	 *
	 * @param userKey
	 * @param updDate
	 * @return
	 */
	public boolean update(ProfileForm form, UserInfo userInfo) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}
		boolean resultFlg = false;

		try {

			UsUserTbl entity = getUserTbl(userInfo.getTargetUserKey(), form.getUpdDate());

			if (entity == null) {
				throw new Exception();
			}

			if (!entity.getUserKbn().equals(form.getUserKbn())) {
				// ユーザ情報ロールリレーションの登録
				insertUserRelRoleTbl(form, userInfo);
			}

			// ユーザ情報更新
			updateUserTbl(entity, form, userInfo);

			logger.infoCode("I0002"); // I0002=メソッド終了:{0}
			resultFlg = true;

		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
		}

		return resultFlg;
	}

	/**
	 * ユーザ情報ロールリレーションの登録
	 *
	 * @param userKey
	 * @param updDate
	 * @return
	 */
	public void insertUserRelRoleTbl(ProfileForm form, UserInfo userInfo) throws Exception {
		try {
			UsUserRelRoleTbl entiry = new UsUserRelRoleTbl();
			UsUserRelRoleTblPK id = new UsUserRelRoleTblPK();
			id.setUserKey(userInfo.getTargetUserKey());

			String roleCode = "";
			if (CommonConst.USER_KBN_USER1.equals(form.getUserKbn())) {
				roleCode = CommonConst.ROLE_CODE_USER1;
			} else if (CommonConst.USER_KBN_USER2.equals(form.getUserKbn())) {
				roleCode = CommonConst.ROLE_CODE_USER2;
			} else if (CommonConst.USER_KBN_USER3.equals(form.getUserKbn())) {
				roleCode = CommonConst.ROLE_CODE_USER3;
			} else if (CommonConst.USER_KBN_USER4.equals(form.getUserKbn())) {
				roleCode = CommonConst.ROLE_CODE_USER4;
			}
			if (StringUtil.isNotNull(roleCode)) {

				// ユーザ情報ロールリレーションの削除
				usUserRelRoleTblRepository.delete(userInfo.getTargetUserKey());

				id.setRoleCode(roleCode);

				entiry.setId(id);
				entiry.setUpdDate(DateUtil.getNowTimestamp());
				entiry.setUpdUserKey(userInfo.getLoginUserKey());
				usUserRelRoleTblRepository.save(entiry);
			}

		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * ユーザ情報更新
	 *
	 * @param userKey
	 * @param updDate
	 * @return
	 */
	public void updateUserTbl(UsUserTbl entity, ProfileForm form, UserInfo userInfo) throws Exception {

		try {
			// ユーザ情報登録
			entity.setUserPublicFlag(form.getUserPublicFlag());
			entity.setDegree(form.getDegree());
			entity.setUserKbn(form.getUserKbn());
			entity.setUserFamilyName(form.getUserFamilyName());
			entity.setUserMiddleName(form.getUserMiddleName());
			entity.setUserName(form.getUserName());
			entity.setUserFamilyNameKn(form.getUserFamilyNameKn());
			entity.setUserMiddleNameKn(form.getUserMiddleNameKn());
			entity.setUserNameKn(form.getUserNameKn());
			entity.setUserFamilyNameEn(form.getUserFamilyNameEn());
			entity.setUserMiddleNameEn(form.getUserMiddleNameEn());
			entity.setUserNameEn(form.getUserNameEn());
			entity.setSex(form.getSex());
			entity.setResearchSubject(form.getResearchSubject());
			entity.setStudentId(form.getStudentId());
			entity.setTeacherName(form.getTeacherName());
			entity.setJstCode(form.getJstCode());
			entity.setCountry(form.getCountry());
			entity.setTelno(form.getTelno());
			entity.setFreeInput1(form.getFreeInput1());
			entity.setFreeInput2(form.getFreeInput2());
			entity.setFreeInput3(form.getFreeInput3());
			entity.setFreeInput4(form.getFreeInput4());
			entity.setFreeInput5(form.getFreeInput5());
			entity.setUploadKey(form.getImageUploadKey());
			if (StringUtil.isNull(form.getImageFileName())) {
				entity.setUploadKey(null);
			}
			entity.setUpdDate(DateUtil.getNowTimestamp());
			entity.setUpdUserKey(userInfo.getLoginUserKey());
			usUserTblRepository.save(entity);

			if (StringUtil.isNull(form.getPrMovieFileUploadKey())
					|| StringUtil.isNotNull(form.getPrMovieFileUploadKey())) {
				UsPrmovieUploadTbl tbl = getUsPrmovieUploadTbl(userInfo.getTargetUserKey(), "1");
				if (tbl != null) {
					usPrmovieUploadTblRepository.delete(tbl);
				}
			}

			if (StringUtil.isNotNull(form.getPrMovieFileUploadKey())) {
				UsPrmovieUploadTbl tbl = new UsPrmovieUploadTbl();
				UsPrmovieUploadTblPK pk = new UsPrmovieUploadTblPK();
				pk.setUserKey(userInfo.getTargetUserKey());
				pk.setUploadKey(form.getPrMovieFileUploadKey());
				tbl.setId(pk);
				tbl.setFileKbn("1");
				tbl.setUpdUserKey(userInfo.getLoginUserKey());
				tbl.setUpdDate(DateUtil.getNowTimestamp());
				usPrmovieUploadTblRepository.save(tbl);
			}

			if (StringUtil.isNull(form.getSeekFileName()) || StringUtil.isNotNull(form.getSeekFileUploadKey())) {
				UsPrmovieUploadTbl tbl = getUsPrmovieUploadTbl(userInfo.getTargetUserKey(), "2");
				if (tbl != null) {
					usPrmovieUploadTblRepository.delete(tbl);
				}
			}

			if (StringUtil.isNotNull(form.getSeekFileUploadKey())) {
				UsPrmovieUploadTbl tbl = new UsPrmovieUploadTbl();
				UsPrmovieUploadTblPK pk = new UsPrmovieUploadTblPK();
				pk.setUserKey(userInfo.getTargetUserKey());
				pk.setUploadKey(form.getSeekFileUploadKey());
				tbl.setId(pk);
				tbl.setFileKbn("2");
				tbl.setUpdUserKey(userInfo.getLoginUserKey());
				tbl.setUpdDate(DateUtil.getNowTimestamp());
				usPrmovieUploadTblRepository.save(tbl);
			}

			if (StringUtil.isNull(form.getDoctorFileName()) || StringUtil.isNotNull(form.getDoctorFileUploadKey())) {
				UsPrmovieUploadTbl tbl = getUsPrmovieUploadTbl(userInfo.getTargetUserKey(), "3");
				if (tbl != null) {
					usPrmovieUploadTblRepository.delete(tbl);
				}
			}

			if (StringUtil.isNotNull(form.getDoctorFileUploadKey())) {
				UsPrmovieUploadTbl tbl = new UsPrmovieUploadTbl();
				UsPrmovieUploadTblPK pk = new UsPrmovieUploadTblPK();
				pk.setUserKey(userInfo.getTargetUserKey());
				pk.setUploadKey(form.getDoctorFileUploadKey());
				tbl.setId(pk);
				tbl.setFileKbn("3");
				tbl.setUpdUserKey(userInfo.getLoginUserKey());
				tbl.setUpdDate(DateUtil.getNowTimestamp());
				usPrmovieUploadTblRepository.save(tbl);
			}

		} catch (Exception e) {
			throw e;
		}
	}

	public UsPrmovieUploadTbl getUsPrmovieUploadTbl(String userKey, String fileKen) {

		// 取得条件：ユーザキー
		Specification<UsPrmovieUploadTbl> whereUserKey = new Specification<UsPrmovieUploadTbl>() {
			@Override
			public Predicate toPredicate(Root<UsPrmovieUploadTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.get("id").get("userKey"), userKey);
			}
		};

		// 取得条件：更新日付
		Specification<UsPrmovieUploadTbl> whereFileKbn = new Specification<UsPrmovieUploadTbl>() {
			@Override
			public Predicate toPredicate(Root<UsPrmovieUploadTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.get("fileKbn"), fileKen);
			}
		};

		UsPrmovieUploadTbl entity = usPrmovieUploadTblRepository
				.findOne(Specifications.where(whereUserKey).and(whereFileKbn));

		return entity;
	}

	/**
	 * ログインID（メールアドレス）からユーザー情報取得
	 *
	 * @param mailAddress
	 * @return
	 */
	public UsUserTbl findOneMailAddress(String mailAddress) {

		// ログインIDからユーザーキーを取得
		UsLoginInfoTbl login = usLoginInfoTblRepository.findOne(mailAddress);
		if (login == null) {
			return null;
		}

		// ユーザー情報を取得
		UsUserTbl user = usUserTblRepository.findOne(login.getUsUserTbl().getUserKey());
		if (user == null) {
			return null;
		}

		return user;
	}

}
