package jp.co.sraw.dto;

import java.io.Serializable;

public class KjThredUploadDto implements Serializable {

	private String thredKey;

	private int seqNo;

	private String uploadKey;

	private String fileName;

	private String updDate;

	private String updUserKey;

	public String getThredKey() {
		return thredKey;
	}

	public void setThredKey(String thredKey) {
		this.thredKey = thredKey;
	}

	public int getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(int seqNo) {
		this.seqNo = seqNo;
	}

	public String getUploadKey() {
		return uploadKey;
	}

	public void setUploadKey(String uploadKey) {
		this.uploadKey = uploadKey;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getUpdDate() {
		return updDate;
	}

	public void setUpdDate(String updDate) {
		this.updDate = updDate;
	}

	public String getUpdUserKey() {
		return updUserKey;
	}

	public void setUpdUserKey(String updUserKey) {
		this.updUserKey = updUserKey;
	}

}
