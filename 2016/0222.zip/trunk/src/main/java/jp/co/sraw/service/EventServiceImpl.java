/*
* ファイル名：UserServiceImpl.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonService;
import jp.co.sraw.common.UserInfo;
import jp.co.sraw.controller.event.EventForm;
import jp.co.sraw.dto.EvEventViewDto;
import jp.co.sraw.dto.EventDto;
import jp.co.sraw.entity.CmBatchTargetTbl;
import jp.co.sraw.entity.CmBatchTargetTblPK;
import jp.co.sraw.entity.CmInfoPublicTbl;
import jp.co.sraw.entity.CmInfoPublicTblPK;
import jp.co.sraw.entity.CmInfoTbl;
import jp.co.sraw.entity.EvEventPublicTbl;
import jp.co.sraw.entity.EvEventPublicTblPK;
import jp.co.sraw.entity.EvEventTbl;
import jp.co.sraw.entity.EvEventUploadTbl;
import jp.co.sraw.entity.EvEventUploadTblPK;
import jp.co.sraw.entity.EvEventView;
import jp.co.sraw.file.FileDto;
import jp.co.sraw.file.FileService;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.repository.CmBatchTargetTblRepository;
import jp.co.sraw.repository.CmInfoPublicTblRepository;
import jp.co.sraw.repository.CmInfoTblRepository;
import jp.co.sraw.repository.EvEventPublicTblRepository;
import jp.co.sraw.repository.EvEventTblRepository;
import jp.co.sraw.repository.EvEventUploadTblRepository;
import jp.co.sraw.repository.EvEventViewRepository;
import jp.co.sraw.security.Role;
import jp.co.sraw.util.DateUtil;
import jp.co.sraw.util.StringUtil;

/**
 * <B>UserServiceクラス</B>
 * <P>
 * ユーザーサービスのメソッドを提供する
 */
@Scope("prototype")
@Service
@Transactional(readOnly = true)
public class EventServiceImpl extends CommonService {

	@Autowired
	private EvEventTblRepository evEventTblRepository;

	@Autowired
	private EvEventPublicTblRepository evEventPublicTblRepository;

	@Autowired
	private CmInfoTblRepository cmInfoTblRepository;

	@Autowired
	private CmInfoPublicTblRepository cmInfoPublicTblRepository;

	@Autowired
	private FileService fileService;

	@Autowired
	private CmBatchTargetTblRepository cmBatchTargetTblRepository;

	@Autowired
	private EvEventUploadTblRepository evEventUploadTblRepository;

	@Autowired
	private ViewServiceImpl<EvEventView, EvEventViewDto, EvEventViewRepository> viewServiceImpl;

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(EventServiceImpl.class);

	public static final String SEARCH_DATE_TYPE_BATCH = "batch"; // batch処理

	public static final String INFO_URL= "/mgmt/event/list"; // お知らせURL

	@PostConstruct
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	public List<EventDto> getDtoList(List<EvEventTbl> list, Locale locale) {
		List<EventDto> dtoList = new ArrayList<>();

		for (int i = 0; i < list.size(); i++) {
			EventDto dto = new EventDto();
			dto = (EventDto) objectUtil.getObjectCopyValue(dto, list.get(i));
			dtoList.add(dto);
		}
		return dtoList;
	}

	public List<EvEventViewDto> findAllEventViewDto(UserInfo userInfo, String searchDateType, Locale locale) {
		viewServiceImpl.initService(new EvEventViewDto(), "eventStartDate", "eventSendDate", "eventSendDate");
		viewServiceImpl.setSearchDateType(searchDateType);
		Map<String, List<EvEventViewDto>> map = viewServiceImpl.getDtoList(userInfo, locale);
		return map.get("default");
	}

	public List<EvEventViewDto> findAllEventViewDto(UserInfo userInfo, Locale locale) {
		viewServiceImpl.initService(new EvEventViewDto(), "eventStartDate", "eventSendDate", "eventSendDate");
		Map<String, List<EvEventViewDto>> map = viewServiceImpl.getDtoList(userInfo, locale);
		return map.get("default");
	}

	/**
	 *
	 * @param userInfo
	 * @param form
	 * @return
	 */
	public EventForm getOneForm(UserInfo userInfo, EventForm form) {
		EvEventTbl entity = findOne(userInfo, form);
		if (entity != null) {
			form = (EventForm) objectUtil.getObjectCopyValue(form, entity);
			return form;
		}
		return null;
	}

	/**
	 * eventKey指定取得
	 *
	 * @param eventKey
	 * @return
	 */
	public EvEventTbl getOne(final String eventKey) {
		return evEventTblRepository.getOne(eventKey);
	}

	public EvEventTbl findOne(UserInfo userInfo, EventForm form) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		// 定数区分
		Specification<EvEventTbl> whereEventKey = StringUtil.isNull(form.getEventKey()) ? null
				: new Specification<EvEventTbl>() {
					@Override
					public Predicate toPredicate(Root<EvEventTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("eventKey"), form.getEventKey());
					}
				};
		Specification<EvEventTbl> whereUpdDate = DateUtil.isNull(form.getUpdDate()) ? null
				: new Specification<EvEventTbl>() {
					@Override
					public Predicate toPredicate(Root<EvEventTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("updDate"), form.getUpdDate());
					}
				};

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return evEventTblRepository.findOne(Specifications.where(whereEventKey).and(whereUpdDate));
	}

	@Transactional
	public boolean delete(UserInfo userInfo, EventForm form) {
		logger.infoCode("I0001");
		try {

			EvEventTbl entity = findOne(userInfo, form);

			// イベント公開範囲テーブルから対象データをDELETEする。
			evEventPublicTblRepository.delete(entity.getEvEventPublicTbls());

			// イベントのアブロードから対象データをDELETEする。
			evEventUploadTblRepository.delete(entity.getEvEventUploadTbls());

			int c1 = evEventTblRepository.delete(form.getEventKey(), form.getUpdDate());

			if (c1 > 0) {
				evEventPublicTblRepository.flush();
				evEventTblRepository.flush();
				logger.infoCode("I0002");
				return true;
			}
		} catch (Exception e) {
			logger.errorCode("E1009", e); // E1009=削除に失敗しました。{0}
		}
		return false;
	}

	/**
	 *
	 * @param form
	 * @param userInfo
	 * @return
	 */
	public List<FileDto> getUploadFileList(EventForm form, UserInfo userInfo) {
		logger.infoCode("I0001");

		List<FileDto> uploadFileList = new ArrayList<>();
		try {
			EvEventTbl entity = findOne(userInfo, form);
			if (entity == null) {
				throw new Exception();
			}
			List<EvEventUploadTbl> uploadList = entity.getEvEventUploadTbls();
			for (EvEventUploadTbl tbl : uploadList) {
				FileDto dto = fileService.getFileUploadDto(tbl.getId().getUploadKey());
				dto.setUploadKey(tbl.getId().getUploadKey());
				uploadFileList.add(dto);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return uploadFileList;
	}

	@Transactional
	public boolean update(EventForm form, UserInfo userInfo) {
		logger.infoCode("I0001");
		try {
			EvEventTbl entity = new EvEventTbl();

			if (form.getPageMode().equals(CommonConst.PAGE_MODE_EDIT)) {
				entity = findOne(userInfo, form);
				if (entity == null) {
					throw new Exception();
				}
			}else{
				entity.setPartyCode(userInfo.getLoginPartyCode());
			}

			entity.setUpdUserKey(userInfo.getLoginUserKey());
			//
			entity.setEventMemo(form.getEventMemo());
			entity.setEventPlace(form.getEventPlace());
			entity.setEventRecruit(form.getEventRecruit());
			entity.setEventSendDate(form.getEventSendDateAsTimestamp());
			entity.setEventStartDate(form.getEventStartDateAsTimestamp());
			entity.setEventTelno(form.getEventTelno());
			entity.setEventTitle(form.getEventTitle());
			entity.setEventUnit(form.getEventUnit());
			entity.setPartyName(form.getPartyName());

			// TODO:
			// *****************************************************
			// 養成能力未完成？？？？
			if (StringUtil.isNull(form.getSubjectInsKbn())) {
				entity.setSubjectInsKbn("0");
			} else {
				entity.setSubjectInsKbn(form.getSubjectInsKbn());
			}
			// *****************************************************
			entity.setBatchStatus(CommonConst.BATCH_STATUS_RUN_YET); // バッチ実行状況用
																		// 0:未処理
			if (userInfo.isMgmt1()) {
				entity.setPublicFlag(form.getPublicFlag());
			} else {
				entity.setPublicFlag("0");
			}
			entity.setUpdDate(DateUtil.getNowTimestamp());

			// 更新テーブル：イベント公開範囲テーブル
			if (form.getPageMode().equals(CommonConst.PAGE_MODE_EDIT)) {
				// イベント公開範囲テーブルから対象データをDELETEする。
				evEventPublicTblRepository.delete(entity.getEvEventPublicTbls());
				// イベントのアブロードから対象データをDELETEする。
				evEventUploadTblRepository.delete(entity.getEvEventUploadTbls());
			}

			entity = evEventTblRepository.save(entity);

			List<EvEventUploadTbl> uploadList = new ArrayList<>();
			List<FileDto> uploadFileList = form.getUploadFileList();

			for (FileDto dto : uploadFileList) {
				EvEventUploadTbl uploadTbl = new EvEventUploadTbl();
				EvEventUploadTblPK pk = new EvEventUploadTblPK();
				pk.setEventKey(entity.getEventKey());
				pk.setUploadKey(dto.getUploadKey());
				uploadTbl.setId(pk);
				// 現在時刻を設定する。
				uploadTbl.setUpdDate(DateUtil.getNowTimestamp());
				// ログイン者のユーザキーの値を設定する。
				uploadTbl.setUpdUserKey(userInfo.getLoginUserKey());
				uploadList.add(uploadTbl);
			}

			evEventUploadTblRepository.save(uploadList);

			List<EvEventPublicTbl> publicList = new ArrayList<>();
			int count = 1;

			// 企業・研究所などがチェックＯＮの場合、１件出力する。
			if (form.getPublicSociety().equals("1")) {
				EvEventPublicTbl tbl = new EvEventPublicTbl();
				EvEventPublicTblPK pk = new EvEventPublicTblPK();
				pk.setEventKey(entity.getEventKey());
				pk.setSeqNo(count);
				tbl.setId(pk);

				// 企業・研究所等が、設定されている分の出力を行う場合、１：ROLE。
				tbl.setPublicKbn("1");
				// 企業・研究所等が、設定されている分の出力を行う場合、１：MGMT4。
				tbl.setRole(Role.ROLE_MGMT4.getRole());
				// 企業・研究所等が、設定されている分の出力を行う場合、NULL。
				tbl.setPartyCode(null);
				// 現在時刻を設定する。
				tbl.setUpdDate(DateUtil.getNowTimestamp());
				// ログイン者のユーザキーの値を設定する。
				tbl.setUpdUserKey(userInfo.getLoginUserKey());
				publicList.add(tbl);
				count = count + 1;
			}
			if (form.getPublicUniversity().equals("2")) {
				// 大學がチェックＯＮの場合、公開範囲（公開）で選択されている件数出力する。
				for (int i = 0; i < form.getPublicPartyArray().length; i++) {
					EvEventPublicTbl tbl = new EvEventPublicTbl();
					EvEventPublicTblPK pk = new EvEventPublicTblPK();
					pk.setEventKey(entity.getEventKey());
					pk.setSeqNo(count);
					tbl.setId(pk);

					// 大學が、設定されている分の出力を行う場合、２：組織。
					tbl.setPublicKbn("2");
					// 大學が、設定されている分の出力を行う場合、NULL。
					tbl.setRole(null);
					// 大學が、設定されている分の出力を行う場合、対象大学の組織コード。
					tbl.setPartyCode(form.getPublicPartyArray()[i]);
					// 現在時刻を設定する。
					tbl.setUpdDate(DateUtil.getNowTimestamp());
					// ログイン者のユーザキーの値を設定する。
					tbl.setUpdUserKey(userInfo.getLoginUserKey());
					publicList.add(tbl);
					count = count + 1;
				}
			}
			if (form.getPageMode().equals(CommonConst.PAGE_MODE_ADD)
					|| form.getPageMode().equals(CommonConst.PAGE_MODE_COPY)) {
				// お知らせ情報、お知らせ情報公開範囲登録
				this.insertCmInfo(userInfo, entity.getEventTitle(), entity.getEventKey(), CommonConst.OP_ACTION_ADDED, Role.ROLE_MGMT1.getRole());
			}

			evEventPublicTblRepository.save(publicList);

			CmBatchTargetTbl batch = new CmBatchTargetTbl();
			CmBatchTargetTblPK id = new CmBatchTargetTblPK();
			// 処理日付 現在時刻を設定する。
			id.setMakeDate(DateUtil.getNowTimestamp());
			// データ区分 インターン募集・合格者登録（'23'）を設定する。
			id.setDataKbn("21");
			// 参照キー インターンシップキーを設定する。
			id.setRefDataKey(entity.getEventKey());
			//
			batch.setId(id);
			// お知らせ情報作成フラグ 作成済み（’1’）を設定する。
			batch.setInfoMakeFlag("1");
			// スケジュール情報作成フラグ 作成済み（’1’）を設定する。
			batch.setMailMakeFlag("1");
			// eメール送信済みフラグ 未作成（’０’）を設定する。
			batch.setScheduleMakeFlag("0");
			// 送信対象NULL値を設定する。
			batch.setSendUserKey(null);
			// 送信対象ロール HIRAKU 運営協議会事務局（’ROLE_MGMT1’）を設定する。
			batch.setSendRole(Role.ROLE_MGMT1.getRole());
			// 送信対象組織 NULL値を設定する。
			batch.setSendPartyCode(null);
			// データ更新日 現在時刻を設定する。
			batch.setUpdDate(DateUtil.getNowTimestamp());
			// データ更新者 ログイン者のユーザキーの値を設定する。
			batch.setUpdUserKey(userInfo.getLoginUserKey());
			//
			batch = cmBatchTargetTblRepository.save(batch);

			if (DateUtil.getNowTimestamp().before(DateUtil.formatTimestampStart(
					DateUtil.getTimestamp(form.getEventSendDate(), CommonConst.DEFAULT_YYYYMMDD)))) {
				// バッチ処理用抽出データ （当日日付が配信日以降の場合、行う）

				CmBatchTargetTbl batch2 = new CmBatchTargetTbl();
				CmBatchTargetTblPK pk = new CmBatchTargetTblPK();
				// 処理日付 現在時刻を設定する。
				pk.setMakeDate(DateUtil.getNowTimestamp());
				// データ区分 イベント登録（'1'）を設定する。
				pk.setDataKbn("1");
				// 参照キー インターンシップキーを設定する。
				pk.setRefDataKey(entity.getEventKey());
				//
				batch2.setId(pk);
				// お知らせ情報作成フラグ 作成済み（’1’）を設定する。
				batch2.setInfoMakeFlag("1");
				// スケジュール情報作成フラグ 未作成（’０’）を設定する。
				batch2.setMailMakeFlag("0");
				// eメール送信済みフラグ 作成済み（’1’）を設定する。
				batch2.setScheduleMakeFlag("1");
				// 送信対象NULL値を設定する。
				batch2.setSendUserKey(null);
				// 送信対象ロール NULL値を設定する。
				batch2.setSendRole(null);
				// 送信対象組織 NULL値を設定する。
				batch2.setSendPartyCode(null);
				// データ更新日 現在時刻を設定する。
				batch2.setUpdDate(DateUtil.getNowTimestamp());
				// データ更新者 ログイン者のユーザキーの値を設定する。
				batch2.setUpdUserKey(userInfo.getLoginUserKey());
				//
				batch2 = cmBatchTargetTblRepository.save(batch2);
			}

			logger.infoCode("I0002");
			return true;

		} catch (Exception e) {
			e.printStackTrace();
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
		}
		return false;
	}

	/**
	 *
	 * @param userInfo
	 * @param form
	 * @param opeKbn
	 * @param role
	 * @param partyCode
	 * @return
	 */
	public boolean insertCmInfo(UserInfo userInfo, String title, String eventKey, String opeKbn, String role) {
		boolean result = false;

		try {
			CmInfoTbl entity = new CmInfoTbl();
			entity.setSendDate(DateUtil.getNowTimestamp());
			entity.setTitle(title);
			entity.setDataKbn("1");
			entity.setOpeKbn(opeKbn);
			entity.setInfoRefKey(eventKey);
			entity.setMakeUserKey(userInfo.getLoginUserKey());
			// https:///????/mgmt/event/list を設定する。
			entity.setUrl(INFO_URL);
			entity.setUpdDate(DateUtil.getNowTimestamp());
			entity.setUpdUserKey(userInfo.getLoginUserKey());

			entity = cmInfoTblRepository.save(entity);
			String infoKey = entity.getInfoKey();

			if (infoKey != null && StringUtil.isNotNull(infoKey)) {
				CmInfoPublicTbl entitySub = new CmInfoPublicTbl();
				CmInfoPublicTblPK id = new CmInfoPublicTblPK();
				id.setInfoKey(infoKey);
				id.setSeqNo(1);
				entitySub.setId(id);
				entitySub.setPublicKbn("1");
				entitySub.setRole(role);
				entitySub.setPartyCode(null);
				entitySub.setUpdDate(DateUtil.getNowTimestamp());
				entitySub.setUpdUserKey(userInfo.getLoginUserKey());

				cmInfoPublicTblRepository.save(entitySub);

				result = true;
			}

		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
		}

		return result;
	}

}
