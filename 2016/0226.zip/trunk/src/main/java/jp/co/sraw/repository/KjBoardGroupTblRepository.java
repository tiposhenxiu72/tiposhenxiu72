package jp.co.sraw.repository;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import jp.co.sraw.entity.KjBoardGroupTbl;

@Repository
public interface KjBoardGroupTblRepository extends JpaRepository<KjBoardGroupTbl, String>, JpaSpecificationExecutor<KjBoardGroupTbl> {

	@Modifying
	@Query(name = "KjBoardGroupTbl.delete")
	public int delete(@Param("boardGroupKey") String boardGroupKey, @Param("updDate") Timestamp updDate);

	@Query(name="KjBoardGroupTbl.findAllThred")
	public List<KjBoardGroupTbl> findAllThred(@Param("userKey") String userKey);

}
