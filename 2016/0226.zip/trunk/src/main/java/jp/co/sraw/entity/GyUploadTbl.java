package jp.co.sraw.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

/**
 * The persistent class for the gy_society_tbl database table.
 *
 */
@MappedSuperclass
public class GyUploadTbl extends GyHasTtitleTbl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name = "upload_key")
	private String uploadKey;

	public String getUploadKey() {
		return this.uploadKey;
	}

	public void setUploadKey(String uploadKey) {
		this.uploadKey = uploadKey;
	}

}