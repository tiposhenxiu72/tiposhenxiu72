package jp.co.sraw.context;

public class RoleObject {

	public String getDetailPageUrl() {
		return detailPageUrl;
	}

	public void setDetailPageUrl(String detailPageUrl) {
		this.detailPageUrl = detailPageUrl;
	}

	private String detailPageUrl;

	public String getEditPageUrl() {
		return editPageUrl;
	}

	public void setEditPageUrl(String editPageUrl) {
		this.editPageUrl = editPageUrl;
	}

	private String editPageUrl;
}
