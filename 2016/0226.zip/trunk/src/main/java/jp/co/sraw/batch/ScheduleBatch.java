package jp.co.sraw.batch;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.service.BatchTargetService;

@Component
public class ScheduleBatch implements BatchRunner  {
	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(ScheduleBatch.class);

	@Autowired
	private BatchTargetService batchTargetService;

	public boolean run(Map<String, String> parameters) throws Exception {

		// スケジュール作成
		// 支援制度からの情報抽出
		// 無し

		// イベントからの情報抽出
		Boolean eventFlag = batchTargetService.updateEventBatchSchedule();

		// インターンシップからの情報抽出
		Boolean internshipFlag = batchTargetService.updateInternshipBatchSchedule();

		// すべてupdate成功なら、trueを戻す
		if (eventFlag && internshipFlag) {
			return true;
		}
		return false;
	}

}
