/*
* ファイル名：EventForm.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.event;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.validator.constraints.NotBlank;
import org.maru.m4hv.extensions.constraints.ActualDate;
import org.maru.m4hv.extensions.constraints.CharLength;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonForm;
import jp.co.sraw.file.FileDto;
import jp.co.sraw.util.DateUtil;
import jp.co.sraw.util.StringUtil;

/**
 * <B>EventFormクラス</B>
 * <P>
 * Formのメソッドを提供する
 */
public class EventForm extends CommonForm {

	private String searchDateType; // 検索条件：期間

	private String searchPublicFlag; // 検索条件：公開フラグ

	private String eventKey;

	private String deletedFileList;

	public String getDeletedFileList() {
		return deletedFileList;
	}

	public void setDeletedFileList(String deletedFileList) {
		this.deletedFileList = deletedFileList;
	}

	@NotBlank
	@CharLength(max = 10000)
	private String eventMemo;

	@NotBlank
	@CharLength(max = 100)
	private String eventPlace;

	@CharLength(max = 100)
	private String eventRecruit;

	@NotBlank
	@ActualDate
	private String eventStartDate;

	@NotBlank
	@ActualDate
	private String eventSendDate;

	@NotBlank
	@CharLength(max = 100)
	private String eventTelno;

	@NotBlank
	@CharLength(max = 100)
	private String eventTitle;

	@CharLength(max = 100)
	private String eventUnit;

	private String partyCode;

	private String targetPartyCode;

	@NotBlank
	@CharLength(max = 100)
	private String partyName;

	private String publicFlag;

	private String subjectInsKbn;

	private Timestamp updDate;

	private String updUserKey;

	private String publicKbn;

	private String role;

	private String publicDisabled;

	private List<FileDto> uploadFileList = new ArrayList<FileDto>();

	private String uploadFileNames;

	private String deleteFlag = "1";

	private String skillJson;

	private String isMgmt;

	public String getSkillJson() {
		return skillJson;
	}

	public void setSkillJson(String skillJson) {
		this.skillJson = skillJson;
	}

	public String getIsMgmt() {
		return isMgmt;
	}

	public void setIsMgmt(String isMgmt) {
		this.isMgmt = isMgmt;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	private String publicUniversity;

	public String getPublicUniversity() {
		return publicUniversity;
	}

	public String getPublicSociety() {
		return publicSociety;
	}

	public void setPublicSociety(String publicSociety) {
		this.publicSociety = publicSociety;
	}

	public void setPublicUniversity(String publicUniversity) {
		this.publicUniversity = publicUniversity;
	}

	private String publicSociety;

	public String getUploadFileNames() {
		String fileNames = "";
		String splitStr = "";
		if (this.uploadFileList.size() > 0) {
			for (FileDto dto : this.uploadFileList) {
				fileNames = fileNames + splitStr + dto.getUploadName();
				splitStr = ",";
			}
			return fileNames;
		}
		return uploadFileNames;
	}

	public void setUploadFileNames(String uploadFileNames) {
		this.uploadFileNames = uploadFileNames;
	}

	private String publicPartyList;

	public List<FileDto> getUploadFileList() {
		return uploadFileList;
	}

	public void setUploadFileList(List<FileDto> uploadFileList) {
		if (uploadFileList != null) {
			this.uploadFileList = uploadFileList;
		} else {
			this.uploadFileList = new ArrayList<FileDto>();
		}
	}

	public String getEventKey() {
		return this.eventKey;
	}

	public void setEventKey(String eventKey) {
		this.eventKey = eventKey;
	}

	public String getEventMemo() {
		return this.eventMemo;
	}

	public void setEventMemo(String eventMemo) {
		this.eventMemo = eventMemo;
	}

	public String getEventPlace() {
		return this.eventPlace;
	}

	public void setEventPlace(String eventPlace) {
		this.eventPlace = eventPlace;
	}

	public String getEventRecruit() {
		return this.eventRecruit;
	}

	public void setEventRecruit(String eventRecruit) {
		this.eventRecruit = eventRecruit;
	}

	public String getEventTelno() {
		return this.eventTelno;
	}

	public void setEventTelno(String eventTelno) {
		this.eventTelno = eventTelno;
	}

	public String getEventTitle() {
		return this.eventTitle;
	}

	public void setEventTitle(String eventTitle) {
		this.eventTitle = eventTitle;
	}

	public String getEventUnit() {
		return this.eventUnit;
	}

	public void setEventUnit(String eventUnit) {
		this.eventUnit = eventUnit;
	}

	public String getPartyCode() {
		return this.partyCode;
	}

	public void setPartyCode(String partyCode) {
		this.partyCode = partyCode;
	}

	public String getTargetPartyCode() {
		return this.targetPartyCode;
	}

	public void setTargetPartyCode(String targetPartyCode) {
		this.targetPartyCode = targetPartyCode;
	}

	public String getPartyName() {
		return this.partyName;
	}

	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}

	public String getPublicFlag() {
		return this.publicFlag;
	}

	public void setPublicFlag(String publicFlag) {
		this.publicFlag = publicFlag;
	}

	public String getSubjectInsKbn() {
		return this.subjectInsKbn;
	}

	public void setSubjectInsKbn(String subjectInsKbn) {
		this.subjectInsKbn = subjectInsKbn;
	}

	public String getUpdUserKey() {
		return this.updUserKey;
	}

	public void setUpdUserKey(String updUserKey) {
		this.updUserKey = updUserKey;
	}

	public String getEventStartDate() {
		return eventStartDate;
	}

	public Timestamp getEventStartDateAsTimestamp() {
		return DateUtil.getTimestamp(this.eventStartDate, CommonConst.DEFAULT_YYYYMMDD);
	}

	public void setEventStartDate(String eventStartDate) {
		this.eventStartDate = StringUtil.htmlFilter(eventStartDate);
	}

	public String getEventSendDate() {
		return eventSendDate;
	}

	public Timestamp getEventSendDateAsTimestamp() {
		return DateUtil.getTimestamp(this.eventSendDate, CommonConst.DEFAULT_YYYYMMDD);
	}

	public void setEventSendDate(String eventSendDate) {
		this.eventSendDate = StringUtil.htmlFilter(eventSendDate);
	}

	public String getPublicKbn() {
		return publicKbn;
	}

	public void setPublicKbn(String publicKbn) {
		this.publicKbn = publicKbn;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getPublicDisabled() {
		return publicDisabled;
	}

	public void setPublicDisabled(String publicDisabled) {
		this.publicDisabled = publicDisabled;
	}

	public Timestamp getUpdDate() {
		return updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getSearchDateType() {
		return searchDateType;
	}

	public void setSearchDateType(String searchDateType) {
		this.searchDateType = searchDateType;
	}

	public String getSearchPublicFlag() {
		return searchPublicFlag;
	}

	public void setSearchPublicFlag(String searchPublicFlag) {
		this.searchPublicFlag = searchPublicFlag;
	}

	/**
	 * @param publicItemArray
	 *            セットする publicItemArray
	 */
	public void setPublicItemArray(String[] publicItemArray) {
		for (String itemValue : publicItemArray) {
			if (itemValue.equals("1")) {
				this.publicSociety = "1";
			}
			if (itemValue.equals("2")) {
				this.publicUniversity = "2";
			}
		}
	}

	public void setPublicPartyList(String publicPartyList) {
		this.publicPartyList = publicPartyList;
	}

	public String[] getPublicPartyList() {
		String[] array = new String[] {};
		if (this.publicPartyList != null)
			array = this.publicPartyList.replace("，", ",").split(",");
		return array;
	}

	public String[] getPublicPartyArray() {
		String[] array = new String[] {};
		if (this.publicPartyList != null)
			array = this.publicPartyList.replace("，", ",").split(",");
		return array;
	}

	public void setPublicPartyArray(String[] publicPartyArray) {
		String partyList = "";
		for (String party : publicPartyArray) {
			partyList = partyList + party + ",";
		}
		this.publicPartyList = partyList;
	}
}
