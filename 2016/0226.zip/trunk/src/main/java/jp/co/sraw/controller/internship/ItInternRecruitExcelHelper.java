package jp.co.sraw.controller.internship;

import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Service;

import jp.co.sraw.common.CommonForm;
import jp.co.sraw.entity.ItInternRecruitView;
import jp.co.sraw.file.AbstractExcelHelper;
import jp.co.sraw.util.PoiBook;

@Service
public class ItInternRecruitExcelHelper extends AbstractExcelHelper<ItInternRecruitView> {

	private final String DATA_SHEET_NAME = "INTERNSHIP";

	@Override
	public void buildExcelDocument(PoiBook workbook, List<ItInternRecruitView> list) {
		workbook.activeSheet = workbook.book.getSheet(DATA_SHEET_NAME);

		for (int i = 0; i < list.size(); i++) {
			ItInternRecruitView form = list.get(i);
			form.setViewType(CommonForm.VIEW_TYPE_FORM);
			int rowno = i + 1;
			// 種別
			workbook.changeValue(rowno, 0, form.getInternshipKbn());
			// 応募期間(FROM)
			workbook.changeValue(rowno, 1, getDateInfo(form.getInternshipStartDate()));
			// 応募期間(TO)
			workbook.changeValue(rowno, 2, getDateInfo(form.getInternshipEndDate()));
			// 見出し
			workbook.changeValue(rowno, 3, form.getInternshipTitle());
			// 募集者
			workbook.changeValue(rowno, 4, form.getInternshipPartyName());
			// 応募者氏名
			workbook.changeValue(rowno, 5, form.getUserFullName());
			// 応募者所属
			workbook.changeValue(rowno, 6, form.getAffiliationName());
			// 応募者性別
			workbook.changeValue(rowno, 7, form.getSex());
			// 合否結果
			workbook.changeValue(rowno, 8, form.getDecisionKbnTitle());
			// 応募者学年
			workbook.changeValue(rowno, 9, form.getRecruitGrade());
			// 応募者指導教員
			workbook.changeValue(rowno, 10, form.getRecruitTeacher());
			// 応募者派遣先
			workbook.changeValue(rowno, 11, form.getRecruitPartyName());
			// 企業派遣期間(FROM)
			workbook.changeValue(rowno, 12, getDateInfo(form.getRecruitStartDate()));
			// 企業派遣期間(TO)
			workbook.changeValue(rowno, 13, getDateInfo(form.getRecruitEndDate()));
			// 就職状況
			workbook.changeValue(rowno, 14, form.getRecruitStatus());
			// 備考欄
			workbook.changeValue(rowno, 15, form.getRecruitMemo());
		}
	}

	@Override
	public Sheet getSheet(Workbook workbook) {
		return workbook.getSheet(DATA_SHEET_NAME);
	}

	@Override
	public ItInternRecruitView getForm(Row row) {

		ItInternRecruitView form = new ItInternRecruitView();

		return form;
	}

}