/*
* ファイル名：UserNameCacheAuthenticationFailureHandler.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/01/28   toishigawa  新規作成
*/
package jp.co.sraw.holder;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;

/**
* <B>UserNameCacheAuthenticationFailureHandler</B>
* <P>
* ログインに失敗したusernameを保持を提供する
*/
public class UserNameCacheAuthenticationFailureHandler extends SimpleUrlAuthenticationFailureHandler {

	private static Logger logger = LoggerFactory.getLogger(UserNameCacheAuthenticationFailureHandler.class);

	public static final String LAST_USERNAME_KEY = "LAST_USERNAME";

	private String usernameParameter;

	public UserNameCacheAuthenticationFailureHandler(String usernameParameter, String defaultFailureUrl) {
		super.setDefaultFailureUrl(defaultFailureUrl);
		this.usernameParameter = usernameParameter;

	}

	@Override
	public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException exception) throws IOException, ServletException {

		try {
			super.onAuthenticationFailure(request, response, exception);

			String lastUserName = request.getParameter(usernameParameter);

			if (logger.isDebugEnabled()) {
				logger.debug("Failure LoginUser={}", lastUserName);
			}

			HttpSession session = request.getSession(false);
			if (session != null || isAllowSessionCreation()) {
				request.getSession().setAttribute(LAST_USERNAME_KEY, lastUserName);
			}
		} catch (IOException e) {
			throw e;

		} catch (ServletException e) {
			throw e;

		} catch (Exception e) {
			if (logger.isDebugEnabled()) {
				e.printStackTrace();
			}
		}
	}

}
