package jp.co.sraw.dto;

import java.io.Serializable;

public class AdvicerDto implements Serializable {

	private static final long serialVersionUID = 1L;

	/*
	 * ユーザキー
	 */
	private String userKey;

	/*
	 * ユーザ名（姓）
	 */
	private String userFamilyName;

	/*
	 * ユーザ名（ミドルネーム）
	 */
	private String userMiddleName;

	/*
	 * ユーザ名（名）
	 */
	private String userName;

	/*
	 * 組織名称
	 */
	private String partyName;

	/*
	 * 組織名称（略）
	 */
	private String partyNameAbbr;

	/**
	 * userKeyを取得します。
	 * @return userKey
	 */
	public String getUserKey() {
	    return userKey;
	}

	/**
	 * userKeyを設定します。
	 * @param userKey userKey
	 */
	public void setUserKey(String userKey) {
	    this.userKey = userKey;
	}

	/**
	 * userFamilyNameを取得します。
	 * @return userFamilyName
	 */
	public String getUserFamilyName() {
	    return userFamilyName;
	}

	/**
	 * userFamilyNameを設定します。
	 * @param userFamilyName userFamilyName
	 */
	public void setUserFamilyName(String userFamilyName) {
	    this.userFamilyName = userFamilyName;
	}

	/**
	 * userMiddleNameを取得します。
	 * @return userMiddleName
	 */
	public String getUserMiddleName() {
	    return userMiddleName;
	}

	/**
	 * userMiddleNameを設定します。
	 * @param userMiddleName userMiddleName
	 */
	public void setUserMiddleName(String userMiddleName) {
	    this.userMiddleName = userMiddleName;
	}

	/**
	 * userNameを取得します。
	 * @return userName
	 */
	public String getUserName() {
	    return userName;
	}

	/**
	 * userNameを設定します。
	 * @param userName userName
	 */
	public void setUserName(String userName) {
	    this.userName = userName;
	}

	/**
	 * partyNameを取得します。
	 * @return partyName
	 */
	public String getPartyName() {
	    return partyName;
	}

	/**
	 * partyNameを設定します。
	 * @param partyName partyName
	 */
	public void setPartyName(String partyName) {
	    this.partyName = partyName;
	}

	/**
	 * partyNameAbbrを取得します。
	 * @return partyNameAbbr
	 */
	public String getPartyNameAbbr() {
	    return partyNameAbbr;
	}

	/**
	 * partyNameAbbrを設定します。
	 * @param partyNameAbbr partyNameAbbr
	 */
	public void setPartyNameAbbr(String partyNameAbbr) {
	    this.partyNameAbbr = partyNameAbbr;
	}


}