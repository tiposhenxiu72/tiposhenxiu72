package jp.co.sraw.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import jp.co.sraw.dto.KjBoardRelUserDto;
import jp.co.sraw.entity.KjBoardRelUser;
import jp.co.sraw.entity.KjBoardRelUserPK;

@Repository
public interface KjBoardRelUserRepository extends JpaRepository<KjBoardRelUser, KjBoardRelUserPK>, JpaSpecificationExecutor<KjBoardRelUser> {

	@Query(name="KjBoardRelUser.findGroupMemberList")
	public List<KjBoardRelUserDto> findGroupMemberList(@Param("boardGroupKey") String boardGroupKey);

	@Query(name="KjBoardRelUser.findPartyMemberList")
	public List<KjBoardRelUserDto> findPartyMemberList(@Param("partyCode") String partyCode);

	@Query(name="KjBoardRelUser.findSearchMemberList")
	public List<KjBoardRelUserDto> findSearchMemberList(@Param("partyName") String partyName, @Param("affiliationName") String affiliationName, @Param("userName") String userName);
}
