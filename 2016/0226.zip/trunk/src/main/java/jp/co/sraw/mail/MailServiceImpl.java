/*
* ファイル名：MailServiceImpl.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/01/25   toishigawa  新規作成
*/
package jp.co.sraw.mail;

import java.io.IOException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.mail.internet.MimeMessage;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonService;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
/**
* <B>MailServiceImplクラス</B>
* <P>
* メールサービスのメソッドを提供する
*/
@Scope("prototype")
@Service
public class MailServiceImpl extends CommonService {


	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(MailServiceImpl.class);

	private static String TEMPLATE_ENCODEING = "UTF-8";
	private static String TEMPLATE_SUBJECT_PREFIX = "_subject.txt";
	private static String TEMPLATE_BODY_PREFIX = "_body.txt";

	private static String TEMPLATE_NAME_ACCOUNT_REQUEST = "accountRequest"; // アカウント登録
	private static String TEMPLATE_NAME_NEWS_INFORMATION = "newsInformation"; // お知らせ
	private static String TEMPLATE_NAME_CONSULTATION = "consultation"; // キャリア相談
	private static String TEMPLATE_NAME_KJ_REQUEST = "kjGroupInvitation"; // 掲示板


	@Autowired
	private JavaMailSender mailSender;

	@PostConstruct
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	/**
	 * 共通：テキスト本文の場合
	 *
	 * @param bcc
	 * @param subject
	 * @param text
	 * @return
	 */
	private MailStatus sendPlainText(String[] bcc, String subject, String text) {
		// 送信元メールアドレス取得
		String from = messageSource.getMessage("system.mail.from", null, CommonConst.DEFAULT_LOCALE);
		String replyTo= messageSource.getMessage("system.mail.from", null, CommonConst.DEFAULT_LOCALE);
		return mailSend(from, replyTo, bcc, subject, text, false);
	}

	/**
	 * 共通：HTML本文の場合
	 *
	 * @param bcc
	 * @param subject
	 * @param htmlBody
	 * @return
	 */
	private MailStatus sendHtml(String[] bcc, String subject, String htmlBody) {
		// 送信元メールアドレス取得
		String from = messageSource.getMessage("system.mail.from", null, CommonConst.DEFAULT_LOCALE);
		String replyTo= messageSource.getMessage("system.mail.from", null, CommonConst.DEFAULT_LOCALE);
		return mailSend(from, replyTo, bcc, subject, htmlBody, true);
	}

	/**
	 * 共通：メール送信
	 *
	 * @param bcc
	 * @param subject
	 * @param text
	 * @param isHtml
	 * @return
	 */
	private MailStatus mailSend(String from, String replyTo, String[] bcc, String subject, String text, Boolean isHtml) {
		try {
			MimeMessage mail = mailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(mail, true);
			helper.setFrom(from);
			helper.setReplyTo(replyTo);
			//helper.setTo(to);
			helper.setBcc(bcc);
			helper.setSubject(subject);
			helper.setText(text, isHtml);
			mailSender.send(mail);
			logger.infoCode("I1010", subject, bcc.toString()); // I1010=メール送信 '{0}' to: {1}
			return new MailStatus(bcc, subject, text).success();
		} catch (Exception e) {
			try {
				logger.errorCode("E1019", bcc.toString(), e.getMessage()); // E1019=メール送信失敗 to: {0}, error: {1}
			} catch (Exception e1) {
				if (logger.isDebugEnabled()) {
					e1.printStackTrace();
				}
			}
			return new MailStatus(bcc, subject, text).error(e.getMessage());
		}
	}

	/**
	 * 件名ファイル内容取得&置換
	 *
	 * @param name
	 * @param model
	 * @return
	 */
	private String getTemplateSubject(String name, Map<String, String> model) {
		return this.replaceAll(this.getTemplateSubject(name), model);
	}
	/**
	 * 件名ファイル内容取得
	 *
	 * @param name
	 * @return
	 */
	private String getTemplateSubject(String name) {
		String text = "";
		try {
			text = IOUtils.toString(MailServiceImpl.class.getResourceAsStream(CommonConst.RESPATH_MAIL_TEMPLATE + name +TEMPLATE_SUBJECT_PREFIX), TEMPLATE_ENCODEING);
		} catch (IOException e) {
			if (logger.isDebugEnabled()) {
				e.printStackTrace();
			}
		}
		return text;
	}

	/**
	 * 本文ファイル内容取得&置換
	 *
	 * @param name
	 * @param model
	 * @return
	 */
	private String getTemplateBody(String name, Map<String, String> model) {
		return this.replaceAll(this.getTemplateBody(name), model);
	}
	/**
	 * 本文ファイル内容取得
	 *
	 * @param name
	 * @return
	 */
	private String getTemplateBody(String name) {
		String text = "";
		try {
			text = IOUtils.toString(MailServiceImpl.class.getResourceAsStream(CommonConst.RESPATH_MAIL_TEMPLATE + name +TEMPLATE_BODY_PREFIX), TEMPLATE_ENCODEING);
		} catch (IOException e) {
			if (logger.isDebugEnabled()) {
				e.printStackTrace();
			}
		}
		return text;
	}

	/**
	 * 文字置き換え
	 *
	 * @param src
	 * @param model
	 * @return
	 */
	private String replaceAll(String src, Map<String, String> model) {
		String rtn = src;
		for (Map.Entry<String, String> e : model.entrySet()) {
			rtn = rtn.replaceAll("\\{"+ e.getKey() +"\\}", e.getValue());
		}
		return rtn;
	}

	/**
	 * アカウント登録
	 * 申請者にアカウント本登録のURLを通知
	 *
	 * @param toMailAddress
	 * @param requestId
	 * @return
	 */
	//@Async // 非同期
	public boolean provisional(String toMailAddress, String requestId, Locale locale) {

		// メールテンプレート取得、メール本文の生成
		Map<String, String> model = new HashMap<String, String>();
		model.put("mailAddress", toMailAddress);
		// アカウント本登録URL
		model.put("rootUrl", messageSource.getMessage("system.public.root.url", null, locale));
		model.put("requestId", requestId);

		String subject = this.getTemplateSubject(TEMPLATE_NAME_ACCOUNT_REQUEST, model);
		String body = this.getTemplateBody(TEMPLATE_NAME_ACCOUNT_REQUEST, model);

		// メール配信
		MailStatus mailStatus = sendPlainText(new String[]{toMailAddress}, subject, body);

		return mailStatus.isSuccess();
	}

	/**
	 * キャリア面談
	 * キャリア面談登録通知
	 *
	 * @param userName
	 * @param title
	 * @param action
	 * @param toMailAddress
	 * @param consultataionUrl
	 * @param locale
	 * @return
	 */
	//@Async // 非同期
	public boolean consultation(String userName, String title, String action,
			String toMailAddress, String consultataionUrl, Locale locale) {

		// メールテンプレート取得、メール本文の生成
		Map<String, String> model = new HashMap<String, String>();
		// ユーザ名
		model.put("userName", userName);
		// タイトル
		model.put("title", title);
		// 対象処理
		model.put("action", action);
		// URL
		String url = messageSource.getMessage("system.public.root.url", null, locale);
		url = url.concat(consultataionUrl);
		model.put("url", url);

		String subject = this.getTemplateSubject(TEMPLATE_NAME_CONSULTATION, model);
		String body = this.getTemplateBody(TEMPLATE_NAME_CONSULTATION, model);

		// メール配信
		MailStatus mailStatus = sendPlainText(new String[]{toMailAddress}, subject, body);

		return mailStatus.isSuccess();
	}

	/**
	 * 掲示板
	 * 掲示板グループ招待
	 *
	 * @param userName
	 * @param toMailAddress
	 * @param requestId
	 * @param locale
	 * @return
	 */
	//@Async // 非同期
	public boolean kjGroupInvitation(String userName, String toMailAddress, String requestId, Locale locale) {

		// メールテンプレート取得、メール本文の生成
		Map<String, String> model = new HashMap<String, String>();
		// 送信先メールアドレス
		model.put("mailAddress", toMailAddress);
		// ユーザ名
		model.put("userName", userName);
		// 掲示板グループメンバ承認URL
		model.put("rootUrl", messageSource.getMessage("system.public.root.url", null, locale));
		// パラメータ
		model.put("requestId", requestId);

		String subject = this.getTemplateSubject(TEMPLATE_NAME_KJ_REQUEST, model);
		String body = this.getTemplateBody(TEMPLATE_NAME_KJ_REQUEST, model);

		// メール配信
		MailStatus mailStatus = sendPlainText(new String[]{toMailAddress}, subject, body);

		return mailStatus.isSuccess();
	}

	/**
	 * バッチ
	 * お知らせ
	 *
	 * @param userName
	 * @param toMailAddress
	 * @param menuName
	 * @param message
	 * @param dateTime
	 * @param url
	 * @param locale
	 * @return
	 */
	//@Async // 非同期
	public boolean newsInformation(String userName, String toMailAddress, String menuName, String message, String dateTime, String url) {

		// メールテンプレート取得、メール本文の生成
		Map<String, String> model = new HashMap<String, String>();
		// 送信先メールアドレス
		model.put("mailAddress", toMailAddress);
		// ユーザ名
		model.put("userName", userName);
		// タイトル(支援制度情報 or イベント情報 or インターンシップ情報)
		model.put("menuName", menuName);
		// メッセージ(支援制度情報 or イベント情報 or インターンシップ情報)
		model.put("message", message);
		// 日付
		model.put("dateTime", dateTime);
		// rootUrl
		model.put("rootUrl", messageSource.getMessage("system.public.root.url", null, CommonConst.DEFAULT_LOCALE));
		// url
		model.put("url", url);

		String subject = this.getTemplateSubject(TEMPLATE_NAME_NEWS_INFORMATION, model);
		String body = this.getTemplateBody(TEMPLATE_NAME_NEWS_INFORMATION, model);

		// メール配信
		MailStatus mailStatus = sendPlainText(new String[]{toMailAddress}, subject, body);

		return mailStatus.isSuccess();
	}

}
