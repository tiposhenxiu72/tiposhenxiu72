package jp.co.sraw.dto;

public class ResearchAreaDto {

	private String code; // 研究分野コード
	private String name; // 研究分野名
	/**
	 * @return code
	 */
	public String getCode() {
		return code;
	}
	/**
	 * @param code セットする code
	 */
	public void setCode(String code) {
		this.code = code;
	}
	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name セットする name
	 */
	public void setName(String name) {
		this.name = name;
	}



}
