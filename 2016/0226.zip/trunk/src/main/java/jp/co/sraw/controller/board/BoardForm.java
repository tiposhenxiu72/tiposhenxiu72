/*
* ファイル名：BoardForm.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/01/21   mizoguchi      新規作成
*/
package jp.co.sraw.controller.board;

import java.sql.Timestamp;
import java.util.List;

import org.hibernate.validator.constraints.NotBlank;
import org.maru.m4hv.extensions.constraints.CharLength;
import org.springframework.web.multipart.MultipartFile;

import jp.co.sraw.common.CommonForm;
import jp.co.sraw.dto.KjBoardRelUserDto;

/**
 * <B>BoardFormクラス</B>
 * <P>
 * Formのメソッドを提供する
 */
public class BoardForm extends CommonForm {

	public static interface group1{};	// 掲示板グループ編集時
	public static interface group2{};	// 新規スレッド作成時
	public static interface group3{};	// 新規投稿作成時
	public static interface group4{};	// 共有情報作成時

	private String boardGroupKey;

	@NotBlank(groups=group1.class)
	@CharLength(max = 256, groups=group1.class)
	private String boardName;

	@NotBlank(groups=group1.class)
	private String commonFlag;

	private String publicFlag;

	private String adminFlg;

	@NotBlank(groups=group1.class)
	private String adminUserKey;

	private String outline;

	private Timestamp updDate;

	private String updUserKey;

	private String userKey;

	private String[] relUserKey;

	private String[] relUserStatusKbn;

	private String[] relUserName;

	private String[] relAffiliationName;

	private String[] relPartyName;

	private String userStatusKbn;

	private String uploadFlg;

	private String uploadFlgAfter;

	private String uploadKey;

	private String uploadKeyAfter;

	@NotBlank(groups=group4.class)
	@CharLength(max = 100, groups=group4.class)
	private String title;

	private String searchKeyword;

	private String thredKey;

	@NotBlank(groups=group2.class)
	@CharLength(max = 256, groups=group2.class)
	private String thredName;

	private Timestamp insDate;

	private String insUserKey;

	private int seqNo;

	@NotBlank(groups={group2.class, group3.class})
	private String memo;

	private Timestamp contributionUpdDate;

	private Timestamp readDate;

	private String fileKbn;

	@NotBlank(groups=group4.class)
	@CharLength(max = 100, groups=group4.class)
	private String fileName;

	private String filePutPath;

	private MultipartFile doc;

	private List<KjBoardRelUserDto> sendMailList;

	public MultipartFile getDoc() {
		return doc;
	}

	public void setDoc(MultipartFile doc) {
		this.doc = doc;
	}

	public String getBoardGroupKey() {
		return boardGroupKey;
	}

	public void setBoardGroupKey(String boardGroupKey) {
		this.boardGroupKey = boardGroupKey;
	}

	public String getBoardName() {
		return boardName;
	}

	public void setBoardName(String boardName) {
		this.boardName = boardName;
	}

	public String getCommonFlag() {
		return commonFlag;
	}

	public void setCommonFlag(String commonFlag) {
		this.commonFlag = commonFlag;
	}

	public String getPublicFlag() {
		return publicFlag;
	}

	public void setPublicFlag(String publicFlag) {
		this.publicFlag = publicFlag;
	}

	public String getAdminFlg() {
		return adminFlg;
	}

	public void setAdminFlg(String adminFlg) {
		this.adminFlg = adminFlg;
	}

	public String getAdminUserKey() {
		return adminUserKey;
	}

	public void setAdminUserKey(String adminUserKey) {
		this.adminUserKey = adminUserKey;
	}

	public String getOutline() {
		return outline;
	}

	public void setOutline(String outline) {
		this.outline = outline;
	}

	public Timestamp getUpdDate() {
		return updDate;
	}

	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	public String getUploadKeyAfter() {
		return uploadKeyAfter;
	}

	public void setUploadKeyAfter(String uploadKeyAfter) {
		this.uploadKeyAfter = uploadKeyAfter;
	}

	public String getUpdUserKey() {
		return updUserKey;
	}

	public String getUploadFlg() {
		return uploadFlg;
	}

	public void setUploadFlg(String uploadFlg) {
		this.uploadFlg = uploadFlg;
	}

	public String getUploadFlgAfter() {
		return uploadFlgAfter;
	}

	public void setUploadFlgAfter(String uploadFlgAfter) {
		this.uploadFlgAfter = uploadFlgAfter;
	}

	public void setUpdUserKey(String updUserKey) {
		this.updUserKey = updUserKey;
	}

	public String getUserKey() {
		return userKey;
	}

	public void setUserKey(String userKey) {
		this.userKey = userKey;
	}

	public String[] getRelUserKey() {
		return relUserKey;
	}

	public void setRelUserKey(String[] relUserKey) {
		this.relUserKey = relUserKey;
	}

	public String[] getRelUserStatusKbn() {
		return relUserStatusKbn;
	}

	public void setRelUserStatusKbn(String[] relUserStatusKbn) {
		this.relUserStatusKbn = relUserStatusKbn;
	}

	public String getUserStatusKbn() {
		return userStatusKbn;
	}

	public void setUserStatusKbn(String userStatusKbn) {
		this.userStatusKbn = userStatusKbn;
	}

	public String getUploadKey() {
		return uploadKey;
	}

	public void setUploadKey(String uploadKey) {
		this.uploadKey = uploadKey;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSearchKeyword() {
		return searchKeyword;
	}

	public void setSearchKeyword(String searchKeyword) {
		this.searchKeyword = searchKeyword;
	}

	public String getThredKey() {
		return thredKey;
	}

	public void setThredKey(String thredKey) {
		this.thredKey = thredKey;
	}

	public String getThredName() {
		return thredName;
	}

	public void setThredName(String thredName) {
		this.thredName = thredName;
	}

	public Timestamp getInsDate() {
		return insDate;
	}

	public void setInsDate(Timestamp insDate) {
		this.insDate = insDate;
	}

	public String getInsUserKey() {
		return insUserKey;
	}

	public void setInsUserKey(String insUserKey) {
		this.insUserKey = insUserKey;
	}

	public int getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(int seqNo) {
		this.seqNo = seqNo;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public Timestamp getContributionUpdDate() {
		return contributionUpdDate;
	}

	public void setContributionUpdDate(Timestamp contributionUpdDate) {
		this.contributionUpdDate = contributionUpdDate;
	}

	public Timestamp getReadDate() {
		return readDate;
	}

	public void setReadDate(Timestamp readDate) {
		this.readDate = readDate;
	}

	public String getFileKbn() {
		return fileKbn;
	}

	public void setFileKbn(String fileKbn) {
		this.fileKbn = fileKbn;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFilePutPath() {
		return filePutPath;
	}

	public void setFilePutPath(String filePutPath) {
		this.filePutPath = filePutPath;
	}

	public List<KjBoardRelUserDto> getSendMailList() {
		return sendMailList;
	}

	public void setSendMailList(List<KjBoardRelUserDto> sendMailList) {
		this.sendMailList = sendMailList;
	}

	public String[] getRelUserName() {
		return relUserName;
	}

	public void setRelUserName(String[] relUserName) {
		this.relUserName = relUserName;
	}

	public String[] getRelAffiliationName() {
		return relAffiliationName;
	}

	public void setRelAffiliationName(String[] relAffiliationName) {
		this.relAffiliationName = relAffiliationName;
	}

	public String[] getRelPartyName() {
		return relPartyName;
	}

	public void setRelPartyName(String[] relPartyName) {
		this.relPartyName = relPartyName;
	}

}
