package jp.co.sraw.repository;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import jp.co.sraw.entity.UsResultUploadTbl;

@Scope("prototype")
@Repository
public interface UsResultUploadTblRepository extends GyRepository<UsResultUploadTbl> {

}
