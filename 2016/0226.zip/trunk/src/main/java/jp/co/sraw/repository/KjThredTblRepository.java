package jp.co.sraw.repository;

import java.sql.Timestamp;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import jp.co.sraw.entity.KjThredTbl;

@Repository
public interface KjThredTblRepository extends JpaRepository<KjThredTbl, String>, JpaSpecificationExecutor<KjThredTbl> {

	@Query(name="KjThredTbl.findThred")
	public KjThredTbl findThred(@Param("thredKey") String thredKey);

	@Modifying
	@Query(name = "KjThredTbl.delete")
	public int delete(@Param("thredKey") String thredKey, @Param("updDate") Timestamp updDate);

}
