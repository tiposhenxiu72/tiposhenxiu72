/*
* ファイル名：UserServiceImpl.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.portfolio.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.sraw.controller.portfolio.form.GyResearchAreaForm;
import jp.co.sraw.entity.GyResearchAreaTbl;
import jp.co.sraw.entity.MsResearchAreaTbl;
import jp.co.sraw.repository.GyResearchAreaTblRepository;
import jp.co.sraw.repository.MsResearchAreaTblRepository;
import jp.co.sraw.service.MsResearchAreaServiceImpl;
import jp.co.sraw.util.StringUtil;

/**
 * <B>ResearchAreaServiceImplクラス</B>
 * <P>
 * ユーザーサービスのメソッドを提供する
 */
@Scope("prototype")
@Service
@Transactional(readOnly = true)
public class ResearchAreaServiceImpl
		extends PortfolioServiceImpl<GyResearchAreaTbl, GyResearchAreaForm, GyResearchAreaTblRepository> {

	@Autowired
	private MsResearchAreaTblRepository msResearchAreaTblRepository;

	@Autowired
	public MsResearchAreaServiceImpl serviceImpl;

	@Override
	public GyResearchAreaTbl getPortfolioTbl(GyResearchAreaForm f, GyResearchAreaTbl t) {
		String summary = getSummaryFORMFormat(f.getSummaryid());
		f.setSummaryName(summary);
		t = super.getPortfolioTbl(f, t);
		t.setSummary(summary);
		return t;
	}

	private String getSummaryFORMFormat(String areaCode) {
		if (StringUtil.isNull(areaCode)) {
			return "";
		}
		MsResearchAreaTbl tbl = msResearchAreaTblRepository.findOne(areaCode);
		if (tbl != null) {
			return tbl.getResearchAreaName();
		}
		return areaCode;
	}

	@Override
	public GyResearchAreaForm getPortfolioForm(GyResearchAreaTbl tbl) {
		if (tbl == null)
			return null;
		//
		GyResearchAreaForm dto = new GyResearchAreaForm();
		dto = (GyResearchAreaForm) objectUtil.getObjectCopyValue(dto, tbl);
		dto.setSummaryName(tbl.getSummary());
		return dto;
	}

	public List<MsResearchAreaTbl> findAllMsResearchArea() {
		return msResearchAreaTblRepository.findAll();
	}

	protected Sort orderBy() {
		// a.細目番号（昇順）
		Sort sort1 = new Sort(Sort.Direction.ASC, "summaryid");
		// a.中分類ID（昇順）
		Sort sort2 = new Sort(Sort.Direction.ASC, "subjectid").and(sort1);
		// a.大分類ID（昇順）
		Sort sort = new Sort(Sort.Direction.ASC, "fieldid").and(sort2);
		return sort;
	}
}
