package jp.co.sraw.file;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellValue;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.FormulaError;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.springframework.stereotype.Service;

import jp.co.sraw.common.CommonForm;
import jp.co.sraw.util.PoiBook;
import jp.co.sraw.util.StringUtil;

@Service
public abstract class AbstractExcelHelper<F extends CommonForm> {

	public static final String DELIMITER = ":";

	public List<F> getFormList(Workbook workbook) {

		Sheet sheet = getSheet(workbook);

		int startRow = 1;

		List<F> list = new ArrayList<>();

		for (int i = startRow; i <= sheet.getLastRowNum(); i++) {
			Row row = sheet.getRow(i);
			if (row != null) {
				list.add(getForm(row));
			}
		}
		return list;
	}

	public abstract Sheet getSheet(Workbook workbook);

	public abstract F getForm(Row row);

	/**
	 * セル取得
	 *
	 * @param row
	 * @param sortNo
	 * @return
	 */
	protected String getCellValue(Row row, int sortNo) {
		return getCellValue(row, sortNo, false);
	}
	/**
	 *
	 *
	 * @param row
	 * @param sortNo
	 * @param formatFlag 数値整形 (YYYYMMDD、YYYYMM、YYYYの場合に使用)
	 * @return
	 */
	protected String getCellValue(Row row, int sortNo, boolean formatFlag) {
		if (row.getCell(sortNo) == null)
			return null;
		int cellType = row.getCell(sortNo).getCellType();
		String result = "";
		switch (cellType) {
		case Cell.CELL_TYPE_BLANK:
			result = getStringRangeValue(row.getCell(sortNo));
			break;
		case Cell.CELL_TYPE_ERROR:
			byte errorCode = row.getCell(sortNo).getErrorCellValue();
			FormulaError error = FormulaError.forInt(errorCode);
			result = error.getString();
			break;
		case Cell.CELL_TYPE_FORMULA:
			result = getStringFormulaValue(row.getCell(sortNo));
			break;
		case Cell.CELL_TYPE_NUMERIC:
			result = getStringValue(row.getCell(sortNo));
			// 数値整形 (YYYYMMDD、YYYYMM、YYYYの場合に使用)
			if (formatFlag && StringUtil.isNotNull(result)) {
				DecimalFormat format = new DecimalFormat("0.#");
				result = format.format(row.getCell(sortNo).getNumericCellValue());
			}
			break;
		case Cell.CELL_TYPE_BOOLEAN:
		case Cell.CELL_TYPE_STRING:
			result = getStringValue(row.getCell(sortNo));
			break;
		default:
			break;
		}
		if (StringUtil.isNotNull(result) && result.contains(DELIMITER))
			result = result.substring(0, result.indexOf(DELIMITER));
		return result;
	}

	protected int getCellIntValue(Row row, int sortNo) {
		if (row.getCell(sortNo) == null)
			return 0;
		int cellType = row.getCell(sortNo).getCellType();
		int result = 0;
		try {
			switch (cellType) {
			case Cell.CELL_TYPE_BLANK:
				result = Integer.parseInt(getStringRangeValue(row.getCell(sortNo)));
				break;
			case Cell.CELL_TYPE_BOOLEAN:
			case Cell.CELL_TYPE_ERROR:
				break;
			case Cell.CELL_TYPE_FORMULA:
				result = Integer.parseInt(getStringFormulaValue(row.getCell(sortNo)));
				break;
			case Cell.CELL_TYPE_NUMERIC:
			case Cell.CELL_TYPE_STRING:
				result = Integer.parseInt(getStringValue(row.getCell(sortNo)));
			default:
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	protected BigDecimal getCellBigDecimal(Row row, int sortNo) {
		if (row.getCell(sortNo) == null)
			return null;
		int cellType = row.getCell(sortNo).getCellType();
		BigDecimal result = new BigDecimal(-1);
		try {
			switch (cellType) {
			case Cell.CELL_TYPE_BLANK:
			case Cell.CELL_TYPE_BOOLEAN:
			case Cell.CELL_TYPE_ERROR:
				break;
			case Cell.CELL_TYPE_FORMULA:
				result = new BigDecimal(getStringFormulaValue(row.getCell(sortNo)));
				break;
			case Cell.CELL_TYPE_NUMERIC:
			case Cell.CELL_TYPE_STRING:
				result = new BigDecimal(getStringValue(row.getCell(sortNo)));
			default:
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public String getDateInfo(Timestamp time) {
		if (time != null) {
			return time.toString();
		}
		return "";
	}

	public void buildExcelDocument(PoiBook workbook, List<F> list) {
		// TODO 自動生成されたメソッド・スタブ

	}

	/**
	 * セルの数式を計算し、Stringとして取得する
	 *
	 * @param cell
	 * @return
	 */
	private String getStringFormulaValue(Cell cell) {
		assert cell.getCellType() == Cell.CELL_TYPE_FORMULA;

		Workbook book = cell.getSheet().getWorkbook();
		CreationHelper helper = book.getCreationHelper();
		FormulaEvaluator evaluator = helper.createFormulaEvaluator();
		CellValue value = evaluator.evaluate(cell);
		switch (value.getCellType()) {
		case Cell.CELL_TYPE_STRING:
			return value.getStringValue();
		case Cell.CELL_TYPE_NUMERIC:
			return Double.toString(value.getNumberValue());
		case Cell.CELL_TYPE_BOOLEAN:
			return Boolean.toString(value.getBooleanValue());
		default:
			return null;
		}
	}

	/**
	 * 結合セルの値をStringとして取得する
	 *
	 * @param cell
	 * @return
	 */
	public String getStringRangeValue(Cell cell) {
		int rowIndex = cell.getRowIndex();
		int columnIndex = cell.getColumnIndex();

		Sheet sheet = cell.getSheet();
		int size = sheet.getNumMergedRegions();
		for (int i = 0; i < size; i++) {
			CellRangeAddress range = sheet.getMergedRegion(i);
			if (range.isInRange(rowIndex, columnIndex)) {
				Cell firstCell = getCell(sheet, range.getFirstRow(), range.getFirstColumn()); // 左上のセルを取得
				return getStringValue(firstCell);
			}
		}
		return null;
	}

	/**
	 * セルの取得
	 *
	 * @param sheet
	 * @param rowIndex
	 * @param columnIndex
	 * @return
	 */
	public Cell getCell(Sheet sheet, int rowIndex, int columnIndex) {
		Row row = sheet.getRow(rowIndex);
		if (row != null) {
			Cell cell = row.getCell(columnIndex);
			return cell;
		}
		return null;
	}

	/**
	 * セルの値をStringとして取得する例
	 *
	 * @param cell
	 * @return
	 */
	public String getStringValue(Cell cell) {
		if (cell == null) {
			return null;
		}
		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_STRING:
			return cell.getStringCellValue();
		case Cell.CELL_TYPE_NUMERIC:
			return Double.toString(cell.getNumericCellValue());
		case Cell.CELL_TYPE_BOOLEAN:
			return Boolean.toString(cell.getBooleanCellValue());
		case Cell.CELL_TYPE_FORMULA:
			return getStringFormulaValue(cell);
		case Cell.CELL_TYPE_BLANK:
			return getStringRangeValue(cell);
		case Cell.CELL_TYPE_ERROR:
			byte errorCode = cell.getErrorCellValue();
			FormulaError error = FormulaError.forInt(errorCode);
			return error.getString();
		default:
			return null;
		}
	}


}
