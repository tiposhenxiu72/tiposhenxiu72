/*
* ファイル名：BoardJsonForm.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/01/21   mizoguchi      新規作成
*/
package jp.co.sraw.controller.board;

import jp.co.sraw.common.CommonForm;

/**
 * <B>BoardFormクラス</B>
 * <P>
 * Formのメソッドを提供する
 */
public class BoardJsonForm extends CommonForm {

	private String party;

	private String affiliation;

	private String name;

	public String getParty() {
		return party;
	}

	public void setParty(String party) {
		this.party = party;
	}

	public String getAffiliation() {
		return affiliation;
	}

	public void setAffiliation(String affiliation) {
		this.affiliation = affiliation;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


}
