/*
* ファイル名：InformationExtractionBatch.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/02/01   toishigawa  新規作成
*/
package jp.co.sraw.batch;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.service.BatchTargetService;
import jp.co.sraw.util.StringUtil;

/**
* <B>InformationExtractionBatchクラス</B>
* <P>
* 処理対象データ抽出
*/
@Component
public class InformationExtractionBatch implements BatchRunner {
	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(InformationExtractionBatch.class);

	@Autowired
	private BatchTargetService batchTargetService;// batch処理のサービス

	@Override
	public boolean run(Map<String, String> parameters) throws Exception {

		// 引数：対象日(YYYYMMDD形式)
		String targetDay = parameters.get("targetday");

		// 引数：調整日数
		String adjustmentDays = parameters.get("adjustmentdays");
		int adjustment = 0;

		// 引数不正
		if (StringUtil.isNull(targetDay) || StringUtil.isNull(adjustmentDays)) {
			return false;
		}
		try {
			adjustment = Integer.parseInt(adjustmentDays);
		} catch (Exception e) {
			// 引数不正
			return false;
		}

		// バッチ処理用抽出データの編集
		// 支援制度からの情報抽出
		Boolean supportFlag = batchTargetService.updateSupportBatchTarget(targetDay);
		// イベントからの情報抽出
		Boolean eventFlag = batchTargetService.updateEventBatchTarget(targetDay);
		// インターンシップからの情報抽出
		Boolean internshipFlag = batchTargetService.updateInternshipBatchTarget(targetDay, adjustment);

		// すべてupdate成功なら、trueを戻す
		if (supportFlag && eventFlag && internshipFlag) {
			return true;
		}
		return false;
	}
}
