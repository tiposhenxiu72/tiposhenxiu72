package jp.co.sraw.entity;

import java.io.Serializable;

import javax.persistence.MappedSuperclass;

@MappedSuperclass
public class ViewTbl implements Serializable {
}
