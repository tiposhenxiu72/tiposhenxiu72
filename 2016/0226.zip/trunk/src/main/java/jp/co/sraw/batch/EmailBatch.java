package jp.co.sraw.batch;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.service.BatchTargetService;

@Component
public class EmailBatch implements BatchRunner {
	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(EmailBatch.class);

	@Autowired
	private BatchTargetService batchTargetService;

	public boolean run(Map<String, String> parameters) throws Exception {

		// eメール送信
		// 支援制度からの情報抽出
		Boolean supportFlag = batchTargetService.updateSupportBatchMail();
		// イベントからの情報抽出
		Boolean eventFlag = batchTargetService.updateEventBatchMail();
		// インターンシップからの情報抽出
		Boolean internshipFlag = batchTargetService.updateInternshipBatchMail();

		// すべてupdate成功なら、trueを戻す
		if (supportFlag && eventFlag && internshipFlag) {
			return true;
		}
		return false;
	}
}
