package jp.co.sraw.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import jp.co.sraw.entity.NrAchievementReportBkupTbl;
import jp.co.sraw.entity.NrAchievementReportBkupTblPK;

@Scope("prototype")
@Repository
public interface NrAchievementReportBkupTblRepository
		extends JpaRepository<NrAchievementReportBkupTbl, NrAchievementReportBkupTblPK>,
		JpaSpecificationExecutor<NrAchievementReportBkupTbl> {

	@Modifying
	@Query(name = "NrAchievementReportBkupTbl.backup")
	public int backup(@Param("savedDate") Date savedDate);

	public List<NrAchievementReportBkupTbl> findByIdUserKeyOrderByUpdDateDesc(String userKey);
	public NrAchievementReportBkupTbl findByIdUserKeyAndIdSaveDate(String userKey, Date savedDate);
}
