package jp.co.sraw.controller.portfolio.excel;

import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Service;

import jp.co.sraw.common.CommonForm;
import jp.co.sraw.controller.portfolio.form.GyDegreeForm;
import jp.co.sraw.util.PoiBook;

@Service
public class DegreeExcelHelper extends PortfolioExcelHelper<GyDegreeForm> {

	public DegreeExcelHelper() {
		this.DATA_SHEET_NAME = "DEGREE";
	}

	@Override
	public void buildExcelDocument(PoiBook workbook, List<GyDegreeForm> list) {
		workbook.activeSheet = workbook.book.getSheet(DATA_SHEET_NAME);

		for (int i = 0; i < list.size(); i++) {
			GyDegreeForm form = list.get(i);
			form.setViewType(CommonForm.VIEW_TYPE_EXCEL);
			int rowno = i + 1;
			// 言語区分
			// workbook.changeValue(rowno, 0, form.getLanguage());
			// 学位名
			workbook.changeValue(rowno, 0, form.getDegreename());
			// 学位・授与機関
			workbook.changeValue(rowno, 1, form.getOrganization());
			// 公開範囲
			workbook.changeValue(rowno, 2, form.getPublicFlag());
		}
	}

	@Override
	public Sheet getSheet(Workbook workbook) {
		return workbook.getSheet(DATA_SHEET_NAME);
	}

	@Override
	public GyDegreeForm getForm(Row row) {
		GyDegreeForm form = new GyDegreeForm();

		// 言語区分
		// form.setLanguage(getCellValue(row, 0));
		// 学位名
		form.setDegreename(getCellValue(row, 0));
		// 学位・授与機関
		form.setOrganization(getCellValue(row, 1));
		// 公開範囲
		form.setPublicFlag(getCellValue(row, 2));

		return form;
	}

}