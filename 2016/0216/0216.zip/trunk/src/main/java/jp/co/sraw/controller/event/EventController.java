/*
* ファイル名：IndexController.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.event;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.annotation.PostConstruct;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import jp.co.sraw.common.CommonController;
import jp.co.sraw.dto.EvEventViewDto;
import jp.co.sraw.dto.EventDto;
import jp.co.sraw.entity.EvEventTbl;
import jp.co.sraw.entity.EvEventUploadTbl;
import jp.co.sraw.file.FileService;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.service.EventServiceImpl;
import jp.co.sraw.util.StringUtil;

/**
 * <B>EventControllerクラス</B>
 * <P>
 * Controllerのメソッドを提供する
 */
@Controller
@RequestMapping("/event")
public class EventController extends CommonController {

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(EventController.class);

	private static final int BUFFER_SIZE = 4096;

	@PostConstruct
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	@Autowired
	private EventServiceImpl eventServiceImpl;

	private static final String LIST_PAGE = "event/list";

	private static final String FORM_NAME = "form";

	@Autowired
	private FileService fileService;

	List<EventDto> slist = new ArrayList<>();

	/**
	 *
	 *
	 * @param name
	 * @param model
	 * @return
	 */
	@RequestMapping({ "", "/", "/list" })
	public String list(@ModelAttribute(FORM_NAME) final EventForm form, Model model, Locale locale) {

		logger.infoCode("I0001");

		List<EvEventViewDto> eventPresentList = new ArrayList<>();

		eventPresentList = eventServiceImpl.findAllEventViewDto(userInfo, locale);

		model.addAttribute("eventPresentList", eventPresentList);

		if (logger.isDebugEnabled()) {
			logger.debug("LoginUserKey=" + userInfo.getLoginUserKey());
			logger.debug("TargetUserKey=" + userInfo.getTargetUserKey());
		}

		// dump
		modelDump(logger, model, "index");

		return LIST_PAGE;
	}

	@RequestMapping({ "/download" })
	public void download(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute(FORM_NAME) final EventForm form) throws Exception {

		ServletContext context = request.getServletContext();
		String appPath = context.getRealPath("");
		System.out.println("appPath = " + appPath);

		EvEventTbl eventTbl = eventServiceImpl.getOne(form.getEventKey());

		List<EvEventUploadTbl> uploadTabList = eventTbl.getEvEventUploadTbls();

		List<String> downloadList = new ArrayList<>();
		for (EvEventUploadTbl tbl : uploadTabList) {
			downloadList.add(tbl.getId().getUploadKey());
		}

		String downloadFilePath = fileService.getFileWithZip(userInfo.getLoginUserKey(), downloadList);

		if (StringUtil.isNull(downloadFilePath)) {
			return;
		}

		File downloadFile = new File(downloadFilePath);
		FileInputStream inputStream = new FileInputStream(downloadFile);

		String mimeType = context.getMimeType("application/zip");
		if (mimeType == null) {
			mimeType = "application/octet-stream";
		}
		System.out.println("MIME type: " + mimeType);

		response.setContentType(mimeType);
		response.setContentLength((int) downloadFile.length());

		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"", eventTbl.getEventTitle() + ".zip");
		response.setHeader(headerKey, headerValue);

		// get output stream of the response
		OutputStream outStream = response.getOutputStream();

		byte[] buffer = new byte[BUFFER_SIZE];
		int bytesRead = -1;

		while ((bytesRead = inputStream.read(buffer)) != -1) {
			outStream.write(buffer, 0, bytesRead);
		}

		inputStream.close();
		outStream.close();

	}
}
