/*
* ファイル名：AccountForm.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/01/25   toishigawa  新規作成
*/
package jp.co.sraw.controller.account;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;
import org.maru.m4hv.extensions.constraints.CharLength;
import org.maru.m4hv.extensions.constraints.Katakana;

import jp.co.sraw.common.CommonForm;
import jp.co.sraw.util.StringUtil;
import jp.co.sraw.validation.AlphaNumberSymbol;


/**
* <B>AccountFormクラス</B>
* <P>
* AccountFormのメソッドを提供する
*/
public class AccountForm extends CommonForm {

	//グループの定義
	public interface Group01 {} // アカウント登録(メールアドレスのみ)
	public interface Group02 {} // アカウント本登録(学認:パスワード無し)
	public interface Group03 {} // アカウント本登録(DB認証:パスワード有り)

	private String requestId; //申請ID
	private String gakuninChkFlag; //学認認証済み(1:認証済み)

	// 学認
	private boolean gakuninFlag;
	private String gakuninEntityId;
	private String gakuninSAML1SSOurl;

	// 参考URL: https://meatwiki.nii.ac.jp/confluence/display/GakuNinShibInstall/Embedded+DS
	//          https://ds.gakunin.nii.ac.jp/WAYF/embedded-wayf.js
	private String wayfSpEntityID;   //"Embedded DSを利用するSPのentityID"
	private String wayfSpHandlerURL; // "Embedded DSを利用するSPのハンドラURL" 例: https://sp.example.ac.jp/Shibboleth.sso
	private String wayfReturnUrl;    // "Embedded DSを利用するSPで認証後に戻るURL"


	//入力
	@NotBlank(groups = {Group01.class, Group02.class, Group03.class})
	@Email(groups = {Group01.class, Group02.class, Group03.class})
	private String mailAddress; //E-Mailアドレス

	@NotBlank(groups = {Group03.class})
	@CharLength(min=1, max=50, groups = {Group03.class})
	private String password; //パスワード

	@NotBlank(groups = {Group02.class, Group03.class})
	private String userKbn; // ユーザ区分

	@NotBlank(groups = {Group02.class, Group03.class})
	@CharLength(max=100, groups = {Group02.class, Group03.class})
	private String userFamilyName; // 利用者姓(原語)

	@NotBlank(groups = {Group02.class, Group03.class})
	@CharLength(max=100, groups = {Group02.class, Group03.class})
	@Katakana(enableSpace = true, groups = {Group02.class, Group03.class})
	private String userFamilyNameKn; // 利用者姓(カナ)

	@NotBlank(groups = {Group02.class, Group03.class})
	@CharLength(max=100, groups = {Group02.class, Group03.class})
	@AlphaNumberSymbol(groups = {Group02.class, Group03.class})
	private String userFamilyNameEn; // 利用者姓(英訳)

	@NotNull(groups = {Group02.class, Group03.class})
	@CharLength(max=100, groups = {Group02.class, Group03.class})
	private String userMiddleName; // 利用者ミドルネーム(原語)

	@NotNull(groups = {Group02.class, Group03.class})
	@CharLength(max=100, groups = {Group02.class, Group03.class})
	@Katakana(enableSpace = true, groups = {Group02.class, Group03.class})
	private String userMiddleNameKn; // 利用者ミドルネーム(カナ)

	@NotNull(groups = {Group02.class, Group03.class})
	@CharLength(max=100, groups = {Group02.class, Group03.class})
	@AlphaNumberSymbol(groups = {Group02.class, Group03.class})
	private String userMiddleNameEn; // 利用者ミドルネーム(英訳)

	@NotBlank(groups = {Group02.class, Group03.class})
	@CharLength(max=100, groups = {Group02.class, Group03.class})
	private String userName; // 利用者名(原語)

	@NotBlank(groups = {Group02.class, Group03.class})
	@CharLength(max=100, groups = {Group02.class, Group03.class})
	@Katakana(enableSpace = true, groups = {Group02.class, Group03.class})
	private String userNameKn; // 利用者名(カナ)

	@NotBlank(groups = {Group02.class, Group03.class})
	@CharLength(max=100, groups = {Group02.class, Group03.class})
	@AlphaNumberSymbol(groups = {Group02.class, Group03.class})
	private String userNameEn; // 利用者名(英訳)

	@NotBlank(groups = {Group02.class, Group03.class})
	private String sex; // 性別

	@CharLength(max=100, groups = {Group02.class, Group03.class})
	private String researchSubject; // 研究科

	@NotBlank(groups = {Group02.class, Group03.class})
	private String degree; // 学年・職位

	private String researchArea; // 研究分野

	@CharLength(max=100, groups = {Group02.class, Group03.class})
	private String studentId; // 学籍ID／職員ID

	@NotBlank(groups = {Group02.class, Group03.class})
	private String partyCode; // 組織コード

	private String userPublicFlag; // ユーザ公開フラグ

	//private String affiliationName; // 所属名称

	private String country; // 国籍／生誕国

	private String teacherName; // 指導教員

	private String mailSetting; // メール受信設定


	/**
	 * 氏名
	 *
	 * @return
	 */
	public String getUserFullName() {
		return StringUtil.getUserName(this.userKbn, this.userFamilyName, this.userMiddleName, this.userName);
	}

	/**
	 * 氏名(カタカナ)
	 *
	 * @return
	 */
	public String getUserFullNameKn() {
		return StringUtil.getUserName(this.userKbn, this.userFamilyNameKn, this.userMiddleNameKn, this.userNameKn);
	}

	/**
	 * 氏名(英字)
	 *
	 * @return
	 */
	public String getUserFullNameEn() {
		return StringUtil.getUserNameEn(this.userKbn, this.userFamilyNameEn, this.userMiddleNameEn, this.userNameEn);
	}

	/**
	 * @return mailAddress
	 */
	public String getMailAddress() {
		return mailAddress;
	}

	/**
	 * @param mailAddress セットする mailAddress
	 */
	public void setMailAddress(String mailAddress) {
		this.mailAddress = mailAddress;
	}

	/**
	 * @return password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password セットする password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return userPublicFlag
	 */
	public String getUserPublicFlag() {
		return userPublicFlag;
	}

	/**
	 * @param userPublicFlag セットする userPublicFlag
	 */
	public void setUserPublicFlag(String userPublicFlag) {
		this.userPublicFlag = userPublicFlag;
	}

	/**
	 * @return userKbn
	 */
	public String getUserKbn() {
		return userKbn;
	}

	/**
	 * @param userKbn セットする userKbn
	 */
	public void setUserKbn(String userKbn) {
		this.userKbn = userKbn;
	}

	/**
	 * @return userFamilyName
	 */
	public String getUserFamilyName() {
		return userFamilyName;
	}

	/**
	 * @param userFamilyName セットする userFamilyName
	 */
	public void setUserFamilyName(String userFamilyName) {
		this.userFamilyName = userFamilyName;
	}

	/**
	 * @return userFamilyNameKn
	 */
	public String getUserFamilyNameKn() {
		return userFamilyNameKn;
	}

	/**
	 * @param userFamilyNameKn セットする userFamilyNameKn
	 */
	public void setUserFamilyNameKn(String userFamilyNameKn) {
		this.userFamilyNameKn = userFamilyNameKn;
	}

	/**
	 * @return userFamilyNameEn
	 */
	public String getUserFamilyNameEn() {
		return userFamilyNameEn;
	}

	/**
	 * @param userFamilyNameEn セットする userFamilyNameEn
	 */
	public void setUserFamilyNameEn(String userFamilyNameEn) {
		this.userFamilyNameEn = userFamilyNameEn;
	}

	/**
	 * @return userMiddleName
	 */
	public String getUserMiddleName() {
		return userMiddleName;
	}

	/**
	 * @param userMiddleName セットする userMiddleName
	 */
	public void setUserMiddleName(String userMiddleName) {
		this.userMiddleName = userMiddleName;
	}

	/**
	 * @return userMiddleNameKn
	 */
	public String getUserMiddleNameKn() {
		return userMiddleNameKn;
	}

	/**
	 * @param userMiddleNameKn セットする userMiddleNameKn
	 */
	public void setUserMiddleNameKn(String userMiddleNameKn) {
		this.userMiddleNameKn = userMiddleNameKn;
	}

	/**
	 * @return userMiddleNameEn
	 */
	public String getUserMiddleNameEn() {
		return userMiddleNameEn;
	}

	/**
	 * @param userMiddleNameEn セットする userMiddleNameEn
	 */
	public void setUserMiddleNameEn(String userMiddleNameEn) {
		this.userMiddleNameEn = userMiddleNameEn;
	}

	/**
	 * @return userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName セットする userName
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return userNameKn
	 */
	public String getUserNameKn() {
		return userNameKn;
	}

	/**
	 * @param userNameKn セットする userNameKn
	 */
	public void setUserNameKn(String userNameKn) {
		this.userNameKn = userNameKn;
	}

	/**
	 * @return userNameEn
	 */
	public String getUserNameEn() {
		return userNameEn;
	}

	/**
	 * @param userNameEn セットする userNameEn
	 */
	public void setUserNameEn(String userNameEn) {
		this.userNameEn = userNameEn;
	}

	/**
	 * @return sex
	 */
	public String getSex() {
		return sex;
	}

	/**
	 * @param sex セットする sex
	 */
	public void setSex(String sex) {
		this.sex = sex;
	}

	/**
	 * @return country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country セットする country
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return researchSubject
	 */
	public String getResearchSubject() {
		return researchSubject;
	}

	/**
	 * @param researchSubject セットする researchSubject
	 */
	public void setResearchSubject(String researchSubject) {
		this.researchSubject = researchSubject;
	}

	/**
	 * @return degree
	 */
	public String getDegree() {
		return degree;
	}

	/**
	 * @param degree セットする degree
	 */
	public void setDegree(String degree) {
		this.degree = degree;
	}

	/**
	 * @return researchArea
	 */
	public String getResearchArea() {
		return researchArea;
	}

	/**
	 * @param researchArea セットする researchArea
	 */
	public void setResearchArea(String researchArea) {
		this.researchArea = researchArea;
	}

	/**
	 * @return studentId
	 */
	public String getStudentId() {
		return studentId;
	}

	/**
	 * @param studentId セットする studentId
	 */
	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	/**
	 * @return teacherName
	 */
	public String getTeacherName() {
		return teacherName;
	}

	/**
	 * @param teacherName セットする teacherName
	 */
	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

	/**
	 * @return partyCode
	 */
	public String getPartyCode() {
		return partyCode;
	}

	/**
	 * @param partyCode セットする partyCode
	 */
	public void setPartyCode(String partyCode) {
		this.partyCode = partyCode;
	}

	/**
	 * @return mailSetting
	 */
	public String getMailSetting() {
		return mailSetting;
	}

	/**
	 * @param mailSetting セットする mailSetting
	 */
	public void setMailSetting(String mailSetting) {
		this.mailSetting = mailSetting;
	}

	/**
	 * @return gakuninFlag
	 */
	public boolean isGakuninFlag() {
		return gakuninFlag;
	}

	/**
	 * @param gakuninFlag セットする gakuninFlag
	 */
	public void setGakuninFlag(boolean gakuninFlag) {
		this.gakuninFlag = gakuninFlag;
	}

	/**
	 * @return gakuninEntityId
	 */
	public String getGakuninEntityId() {
		return gakuninEntityId;
	}

	/**
	 * @param gakuninEntityId セットする gakuninEntityId
	 */
	public void setGakuninEntityId(String gakuninEntityId) {
		this.gakuninEntityId = gakuninEntityId;
	}

	/**
	 * @return gakuninSAML1SSOurl
	 */
	public String getGakuninSAML1SSOurl() {
		return gakuninSAML1SSOurl;
	}

	/**
	 * @param gakuninSAML1SSOurl セットする gakuninSAML1SSOurl
	 */
	public void setGakuninSAML1SSOurl(String gakuninSAML1SSOurl) {
		this.gakuninSAML1SSOurl = gakuninSAML1SSOurl;
	}

	/**
	 * @return wayfSpEntityID
	 */
	public String getWayfSpEntityID() {
		return wayfSpEntityID;
	}

	/**
	 * @param wayfSpEntityID セットする wayfSpEntityID
	 */
	public void setWayfSpEntityID(String wayfSpEntityID) {
		this.wayfSpEntityID = wayfSpEntityID;
	}

	/**
	 * @return wayfSpHandlerURL
	 */
	public String getWayfSpHandlerURL() {
		return wayfSpHandlerURL;
	}

	/**
	 * @param wayfSpHandlerURL セットする wayfSpHandlerURL
	 */
	public void setWayfSpHandlerURL(String wayfSpHandlerURL) {
		this.wayfSpHandlerURL = wayfSpHandlerURL;
	}

	/**
	 * @return wayfReturnUrl
	 */
	public String getWayfReturnUrl() {
		return wayfReturnUrl;
	}

	/**
	 * @param wayfReturnUrl セットする wayfReturnUrl
	 */
	public void setWayfReturnUrl(String wayfReturnUrl) {
		this.wayfReturnUrl = wayfReturnUrl;
	}

	/**
	 * @return requestId
	 */
	public String getRequestId() {
		return requestId;
	}

	/**
	 * @param requestId セットする requestId
	 */
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	/**
	 * @return gakuninChkFlag
	 */
	public String getGakuninChkFlag() {
		return gakuninChkFlag;
	}

	/**
	 * @param gakuninChkFlag セットする gakuninChkFlag
	 */
	public void setGakuninChkFlag(String gakuninChkFlag) {
		this.gakuninChkFlag = gakuninChkFlag;
	}

}
