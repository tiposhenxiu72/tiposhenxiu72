/*
* ファイル名：UserServiceImpl.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.portfolio.service;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.sraw.controller.portfolio.form.CompetitionUploadForm;
import jp.co.sraw.entity.UsCompetitionTbl;
import jp.co.sraw.entity.UsPrmovieUploadTbl;
import jp.co.sraw.file.FileDto;
import jp.co.sraw.file.FileService;
import jp.co.sraw.repository.UsCompetitionTblRepository;
import jp.co.sraw.repository.UsPrmovieUploadTblRepository;

/**
 * <B>CompetitionUploadServiceImplクラス</B>
 * <P>
 * ユーザーサービスのメソッドを提供する
 */
@Service
@Transactional(readOnly = true)
public class CompetitionUploadServiceImpl
		extends MultiHandleServiceImpl<UsCompetitionTbl, CompetitionUploadForm, UsCompetitionTblRepository> {

	@Autowired
	private FileService fileService;

	@Autowired
	private UsPrmovieUploadTblRepository usPrmovieUploadTblRepository;

	@Override
	public CompetitionUploadForm getPortfolioForm(UsCompetitionTbl tbl) {
		if (tbl == null)
			return null;
		//
		CompetitionUploadForm dto = new CompetitionUploadForm();
		dto = (CompetitionUploadForm) objectUtil.getObjectCopyValue(dto, tbl);
		if (dto.getInsKbn().equals("1")) {
			FileDto fileDto = fileService.getFileUploalDto(dto.getUploadKey());
			if (fileDto != null) {
				dto.setFileName(fileDto.getUploadName());
			}
		} else {
			dto.setFileName(dto.getLink());
		}
		return dto;
	}

	protected Sort orderBy() {
		// 登録日（降順）
		return new Sort(Sort.Direction.DESC, "insDate");
	}

	public List<FileDto> findAll(String userKey, String[] publicFlags) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		//
		Specification<UsPrmovieUploadTbl> whereUserKey = new Specification<UsPrmovieUploadTbl>() {
			@Override
			public Predicate toPredicate(Root<UsPrmovieUploadTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.get("usUserTbl").get("userKey"), userKey);
			}
		};

		// 取得条件：
		Specification<UsPrmovieUploadTbl> wherePublicFlags = publicFlags == null ? null
				: new Specification<UsPrmovieUploadTbl>() {
					@Override
					public Predicate toPredicate(Root<UsPrmovieUploadTbl> root, CriteriaQuery<?> query,
							CriteriaBuilder cb) {
						Predicate predicate = cb.conjunction();
						for (int i = 0; i < publicFlags.length; i++) {
							String keyword = publicFlags[i];
							if (i == 0) {
								predicate = cb.and(predicate, cb.equal(root.get("publicFlag"), keyword));
							} else {
								predicate = cb.or(predicate, cb.equal(root.get("publicFlag"), keyword));
							}
						}
						return predicate;
					}
				};

		List<UsPrmovieUploadTbl> list = (List<UsPrmovieUploadTbl>) usPrmovieUploadTblRepository
				.findAll((Specification<UsPrmovieUploadTbl>) Specifications.where(whereUserKey).and(wherePublicFlags));

		List<FileDto> fileList = new ArrayList<>();
		for (UsPrmovieUploadTbl tbl : list) {
			FileDto dto = fileService.getFileUploalDto(tbl.getId().getUploadKey());
			fileList.add(dto);
		}

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return fileList;
	}
}
