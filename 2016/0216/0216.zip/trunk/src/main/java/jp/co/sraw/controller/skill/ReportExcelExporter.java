package jp.co.sraw.controller.skill;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.poi.hssf.usermodel.HSSFShapeGroup;
import org.apache.poi.hssf.util.HSSFColor;

import jp.co.sraw.dto.SkillAnswerStatsDto;
import jp.co.sraw.dto.SkillLessonTakenDto;
import jp.co.sraw.dto.SkillReportDto;
import jp.co.sraw.entity.NrAchievementReportBkupTbl;
import jp.co.sraw.entity.NrAchievementReportTbl;
import jp.co.sraw.oxm.rubric.Rubric;
import jp.co.sraw.oxm.rubric.RubricCategory;
import jp.co.sraw.util.DateUtil;
import jp.co.sraw.util.PoiBook;

/**
 * 自己評価レポートをExcelへエクスポートする。
 *
 *
 */
public class ReportExcelExporter {
	private static final String SHNAME_TOP = "自己評価レポート";
	private static final String SHNAME_BOTTOM = "養成能力と目標";
	private static final String CAPTION_PIECHART = "RDFグラフィック";
	private static final String FORMAT_SAVEDDATE = "yyyy年M月";
	private static final String FORMAT_ACHIEVEMENT = "%d項目中 %d項目達成";
	private static final String FORMAT_NUMLESSONS = "全%d件";
	private static final String NA = "-";
	private static final String DONE = "達成済";
	private static final String NOTYET = "未達成";
	private static final String EOL = "\r\n";

	private static final int LEVEL_CAT = 0;
	private static final int LEVEL_SUBCAT = 1;
	private static final int LEVEL_ITEM = 2;
	private static final int[] ALL_LEVELS = { LEVEL_CAT, LEVEL_SUBCAT, LEVEL_ITEM };
	private static final int[][] RGB_CATS = { { 157, 220, 249, HSSFColor.AQUA.index },
			{ 186, 201, 231, HSSFColor.PINK.index }, { 165, 212, 218, HSSFColor.DARK_TEAL.index },
			{ 211, 191, 221, HSSFColor.LAVENDER.index } };
	private static final int[] RGB_DONE = { 255, 0, 0, HSSFColor.RED.index };
	private static final int[] RGB_NOTYET = { 0, 176, 80, HSSFColor.DARK_GREEN.index };
	private static final int[][] RGB_MAX = { { 58, 187, 242 }, { 107, 139, 203 }, { 93, 177, 187 }, { 163, 122, 183 } };
	private static final int[][] RGB_MIN = { { 231, 247, 254 }, { 237, 241, 249 }, { 235, 246, 247 },
			{ 244, 239, 246 } };
	private static final int[] RGB_WHITE = { 255, 255, 255 };

	// コンフィグ情報。
	// int[2]は、{row, col}の意味。
	// int[3]は、level=0～2。
	private static final int[] SAVED_DATE = { 2, 1 };
	private static final int[][] USER_NAME = { { 1, 6 }, { 1, 5 }, { 1, 5 } };
	private static final int[] LENS_NAME = { 6, 1 };
	private static final int[] ACHIEVEMENT = { 8, 2 };
	private static final int[] WHOLE_TARGET = { 11, 0 };
	private static final int[] ANNUAL_TARGET = { 14, 0 };
	private static final int[] PIECHART_CAPTION = { 16, 0 };
	private static final int RTABLE_TOP = 39;
	private static final int CTABLE = 0;
	private static final int[] COFF_NUMLESSONS = { 4, 6, 10 }; // levelにより値が違う。
	private static final int[] NUM_ROWS = { 10, 30, 100 };
	private static final short HEIGHT_ITEM = 27;
	private static final int ROFF_REVIEW_BODY = 2;
	private static final int NUM_ROWS_REVIEW = 4;
	private static final short HEIGHT_REVIEW = 70;

	private PoiBook book;

	private class FreeVar { // 自由変数用のコンテナ。
		public int val = 0;

		public FreeVar(int val) {
			this.val = val;
		}
	}

	public ReportExcelExporter(PoiBook book) {
		this.book = book;
	}

	/**
	 * エクスポートする。
	 */
	public void export(Integer level, SkillReportDto dto, SkillAnswerStatsDto stats) {
		prepareTopSheet(level);
		preparePalette();
		exportTop(level, dto, stats);

		book.selectSheet(SHNAME_BOTTOM);
		exportBottom(dto.getRubricAll());

		book.selectSheet(levelToSheetName(level));
	}

	private void exportTop(Integer level, SkillReportDto dto, SkillAnswerStatsDto stats) {
		exportSavedDate(stats.getSavedDate());
		exportUserInfo(dto, level);
		exportLensName(dto);
		exportAchievement(dto, stats);
		exportTarget(dto, stats);
		exportPieChart(dto);
		exportTable(level, dto, stats);
	}

	private void exportBottom(Rubric rub) {
		FreeVar roff = new FreeVar(0);
		IntStream.range(0, rub.getCategoryList().size()).forEach(catIx -> {
			RubricCategory cat = rub.getCategoryList().get(catIx);
			int numItemsInCat = cat.getChildList().stream().map(sc -> sc.getChildList().size()).reduce(0, Integer::sum);
			exportCaption(roff.val, 0, cat, catIx, numItemsInCat);

			IntStream.range(0, cat.getChildList().size()).forEach(subcIx -> {
				RubricCategory subc = cat.getChildList().get(subcIx);
				exportCaption(roff.val, 1, subc, catIx, subc.getChildList().size());

				IntStream.range(0, subc.getChildList().size()).forEach(itemIx -> {
					RubricCategory item = subc.getChildList().get(itemIx);
					exportCaption(roff.val, 2, item, catIx, 0);
					book.changeValue(RTABLE_TOP + roff.val, CTABLE + 3, item.getSummary());
					book.setRowHeight(RTABLE_TOP + roff.val, HEIGHT_ITEM);

					roff.val = roff.val + 1;
				});
			});
		});

		deleteUnusedRows(RTABLE_TOP + roff.val, NUM_ROWS[LEVEL_ITEM]);
	}

	private void exportSavedDate(Date savedDate) {
		savedDate = savedDate == null ? new Date() : savedDate;
		book.changeValue(SAVED_DATE[0], SAVED_DATE[1], DateUtil.dateTimeFormat(savedDate, FORMAT_SAVEDDATE));
	}

	private void exportUserInfo(SkillReportDto dto, int level) {
		int[] rc = USER_NAME[level];
		book.changeValue(rc[0], rc[1], dto.getUserName());
		book.changeValue(rc[0] + 1, rc[1], dto.getDegreeName());
		book.changeValue(rc[0] + 2, rc[1], dto.getPartyName());
		book.changeValue(rc[0] + 3, rc[1], dto.getMajorName());
	}

	private void exportLensName(SkillReportDto dto) {
		book.changeValue(LENS_NAME[0], LENS_NAME[1], dto.getLensName());
	}

	private void exportAchievement(SkillReportDto dto, SkillAnswerStatsDto stats) {
		if (dto.isCanEditDone()) {
			book.changeValue(ACHIEVEMENT[0], ACHIEVEMENT[1], String.valueOf(stats.getRatio()) + "%");
			book.changeValue(ACHIEVEMENT[0], ACHIEVEMENT[1] + 1,
					String.format(FORMAT_ACHIEVEMENT, stats.getDenom(), stats.getNume()));
		} else {
			book.deleteRows(ACHIEVEMENT[0], ACHIEVEMENT[0] + 1, 0);
		}
	}

	private void exportTarget(SkillReportDto dto, SkillAnswerStatsDto stats) {
		String whole;
		String annual;
		if (stats.getSavedDate() == null) { // 最新?
			NrAchievementReportTbl repo = dto.getReport();
			whole = repo == null ? "" : repo.getAllAchievement();
			annual = repo == null ? "" : repo.getYearlyAchievement();
		} else { // 過去。
			NrAchievementReportBkupTbl repo = dto.getSavedReport();
			whole = repo == null ? "" : repo.getAllAchievement();
			annual = repo == null ? "" : repo.getYearlyAchievement();
		}
		book.changeValue(WHOLE_TARGET[0], WHOLE_TARGET[1], whole);
		book.changeValue(ANNUAL_TARGET[0], ANNUAL_TARGET[1], annual);
	}

	private void exportPieChart(SkillReportDto dto) {
		if (!dto.isCanEditDone()) {
			book.changeValue(PIECHART_CAPTION[0], PIECHART_CAPTION[1], CAPTION_PIECHART);
		}

		List<HSSFShapeGroup> sgs = book.topLevelShapeGroup();
		sgs.forEach(sg -> {
			if (sg.getChildren().size() == 4) { // cat?
				sg.forEach(pie -> {
					int angle = normalizeAngle(pie.getRotationDegree());
					int catIx = catIxFromAngle(angle);
					int[] rgb = calcRGB(catIx, dto.getAnswers().get(catIx), dto.isCanEditDone());
					pie.setFillColor(rgb[0], rgb[1], rgb[2]);
				});
			} else if (sg.getChildren().size() == 12) { // sub cat?
				sg.forEach(pie -> {
					int angle = normalizeAngle(pie.getRotationDegree());
					int catIx = catIxFromAngle(angle);
					int subcIx = subcIxFromAngle(angle);
					int[] rgb = calcRGB(catIx, dto.getAnswers().get(catIx).getChildList().get(subcIx),
							dto.isCanEditDone());
					pie.setFillColor(rgb[0], rgb[1], rgb[2]);
				});
			} else {
			}
		});
	}

	private int[] calcRGB(int catIx, AnswerForm ans, boolean canEditDone) {
		int[] max = RGB_MAX[catIx];
		int[] min = RGB_MIN[catIx];
		double[] delta = { ((double) min[0] - max[0]) / 4, ((double) min[1] - max[1]) / 4,
				((double) min[2] - max[2]) / 4 };

		long lv = canEditDone ? ans.getAchievementLevel() : 50;
		if (lv == 0) {
			return RGB_WHITE;
		} else if (lv < 25) {
			return min;
		} else if (lv < 50) {
			return new int[] { min[0] - ((int) delta[0]), min[1] - ((int) delta[1]), min[2] - ((int) delta[2]) };
		} else if (lv < 75) {
			return new int[] { min[0] - ((int) delta[0] * 2), min[1] - ((int) delta[1] * 2),
					min[2] - ((int) delta[2] * 2) };
		} else if (lv < 100) {
			return new int[] { min[0] - ((int) delta[0] * 3), min[1] - ((int) delta[1] * 3),
					min[2] - ((int) delta[2] * 3) };
		}
		return max;
	}

	private int normalizeAngle(int angle) {
		while (angle < 0) {
			angle += 360;
		}
		while (angle >= 360) {
			angle -= 360;
		}
		return angle;
	}

	private int catIxFromAngle(int angle) {
		angle = normalizeAngle(angle);
		return angle / 90;
	}

	private int subcIxFromAngle(int angle) {
		angle = normalizeAngle(angle);
		// 左側は逆順。
		if (angle >= 180) {
			return (89 - (angle % 90)) / 30;
		}
		return angle % 90 / 30;
	}

	private void exportTable(Integer level, SkillReportDto dto, SkillAnswerStatsDto stats) {
		if (level == LEVEL_CAT) {
			exportCatTable(dto, stats, level);
		} else if (level == LEVEL_SUBCAT) {
			exportSubcatTable(dto, stats, level);
		} else {
			exportItemTable(dto, stats, level);
		}
	}

	private void exportCatTable(SkillReportDto dto, SkillAnswerStatsDto stats, int level) {
		Rubric rub = dto.getRubric();
		IntStream.range(0, rub.getCategoryList().size()).forEach(i -> {
			RubricCategory cat = rub.getCategoryList().get(i);
			AnswerForm ans = dto.getAnswers().get(i);
			exportCaption(i, 0, cat, i, 1);
			exportAchievement(i, 1, ans);
			List<SkillLessonTakenDto> lessons = dto.getLessonMap().get(cat.getAbilityCode());
			exportLessons(i, 2, COFF_NUMLESSONS[level], lessons);
			book.setRowHeight(RTABLE_TOP + i, HEIGHT_ITEM);
		});

		deleteUnusedRows(RTABLE_TOP + rub.getCategoryList().size(), NUM_ROWS[level]);
		book.setRowHeight(RTABLE_TOP + rub.getCategoryList().size() + ROFF_REVIEW_BODY, HEIGHT_REVIEW);
	}

	private void exportSubcatTable(SkillReportDto dto, SkillAnswerStatsDto stats, int level) {
		Rubric rub = dto.getRubric();
		FreeVar roff = new FreeVar(0);
		IntStream.range(0, rub.getCategoryList().size()).forEach(catIx -> {
			RubricCategory cat = rub.getCategoryList().get(catIx);
			exportCaption(roff.val, 0, cat, catIx, cat.getChildList().size());

			IntStream.range(0, cat.getChildList().size()).forEach(subcIx -> {
				RubricCategory subc = cat.getChildList().get(subcIx);
				exportCaption(roff.val, 1, subc, catIx, 1);

				AnswerForm ans = dto.getAnswers().get(catIx).getChildList().get(subcIx);
				exportAchievement(roff.val, 2, ans);

				book.changeValue(RTABLE_TOP + roff.val, CTABLE + 3, ans.getActionPlan());
				book.changeValue(RTABLE_TOP + roff.val, CTABLE + 4, ans.getEvidence());

				List<SkillLessonTakenDto> lessons = dto.getLessonMap().get(subc.getAbilityCode());
				exportLessons(roff.val, 5, COFF_NUMLESSONS[level], lessons);

				book.setRowHeight(RTABLE_TOP + roff.val, HEIGHT_ITEM);

				roff.val = roff.val + 1;
			});
		});

		deleteUnusedRows(RTABLE_TOP + roff.val, NUM_ROWS[level]);
		book.setRowHeight(RTABLE_TOP + roff.val + ROFF_REVIEW_BODY, HEIGHT_REVIEW);
	}

	private void exportItemTable(SkillReportDto dto, SkillAnswerStatsDto stats, int level) {
		Rubric rub = dto.getRubric();
		FreeVar roff = new FreeVar(0);
		IntStream.range(0, rub.getCategoryList().size()).forEach(catIx -> {
			RubricCategory cat = rub.getCategoryList().get(catIx);
			exportCaption(roff.val, 0, cat, catIx, (int) dto.getAnswers().get(catIx).getNumGrandchildren());

			IntStream.range(0, cat.getChildList().size()).forEach(subcIx -> {
				RubricCategory subc = cat.getChildList().get(subcIx);
				AnswerForm subcAns = dto.getAnswers().get(catIx).getChildList().get(subcIx);
				exportCaption(roff.val, 1, subc, catIx, (int) subcAns.getNumChildren());

				book.changeValue(RTABLE_TOP + roff.val, CTABLE + 2, subcAns.getActionPlan());
				book.mergeCell(RTABLE_TOP + roff.val, CTABLE + 2, (int) subcAns.getNumChildren() - 1, 0);
				book.changeValue(RTABLE_TOP + roff.val, CTABLE + 3, subcAns.getEvidence());
				book.mergeCell(RTABLE_TOP + roff.val, CTABLE + 3, (int) subcAns.getNumChildren() - 1, 0);

				IntStream.range(0, subc.getChildList().size()).forEach(itemIx -> {
					RubricCategory item = subc.getChildList().get(itemIx);
					AnswerForm itemAns = subcAns.getChildList().get(itemIx);
					exportCaption(roff.val, 4, item, catIx, 0);
					exportAchievement(roff.val, 5, itemAns, item.forBasicLens());

					if (itemAns.isAnswered()) {
						if (itemAns.getPhase() != null) {
							book.changeValue(RTABLE_TOP + roff.val, CTABLE + 6, String.valueOf(itemAns.getPhase()));
						}
						book.changeValue(RTABLE_TOP + roff.val, CTABLE + 7, itemAns.getActionPlan());
						book.changeValue(RTABLE_TOP + roff.val, CTABLE + 8, itemAns.getEvidence());
					}

					List<SkillLessonTakenDto> lessons = dto.getLessonMap().get(item.getAbilityCode());
					exportLessons(roff.val, 9, COFF_NUMLESSONS[level], lessons);

					book.setRowHeight(RTABLE_TOP + roff.val, HEIGHT_ITEM);

					roff.val = roff.val + 1;
				});
			});
		});

		deleteUnusedRows(RTABLE_TOP + roff.val, NUM_ROWS[level]);
		book.setRowHeight(RTABLE_TOP + roff.val + ROFF_REVIEW_BODY, HEIGHT_REVIEW);
	}

	private void exportCaption(int roff, int coff, RubricCategory cat, int catIx, int numRows) {
		book.changeValue(RTABLE_TOP + roff, CTABLE + coff, cat.getCaption());
		book.fill(RTABLE_TOP + roff, CTABLE + coff, colorIndex(RGB_CATS[catIx]));
		if (numRows > 1) {
			book.mergeCell(RTABLE_TOP + roff, CTABLE + coff, numRows - 1, 0);
		}
	}

	private void exportAchievement(int roff, int coff, AnswerForm ans) {
		exportAchievement(roff, coff, ans, true);
	}

	private void exportAchievement(int roff, int coff, AnswerForm ans, boolean forBasic) {
		// forBasicフラグは、小項目専用。
		// 基礎能力診断以外なら、NAを出したい。
		if (!forBasic) {
			book.changeValue(RTABLE_TOP + roff, CTABLE + coff, NA);
		} else if (ans.allAchieved()) {
			book.changeValue(RTABLE_TOP + roff, CTABLE + coff, DONE);
			book.setFontColor(RTABLE_TOP + roff, CTABLE + coff, colorIndex(RGB_DONE));
		} else {
			book.changeValue(RTABLE_TOP + roff, CTABLE + coff, NOTYET);
			book.setFontColor(RTABLE_TOP + roff, CTABLE + coff, colorIndex(RGB_NOTYET));
		}
	}

	private void exportLessons(int roff, int coff, int coffNum, List<SkillLessonTakenDto> lessons) {
		if (lessons != null) {
			book.changeValue(RTABLE_TOP + roff, CTABLE + coff, lessons.stream()
					.map(less -> less.getName() + "(" + less.getParty() + ")").collect(Collectors.joining(EOL)));
			book.changeValue(RTABLE_TOP + roff, CTABLE + coffNum,
					String.format(FORMAT_NUMLESSONS, lessons.size()));
		} else {
			book.changeValue(RTABLE_TOP + roff, CTABLE + coffNum, String.format(FORMAT_NUMLESSONS, 0));
		}
	}

	private void deleteUnusedRows(int rfrom, int num) {
		book.deleteRows(rfrom, RTABLE_TOP + num, NUM_ROWS_REVIEW);
	}

	private void prepareTopSheet(int level) {
		book.selectSheet(levelToSheetName(level));
		book.setSheetName(SHNAME_TOP);
		deleteUnusedSheets(level);
	}

	private void preparePalette() {
		Arrays.stream(RGB_CATS).forEach(rgbi -> book.customizeColor(rgbi, colorIndex(rgbi)));
		book.customizeColor(RGB_DONE, colorIndex(RGB_DONE));
		book.customizeColor(RGB_NOTYET, colorIndex(RGB_NOTYET));
	}

	private short colorIndex(int[] rgbi) {
		return (short) rgbi[3];
	}

	private String levelToSheetName(int level) {
		return String.valueOf(level);
	}

	private void deleteUnusedSheets(int level) {
		Arrays.stream(ALL_LEVELS).filter(lv -> lv != level).forEach(lv -> book.deleteSheet(levelToSheetName(lv)));
	}
}
