package jp.co.sraw.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the cr_consul_adv_view database table.
 *
 */
@Entity
@Table(name="cr_consul_adv_view")
@NamedQuery(name="CrConsulAdvView.findAll", query="SELECT c FROM CrConsulAdvView c")
public class CrConsulAdvView implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 区分
	 */
	@Column(name="kbn")
	private String kbn;

	/**
	 * 共有ユーザキー
	 */
	@Column(name="public_user_key")
	private String publicUserKey;

	/**
	 * 面談依頼キー
	 */
	@Id
	@Column(name="consultation_key")
	private String consultationKey;

	/**
	 * ユーザキー
	 */
	@Column(name="user_key")
	private String userKey;

	/**
	 * 面談依頼登録日
	 */
	@Column(name="consultation_ins_date")
	private Timestamp consultationInsDate;

	/**
	 * 依頼内容区分
	 */
	@Column(name="request_kbn")
	private String requestKbn;

	/**
	 * 相談項目区分
	 */
	@Column(name="consultation_kbn")
	private String consultationKbn;

	/**
	 * 相談者メモ
	 */
	@Column(name="user_memo")
	private String userMemo;

	/**
	 * 面談設定者
	 */
	@Column(name="consultation_user_key")
	private String consultationUserKey;

	/**
	 * 面談日
	 */
	@Column(name="consultation_date")
	private Timestamp consultationDate;

	/**
	 * 面談時間開始
	 */
	@Column(name="consultation_start")
	private String consultationStart;

	/**
	 * 面談時間終了
	 */
	@Column(name="consultation_end")
	private String consultationEnd;

	/**
	 * 面談場所
	 */
	@Column(name="consultation_room")
	private String consultationRoom;

	/**
	 * 担当窓口
	 */
	@Column(name="consultation_organization")
	private String consultationOrganization;

	/**
	 * 連絡先
	 */
	@Column(name="consultation_telno")
	private String consultationTelno;

	/**
	 * 相談員対応時間
	 */
	@Column(name="consultation_date_info")
	private String consultationDateInfo;

	/**
	 * 相談員情報
	 */
	@Column(name="consultation_user_info")
	private String consultationUserInfo;

	/**
	 * 相談状態
	 */
	@Column(name="consultation_status")
	private String consultationStatus;

	/**
	 * 相談者
	 */
	@Column(name="advicer_user_key")
	private String advicerUserKey;

	/**
	 * 面談メモ
	 */
	@Column(name="consultation_memo")
	private String consultationMemo;

	/**
	 * データ更新日
	 */
	@Column(name="upd_date")
	private Timestamp updDate;

	/**
	 * データ更新者
	 */
	@Column(name="upd_user_key")
	private String updUserKey;

	/**
	 * 利用者姓(原語)
	 */
	@Column(name="user_family_name")
	private String userFamilyName;

	/**
	 * 利用者姓(英訳)
	 */
	@Column(name="user_family_name_en")
	private String userFamilyNameEn;

	/**
	 * 利用者ミドルネーム(原語)
	 */
	@Column(name="user_middle_name")
	private String userMiddleName;

	/**
	 * 利用者ミドルネーム(英訳)
	 */
	@Column(name="user_middle_name_en")
	private String userMiddleNameEn;

	/**
	 * 利用者名(原語)
	 */
	@Column(name="user_name")
	private String userName;

	/**
	 * 利用者名(英訳)
	 */
	@Column(name="user_name_en")
	private String userNameEn;

	/**
	 * 組織コード
	 */
	@Column(name="party_code")
	private String partyCode;

	/**
	 * 組織名称（原語）
	 */
	@Column(name="party_name")
	private String partyName;

	/**
	 * 組織名称（英訳）
	 */
	@Column(name="party_name_en")
	private String partyNameEn;

	/**
	 * 組織名略称（原語）
	 */
	@Column(name="party_name_abbr")
	private String partyNameAbbr;

	/**
	 * 組織名略称（英訳）
	 */
	@Column(name="party_name_abbr_en")
	private String partyNameAbbrEn;

	/**
	 * 利用者姓(原語)_相談者
	 */
	@Column(name="user_family_name_advicer")
	private String userFamilyNameAdvicer;

	/**
	 * 利用者姓(英訳)_相談者
	 */
	@Column(name="user_family_name_en_advicer")
	private String userFamilyNameEnAdvicer;

	/**
	 * 利用者ミドルネーム(原語)_相談者
	 */
	@Column(name="user_middle_name_advicer")
	private String userMiddleNameAdvicer;

	/**
	 * 利用者ミドルネーム(英訳)_相談者
	 */
	@Column(name="user_middle_name_en_advicer")
	private String userMiddleNameEnAdvicer;

	/**
	 * 利用者名(原語)_相談者
	 */
	@Column(name="user_name_advicer")
	private String userNameAdvicer;

	/**
	 * 利用者名(英訳)_相談者
	 */
	@Column(name="user_name_en_advicer")
	private String userNameEnAdvicer;

	/**
	 * 組織コード_相談者
	 */
	@Column(name="party_code_advicer")
	private String partyCodeAdvicer;

	/**
	 * 組織名称（原語）_相談者
	 */
	@Column(name="party_name_advicer")
	private String partyNameAdvicer;

	/**
	 * 組織名称（英訳）_相談者
	 */
	@Column(name="party_name_en_advicer")
	private String partyNameEnAdvicer;

	/**
	 * 組織名略称（原語）_相談者
	 */
	@Column(name="party_name_abbr_advicer")
	private String partyNameAbbrAdvicer;

	/**
	 * 組織名略称（英訳）_相談者
	 */
	@Column(name="party_name_abbr_en_advicer")
	private String partyNameAbbrEnAdvicer;

	/**
	 * 写真（相談員）
	 */
	@Column(name="advicer_upload_key")
	private String advicerUploadKey;

	/**
	 * 区分を取得します。
	 * @return 区分
	 */
	public String getKbn() {
	    return kbn;
	}

	/**
	 * 区分を設定します。
	 * @param kbn 区分
	 */
	public void setKbn(String kbn) {
	    this.kbn = kbn;
	}

	/**
	 * 共有ユーザキーを取得します。
	 * @return 共有ユーザキー
	 */
	public String getPublicUserKey() {
	    return publicUserKey;
	}

	/**
	 * 共有ユーザキーを設定します。
	 * @param publicUserKey 共有ユーザキー
	 */
	public void setPublicUserKey(String publicUserKey) {
	    this.publicUserKey = publicUserKey;
	}

	/**
	 * 面談依頼キーを取得します。
	 * @return 面談依頼キー
	 */
	public String getConsultationKey() {
	    return consultationKey;
	}

	/**
	 * 面談依頼キーを設定します。
	 * @param consultationKey 面談依頼キー
	 */
	public void setConsultationKey(String consultationKey) {
	    this.consultationKey = consultationKey;
	}

	/**
	 * ユーザキーを取得します。
	 * @return ユーザキー
	 */
	public String getUserKey() {
	    return userKey;
	}

	/**
	 * ユーザキーを設定します。
	 * @param userKey ユーザキー
	 */
	public void setUserKey(String userKey) {
	    this.userKey = userKey;
	}

	/**
	 * 面談依頼登録日を取得します。
	 * @return 面談依頼登録日
	 */
	public Timestamp getConsultationInsDate() {
	    return consultationInsDate;
	}

	/**
	 * 面談依頼登録日を設定します。
	 * @param consultationInsDate 面談依頼登録日
	 */
	public void setConsultationInsDate(Timestamp consultationInsDate) {
	    this.consultationInsDate = consultationInsDate;
	}

	/**
	 * 依頼内容区分を取得します。
	 * @return 依頼内容区分
	 */
	public String getRequestKbn() {
	    return requestKbn;
	}

	/**
	 * 依頼内容区分を設定します。
	 * @param requestKbn 依頼内容区分
	 */
	public void setRequestKbn(String requestKbn) {
	    this.requestKbn = requestKbn;
	}

	/**
	 * 相談項目区分を取得します。
	 * @return 相談項目区分
	 */
	public String getConsultationKbn() {
	    return consultationKbn;
	}

	/**
	 * 相談項目区分を設定します。
	 * @param consultationKbn 相談項目区分
	 */
	public void setConsultationKbn(String consultationKbn) {
	    this.consultationKbn = consultationKbn;
	}

	/**
	 * 相談者メモを取得します。
	 * @return 相談者メモ
	 */
	public String getUserMemo() {
	    return userMemo;
	}

	/**
	 * 相談者メモを設定します。
	 * @param userMemo 相談者メモ
	 */
	public void setUserMemo(String userMemo) {
	    this.userMemo = userMemo;
	}

	/**
	 * 面談設定者を取得します。
	 * @return 面談設定者
	 */
	public String getConsultationUserKey() {
	    return consultationUserKey;
	}

	/**
	 * 面談設定者を設定します。
	 * @param consultationUserKey 面談設定者
	 */
	public void setConsultationUserKey(String consultationUserKey) {
	    this.consultationUserKey = consultationUserKey;
	}

	/**
	 * 面談日を取得します。
	 * @return 面談日
	 */
	public Timestamp getConsultationDate() {
	    return consultationDate;
	}

	/**
	 * 面談日を設定します。
	 * @param consultationDate 面談日
	 */
	public void setConsultationDate(Timestamp consultationDate) {
	    this.consultationDate = consultationDate;
	}

	/**
	 * 面談時間開始を取得します。
	 * @return 面談時間開始
	 */
	public String getConsultationStart() {
	    return consultationStart;
	}

	/**
	 * 面談時間開始を設定します。
	 * @param consultationStart 面談時間開始
	 */
	public void setConsultationStart(String consultationStart) {
	    this.consultationStart = consultationStart;
	}

	/**
	 * 面談時間終了を取得します。
	 * @return 面談時間終了
	 */
	public String getConsultationEnd() {
	    return consultationEnd;
	}

	/**
	 * 面談時間終了を設定します。
	 * @param consultationEnd 面談時間終了
	 */
	public void setConsultationEnd(String consultationEnd) {
	    this.consultationEnd = consultationEnd;
	}

	/**
	 * 面談場所を取得します。
	 * @return 面談場所
	 */
	public String getConsultationRoom() {
	    return consultationRoom;
	}

	/**
	 * 面談場所を設定します。
	 * @param consultationRoom 面談場所
	 */
	public void setConsultationRoom(String consultationRoom) {
	    this.consultationRoom = consultationRoom;
	}

	/**
	 * 担当窓口を取得します。
	 * @return 担当窓口
	 */
	public String getConsultationOrganization() {
	    return consultationOrganization;
	}

	/**
	 * 担当窓口を設定します。
	 * @param consultationOrganization 担当窓口
	 */
	public void setConsultationOrganization(String consultationOrganization) {
	    this.consultationOrganization = consultationOrganization;
	}

	/**
	 * 連絡先を取得します。
	 * @return 連絡先
	 */
	public String getConsultationTelno() {
	    return consultationTelno;
	}

	/**
	 * 連絡先を設定します。
	 * @param consultationTelno 連絡先
	 */
	public void setConsultationTelno(String consultationTelno) {
	    this.consultationTelno = consultationTelno;
	}

	/**
	 * 相談員対応時間を取得します。
	 * @return 相談員対応時間
	 */
	public String getConsultationDateInfo() {
	    return consultationDateInfo;
	}

	/**
	 * 相談員対応時間を設定します。
	 * @param consultationDateInfo 相談員対応時間
	 */
	public void setConsultationDateInfo(String consultationDateInfo) {
	    this.consultationDateInfo = consultationDateInfo;
	}

	/**
	 * 相談員情報を取得します。
	 * @return 相談員情報
	 */
	public String getConsultationUserInfo() {
	    return consultationUserInfo;
	}

	/**
	 * 相談員情報を設定します。
	 * @param consultationUserInfo 相談員情報
	 */
	public void setConsultationUserInfo(String consultationUserInfo) {
	    this.consultationUserInfo = consultationUserInfo;
	}

	/**
	 * 相談状態を取得します。
	 * @return 相談状態
	 */
	public String getConsultationStatus() {
	    return consultationStatus;
	}

	/**
	 * 相談状態を設定します。
	 * @param consultationStatus 相談状態
	 */
	public void setConsultationStatus(String consultationStatus) {
	    this.consultationStatus = consultationStatus;
	}

	/**
	 * 相談者を取得します。
	 * @return 相談者
	 */
	public String getAdvicerUserKey() {
	    return advicerUserKey;
	}

	/**
	 * 相談者を設定します。
	 * @param advicerUserKey 相談者
	 */
	public void setAdvicerUserKey(String advicerUserKey) {
	    this.advicerUserKey = advicerUserKey;
	}

	/**
	 * 面談メモを取得します。
	 * @return 面談メモ
	 */
	public String getConsultationMemo() {
	    return consultationMemo;
	}

	/**
	 * 面談メモを設定します。
	 * @param consultationMemo 面談メモ
	 */
	public void setConsultationMemo(String consultationMemo) {
	    this.consultationMemo = consultationMemo;
	}

	/**
	 * データ更新日を取得します。
	 * @return データ更新日
	 */
	public Timestamp getUpdDate() {
	    return updDate;
	}

	/**
	 * データ更新日を設定します。
	 * @param updDate データ更新日
	 */
	public void setUpdDate(Timestamp updDate) {
	    this.updDate = updDate;
	}

	/**
	 * データ更新者を取得します。
	 * @return データ更新者
	 */
	public String getUpdUserKey() {
	    return updUserKey;
	}

	/**
	 * データ更新者を設定します。
	 * @param updUserKey データ更新者
	 */
	public void setUpdUserKey(String updUserKey) {
	    this.updUserKey = updUserKey;
	}

	/**
	 * 利用者姓(原語)を取得します。
	 * @return 利用者姓(原語)
	 */
	public String getUserFamilyName() {
	    return userFamilyName;
	}

	/**
	 * 利用者姓(原語)を設定します。
	 * @param userFamilyName 利用者姓(原語)
	 */
	public void setUserFamilyName(String userFamilyName) {
	    this.userFamilyName = userFamilyName;
	}

	/**
	 * 利用者姓(英訳)を取得します。
	 * @return 利用者姓(英訳)
	 */
	public String getUserFamilyNameEn() {
	    return userFamilyNameEn;
	}

	/**
	 * 利用者姓(英訳)を設定します。
	 * @param userFamilyNameEn 利用者姓(英訳)
	 */
	public void setUserFamilyNameEn(String userFamilyNameEn) {
	    this.userFamilyNameEn = userFamilyNameEn;
	}

	/**
	 * 利用者ミドルネーム(原語)を取得します。
	 * @return 利用者ミドルネーム(原語)
	 */
	public String getUserMiddleName() {
	    return userMiddleName;
	}

	/**
	 * 利用者ミドルネーム(原語)を設定します。
	 * @param userMiddleName 利用者ミドルネーム(原語)
	 */
	public void setUserMiddleName(String userMiddleName) {
	    this.userMiddleName = userMiddleName;
	}

	/**
	 * 利用者ミドルネーム(英訳)を取得します。
	 * @return 利用者ミドルネーム(英訳)
	 */
	public String getUserMiddleNameEn() {
	    return userMiddleNameEn;
	}

	/**
	 * 利用者ミドルネーム(英訳)を設定します。
	 * @param userMiddleNameEn 利用者ミドルネーム(英訳)
	 */
	public void setUserMiddleNameEn(String userMiddleNameEn) {
	    this.userMiddleNameEn = userMiddleNameEn;
	}

	/**
	 * 利用者名(原語)を取得します。
	 * @return 利用者名(原語)
	 */
	public String getUserName() {
	    return userName;
	}

	/**
	 * 利用者名(原語)を設定します。
	 * @param userName 利用者名(原語)
	 */
	public void setUserName(String userName) {
	    this.userName = userName;
	}

	/**
	 * 利用者名(英訳)を取得します。
	 * @return 利用者名(英訳)
	 */
	public String getUserNameEn() {
	    return userNameEn;
	}

	/**
	 * 利用者名(英訳)を設定します。
	 * @param userNameEn 利用者名(英訳)
	 */
	public void setUserNameEn(String userNameEn) {
	    this.userNameEn = userNameEn;
	}

	/**
	 * 組織コードを取得します。
	 * @return 組織コード
	 */
	public String getPartyCode() {
	    return partyCode;
	}

	/**
	 * 組織コードを設定します。
	 * @param partyCode 組織コード
	 */
	public void setPartyCode(String partyCode) {
	    this.partyCode = partyCode;
	}

	/**
	 * 組織名称（原語）を取得します。
	 * @return 組織名称（原語）
	 */
	public String getPartyName() {
	    return partyName;
	}

	/**
	 * 組織名称（原語）を設定します。
	 * @param partyName 組織名称（原語）
	 */
	public void setPartyName(String partyName) {
	    this.partyName = partyName;
	}

	/**
	 * 組織名称（英訳）を取得します。
	 * @return 組織名称（英訳）
	 */
	public String getPartyNameEn() {
	    return partyNameEn;
	}

	/**
	 * 組織名称（英訳）を設定します。
	 * @param partyNameEn 組織名称（英訳）
	 */
	public void setPartyNameEn(String partyNameEn) {
	    this.partyNameEn = partyNameEn;
	}

	/**
	 * 組織名略称（原語）を取得します。
	 * @return 組織名略称（原語）
	 */
	public String getPartyNameAbbr() {
	    return partyNameAbbr;
	}

	/**
	 * 組織名略称（原語）を設定します。
	 * @param partyNameAbbr 組織名略称（原語）
	 */
	public void setPartyNameAbbr(String partyNameAbbr) {
	    this.partyNameAbbr = partyNameAbbr;
	}

	/**
	 * 組織名略称（英訳）を取得します。
	 * @return 組織名略称（英訳）
	 */
	public String getPartyNameAbbrEn() {
	    return partyNameAbbrEn;
	}

	/**
	 * 組織名略称（英訳）を設定します。
	 * @param partyNameAbbrEn 組織名略称（英訳）
	 */
	public void setPartyNameAbbrEn(String partyNameAbbrEn) {
	    this.partyNameAbbrEn = partyNameAbbrEn;
	}

	/**
	 * 利用者姓(原語)_相談者を取得します。
	 * @return 利用者姓(原語)_相談者
	 */
	public String getUserFamilyNameAdvicer() {
	    return userFamilyNameAdvicer;
	}

	/**
	 * 利用者姓(原語)_相談者を設定します。
	 * @param userFamilyNameAdvicer 利用者姓(原語)_相談者
	 */
	public void setUserFamilyNameAdvicer(String userFamilyNameAdvicer) {
	    this.userFamilyNameAdvicer = userFamilyNameAdvicer;
	}

	/**
	 * 利用者姓(英訳)_相談者を取得します。
	 * @return 利用者姓(英訳)_相談者
	 */
	public String getUserFamilyNameEnAdvicer() {
	    return userFamilyNameEnAdvicer;
	}

	/**
	 * 利用者姓(英訳)_相談者を設定します。
	 * @param userFamilyNameEnAdvicer 利用者姓(英訳)_相談者
	 */
	public void setUserFamilyNameEnAdvicer(String userFamilyNameEnAdvicer) {
	    this.userFamilyNameEnAdvicer = userFamilyNameEnAdvicer;
	}

	/**
	 * 利用者ミドルネーム(原語)_相談者を取得します。
	 * @return 利用者ミドルネーム(原語)_相談者
	 */
	public String getUserMiddleNameAdvicer() {
	    return userMiddleNameAdvicer;
	}

	/**
	 * 利用者ミドルネーム(原語)_相談者を設定します。
	 * @param userMiddleNameAdvicer 利用者ミドルネーム(原語)_相談者
	 */
	public void setUserMiddleNameAdvicer(String userMiddleNameAdvicer) {
	    this.userMiddleNameAdvicer = userMiddleNameAdvicer;
	}

	/**
	 * 利用者ミドルネーム(英訳)_相談者を取得します。
	 * @return 利用者ミドルネーム(英訳)_相談者
	 */
	public String getUserMiddleNameEnAdvicer() {
	    return userMiddleNameEnAdvicer;
	}

	/**
	 * 利用者ミドルネーム(英訳)_相談者を設定します。
	 * @param userMiddleNameEnAdvicer 利用者ミドルネーム(英訳)_相談者
	 */
	public void setUserMiddleNameEnAdvicer(String userMiddleNameEnAdvicer) {
	    this.userMiddleNameEnAdvicer = userMiddleNameEnAdvicer;
	}

	/**
	 * 利用者名(原語)_相談者を取得します。
	 * @return 利用者名(原語)_相談者
	 */
	public String getUserNameAdvicer() {
	    return userNameAdvicer;
	}

	/**
	 * 利用者名(原語)_相談者を設定します。
	 * @param userNameAdvicer 利用者名(原語)_相談者
	 */
	public void setUserNameAdvicer(String userNameAdvicer) {
	    this.userNameAdvicer = userNameAdvicer;
	}

	/**
	 * 利用者名(英訳)_相談者を取得します。
	 * @return 利用者名(英訳)_相談者
	 */
	public String getUserNameEnAdvicer() {
	    return userNameEnAdvicer;
	}

	/**
	 * 利用者名(英訳)_相談者を設定します。
	 * @param userNameEnAdvicer 利用者名(英訳)_相談者
	 */
	public void setUserNameEnAdvicer(String userNameEnAdvicer) {
	    this.userNameEnAdvicer = userNameEnAdvicer;
	}

	/**
	 * 組織コード_相談者を取得します。
	 * @return 組織コード_相談者
	 */
	public String getPartyCodeAdvicer() {
	    return partyCodeAdvicer;
	}

	/**
	 * 組織コード_相談者を設定します。
	 * @param partyCodeAdvicer 組織コード_相談者
	 */
	public void setPartyCodeAdvicer(String partyCodeAdvicer) {
	    this.partyCodeAdvicer = partyCodeAdvicer;
	}

	/**
	 * 組織名称（原語）_相談者を取得します。
	 * @return 組織名称（原語）_相談者
	 */
	public String getPartyNameAdvicer() {
	    return partyNameAdvicer;
	}

	/**
	 * 組織名称（原語）_相談者を設定します。
	 * @param partyNameAdvicer 組織名称（原語）_相談者
	 */
	public void setPartyNameAdvicer(String partyNameAdvicer) {
	    this.partyNameAdvicer = partyNameAdvicer;
	}

	/**
	 * 組織名称（英訳）_相談者を取得します。
	 * @return 組織名称（英訳）_相談者
	 */
	public String getPartyNameEnAdvicer() {
	    return partyNameEnAdvicer;
	}

	/**
	 * 組織名称（英訳）_相談者を設定します。
	 * @param partyNameEnAdvicer 組織名称（英訳）_相談者
	 */
	public void setPartyNameEnAdvicer(String partyNameEnAdvicer) {
	    this.partyNameEnAdvicer = partyNameEnAdvicer;
	}

	/**
	 * 組織名略称（原語）_相談者を取得します。
	 * @return 組織名略称（原語）_相談者
	 */
	public String getPartyNameAbbrAdvicer() {
	    return partyNameAbbrAdvicer;
	}

	/**
	 * 組織名略称（原語）_相談者を設定します。
	 * @param partyNameAbbrAdvicer 組織名略称（原語）_相談者
	 */
	public void setPartyNameAbbrAdvicer(String partyNameAbbrAdvicer) {
	    this.partyNameAbbrAdvicer = partyNameAbbrAdvicer;
	}

	/**
	 * 組織名略称（英訳）_相談者を取得します。
	 * @return 組織名略称（英訳）_相談者
	 */
	public String getPartyNameAbbrEnAdvicer() {
	    return partyNameAbbrEnAdvicer;
	}

	/**
	 * 組織名略称（英訳）_相談者を設定します。
	 * @param partyNameAbbrEnAdvicer 組織名略称（英訳）_相談者
	 */
	public void setPartyNameAbbrEnAdvicer(String partyNameAbbrEnAdvicer) {
	    this.partyNameAbbrEnAdvicer = partyNameAbbrEnAdvicer;
	}

	/**
	 * 写真（相談員）を取得します。
	 * @return 写真（相談員）
	 */
	public String getAdvicerUploadKey() {
	    return advicerUploadKey;
	}

	/**
	 * 写真（相談員）を設定します。
	 * @param advicerUploadKey 写真（相談員）
	 */
	public void setAdvicerUploadKey(String advicerUploadKey) {
	    this.advicerUploadKey = advicerUploadKey;
	}


}