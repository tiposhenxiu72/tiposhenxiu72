package jp.co.sraw.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the us_result_upload_tbl database table.
 *
 */
@Entity
@Table(name = "us_result_upload_tbl")
@NamedQuery(name = "UsResultUploadTbl.findAll", query = "SELECT u FROM UsResultUploadTbl u")
public class UsResultUploadTbl extends GyUploadTbl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name = "ins_date")
	private Timestamp insDate;

	public UsResultUploadTbl() {
	}

	public Timestamp getInsDate() {
		return this.insDate;
	}

	public void setInsDate(Timestamp insDate) {
		this.insDate = insDate;
	}
}