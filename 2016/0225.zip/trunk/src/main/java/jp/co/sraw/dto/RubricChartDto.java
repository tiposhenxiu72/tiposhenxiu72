package jp.co.sraw.dto;

import java.io.Serializable;
import java.util.List;

public class RubricChartDto implements Serializable {

	private List<RubricChartDto> children;
	private String code;
	private String caption;
	private String color;

	public List<RubricChartDto> getChildren() {
		return children;
	}

	public void setChildren(List<RubricChartDto> children) {
		this.children = children;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCaption() {
		return caption;
	}

	public void setCaption(String caption) {
		this.caption = caption;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

}
