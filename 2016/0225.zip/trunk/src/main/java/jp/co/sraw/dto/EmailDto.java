package jp.co.sraw.dto;

import java.io.Serializable;

import jp.co.sraw.util.StringUtil;

public class EmailDto implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;


	private String userKey;

	private String userKbn;

	//private String mailAddress;

	private String portalLoginId;

	private String userFamilyName;

	private String userMiddleName;

	private String userName;

	private String partyCode;

	private String mailSetteing;

	private String role;

	/**
	 * @return userFullName
	 */
	public String getUserFullName() {
		String userFullName = "";
		userFullName = StringUtil.getUserName(getUserKbn(), getUserFamilyName(),
						getUserMiddleName(), getUserName());

		return userFullName;
	}

	/**
	 * @return userKey
	 */
	public String getUserKey() {
		return userKey;
	}

	/**
	 * @param userKey セットする userKey
	 */
	public void setUserKey(String userKey) {
		this.userKey = userKey;
	}

	/**
	 * @return portalLoginId
	 */
	public String getPortalLoginId() {
		return portalLoginId;
	}

	/**
	 * @param portalLoginId セットする portalLoginId
	 */
	public void setPortalLoginId(String portalLoginId) {
		this.portalLoginId = portalLoginId;
	}

	/**
	 * @return userFamilyName
	 */
	public String getUserFamilyName() {
		return userFamilyName;
	}

	/**
	 * @param userFamilyName セットする userFamilyName
	 */
	public void setUserFamilyName(String userFamilyName) {
		this.userFamilyName = userFamilyName;
	}

	/**
	 * @return userMiddleName
	 */
	public String getUserMiddleName() {
		return userMiddleName;
	}

	/**
	 * @param userMiddleName セットする userMiddleName
	 */
	public void setUserMiddleName(String userMiddleName) {
		this.userMiddleName = userMiddleName;
	}

	/**
	 * @return userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName セットする userName
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return partyCode
	 */
	public String getPartyCode() {
		return partyCode;
	}

	/**
	 * @param partyCode セットする partyCode
	 */
	public void setPartyCode(String partyCode) {
		this.partyCode = partyCode;
	}

	/**
	 * @return mailSetteing
	 */
	public String getMailSetteing() {
		return mailSetteing;
	}

	/**
	 * @param mailSetteing セットする mailSetteing
	 */
	public void setMailSetteing(String mailSetteing) {
		this.mailSetteing = mailSetteing;
	}

	/**
	 * @return role
	 */
	public String getRole() {
		return role;
	}

	/**
	 * @param role セットする role
	 */
	public void setRole(String role) {
		this.role = role;
	}

	/**
	 * @return userKbn
	 */
	public String getUserKbn() {
		return userKbn;
	}

	/**
	 * @param userKbn セットする userKbn
	 */
	public void setUserKbn(String userKbn) {
		this.userKbn = userKbn;
	}

}
