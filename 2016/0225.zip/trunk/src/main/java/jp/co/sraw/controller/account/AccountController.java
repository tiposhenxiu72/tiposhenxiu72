/*
* ファイル名：AccountController.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.account;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationDetailsSource;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonController;
import jp.co.sraw.common.UserInfo;
import jp.co.sraw.config.WebSecurityConfig;
import jp.co.sraw.controller.login.LoginController;
import jp.co.sraw.dto.MsCodeDto;
import jp.co.sraw.dto.PartyDto;
import jp.co.sraw.entity.MsPartyTbl;
import jp.co.sraw.entity.UsRequestTbl;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.mail.MailServiceImpl;
import jp.co.sraw.security.gakunin.Gakunin;
import jp.co.sraw.service.MsPartyServiceImpl;
import jp.co.sraw.service.UserInfoServiceImpl;
import jp.co.sraw.service.UserServiceImpl;
import jp.co.sraw.util.DbUtil;
import jp.co.sraw.util.StringUtil;

/**
* <B>AccountControllerクラス</B>
* <P>
* Controllerのメソッドを提供する
*/
@Controller
@RequestMapping("/account")
public class AccountController extends CommonController {

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(LoginController.class);

	private static final String ACCOUNT_ALERT_MESSAGE = "account_alert_message";

	private static final String REDIRECT_INDEX = "redirect:index";
	private static final String REDIRECT_REGIST = "redirect:regist";
	private static final String REDIRECT_HOME = "redirect:"+ WebSecurityConfig.DEFAULT_SUCCESS_URL;
	private static final String INDEX_PAGE = "account/index";
	private static final String PROVISIONAL_PAGE = "account/provisional";
	private static final String REGIST_PAGE = "account/regist";
	private static final String REGIST_ERROR_PAGE = "account/registError";
	private static final String CONFIRM_PAGE = "account/confirm";

	/** 確認ページ用URL */
	private static final String ACTION_SSO_CONFIRM = "/account/ssoConfirm";
	private static final String ACTION_DB_CONFIRM = "/account/confirm";

	// 定数区分
	private static final String CODE_USER_KBN = "0035"; // 定数区分[0035] 学年／職位
	private static final String CODE_SEX = "0025"; // 定数区分[0025] 性別
	private static final String CODE_SEX_MAN = "1"; // 性別 1：男
	private static final String CODE_MAILSETTING = "0032"; // 定数区分[0032] メール受信区分

	@Autowired
	private MsPartyServiceImpl msPartyServiceImpl;

	@Autowired
	private UserServiceImpl userServiceImpl;

	@Autowired
	private UserInfoServiceImpl userInfoServiceImpl;

	@Autowired
	private MailServiceImpl mailServiceImpl;

	@PostConstruct
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	@ModelAttribute(CommonConst.FORM_NAME)
	public AccountForm setupForm() {
		AccountForm form = new AccountForm();
		return form;
	}

	/**
	 * アカウント登録 初期
	 *
	 * @param form
	 * @param model
	 * @return
	 */
	@RequestMapping({"", "/"})
	public String index(@ModelAttribute(CommonConst.FORM_NAME) AccountForm form, Model model, Locale locale) {
		logger.infoCode("I0001", "index"); // I0001=メソッド開始:{0}

		// 登録可能ドメイン一覧
		List<String> domainList = new ArrayList<String>();
		List<PartyDto> pList = getPartyList("", locale);
		for (PartyDto p : pList) {
			if (StringUtil.isNotNull(p.getDomain())) {
				domainList.add(p.getDomain());
			}
		}

		model.addAttribute("domainList", domainList);

		// dump
		modelDump(logger, model, "index");

		logger.infoCode("I0002", "index"); // I0002=メソッド終了:{0}
		return INDEX_PAGE;
	}


	/**
	 * アカウント登録 申請テーブル保存＆メール配信
	 *
	 * @param form
	 * @param bindingResult
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = "/provisional", method = RequestMethod.POST)
	public String provisional(@Validated(AccountForm.Group01.class) @ModelAttribute(CommonConst.FORM_NAME) AccountForm form, BindingResult bindingResult, Model model, Locale locale) {
		logger.infoCode("I0001", "provisional"); // I0001=メソッド開始:{0}

		///////////////////////////////////////////////////////////////////////////////////
		// バリデーションエラーがある場合
		if (bindingResult.hasErrors()) {
			if (logger.isDebugEnabled()) {
				logger.debugCode("W1010", bindingResult.getFieldError()); // W1010=Validationチェックエラーがありました。
			}
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.valid.data"); // error.data.message.valid.data=入力項目に誤りがあります。

			logger.infoCode("I0002", "/provisional"); // I0002=メソッド終了:{0}
			return INDEX_PAGE;
		}

		// 申請データ登録(ID生成も行う)
		String requestId = userServiceImpl.requestAccountSave(form.getMailAddress());
		if (StringUtil.isNotNull(requestId)) {
			// DB更新が成功した場合
			logger.infoCode("I1005", form.getMailAddress()); // I1005=新規作成しました。{0}



			//////////////////////////////////////////////////////////////////////////////
			// メール配信
			if (mailServiceImpl.provisional(form.getMailAddress(), requestId, locale)) {
				// メール配信成功
				logger.infoCode("I0002", "provisional"); // I0002=メソッド終了:{0}
				return PROVISIONAL_PAGE;
			} else {
				model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.mail.send"); // error.data.message.mail.send=メール配信が失敗しました。
			}
		} else {
			// DB更新が失敗した場合
			logger.errorCode("E1007", form.getMailAddress()); // E1007=登録に失敗しました。{0}
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.regist"); // error.data.message.db.regist=登録が失敗しました。
		}

		logger.errorCode("E0014", "provisional"); // E0014=メソッド異常終了:{0}
		return INDEX_PAGE;
	}


	/**
	 * アカウント本登録 初期＆入力
	 * 学認が必要な場合は編集画面表示前にチェックを行う。
	 *
	 * @param request
	 * @param requestId
	 * @param gakuninChkFlag 学認からの戻り値(1:学認認証済み=Emailチェックする
	 * @param bindingResult
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping({"/regist/{requestId}", "/regist/{requestId}/{gakuninChkFlag}"})
	public String regist(HttpServletRequest request, @PathVariable String requestId, @PathVariable("gakuninChkFlag") Optional<String> gakuninChkFlag, @ModelAttribute(CommonConst.FORM_NAME) AccountForm form, BindingResult bindingResult, Model model, Locale locale) {
		logger.infoCode("I0001", "regist"); // I0001=メソッド開始:{0}

		// ドメイン
		String domain = "";
		// 申請データ取得
		UsRequestTbl u = userServiceImpl.findRequest(requestId);
		if (u == null) {

			model.addAttribute(ACCOUNT_ALERT_MESSAGE, "account.message.error.request"); // account.message.error.request=指定したデータは有効期間経過後または無効なデータです。
			logger.infoCode("I0002", "regist"); // I0002=メソッド終了:{0}
			return REGIST_ERROR_PAGE;
		} else {

			// 登録済みメールアドレスチェック
			if (userServiceImpl.findOneMailAddress(u.getMailAddress()) != null) {

				model.addAttribute(ACCOUNT_ALERT_MESSAGE, "error.data.message.mailaddress.registered"); // error.data.message.mailaddress.registered=登録済みのメールアドレスです。
				logger.warnCode("W1011", u.getMailAddress()); // W1011=すでにデータが存在します。{0}
				logger.infoCode("I0002", "regist"); // I0002=メソッド終了:{0}
				return REGIST_ERROR_PAGE;
			}

			// Form
			form.setRequestId(requestId);
			form.setMailAddress(u.getMailAddress());
			// 性別 初期選択：男性
			if (StringUtil.isNull(form.getSex())) {
				form.setSex(CODE_SEX_MAN);
			}
			// 確認用URL
			form.setPageActionUrl(ACTION_DB_CONFIRM);

			// 機関指定 必須切り替え「学籍ID/職員IDなど」
			String[] requiredPartyList = new String[]{};
			if (!CollectionUtils.isEmpty(systemSetting.getUserParamRequiredPartyCodeList())) {
				requiredPartyList = (String[])systemSetting.getUserParamRequiredPartyCodeList().toArray(new String[0]);
			}

			// メールアドレスから機関のドメイン取得
			List<PartyDto> partyList = getPartyList(u.getMailAddress(), locale);
			for (PartyDto p : partyList) {
				if (p.isSelected()) {
					domain = p.getDomain();
					break;
				}
			}

			// TODO:
			///////////////////////////////////////////////////////////////////////////////////
			// 学認チェック(学認認証済みの場合、E-mailチェック)

			boolean gakuninFlag = systemSetting.isGakuninFlag();
			String gakuninLoginId = systemSetting.getGakuninLoginId();
			form.setGakuninChkFlag("0");
			if ((gakuninChkFlag.isPresent() && "1".equals(gakuninChkFlag.get())) && gakuninFlag && StringUtil.isNotNull(gakuninLoginId)) {
				boolean gakuninChk = false;
				try {
					// ヘッダーパラメータ取得
					String username = request.getHeader(gakuninLoginId);

					// 学認からの戻り値チェック
					if (form.getMailAddress().equals(username)) {
						gakuninChk = true;
						form.setGakuninChkFlag("1");
					}

				} catch (Exception e) {
					logger.errorCode("E0014", e); // E0014=メソッド異常終了:{0}
				}
				// 認証失敗
				if (!gakuninChk) {
					// エラー
					model.addAttribute(ACCOUNT_ALERT_MESSAGE, "message.validate.equal.gakuNin"); // message.validate.equal.gakuNin=学術認証と一致しない値です
					logger.infoCode("I0002", "regist"); // I0002=メソッド終了:{0}
					return REGIST_ERROR_PAGE;
				}
			}

			///////////////////////////////////////////////////////////////////////////////////
			// 学認idp一覧取得
			// Idp一覧が取得できるURLにアクセスしてJSONで取得。 サンプルURL: https://office.gakunin.nii.ac.jp/TestFed/export/discofeed/TS0083JP
			// 学認するドメインとidpのURLを設定
			form.setGakuninFlag(false);
			form.setGakuninEntityId("");
			form.setGakuninSAML1SSOurl("");
			if (gakuninFlag) {
				for (Gakunin gakunin : super.getGakuninList()) {
					try {
						URL url = new URL(gakunin.getEntityID());
						// ドメイン名が同じか、サブドメイン以降が同じ場合
						if (url.getHost().endsWith("."+ domain) || url.getHost().equals(domain)) {
							form.setGakuninFlag(true);
							form.setGakuninEntityId(gakunin.getEntityID());
							//form.setGakuninSAML1SSOurl(gakunin.getSAML1SSOurl());
							form.setPageActionUrl(ACTION_SSO_CONFIRM);
							break;
						}
					} catch (Exception e) {
						if (logger.isDebugEnabled()) {
							e.printStackTrace();
						}
					}
				}
			}

			// 設定
			setModelAttribute(form.getMailAddress(), form.getPartyCode(), model, locale);
			model.addAttribute("requiredPartyList", requiredPartyList);
			model.addAttribute(CommonConst.FORM_NAME, form);
		}

		// dump
		modelDump(logger, model, "regist");

		logger.infoCode("I0002", "regist"); // I0002=メソッド終了:{0}
		return REGIST_PAGE;
	}

	/**
	 * アカウント本登録 学認用 確認
	 *
	 * @param form
	 * @param bindingResult
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = "/ssoConfirm", method = RequestMethod.POST)
	public String ssoConfirm(@Validated(AccountForm.Group02.class)  @ModelAttribute(CommonConst.FORM_NAME) AccountForm form, BindingResult bindingResult, Model model, Locale locale) {
		logger.infoCode("I0001", "ssoConfirm"); // I0001=メソッド開始:{0}

		// 設定
		setModelAttribute(form.getMailAddress(), form.getPartyCode(), model, locale);
		model.addAttribute(CommonConst.FORM_NAME, form);

		// dump
		modelDump(logger, model, "ssoConfirm");

		///////////////////////////////////////////////////////////////////////////////////
		// バリデーションエラーがある場合
		if (bindingResult.hasErrors()) {
			if (logger.isDebugEnabled()) {
				logger.debugCode("W1010", bindingResult.getFieldError()); // W1010=Validationチェックエラーがありました。
			}
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.valid.data"); // error.data.message.valid.data=入力項目に誤りがあります。

			logger.infoCode("I0002", "ssoConfirm"); // I0002=メソッド終了:{0}
			return REGIST_PAGE;
		}

		logger.errorCode("E0014", "ssologin"); // E0014=メソッド異常終了:{0}
		return REGIST_PAGE;
	}


	/**
	 * アカウント本登録 DB認証用 確認
	 *
	 * @param form
	 * @param bindingResult
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = "/confirm", method = RequestMethod.POST)
	public String dbConfirm(@Validated(AccountForm.Group03.class)  @ModelAttribute(CommonConst.FORM_NAME) AccountForm form, BindingResult bindingResult, Model model, Locale locale) {
		logger.infoCode("I0001", "dbConfirm"); // I0001=メソッド開始:{0}

		// 設定
		setModelAttribute(form.getMailAddress(), form.getPartyCode(),model, locale);
		model.addAttribute(CommonConst.FORM_NAME, form);

		// dump
		modelDump(logger, model, "dbConfirm");

		///////////////////////////////////////////////////////////////////////////////////
		// バリデーションエラーがある場合
		if (bindingResult.hasErrors()) {
			if (logger.isDebugEnabled()) {
				logger.debugCode("W1010", bindingResult.getFieldError()); // W1010=Validationチェックエラーがありました。
			}
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.valid.data"); // error.data.message.valid.data=入力項目に誤りがあります。

			logger.infoCode("I0002", "dbConfirm"); // I0002=メソッド終了:{0}
			return REGIST_PAGE;
		}

		logger.infoCode("I0002", "dbConfirm"); // I0002=メソッド終了:{0}
		return CONFIRM_PAGE;
	}

	/**
	 * アカウント本登録 完了
	 *
	 * @param form
	 * @param bindingResult
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public String create(@ModelAttribute(CommonConst.FORM_NAME) final AccountForm form, Model model, HttpServletRequest request, Locale locale) {
		logger.infoCode("I0001", "create"); // I0001=メソッド開始:{0}

		// 設定
		setModelAttribute(form.getMailAddress(), form.getPartyCode(),model, locale);
		model.addAttribute(CommonConst.FORM_NAME, form);

		// dump
		modelDump(logger, model, "dbConfirm");

		// 登録済みメールアドレスチェック
		if (userServiceImpl.findOneMailAddress(form.getMailAddress()) != null) {
			model.addAttribute(ACCOUNT_ALERT_MESSAGE, "error.data.message.mailaddress.registered"); // error.data.message.mailaddress.registered=登録済みのメールアドレスです。
			logger.warnCode("W1011", form.getMailAddress()); // W1011=すでにデータが存在します。{0}
			logger.infoCode("I0002", "create"); // I0002=メソッド終了:{0}
			return REGIST_ERROR_PAGE;
		}

		try {
			// メール設定
			form.setMailSetting(getMailsetting());

			// ユーザー登録
			if (userServiceImpl.addAccountSave(form)) {
				// 認証済みにする
				UserInfo lendingUserInfo = userInfoServiceImpl.loadUserByUsername(form.getMailAddress());
				if (lendingUserInfo != null) {
					// UsernamePasswordAuthenticationToken を生成して SecurityContext にセットする
					UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(lendingUserInfo, null,
							lendingUserInfo.getAuthorities());

					// org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter
					// setDetails メソッドを見て実装しています
					AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource = new WebAuthenticationDetailsSource();
					token.setDetails(authenticationDetailsSource.buildDetails(request));
					SecurityContextHolder.getContext().setAuthentication(token);

					// 画面遷移
					logger.infoCode("I0002", "create"); // I0002=メソッド終了:{0}
					return REDIRECT_HOME;
				}
			}
		} catch (Exception e) {
			logger.errorCode("E0014", e); // E0014=メソッド異常終了:{0}
		}

		model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.regist"); // error.data.message.db.regist=登録が失敗しました。

		logger.errorCode("E0014", "create"); // E0014=メソッド異常終了:{0}
		return CONFIRM_PAGE;

	}

	/**
	 * ダイレクトアクセス対策
	 *
	 * @return
	 */
	@RequestMapping(value = {"/provisional", "/regist", "/ssoConfirm", "/confirm", "/create"}, method = RequestMethod.GET)
	public String redirect() {
		logger.warnCode("W1009"); // W1009=URLダイレクトアクセスがありました。
		return CommonConst.REDIRECT_INDEX;
	}

	/**
	 * 共通model
	 *
	 * @param mailAddress
	 * @param partyCode 初期選択組織
	 * @param model
	 * @param locale
	 */
	private void setModelAttribute(String mailAddress, String partyCode, Model model, Locale locale) {

		// 組織リスト取得
		List<PartyDto> partyList = getPartyList(mailAddress, locale);
		// 初期選択組織(メールアドレスドメインから上書き)
		if (StringUtil.isNotNull(partyCode)) {
			List<PartyDto> partyListTmp = new ArrayList<PartyDto>();
			for (PartyDto p :partyList) {
				if (partyCode.equals(p.getCode())) {
					p.setSelected(true);
				} else {
					p.setSelected(false);
				}
				partyListTmp.add(p);
			}
			partyList.clear();
			partyList.addAll(partyListTmp);
		}
		Map<String, PartyDto> partyMap = new HashMap<String, PartyDto>();
		for (PartyDto p : partyList) {
			partyMap.put(p.getCode(), p);
		}
		// 学年／職位
		List<MsCodeDto> userKbnList = DbUtil.getJosuList(CODE_USER_KBN, locale);
		Map<String, MsCodeDto> userKbnMap = new HashMap<String, MsCodeDto>();
		for (MsCodeDto m : userKbnList) {
			userKbnMap.put(m.getCode(), m);
		}
		// 性別
		List<MsCodeDto> sexList = DbUtil.getJosuList(CODE_SEX, locale);
		Map<String, MsCodeDto> sexMap = new HashMap<String, MsCodeDto>();
		for (MsCodeDto m : sexList) {
			sexMap.put(m.getCode(), m);
		}

		// model
		model.addAttribute("partyList", partyList);
		model.addAttribute("partyMap", partyMap);
		model.addAttribute("userKbnList", userKbnList);
		model.addAttribute("userKbnMap", userKbnMap);
		model.addAttribute("sexList", sexList);
		model.addAttribute("sexMap", sexMap);
	}

	/**
	 * メール設定区分を「,」区切りで返す
	 *
	 * @return
	 */
	private String getMailsetting(){
		String str = "";
		List<MsCodeDto> list = DbUtil.getJosuList(CODE_MAILSETTING);
		for (MsCodeDto m : list) {
			if (StringUtil.isNotNull(str)) {
				str = str + ",";
			}
			str = str + m.getCode();
		}
		return str;
	}

	/**
	 * 組織一覧を取得＆選択
	 *
	 * @param mailAddress
	 * @param locale
	 * @return
	 */
	private List<PartyDto> getPartyList(String mailAddress, Locale locale){

		logger.infoCode("I0001", "partyList"); // I0001=メソッド開始:{0}

		List<MsPartyTbl> mList = msPartyServiceImpl.findAllByPartyKbn(null);
		List<PartyDto> resultList = new ArrayList<PartyDto>();
		for (MsPartyTbl m : mList) {
			String name = m.getPartyName();
			if (!CommonConst.DEFAULT_LOCALE.getLanguage().equals(locale.getLanguage())) {
				name = m.getPartyNameEn();
			}
			PartyDto dto = new PartyDto();
			dto.setCode(m.getPartyCode());
			dto.setName(name);
			dto.setKbn(m.getPartyKbn());
			dto.setDomain(m.getDomain());
			// 組織選択
			// ドメイン名が同じか、サブドメイン以降が同じ場合
			if (StringUtil.isNotNull(m.getDomain()) && (mailAddress.endsWith("."+ m.getDomain()) || mailAddress.endsWith("@"+ m.getDomain()))) {
				dto.setSelected(true);
			} else {
				dto.setSelected(false);
			}
			resultList.add(dto);
		}

		logger.infoCode("I0002", "partyList"); // I0002=メソッド終了:{0}
		return resultList;
	}

}
