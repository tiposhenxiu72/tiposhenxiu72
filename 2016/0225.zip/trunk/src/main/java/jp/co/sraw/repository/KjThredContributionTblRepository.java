package jp.co.sraw.repository;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import jp.co.sraw.entity.KjThredContributionTbl;
import jp.co.sraw.entity.KjThredContributionTblPK;

@Repository
public interface KjThredContributionTblRepository extends JpaRepository<KjThredContributionTbl, KjThredContributionTblPK>, JpaSpecificationExecutor<KjThredContributionTbl> {

	@Query("SELECT u FROM KjThredContributionTbl u WHERE u.id.thredKey=:thredKey ORDER BY u.id.seqNo DESC")
	public List <KjThredContributionTbl> findMaxseqno(@Param("thredKey") String thredKey);

	@Modifying
	@Query(name = "KjThredContributionTbl.delete")
	public int delete(@Param("thredKey") String thredKey, @Param("seqNo") int seqNo, @Param("updDate") Timestamp updDate);

}
