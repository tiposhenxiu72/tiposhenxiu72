package jp.co.sraw.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the gy_search_view database table.
 *
 */
@Entity
@Table(name="gy_search_view")
@NamedQuery(name="GySearchView.findAll", query="SELECT g FROM GySearchView g")
public class GySearchView implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="gyoseki_key")
	private String gyosekiKey;

	@Column(name="public_flag")
	private String publicFlag;

	@Column(name="search_key")
	private String searchKey;

	@Column(name="user_key")
	private String userKey;

	@Column(name="user_public_flag")
	private String userPublicFlag;

	public GySearchView() {
	}

	public String getGyosekiKey() {
		return this.gyosekiKey;
	}

	public void setGyosekiKey(String gyosekiKey) {
		this.gyosekiKey = gyosekiKey;
	}

	public String getPublicFlag() {
		return this.publicFlag;
	}

	public void setPublicFlag(String publicFlag) {
		this.publicFlag = publicFlag;
	}

	public String getSearchKey() {
		return this.searchKey;
	}

	public void setSearchKey(String searchKey) {
		this.searchKey = searchKey;
	}

	public String getUserKey() {
		return this.userKey;
	}

	public void setUserKey(String userKey) {
		this.userKey = userKey;
	}

	public String getUserPublicFlag() {
		return this.userPublicFlag;
	}

	public void setUserPublicFlag(String userPublicFlag) {
		this.userPublicFlag = userPublicFlag;
	}

}