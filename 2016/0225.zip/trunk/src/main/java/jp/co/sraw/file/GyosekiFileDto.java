package jp.co.sraw.file;

public class GyosekiFileDto extends FileDto {

	private String gyosekiKey; // ポートフォリオ向け

	private String link; // ポートフォリオ向け Youtube

	private String insKbn; // ポートフォリオ向け

	public GyosekiFileDto () {
		super();
	}

	public GyosekiFileDto (FileDto dto) {
		super();
		if (dto != null) {
			this.setCalcVolumn(dto.getCalcVolumn());
			this.setFieldName(dto.getFieldName());
			this.setFile(dto.getFile());
			this.SetFileKbn(dto.getFileKbn());
			this.setStoragePath(dto.getStoragePath());
			this.setTitle(dto.getTitle());
			this.setUpdDate(dto.getUpdDate());
			this.setUploadKey(dto.getUploadKey());
			this.setUploadName(dto.getUploadName());
		}
	}

	/**
	 * @return gyosekiKey
	 */
	public String getGyosekiKey() {
		return gyosekiKey;
	}

	/**
	 * @param gyosekiKey セットする gyosekiKey
	 */
	public void setGyosekiKey(String gyosekiKey) {
		this.gyosekiKey = gyosekiKey;
	}

	/**
	 * @return link
	 */
	public String getLink() {
		return link;
	}

	/**
	 * @param link セットする link
	 */
	public void setLink(String link) {
		this.link = link;
	}

	/**
	 * @return insKbn
	 */
	public String getInsKbn() {
		return insKbn;
	}

	/**
	 * @param insKbn セットする insKbn
	 */
	public void setInsKbn(String insKbn) {
		this.insKbn = insKbn;
	}


}
