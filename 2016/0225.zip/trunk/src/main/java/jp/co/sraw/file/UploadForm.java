package jp.co.sraw.file;

import java.util.ArrayList;
import java.util.List;

import jp.co.sraw.common.CommonForm;
import jp.co.sraw.common.UserInfo;

public class UploadForm extends CommonForm {

	private List<FileDto> preUploadFileList = new ArrayList<>();

	private List<FileDto> uploadFileList = new ArrayList<>();

	private boolean fileNotNull = false;

	private String fileTextName;

	private String fileKbn;

	private String fieldName = "uploadfile";

	private String calcVolumn = "0";

	public void AddFileDto(FileDto fileDto) {
		if (this.preUploadFileList == null)
			this.preUploadFileList = new ArrayList<>();
		if (fileDto != null) {
			this.preUploadFileList.add(fileDto);
		}
	}

	public String getUploadKey() {
		if (this.uploadFileList != null && this.uploadFileList.size() > 0) {
			return this.uploadFileList.get(0).getUploadKey();
		}
		return null;
	}

	public String getCalcVolumn() {
		return calcVolumn;
	}

	public void setCalcVolumn(String calcVolumn) {
		this.calcVolumn = calcVolumn;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getFileKbn() {
		return fileKbn;
	}

	public void setFileKbn(String fileKbn) {
		this.fileKbn = fileKbn;
	}

	public String getFileTextName() {
		return fileTextName;
	}

	public void setFileTextName(String fileTextName) {
		this.fileTextName = fileTextName;
	}

	private UserInfo userInfo = null;

	public List<FileDto> getPreUploadFileList() {
		return preUploadFileList;
	}

	public void setPreUploadFileList(List<FileDto> preUploadFileList) {
		this.preUploadFileList = preUploadFileList;
	}

	public List<FileDto> getUploadFileList() {
		return uploadFileList;
	}

	public void setUploadFileList(List<FileDto> uploadFileList) {
		this.uploadFileList = uploadFileList;
	}

	public UserInfo getUserInfo() {
		return userInfo;
	}

	public void setUserInfo(UserInfo userInfo) {
		this.userInfo = userInfo;
	}

	public boolean getFileNotNull() {
		return fileNotNull;
	}

	public void setFileNotNull(boolean fileNotNull) {
		this.fileNotNull = fileNotNull;
	}
}
