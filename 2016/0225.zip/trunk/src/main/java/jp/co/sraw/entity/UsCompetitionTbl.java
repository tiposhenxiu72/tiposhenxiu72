package jp.co.sraw.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the us_competition_tbl database table.
 *
 */
@Entity
@Table(name = "us_competition_tbl")
@NamedQuery(name = "UsCompetitionTbl.findAll", query = "SELECT u FROM UsCompetitionTbl u")
public class UsCompetitionTbl extends GyUploadTbl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name = "ins_date")
	private Timestamp insDate;

	@Column(name = "ins_kbn")
	private String insKbn;

	private String link;

	public UsCompetitionTbl() {
	}

	public Timestamp getInsDate() {
		return this.insDate;
	}

	public void setInsDate(Timestamp insDate) {
		this.insDate = insDate;
	}

	public String getInsKbn() {
		return this.insKbn;
	}

	public void setInsKbn(String insKbn) {
		this.insKbn = insKbn;
	}

	public String getLink() {
		return this.link;
	}

	public void setLink(String link) {
		this.link = link;
	}

}