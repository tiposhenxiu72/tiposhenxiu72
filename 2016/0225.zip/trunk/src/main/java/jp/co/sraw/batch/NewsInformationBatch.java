/*
* ファイル名：NewsInformationBatch.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/02/01   toishigawa  新規作成
*/
package jp.co.sraw.batch;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.service.BatchTargetService;

/**
* <B>NewsInformationBatchクラス</B>
* <P>
* お知らせ情報作成
*/
@Component
public class NewsInformationBatch implements BatchRunner {
	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(NewsInformationBatch.class);

	@Autowired
	private BatchTargetService batchTargetService;// batch処理のサービス

	@Override
	public boolean run(Map<String, String> parameters) throws Exception {

		// お知らせ情報作成
		// 支援制度からの情報抽出
		Boolean supportFlag = batchTargetService.updateSupportBatchNewsInfo();

		// イベントからの情報抽出
		Boolean eventFlag = batchTargetService.updateEventBatchNewsInfo();

		// インターンシップからの情報抽出
		Boolean internshipFlag = batchTargetService.updateInternshipBatchNewsInfo();

		// すべてupdate成功なら、trueを戻す
		if (supportFlag && eventFlag && internshipFlag) {
			return true;
		}
		return false;
	}
}
