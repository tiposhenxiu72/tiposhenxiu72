/**
 *
 */
package jp.co.sraw.dto;

import java.util.Map;

import jp.co.sraw.controller.skill.AjaxDto;

public class RelationAnswerDto extends AjaxDto {
	private Map<String, String> skillMap;

	public Map<String, String> getSkillMap() {
		return skillMap;
	}

	public void setSkillMap(Map<String, String> skillMap) {
		this.skillMap = skillMap;
	}
}
