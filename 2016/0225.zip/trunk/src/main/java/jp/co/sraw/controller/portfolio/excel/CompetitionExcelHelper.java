package jp.co.sraw.controller.portfolio.excel;

import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Service;

import jp.co.sraw.common.CommonForm;
import jp.co.sraw.controller.portfolio.form.GyCompetitionForm;
import jp.co.sraw.util.PoiBook;

@Service
public class CompetitionExcelHelper extends PortfolioExcelHelper<GyCompetitionForm> {

	public CompetitionExcelHelper() {
		this.DATA_SHEET_NAME = "COMPETITION";
	}

	@Override
	public void buildExcelDocument(PoiBook workbook, List<GyCompetitionForm> list) {
		workbook.activeSheet = workbook.book.getSheet(DATA_SHEET_NAME);

		for (int i = 0; i < list.size(); i++) {
			GyCompetitionForm form = list.get(i);
			form.setViewType(CommonForm.VIEW_TYPE_EXCEL);
			int rowno = i + 1;
			// 言語区分
			// workbook.changeValue(rowno, 0, form.getLanguage());
			// 提供機関
			workbook.changeValue(rowno, 0, form.getProvider());
			// 制度名
			workbook.changeValue(rowno, 1, form.getSystem());
			// タイトル
			workbook.changeValue(rowno, 2, form.getTitle());
			// 研究期間(From)
			workbook.changeValue(rowno, 3, form.getFromdate());
			// 研究期間(To)
			workbook.changeValue(rowno, 4, form.getTodate());
			// 連携研究者
			workbook.changeValue(rowno, 5, form.getMember());
			// 研究分野
			workbook.changeValue(rowno, 6, form.getField());
			// 研究種目
			workbook.changeValue(rowno, 7, form.getCategory());
			// 代表者
			workbook.changeValue(rowno, 8, form.getAuthor());
			// 配分額(総額)
			workbook.changeValue(rowno, 9, form.getAmounttotal().toString());
			// 配分額(総額)
			workbook.changeValue(rowno, 10, form.getCurrencyName());
			// 公開範囲
			workbook.changeValue(rowno, 11, form.getPublicFlag());
		}
	}

	@Override
	public Sheet getSheet(Workbook workbook) {
		return workbook.getSheet(DATA_SHEET_NAME);
	}

	@Override
	public GyCompetitionForm getForm(Row row) {

		GyCompetitionForm form = new GyCompetitionForm();

		// 言語区分
		// form.setLanguage(getCellValue(row, 0));
		// 提供機関
		form.setProvider(getCellValue(row, 0));
		// 制度名
		form.setSystem(getCellValue(row, 1));
		// タイトル
		form.setTitle(getCellValue(row, 2));
		// 研究期間(From)
		form.setFromdate(getCellValue(row, 3, true));
		// 研究期間(To)
		form.setTodate(getCellValue(row, 4, true));
		// 連携研究者
		form.setMember(getCellValue(row, 5));
		// 研究分野
		form.setField(getCellValue(row, 6));
		// 研究種目
		form.setCategory(getCellValue(row, 7));
		// 代表者
		form.setAuthor(getCellValue(row, 8));
		// 配分額(総額)
		form.setAmounttotal(getCellBigDecimal(row, 9));
		// 配分額(総額)
		form.setCurrencyName(getCellValue(row, 10));
		// 公開範囲
		form.setPublicFlag(getCellValue(row, 11));

		return form;
	}

}