/*
* ファイル名：GyCompetitionForm.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.portfolio.form;

import java.math.BigDecimal;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;

import org.hibernate.validator.constraints.NotBlank;
import org.maru.m4hv.extensions.constraints.CharLength;

import jp.co.sraw.entity.GyCommonTbl;
import jp.co.sraw.entity.GyCompetitionTbl;
import jp.co.sraw.util.DateUtil;
import jp.co.sraw.validation.Date468;

/**
 * <B>GyCompetitionFormクラス</B>
 * <P>
 * Formのメソッドを提供する
 */
public class GyCompetitionForm extends PortfolioForm {

	public GyCompetitionForm() {
		super();
	}

	public String getCompetitionLanguage() {
		return this.getLanguage();
	}

	public void setCompetitionLanguage(String competitionLanguage) {
		this.setLanguage(competitionLanguage);
	}

	@DecimalMin("0")
	@DecimalMax("99999999999")
	private BigDecimal amounttotal;

	@CharLength(max = 255)
	private String author;

	@CharLength(max = 255)
	private String category;

	@CharLength(max = 255)
	private String competitionLanguage;

	@CharLength(max = 255)
	private String field;

	@Date468
	private String fromdate;

	@CharLength(max = 255)
	private String member;

	@CharLength(max = 255)
	private String provider;

	@CharLength(max = 255)
	private String system;

	@Date468
	private String todate;

	@NotBlank
	@CharLength(max = 255)
	private String title;

	@CharLength(max = 255)
	private String currencyName;

	public String getCurrencyName() {
		return currencyName;
	}

	public void setCurrencyName(String currencyName) {
		this.currencyName = currencyName;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public BigDecimal getAmounttotal() {
		return this.amounttotal;
	}

	public void setAmounttotal(BigDecimal amounttotal) {
		this.amounttotal = amounttotal;
	}

	public String getAuthor() {
		return this.author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getCategory() {
		return this.category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getField() {
		return this.field;
	}

	public void setField(String field) {
		this.field = field;
	}

	public String getFromdate() {
		return this.fromdate;
	}

	public String getFromdate468() {
		return DateUtil.editDate468(this.fromdate);
	}

	public void setFromdate(String fromdate) {
		this.fromdate = fromdate;
	}

	public String getMember() {
		return this.member;
	}

	public void setMember(String member) {
		this.member = member;
	}

	public String getProvider() {
		return this.provider;
	}

	public void setProvider(String provider) {
		this.provider = provider;
	}

	public String getSystem() {
		return this.system;
	}

	public void setSystem(String system) {
		this.system = system;
	}

	public String getTodate() {
		return this.todate;
	}

	public String getTodate468() {
		return DateUtil.editDate468(this.todate);
	}

	public void setTodate(String todate) {
		this.todate = todate;
	}

	@Override
	public GyCommonTbl getNewTbl() {
		// TODO 自動生成されたメソッド・スタブ
		return new GyCompetitionTbl();
	}

}
