/*
* ファイル名：SystemSetting.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/01/14   toishigawa  新規作成
*/
package jp.co.sraw.common;

import java.util.List;

/**
* <B>SystemSettingクラス</B>
* <P>
* システムのパラメータを提供する
*/
public class SystemSetting {

	/** Batch起動のためのパラメータ */
	private String batchAccessKey;

	/** 学認使用フラグ */
	private boolean gakuninFlag;
	/** 学認認証結果の項目名 */
	private String gakuninLoginId;
	/** 学認Idpリスト取得先 */
	private String gakuninIdpListUrl;

	/** アクセス許可URI(メニュー存在しない画面) */
	private List<String> accessUriList;
	/**
	 * @return batchAccessKey
	 */

	/** sftp接続用HOST名 */
	private String sftpHostName;

	/** sftp接続用ユーザID */
	private String sftpUserId;

	/** sftp接続用キー */
	private String sftpKey;

	/** webサーバテンプフォルダ */
	private String tmpfolder;

	public String getBatchAccessKey() {
		return batchAccessKey;
	}
	/**
	 * @param batchAccessKey セットする batchAccessKey
	 */
	public void setBatchAccessKey(String batchAccessKey) {
		this.batchAccessKey = batchAccessKey;
	}
	/**
	 * @return accessUriList
	 */
	public List<String> getAccessUriList() {
		return accessUriList;
	}
	/**
	 * @param accessUriList セットする accessUriList
	 */
	public void setAccessUriList(List<String> accessUriList) {
		this.accessUriList = accessUriList;
	}

	public String getSftpHostName() {
		return sftpHostName;
	}
	/**
	 * @param  sftpHostNameセットする
	 */
	public void setSftpHostName(String sftpHostName) {
		this.sftpHostName = sftpHostName;
	}

	public String getSftpUserId() {
		return sftpUserId;
	}

	/**
	 * @param  sftpUserIdセットする
	 */
	public void setSftpUserId(String sftpUserId) {
		this.sftpUserId = sftpUserId;
	}


	public String getSftpKey() {
		return sftpKey;
	}
	/**
	 * @param  sftpKeyセットする
	 */
	public void setSftpKey(String sftpKey) {
		this.sftpKey = sftpKey;
	}
	public String getTmpFolder() {
		return tmpfolder;
	}
	/**
	 * @param  tmpfolderセットする
	 */
	public void setTmpFolder(String tmpfolder) {
		this.tmpfolder = tmpfolder;
	}
	/**
	 * @return gakuninFlag
	 */
	public boolean isGakuninFlag() {
		return gakuninFlag;
	}
	/**
	 * @param gakuninFlag セットする gakuninFlag
	 */
	public void setGakuninFlag(boolean gakuninFlag) {
		this.gakuninFlag = gakuninFlag;
	}
	/**
	 * @return gakuninLoginId
	 */
	public String getGakuninLoginId() {
		return gakuninLoginId;
	}
	/**
	 * @param gakuninLoginId セットする gakuninLoginId
	 */
	public void setGakuninLoginId(String gakuninLoginId) {
		this.gakuninLoginId = gakuninLoginId;
	}
	/**
	 * @return gakuninIdpListUrl
	 */
	public String getGakuninIdpListUrl() {
		return gakuninIdpListUrl;
	}
	/**
	 * @param gakuninIdpListUrl セットする gakuninIdpListUrl
	 */
	public void setGakuninIdpListUrl(String gakuninIdpListUrl) {
		this.gakuninIdpListUrl = gakuninIdpListUrl;
	}
}
