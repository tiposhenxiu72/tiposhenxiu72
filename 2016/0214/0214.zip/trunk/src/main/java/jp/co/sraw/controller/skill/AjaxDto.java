package jp.co.sraw.controller.skill;

import java.io.Serializable;

/**
 * AjaxのレスポンスJSONを生成するためのDTO。このクラス単独でも使うし、親クラスとしても使う。
 */
public class AjaxDto implements Serializable {
	String error; // エラーメッセージ。nullや""ならエラーなし。

	public AjaxDto() {
		error = "";
	}

	public AjaxDto(String error) {
		this.error = error;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

}
