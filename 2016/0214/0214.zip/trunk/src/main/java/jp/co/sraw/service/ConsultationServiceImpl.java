/*
* ファイル名：ConsultationServiceImpl.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/01/15   matsuo  新規作成
*/
package jp.co.sraw.service;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.BindingResult;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonService;
import jp.co.sraw.common.UserInfo;
import jp.co.sraw.controller.consultation.ConsultationForm;
import jp.co.sraw.dto.AdvicerDto;
import jp.co.sraw.dto.ConsultationDto;
import jp.co.sraw.entity.AdvicerView;
import jp.co.sraw.entity.CrConsulAdvView;
import jp.co.sraw.entity.CrConsulMgmtView;
import jp.co.sraw.entity.CrConsulPublicUserTbl;
import jp.co.sraw.entity.CrConsulPublicUserTblPK;
import jp.co.sraw.entity.CrConsulTbl;
import jp.co.sraw.entity.CrConsulView;
import jp.co.sraw.entity.MsPartyTbl;
import jp.co.sraw.entity.UsInfoTbl;
import jp.co.sraw.entity.UsScheduleTbl;
import jp.co.sraw.entity.UsUserTbl;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.mail.MailServiceImpl;
import jp.co.sraw.repository.AdvicerViewRepository;
import jp.co.sraw.repository.CrConsulAdvViewRepository;
import jp.co.sraw.repository.CrConsulMgmtViewRepository;
import jp.co.sraw.repository.CrConsulPublicUserTblRepository;
import jp.co.sraw.repository.CrConsulTblRepository;
import jp.co.sraw.repository.CrConsulViewRepository;
import jp.co.sraw.repository.MsPartyTblRepository;
import jp.co.sraw.repository.UsInfoTblRepository;
import jp.co.sraw.repository.UsScheduleTblRepository;
import jp.co.sraw.repository.UsUserTblRepository;
import jp.co.sraw.util.DateUtil;
import jp.co.sraw.util.DbUtil;
import jp.co.sraw.util.MessageUtil;
import jp.co.sraw.util.ObjectUtil;
import jp.co.sraw.util.StringUtil;

/**
 * <B>ConsultationServiceImplクラス</B>
 * <P>
 * キャリア面談サービスのメソッドを提供する
 */
@Service
@Transactional(readOnly = true)
public class ConsultationServiceImpl extends CommonService {

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(ConsultationServiceImpl.class);

	@Autowired
	private CrConsulTblRepository crConsulTblRepository;

	@Autowired
	private CrConsulPublicUserTblRepository crConsulPublicUserTblRepository;

	@Autowired
	private CrConsulViewRepository crConsulViewRepository;

	@Autowired
	private AdvicerViewRepository advicerViewRepository;

	@Autowired
	private CrConsulAdvViewRepository crConsulAdvViewRepository;

	@Autowired
	private CrConsulMgmtViewRepository crConsulMgmtViewRepository;

	@Autowired
	private MsPartyTblRepository msPartyTblRepository;

	@Autowired
	private UsInfoTblRepository usInfoTblRepository;

	@Autowired
	private UsScheduleTblRepository usScheduleTblRepository;

	@Autowired
	private UserServiceImpl userServiceImpl;

	@Autowired
	private MailServiceImpl mailServiceImpl;

	@Autowired
	private UsUserTblRepository usUserTblRepository;

	// 定数
	public static final String CODE_CONSUL_STATUS_NEW = "1";	// 相談状態:新規
	public static final String CODE_CONSUL_STATUS_SET = "2";	// 相談状態:面談待ち
	public static final String CODE_CONSUL_STATUS_END = "4";	// 相談状態:終了
	private static final String PARTY_KBN_UNIV_NATIONAL = "5";	// 組織区分:国立大学
	private static final String PARTY_KBN_UNIV_PRIVATE = "6";	// 組織区分:私立大学
	private static final String CODE_ADVICER_NEED = "2";		// 希望相談員:あり
	private static final int DAY_OF_ONE_WEEK = 7;				// １週間

	// 定数区分
	public static final String CODE_REQUEST_KBN = "0003";		// 依頼内容
	public static final String CODE_CONSUL_KBN = "0004";		// 相談項目
	public static final String CODE_ADVICER_KBN = "0028";		// 希望相談員
	public static final String CODE_CONSUL_STATUS_KBN = "0029";	// 相談状態

	// URL
	private static final String URL_MGMT = "mgmt/";
	private static final String URL_DETAIL = "consultation/detail/";
	private static final String URL_SETTING = "consultation/setting/";
	private static final String URL_RESULT = "consultation/result/";

	// ユーザお知らせ情報用
	private static final String TITLE_REQUEST = "consultation.request.title";	// 面談依頼
	private static final String TITLE_SETTING = "consultation.setting.title";	// 面談設定
	private static final String TITLE_RESULT = "consultation.result.title";		// 面談結果
	private static final String TITLE_DELIMITER = "：";		// 面談結果

	@PostConstruct
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	/**
	 * 面談一覧のソート条件
	 *
	 * @return
	 */
	private Sort orderByForConsulList(){
		return  new Sort(Sort.Direction.DESC, "consultationDate")
				.and(new Sort(Sort.Direction.DESC, "consultationStart"))
				.and(new Sort(Sort.Direction.DESC, "consultationEnd"))
				.and(new Sort(Sort.Direction.DESC, "consultationInsDate"));
	}

	/**
	 * 面談一覧取得（若手研究者）
	 *
	 * @param userInfo
	 * @return
	 */
	public List<ConsultationDto> findConsulList(UserInfo userInfo) {
		logger.infoCode("I0001", "findConsulList"); // I0001=メソッド開始:{0}
		ObjectUtil util = new ObjectUtil();

		// 取得条件：ユーザキー
		Specification<CrConsulView> whereUserKey = new Specification<CrConsulView>() {
			@Override
			public Predicate toPredicate(Root<CrConsulView> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.get("userKey"), userInfo.getTargetUserKey());
			}
		};

		// 検索処理
		List<CrConsulView> listView = crConsulViewRepository.findAll(
				Specifications.where(whereUserKey)
				, this.orderByForConsulList());

		// 一覧リスト生成
		List<ConsultationDto> list = new ArrayList<ConsultationDto>();
		for (CrConsulView entity : listView) {
			ConsultationDto dto = new ConsultationDto();
			list.add((ConsultationDto)util.getObjectCopyValue(dto, entity));
		}
		logger.infoCode("I0002", "findConsulList"); // I0002=メソッド終了:{0}
		return list;
	}

	/**
	 * 面談一覧取得（相談員）
	 *
	 * @param userInfo
	 * @return
	 */
	public List<ConsultationDto> findConsulAdvicerList(UserInfo userInfo) {
		logger.infoCode("I0001", "findConsulAdvicerList"); // I0001=メソッド開始:{0}

		// キャリア相談実績
		ObjectUtil util = new ObjectUtil();

		// 取得条件：相談員
		Specification<CrConsulAdvView> whereAdvicerUserKey = new Specification<CrConsulAdvView>() {
			@Override
			public Predicate toPredicate(Root<CrConsulAdvView> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				Predicate predicate = cb.conjunction();
				predicate = cb.equal(root.get("kbn"), "ADVICER");
				predicate = cb.and(predicate, cb.equal(root.get("advicerUserKey"), userInfo.getTargetUserKey()));
				return predicate;
			}
		};

		// 取得条件：公開者
		Specification<CrConsulAdvView> wherePublicAdvicer = new Specification<CrConsulAdvView>() {
			@Override
			public Predicate toPredicate(Root<CrConsulAdvView> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				Predicate predicate = cb.conjunction();
				predicate = cb.equal(root.get("kbn"), "PUBLIC");
				predicate = cb.and(predicate, cb.equal(root.get("publicUserKey"), userInfo.getTargetUserKey()));
				return predicate;
			}
		};

		// 検索処理
		List<CrConsulAdvView> listView = crConsulAdvViewRepository.findAll(
				Specifications.where(whereAdvicerUserKey).or(wherePublicAdvicer), this.orderByForConsulList());

		// 一覧リスト生成
		List<ConsultationDto> list = new ArrayList<ConsultationDto>();
		for (CrConsulAdvView entity : listView) {
			ConsultationDto dto = new ConsultationDto();
			list.add((ConsultationDto)util.getObjectCopyValue(dto, entity));
		}
		logger.infoCode("I0002", "findConsulAdvicerList"); // I0002=メソッド終了:{0}
		return list;
	}

	/**
	 * 面談一覧（事務局）
	 *
	 * @param form
	 * @param locale
	 * @return
	 */
	public List<ConsultationDto> findConsulMgmtList(ConsultationForm form, Locale locale) {
		logger.infoCode("I0001", "findConsulMgmtList"); // I0001=メソッド開始:{0}
		ObjectUtil util = new ObjectUtil();

		// 取得条件：キーワード
		Specification<CrConsulMgmtView> whereKeyword = StringUtil.isNull(form.getSearchKeyword()) ? null
				: new Specification<CrConsulMgmtView>() {

			@Override
			public Predicate toPredicate(Root<CrConsulMgmtView> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.like(root.get("keyword"), "%" + form.getSearchKeyword() + "%");
			}
		};

		// 取得条件：組織コード
		Specification<CrConsulMgmtView> wherePartyCode = StringUtil.isNull(form.getSearchParty()) ? null
				: new Specification<CrConsulMgmtView>() {

			@Override
			public Predicate toPredicate(Root<CrConsulMgmtView> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.get("partyCode"), form.getSearchParty());
			}
		};

		// 取得条件：状態
		Specification<CrConsulMgmtView> whereStatus = StringUtil.isNull(form.getSearchStatus()) ? null
				: new Specification<CrConsulMgmtView>() {

			@Override
			public Predicate toPredicate(Root<CrConsulMgmtView> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				String[] statusArray = form.getSearchStatusArray();
				List<String> statusArrayList = new ArrayList<>(Arrays.asList(statusArray));
				return cb.and(root.get("consultationStatus").in(statusArrayList));
			}
		};

		// 検索処理
		List<CrConsulMgmtView> listView = crConsulMgmtViewRepository.findAll(
				Specifications.where(whereKeyword).and(wherePartyCode).and(whereStatus),this.orderByForConsulList());

		// 一覧リスト生成
		List<ConsultationDto> list = new ArrayList<ConsultationDto>();
		for (CrConsulMgmtView entity : listView) {
			ConsultationDto dto = new ConsultationDto();
			list.add((ConsultationDto)util.getObjectCopyValue(dto, entity));
		}

		logger.infoCode("I0002", "findConsulMgmtList"); // I0002=メソッド終了:{0}
		return list;
	}

	/**
	 * 面談内容詳細取得
	 *
	 * @param consultationKey
	 * @return
	 */
	public ConsultationDto findConsul(String consultationKey) {
		logger.infoCode("I0001", "findConsul"); // I0001=メソッド開始:{0}
		ObjectUtil util = new ObjectUtil();

		// キャリア相談実績・検索処理
		CrConsulView entity = crConsulViewRepository.findOne(consultationKey);

		// 一覧リスト生成
		ConsultationDto dto = new ConsultationDto();
		dto = (ConsultationDto)util.getObjectCopyValue(dto, entity);

		logger.infoCode("I0002", "findConsul"); // I0002=メソッド終了:{0}
		return dto;
	}

	/**
	 * 全相談員リストの取得
	 *
	 * @param locale
	 * @return
	 */
	public List<AdvicerDto> findAllAdvicer(Locale locale) {
		logger.infoCode("I0001", "findAllAdvicer");

		// ソート条件
		Sort orderBy;
		if (CommonConst.DEFAULT_LOCALE.getLanguage().equals(locale.getLanguage())) {
			orderBy = new Sort("userFamilyName").and(new Sort("userMiddleName")).and(new Sort("userName"));
		}else{
			orderBy = new Sort("userFamilyNameEn").and(new Sort("userMiddleNameEn")).and(new Sort("userNameEn"));
		}

		// 相談員リスト・検索処理
		List<AdvicerView> entityList = advicerViewRepository.findAll(null ,orderBy);

		// 一覧リスト生成
		ObjectUtil util = new ObjectUtil();
		List<AdvicerDto> dtoList = new ArrayList<>();
		for (AdvicerView entity : entityList) {
			AdvicerDto dto = new AdvicerDto();
			dto = (AdvicerDto) util.getObjectCopyValue(dto, entity);
			if (!CommonConst.DEFAULT_LOCALE.getLanguage().equals(locale.getLanguage())) {
				dto.setUserFamilyName(entity.getUserFamilyNameEn());
				dto.setUserMiddleName(entity.getUserMiddleNameEn());
				dto.setUserName(entity.getUserNameEn());
				dto.setPartyName(entity.getPartyNameEn());
				dto.setPartyNameAbbr(entity.getPartyNameAbbrEn());
			}
			dtoList.add(dto);
		}

		logger.infoCode("I0002", "findAllAdvicer");
		return dtoList;
	}

	/**
	 * 共有者リストの取得
	 *
	 * @param advicerArray
	 * @param locale
	 * @param userInfo
	 * @return
	 */
	public List<AdvicerDto> getPublicAdvicer(String[] advicerArray, Locale locale, UserInfo userInfo) {
		logger.infoCode("I0001", "getPublicAdvicer");

		// 取得条件：ユーザキー（共有者）
		Specification<AdvicerView> whereUserKey = new Specification<AdvicerView>() {

			@Override
			public Predicate toPredicate(Root<AdvicerView> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				List<String> publicUserList = new ArrayList<String>(Arrays.asList(advicerArray));
				if (advicerArray.length == 0) {
					return cb.equal(root.get("userKey"), "");
				}else{
					return cb.and(root.get("userKey").in(publicUserList));
				}
			}
		};

		// 検索処理
		List<AdvicerDto> list = this.getPublicAdvicerEx(whereUserKey, locale, userInfo);
		logger.infoCode("I0002", "findAllAdvicer");
		return list;
	}

	/**
	 * 組織の事務局ユーザ取得
	 *
	 * @param userKey
	 * @param locale
	 * @return
	 */
	public List<UsUserTbl> findMgmtUser(String userKey, Locale locale) {
		logger.infoCode("I0001", "findMgmtUser");

		// ユーザ情報を取得する
		UsUserTbl targetUser = usUserTblRepository.findOne(userKey);

		// 取得条件：組織コード
		Specification<UsUserTbl> wherePartyCode = new Specification<UsUserTbl>() {
			@Override
			public Predicate toPredicate(Root<UsUserTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.get("partyCode"), targetUser.getPartyCode());
			}
		};

		// 取得条件：ロール
		Specification<UsUserTbl> whereRole = new Specification<UsUserTbl>() {
			@Override
			public Predicate toPredicate(Root<UsUserTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				List<String> list = new ArrayList<>();
				list.add(CommonConst.ROLE_CODE_MGMT1);	// 運営協議会事務局
				list.add(CommonConst.ROLE_CODE_MGMT2);	// 共同実施機関窓口（山大・徳大）
				list.add(CommonConst.ROLE_CODE_MGMT3);	// 連携大学
				return cb.and(root.join("usUserRelRoleTbls").get("id").get("roleCode").in(list));
			}
		};

		// 検索処理
		List<UsUserTbl> list = usUserTblRepository.findAll(Specifications.where(wherePartyCode).and(whereRole));

		// 重複除去
		List<UsUserTbl> listDistinct = new ArrayList<UsUserTbl>();
		if (list != null) {
			listDistinct = list.stream().distinct().collect(Collectors.toList());
		}

		logger.infoCode("I0002", "findMgmtUser");
		return listDistinct;
	}

	/**
	 * 共有者リストの取得
	 *
	 * @param consultationKey
	 * @param locale
	 * @param userInfo
	 * @return
	 */
	public List<AdvicerDto> getPublicAdvicer(String consultationKey, Locale locale, UserInfo userInfo) {
		logger.infoCode("I0001", "getPublicAdvicer");

		// キャリア相談実績の取得
		CrConsulTbl crConsulEntity = crConsulTblRepository.findOne(consultationKey);

		// 取得条件：ユーザキー（共有者）
		Specification<AdvicerView> whereUserKey = new Specification<AdvicerView>() {

			@Override
			public Predicate toPredicate(Root<AdvicerView> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				List<String> publicUserList = new ArrayList<String>();
				for (CrConsulPublicUserTbl publicUserEntity : crConsulEntity.getCrConsulPublicUserTbls()) {
					publicUserList.add(publicUserEntity.getUsUserTbl().getUserKey());
				}
				if (crConsulEntity.getCrConsulPublicUserTbls().size() == 0) {
					return cb.equal(root.get("userKey"), "");
				}else{
					return cb.and(root.get("userKey").in(publicUserList));
				}
			}
		};

		// 検索処理
		List<AdvicerDto> list = this.getPublicAdvicerEx(whereUserKey, locale, userInfo);
		logger.infoCode("I0002", "findAllAdvicer");
		return list;
	}

	/**
	 * 非公開者リストの取得
	 *
	 * @param consultationKey
	 * @param locale
	 * @param userInfo
	 * @return
	 */
	public List<AdvicerDto> getNotPublicAdvicer(String consultationKey, Locale locale, UserInfo userInfo) {
		logger.infoCode("I0001", "getNotPublicAdvicer");
		// キャリア相談実績の取得
		CrConsulTbl crConsulEntity = crConsulTblRepository.findOne(consultationKey);

		// 取得条件：ユーザキー（共有者）
		Specification<AdvicerView> whereUserKey = new Specification<AdvicerView>() {

			@Override
			public Predicate toPredicate(Root<AdvicerView> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				List<String> publicUserList = new ArrayList<String>();
				for (CrConsulPublicUserTbl publicUserEntity : crConsulEntity.getCrConsulPublicUserTbls()) {
					publicUserList.add(publicUserEntity.getUsUserTbl().getUserKey());
				}
				publicUserList.add(userInfo.getTargetUserKey());
				return cb.not(root.get("userKey").in(publicUserList));
			}
		};

		// 検索処理
		List<AdvicerDto> list = this.getPublicAdvicerEx(whereUserKey, locale, userInfo);
		logger.infoCode("I0002", "getNotPublicAdvicer");
		return list;
	}

	/**
	 * 公開者/非公開者リストの取得
	 *
	 * @param whereUserKey
	 * @param locale
	 * @param userInfo
	 * @return
	 */
	private List<AdvicerDto> getPublicAdvicerEx(Specification<AdvicerView> whereUserKey, Locale locale, UserInfo userInfo) {
		logger.infoCode("I0001", "getPublicAdvicerEx");

		// ソート条件
		Sort orderBy;
		if (CommonConst.DEFAULT_LOCALE.getLanguage().equals(locale.getLanguage())) {
			orderBy = new Sort("userFamilyName").and(new Sort("userMiddleName")).and(new Sort("userName"));
		}else{
			orderBy = new Sort("userFamilyNameEn").and(new Sort("userMiddleNameEn")).and(new Sort("userNameEn"));
		}

		// 共有者リスト検索処理
		List<AdvicerView> entityList = advicerViewRepository.findAll(Specifications.where(whereUserKey), orderBy);

		// 一覧リスト生成
		ObjectUtil util = new ObjectUtil();
		List<AdvicerDto> dtoList = new ArrayList<>();
		for (AdvicerView entity : entityList) {
			AdvicerDto dto = new AdvicerDto();
			dto = (AdvicerDto) util.getObjectCopyValue(dto, entity);
			if (!CommonConst.DEFAULT_LOCALE.getLanguage().equals(locale.getLanguage())) {
				dto.setUserFamilyName(entity.getUserFamilyNameEn());
				dto.setUserMiddleName(entity.getUserMiddleNameEn());
				dto.setUserName(entity.getUserNameEn());
				dto.setPartyName(entity.getPartyNameEn());
				dto.setPartyNameAbbr(entity.getPartyNameAbbrEn());
			}
			dtoList.add(dto);
		}

		logger.infoCode("I0002", "getPublicAdvicerEx");
		return dtoList;
	}

	/**
	 * 組織情報(大学)のリストを取得する（コード・名称）
	 *
	 * @param locale
	 * @return
	 */
	public List<MsPartyTbl> getPartyUnivList(Locale locale) {
		logger.infoCode("I0001", "getPartyUnivList");

		// 検索条件：組織区分
		Specification<MsPartyTbl> wherePartyKbn =  new Specification<MsPartyTbl>() {
			@Override
			public Predicate toPredicate(Root<MsPartyTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				List<String> list = new ArrayList<>();
				list.add(PARTY_KBN_UNIV_NATIONAL);
				list.add(PARTY_KBN_UNIV_PRIVATE);
				return cb.and(root.get("partyKbn").in(list));
			}
		};

		// ソート条件
		Sort orderBy = new Sort("partyCode");

		// 検索処理
		List<MsPartyTbl> list = msPartyTblRepository.findAll(
				Specifications.where(wherePartyKbn), orderBy);

		// ロケール変換
		if (!CommonConst.DEFAULT_LOCALE.getLanguage().equals(locale.getLanguage())) {
			for (MsPartyTbl entity : list) {
				entity.setPartyName(entity.getPartyNameEn());
			}
		}

		logger.infoCode("I0002", "getPartyUnivList");
		return list;
	}

	/**
	 * 登録処理（面談依頼）
	 *
	 * @param form
	 * @param userInfo
	 * @param locale
	 * @throws Exception
	 */
	@Transactional
	public void registRequest(ConsultationForm form, UserInfo userInfo, Locale locale) throws Exception {
		logger.infoCode("I0001", "registRequest"); // I0001=メソッド開始:{0}

		// キャリア相談実績情報の登録処理：相談者
		if (!this.insertCrConsulTbl(form, userInfo, locale)){
			throw new Exception();
		}

		String title = form.getRequestKbnName() + TITLE_DELIMITER + messageSource.getMessage(TITLE_REQUEST, null, locale);
		if (StringUtil.isNotNull(form.getAdvicerUserKey())) {

			// ユーザお知らせ情報の登録処理：相談員
			if (!this.insertUsInfoTbl(form.getAdvicerUserKey(), form, userInfo, title, URL_SETTING, locale)){
				throw new Exception();
			}
		}else{

			// ユーザお知らせ情報の登録処理：相談者組織
			List<UsUserTbl> userList = this.findMgmtUser(userInfo.getTargetUserKey(), locale);
			for (UsUserTbl user : userList) {
				if (!this.insertUsInfoTbl(user.getUserKey(), form, userInfo, title, URL_MGMT + URL_SETTING, locale)){
					throw new Exception();
				}
			}
		}

		crConsulTblRepository.flush();
		usInfoTblRepository.flush();
		logger.infoCode("I0002", "registRequest"); // I0002=メソッド終了:{0}
	}

	/**
	 * 更新処理（面談設定）
	 *
	 * @param form
	 * @param userInfo
	 * @param locale
	 * @throws Exception
	 */
	@Transactional
	public void registSetting(ConsultationForm form, UserInfo userInfo, Locale locale) throws Exception {
		logger.infoCode("I0001", "registSetting"); // I0001=メソッド開始:{0}

		// キャリア相談実績情報の更新処理
		if (!this.updateCrConsulTblForSetting(form, userInfo)){
			throw new Exception();
		}

		// ユーザスケジュールの削除処理
		if (!this.deleteUsScheduleTbl(form.getConsultationKey())) {
			throw new Exception();
		}

		// ユーザスケジュールの登録処理：相談者
		if (!insertUsScheduleTbl(form.getUserKey(), form, userInfo)){
			throw new Exception();
		}

		// ユーザお知らせ情報の登録処理：相談者
		String title = form.getRequestKbnName() + TITLE_DELIMITER + messageSource.getMessage(TITLE_SETTING, null, locale);
		if (!this.insertUsInfoTbl(form.getUserKey(), form, userInfo, title, URL_DETAIL, locale)){
			throw new Exception();
		}

		// ユーザお知らせ情報の登録処理：相談者組織
		List<UsUserTbl> userList = this.findMgmtUser(form.getUserKey(), locale);
		for (UsUserTbl user : userList) {
			if (!this.insertUsInfoTbl(user.getUserKey(), form, userInfo, title, URL_MGMT + URL_SETTING, locale)){
				throw new Exception();
			}
		}

		if (StringUtil.isNotNull(form.getAdvicerUserKey())) {

			// ユーザスケジュールの登録処理：相談員
			if (!this.insertUsScheduleTbl(form.getAdvicerUserKey(), form, userInfo)){
				throw new Exception();
			}

			// ユーザお知らせ情報の登録処理：相談員
			if (!this.insertUsInfoTbl(form.getAdvicerUserKey(), form, userInfo, title, URL_SETTING, locale)){
				throw new Exception();
			}
		}

		crConsulTblRepository.flush();
		usScheduleTblRepository.flush();
		usInfoTblRepository.flush();

		logger.infoCode("I0002", "registSetting"); // I0002=メソッド終了:{0}
	}

	/**
	 * 更新処理（面談結果）
	 *
	 * @param form
	 * @param userInfo
	 * @param locale
	 * @throws Exception
	 */
	@Transactional
	public void registResult(ConsultationForm form, UserInfo userInfo, Locale locale) throws Exception {
		logger.infoCode("I0001", "registResult"); // I0001=メソッド開始:{0}

		// キャリア相談実績情報の更新処理
		if (!this.updateCrConsulTblForResult(form, userInfo)){
			throw new Exception();
		}

		// キャリア相談公開者の削除処理
		if (!this.deleteCrConsulPublicUserTbl(form.getConsultationKey())) {
			throw new Exception();
		}

		// キャリア相談公開者の登録処理
		if (!this.insertCrConsulPublicUserTbl(form, userInfo)) {
			throw new Exception();
		}

		// ユーザお知らせ情報の登録処理：共有者
		String title = form.getRequestKbnName() + TITLE_DELIMITER + messageSource.getMessage(TITLE_RESULT, null, locale);
		for (String userKey : form.getPublicAdvicerArray()) {
			if (StringUtil.isNotNull(userKey)) {
				if (!this.insertUsInfoTbl(userKey, form, userInfo, title, URL_SETTING, locale)){
					throw new Exception();
				}
			}
		}

		crConsulTblRepository.flush();
		crConsulPublicUserTblRepository.flush();
		usInfoTblRepository.flush();
		logger.infoCode("I0002", "registResult"); // I0002=メソッド終了:{0}
	}

	/**
	 * 削除処理（面談一覧）
	 *
	 * @param consultationKey
	 * @param updDate
	 * @throws Exception
	 */
	@Transactional
	public void registDelete(String consultationKey, Timestamp updDate) throws Exception {
		logger.infoCode("I0001", "registDelete"); // I0001=メソッド開始:{0}

		// ユーザスケジュールの削除処理
		if (!this.deleteUsScheduleTbl(consultationKey)) {
			throw new Exception();
		}

		// キャリア相談実績の削除処理
		if (!this.deleteCrConsulTbl(consultationKey, updDate)) {
			throw new Exception();
		}

		crConsulPublicUserTblRepository.flush();
		crConsulTblRepository.flush();
		usScheduleTblRepository.flush();
		logger.infoCode("I0002", "registDelete"); // I0002=メソッド終了:{0}
	}

	/**
	 * キャリア相談実績取得（P-Key、データ更新日）
	 *
	 * @param consultationKey
	 * @param updDate
	 * @return
	 */
	private CrConsulTbl getCrConsulForUpdate(final String consultationKey, final Timestamp updDate) {
		logger.infoCode("I0001", "getCrConsulForUpdate"); // I0001=メソッド開始:{0}

		// 条件：キー
		Specification<CrConsulTbl> wherePkKey = (StringUtil.isNull(consultationKey)) ? null
				: new Specification<CrConsulTbl>() {
			@Override
			public Predicate toPredicate(Root<CrConsulTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.and(cb.equal(root.get("consultationKey"), consultationKey));
			}
		};
		// 条件：データ更新日
		Specification<CrConsulTbl> whereUpdDate = DateUtil.isNull(updDate) ? null
				: new Specification<CrConsulTbl>() {
			@Override
			public Predicate toPredicate(Root<CrConsulTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.get("updDate"), updDate);
			}
		};

		CrConsulTbl c = crConsulTblRepository.findOne(Specifications.where(wherePkKey).and(whereUpdDate));

		logger.infoCode("I0002", "getCrConsulForUpdate"); // I0002=メソッド終了:{0}
		return c;
	}

	/**
	 * キャリア相談実績の新規登録
	 *
	 * @param form
	 * @param userInfo
	 * @param locale
	 * @return
	 */
	private boolean insertCrConsulTbl(ConsultationForm form, UserInfo userInfo, Locale locale) {
		logger.infoCode("I0001", "insertCrConsulTbl"); // I0001=メソッド開始:{0}
		try {

			// 登録情報の編集
			CrConsulTbl entity = new CrConsulTbl();
			entity.setUserKey(userInfo.getTargetUserKey());				// ユーザキー
			entity.setConsultationInsDate(DateUtil.getNowTimestamp());	// 面談依頼登録日
			entity.setRequestKbn(form.getRequestKbn());					// 依頼内容区分
			entity.setConsultationKbn(form.getConsultationKbn());		// 相談項目区分
			entity.setUserMemo(form.getUserMemo());						// 相談者メモー
			entity.setConsultationStatus(CODE_CONSUL_STATUS_NEW);		// 相談状態
			if ((CODE_ADVICER_NEED.equals(form.getAdvicerKbn())) && StringUtil.isNotNull(form.getAdvicerUserKey())) {
				entity.setAdvicerUserKey(form.getAdvicerUserKey());		// 相談者
			}
			entity.setUpdDate(DateUtil.getNowTimestamp());				// データ更新日
			entity.setUpdUserKey(userInfo.getLoginUserKey());			// データ更新者

			// キャリア相談実績登録処理実行
			entity = crConsulTblRepository.save(entity);
			if (StringUtil.isNull(entity.getConsultationKey())){
				return false;
			}

			// 登録情報をフォームにセット
			Map<String, String> map = DbUtil.getJosuAbbrMap(CODE_REQUEST_KBN, locale);
			form.setRequestKbnName(map.get(form.getRequestKbn()));	// 依頼内容
			form.setConsultationKey(entity.getConsultationKey());	// 面談依頼キー

			logger.infoCode("I0002", "insertCrConsulTbl"); // I0002=メソッド終了:{0}
			return true;
		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
		}
		return false;
	}

	/**
	 * キャリア相談公開者の新規登録
	 *
	 * @param form
	 * @param userInfo
	 * @return
	 */
	private boolean insertCrConsulPublicUserTbl(ConsultationForm form, UserInfo userInfo) {
		logger.infoCode("I0001", "insertCrConsulPublicUserTbl"); // I0001=メソッド開始:{0}
		try {

			// 登録情報の編集
			for (String userKey : form.getPublicAdvicerArray()) {
				if (StringUtil.isNotNull(userKey)) {
					CrConsulPublicUserTblPK pk = new CrConsulPublicUserTblPK();
					pk.setConsultationKey(form.getConsultationKey());	// 面談依頼キー
					pk.setUserKey(userKey);								// ユーザキー
					CrConsulPublicUserTbl entity = new CrConsulPublicUserTbl();
					entity.setId(pk);
					entity.setUpdDate(DateUtil.getNowTimestamp());		// データ更新日
					entity.setUpdUserKey(userInfo.getLoginUserKey());	// データ更新者

					// キャリア相談公開者の登録処理
					entity = crConsulPublicUserTblRepository.save(entity);
					if (StringUtil.isNull(entity.getId().getConsultationKey()) || StringUtil.isNull(entity.getId().getUserKey())){
						return false;
					}
				}
			}
			logger.infoCode("I0002", "insertCrConsulPublicUserTbl"); // I0002=メソッド終了:{0}
			return true;
		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
		}
		return false;
	}

	/**
	 * キャリア相談実績情報の更新処理（面談設定）
	 *
	 * @param form
	 * @param userInfo
	 * @return
	 */
	private boolean updateCrConsulTblForSetting(ConsultationForm form, UserInfo userInfo) {
		logger.infoCode("I0001", "updateCrConsulTblForSetting"); // I0001=メソッド開始:{0}
		try {

			// キャリア面談実績取得
			CrConsulTbl entity = this.getCrConsulForUpdate(form.getConsultationKey(), form.getUpdDate());
			if (entity == null) {
				logger.errorCode("E1001", "CrConsulTbl"); // E1001={0}は別のユーザーによって更新されている為、更新できませんでした。
				return false;
			}

			// 更新情報の編集
			entity.setConsultationUserKey(userInfo.getTargetUserKey());		// 面談設定者
			entity.setConsultationDate(DateUtil.getTimestamp(form.getConsultationDate(), CommonConst.DEFAULT_YYYYMMDD));	// 面談日
			entity.setConsultationStart(form.getConsultationStart());		// 面談時間開始
			entity.setConsultationEnd(form.getConsultationEnd());			// 面談時間終了
			entity.setConsultationRoom(form.getConsultationRoom());			// 面談場所
			entity.setConsultationOrganization(form.getConsultationOrganization());	// 担当窓口
			entity.setConsultationTelno(form.getConsultationTelno());		// 連絡先
			entity.setConsultationStatus(CODE_CONSUL_STATUS_SET);			// 相談状態
			entity.setAdvicerUserKey(form.getAdvicerUserKey());				// 相談者
			entity.setUpdDate(DateUtil.getNowTimestamp());					// データ更新日
			entity.setUpdUserKey(userInfo.getLoginUserKey());				// データ更新者

			// キャリア相談実績更新処理実行
			entity = crConsulTblRepository.save(entity);
			if (StringUtil.isNull(entity.getConsultationKey())){
				return false;
			}

			logger.infoCode("I0002", "updateCrConsulTblForSetting"); // I0002=メソッド終了:{0}
			return true;

		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
		}
		return false;
	}

	/**
	 * キャリア相談実績情報の更新処理（面談結果）
	 *
	 * @param form
	 * @param userInfo
	 * @return
	 */
	private boolean updateCrConsulTblForResult(ConsultationForm form, UserInfo userInfo) {
		logger.infoCode("I0001", "updateCrConsulTblForResult"); // I0001=メソッド開始:{0}

		try {
			// キャリア面談実績取得
			CrConsulTbl entity = this.getCrConsulForUpdate(form.getConsultationKey(), form.getUpdDate());
			if (entity == null) {
				logger.errorCode("E1001", "CrConsulTbl"); // E1001={0}は別のユーザーによって更新されている為、更新できませんでした。
				return false;
			}

			// 更新情報の編集
			entity.setConsultationMemo(form.getConsultationMemo());
			entity.setConsultationStatus(CODE_CONSUL_STATUS_END);
			entity.setUpdDate(DateUtil.getNowTimestamp());
			entity.setUpdUserKey(userInfo.getLoginUserKey());

			// キャリア相談実績更新処理実行
			entity = crConsulTblRepository.save(entity);
			if (StringUtil.isNull(entity.getConsultationKey())){
				return false;
			}

			logger.infoCode("I0002", "updateCrConsulTblForResult"); // I0002=メソッド終了:{0}
			return true;

		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
		}
		return false;
	}

	/**
	 * キャリア相談実績情報/キャリア相談公開者情報の削除
	 *
	 * @param consultationKey
	 * @param updDate
	 * @return
	 */
	private boolean deleteCrConsulTbl(String consultationKey, Timestamp updDate) {
		logger.infoCode("I0001", "deleteCrConsulTbl"); // I0001=メソッド開始:{0}
		try {

			// キャリア相談実績の取得
			CrConsulTbl entity = this.getCrConsulForUpdate(consultationKey, updDate);
			if (entity == null) {
				logger.errorCode("E1001", "CrConsulTbl"); // E1001={0}は別のユーザーによって更新されている為、更新できませんでした。
				logger.errorCode("E1009"); // E1009=削除に失敗しました。{0}
				return false;
			}else{

				// キャリア相談公開者の削除
				crConsulPublicUserTblRepository.delete(entity.getCrConsulPublicUserTbls());

				// キャリア相談実績の削除
				int cnt = crConsulTblRepository.delete(consultationKey, updDate);
				if (cnt == 0) {
					return false;
				}
			}
			logger.infoCode("I0002", "deleteCrConsulTbl"); // I0002=メソッド終了:{0}
			return true;

		} catch (Exception e) {
			logger.errorCode("E1009", e); // E1009=削除に失敗しました。{0}
		}
		return false;
	}

	/**
	 * キャリア相談公開者情報の削除
	 *
	 * @param consultationKey
	 * @return
	 */
	private boolean deleteCrConsulPublicUserTbl(String consultationKey) {
		logger.infoCode("I0001", "deleteCrConsulPublicUserTbl"); // I0001=メソッド開始:{0}
		try {

			// キャリア相談実績の取得
			CrConsulTbl entity = crConsulTblRepository.getOne(consultationKey);
			// キャリア相談公開者の削除
			crConsulPublicUserTblRepository.delete(entity.getCrConsulPublicUserTbls());
			logger.infoCode("I0002", "deleteCrConsulPublicUserTbl"); // I0002=メソッド終了:{0}
			return true;

		} catch (Exception e) {
			logger.errorCode("E1009", e); // E1009=削除に失敗しました。{0}
		}
		return false;
	}

	/**
	 * ユーザスケジュールの削除
	 *
	 * @param consultationKey
	 * @return
	 */
	private boolean deleteUsScheduleTbl(String consultationKey) {
		logger.infoCode("I0001", "deleteUsScheduleTbl"); // I0001=メソッド開始:{0}
		try {

			// ユーザスケジュールの取得（参照キー）
			Specification<UsScheduleTbl> whereScheduleRefKey = new Specification<UsScheduleTbl>() {
				@Override
				public Predicate toPredicate(Root<UsScheduleTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
					return cb.and(cb.equal(root.get("schduleRefKey"), consultationKey));
				}
			};
			List<UsScheduleTbl> c = usScheduleTblRepository.findAll(Specifications.where(whereScheduleRefKey));

			// ユーザスケジュールの削除
			usScheduleTblRepository.delete(c);
			logger.infoCode("I0002", "deleteUsScheduleTbl"); // I0002=メソッド終了:{0}
			return true;

		} catch (Exception e) {
			logger.errorCode("E1009", e); // E1009=削除に失敗しました。{0}
		}
		return false;
	}

	/**
	 * ユーザスケジュールの登録
	 *
	 * @param userKey
	 * @param form
	 * @param userInfo
	 * @return
	 */
	private boolean insertUsScheduleTbl(String userKey, ConsultationForm form, UserInfo userInfo) {
		logger.infoCode("I0001", "insertUsScheduleTbl="+userKey); // I0001=メソッド開始:{0}
		try {

			// ユーザスケジュールの編集
			UsScheduleTbl entity = new UsScheduleTbl();
			UsUserTbl usUserTbl = new UsUserTbl();
			usUserTbl.setUserKey(userKey);
			entity.setUsUserTbl(usUserTbl);						// ユーザキー
			entity.setSuhduleDate(DateUtil.getNowTimestamp());	// スケジュール日付
			entity.setStartTime(form.getConsultationStart());	// 開始時間
			entity.setEndTime(form.getConsultationEnd());		// 終了時間
			entity.setTitle(form.getRequestKbnName());			// タイトル
			entity.setDataKbn(CommonConst.INFO_DATA_KBN_INTERVIEW);			// データ区分
			entity.setSchduleRefKey(form.getConsultationKey());	// 参照キー
			entity.setMakeUserKey(userInfo.getLoginUserKey());	// 作成ユーザキー
			entity.setUpdDate(DateUtil.getNowTimestamp());		// データ更新日
			entity.setUpdUserKey(userInfo.getLoginUserKey());	// データ更新者

			// ユーザスケジュールの登録処理
			entity = usScheduleTblRepository.save(entity);
			if (StringUtil.isNull(entity.getSuhduleKey())){
				return false;
			}

			logger.infoCode("I0002", "insertUsScheduleTbl"); // I0002=メソッド終了:{0}
			return true;

		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
		}
		return false;
	}

	/**
	 * ユーザお知らせ情報の登録
	 *
	 * @param userKey
	 * @param form
	 * @param userInfo
	 * @param opeKbn
	 * @param url
	 * @return
	 */
	private boolean insertUsInfoTbl(String userKey, ConsultationForm form, UserInfo userInfo, String title, String url, Locale locale) {
		logger.infoCode("I0001", "insertUsInfoTbl"); // I0001=メソッド開始:{0}
		try {

			// ユーザお知らせ情報の編集
			UsInfoTbl entity = new UsInfoTbl();
			UsUserTbl usUserTbl = new UsUserTbl();
			usUserTbl.setUserKey(userKey);
			entity.setUsUserTbl(usUserTbl);							// ユーザキー
			entity.setSendDate(DateUtil.getNowTimestamp());			// 配信日
			entity.setTitle(title);									// タイトル
			entity.setDataKbn(CommonConst.INFO_DATA_KBN_INTERVIEW);	// データ区分
			entity.setOpeKbn(CommonConst.OP_ACTION_ADDED);			// 操作区分
			entity.setInfoRefKey(form.getConsultationKey());		// 参照キー
			entity.setUrl(url + form.getConsultationKey());			// リンク先
			entity.setMakeUserKey(userInfo.getLoginUserKey());		// 作成ユーザキー
			entity.setUpdDate(DateUtil.getNowTimestamp());			// データ更新日
			entity.setUpdUserKey(userInfo.getLoginUserKey());		// データ更新者

			// ユーザお知らせ情報の登録処理
			entity = usInfoTblRepository.save(entity);
			if (StringUtil.isNull(entity.getInfoKey())){
				return false;
			}

			logger.infoCode("I0002", "insertUsInfoTbl"); // I0002=メソッド終了:{0}
			return true;

		} catch (Exception e) {
			e.printStackTrace();
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
		}
		return false;
	}

	/**
	 * メール送信（面談依頼）
	 *
	 * @param form
	 * @param userInfo
	 * @param locale
	 * @throws Exception
	 */
	public void sendMailRequest(ConsultationForm form, UserInfo userInfo, Locale locale) throws Exception{
		logger.infoCode("I0001", "sendMailRequest"); // I0001=メソッド開始:{0}

		String title = messageSource.getMessage("consultation.title", null, locale);
		String action = messageSource.getMessage("consultation.request.title", null, locale);
		String url;

		if (StringUtil.isNotNull(form.getAdvicerUserKey())) {

			// メール送信処理（相談員）
			UsUserTbl userEntity = userServiceImpl.findOne(form.getAdvicerUserKey());
			url = URL_SETTING + form.getConsultationKey();
			// メール送信処理
			if (!mailServiceImpl.consultation(this.editUserName(userEntity, locale), title, action, userEntity.getMailAddress(), url, locale)) {
				logger.infoCode("I0002", "sendMailRequest"); // I0002=メソッド終了:{0}
				throw new Exception();
			}
		}else{

			// メール送信処理（事務局）
			url = URL_MGMT + URL_SETTING + form.getConsultationKey();
			this.sendMailMgmt(userInfo.getTargetUserKey(), title, action, url, locale);
		}
		logger.infoCode("I0002", "sendMailRequest"); // I0002=メソッド終了:{0}
	}

	/**
	 * メール送信（面談設定）
	 *
	 * @param form
	 * @param locale
	 * @throws Exception
	 */
	public void sendMailSetting(ConsultationForm form, Locale locale) throws Exception{
		logger.infoCode("I0001", "sendMailSetting"); // I0001=メソッド開始:{0}

		String title = messageSource.getMessage("consultation.title", null, locale);
		String actoin = messageSource.getMessage("consultation.setting.title", null, locale);
		String url;

		// メール送信処理（相談者）
		UsUserTbl userEntity = null;
		userEntity = userServiceImpl.findOne(form.getUserKey());
		url = URL_DETAIL + form.getConsultationKey();
		if (!mailServiceImpl.consultation(this.editUserName(userEntity, locale), title, actoin, userEntity.getMailAddress(), url, locale)) {
			logger.infoCode("I0002", "sendMailSetting"); // I0002=メソッド終了:{0}
			throw new Exception();
		}

		// メール送信処理（相談員）
		userEntity = userServiceImpl.findOne(form.getAdvicerUserKey());
		url = URL_SETTING + form.getConsultationKey();
		if (!mailServiceImpl.consultation(this.editUserName(userEntity, locale), title, actoin, userEntity.getMailAddress(), url, locale)) {
			logger.infoCode("I0002", "sendMailSetting"); // I0002=メソッド終了:{0}
			throw new Exception();
		}

		// メール送信処理（事務局）
		url = URL_MGMT + URL_SETTING + form.getConsultationKey();
		this.sendMailMgmt(form.getUserKey(), title, actoin, url, locale);
		logger.infoCode("I0002", "sendMailSetting"); // I0002=メソッド終了:{0}
	}

	/**
	 * メール送信（面談結果）
	 *
	 * @param form
	 * @param locale
	 * @throws Exception
	 */
	public void sendMailResult(ConsultationForm form, Locale locale) throws Exception{
		logger.infoCode("I0001", "sendMailResult"); // I0001=メソッド開始:{0}

		String title = messageSource.getMessage("consultation.title", null, locale);
		String actoin = messageSource.getMessage( "consultation.result.title", null, locale);
		String url = URL_RESULT + form.getConsultationKey();

		// 共有者
		for (String userKey : form.getPublicAdvicerArray()) {

			// メール送信処理
			UsUserTbl userEntity = userServiceImpl.findOne(userKey);
			if (userEntity != null) {
				if (!mailServiceImpl.consultation(this.editUserName(userEntity, locale), title, actoin, userEntity.getMailAddress(), url, locale)) {
					logger.infoCode("I0002", "sendMailResult"); // I0002=メソッド終了:{0}
					throw new Exception();
				}
			}
		}
		logger.infoCode("I0002", "sendMailResult"); // I0002=メソッド終了:{0}
	}

	/**
	 * メール送信（事務局）
	 *
	 * @param userKey
	 * @param title
	 * @param action
	 * @param url
	 * @param locale
	 * @throws Exception
	 */
	public void sendMailMgmt(String userKey, String title, String action, String url, Locale locale) throws Exception{
		logger.infoCode("I0001", "sendMailMgmt"); // I0001=メソッド開始:{0}

		// 事務局員
		List<UsUserTbl> list = this.findMgmtUser(userKey, locale);
		for (UsUserTbl user : list) {
			// メール送信処理
			UsUserTbl userEntity = userServiceImpl.findOne(user.getUserKey());
			// メール送信処理
			if (!mailServiceImpl.consultation(this.editUserName(userEntity, locale), title, action, user.getMailAddress(), url, locale)) {
				logger.infoCode("I0002", "sendMailMgmt"); // I0002=メソッド終了:{0}
				throw new Exception();
			}
		}
		logger.infoCode("I0002", "sendMailMgmt"); // I0002=メソッド終了:{0}
	}

	/**
	 * 画面表示項目編集
	 *
	 * @param locale
	 * @param entity
	 * @return
	 */
	public ConsultationForm getFormItem(Locale locale, ConsultationDto entity) {
		logger.infoCode("I0001", "getFormItem"); // I0001=メソッド開始:{0}
		ObjectUtil util = new ObjectUtil();

		// 定数マスタMap
		Map<String, String> codeStMap = DbUtil.getJosuAbbrMap(CODE_CONSUL_STATUS_KBN, locale);	// 相談状態
		Map<String, String> codeCnsKbnMap = DbUtil.getJosuAbbrMap(CODE_CONSUL_KBN, locale);		// 相談項目
		Map<String, String> codeReqKbnMap = DbUtil.getJosuAbbrMap(CODE_REQUEST_KBN, locale);	// 依頼内容

		ConsultationForm fm = new ConsultationForm();
		fm = (ConsultationForm)util.getObjectCopyValue(fm, entity);

		// 面談依頼キー
		fm.setConsultationKey(entity.getConsultationKey());
		// 相談状況
		if (StringUtil.isNotNull(entity.getConsultationStatus())) {
			fm.setConsultationStatusName(codeStMap.get(entity.getConsultationStatus()));
		}
		// 依頼内容
		if (StringUtil.isNotNull(entity.getRequestKbn())) {
			fm.setRequestKbnName(codeReqKbnMap.get(entity.getRequestKbn()));
		}
		// 依頼者・依頼者所属
		if (CommonConst.DEFAULT_LOCALE.getLanguage().equals(locale.getLanguage())) {
			fm.setUserName(this.editUserName(entity.getUserFamilyName(), entity.getUserMiddleName(), entity.getUserName()));
			fm.setUserNameAndParty(this.editUserName(entity.getUserFamilyName(), entity.getUserMiddleName(), entity.getUserName(), entity.getPartyName()));
			fm.setUserPartyName(entity.getPartyName());
		}else{
			fm.setUserName(this.editUserName(entity.getUserFamilyNameEn(), entity.getUserMiddleNameEn(), entity.getUserNameEn()));
			fm.setUserNameAndParty(this.editUserName(entity.getUserFamilyNameEn(), entity.getUserMiddleNameEn(), entity.getUserNameEn(), entity.getPartyNameEn()));
			fm.setUserPartyName(entity.getPartyNameEn());
		}
		// 相談項目
		if (StringUtil.isNotNull(entity.getConsultationKbn())) {
			fm.setConsultationKbnName(codeCnsKbnMap.get(entity.getConsultationKbn()));
		}
		// 依頼日
		if (DateUtil.isNotNull(entity.getConsultationInsDate())) {
			fm.setConsultationInsDate(DateUtil.getDate(entity.getConsultationInsDate(), CommonConst.DEFAULT_YYYYMMDD));
		}
		// 希望面談日時・相談内容
		if (StringUtil.isNotNull(entity.getUserMemo())) {
			fm.setUserMemo(StringUtil.nl2br(StringUtil.htmlFilter(entity.getUserMemo())));
		}
		// 面談日
		if (DateUtil.isNotNull(entity.getConsultationDate())) {
			fm.setConsultationDate(DateUtil.getDate(entity.getConsultationDate(), CommonConst.DEFAULT_YYYYMMDD));
		}
		// 面談時間
		fm.setConsultationStartEnd(entity.getConsultationStart());
		if (StringUtil.isNotNull(entity.getConsultationEnd())){
			fm.setConsultationStartEnd(fm.getConsultationStartEnd().concat("～").concat(entity.getConsultationEnd()));
		}
		fm.setConsultationStart(entity.getConsultationStart());
		fm.setConsultationEnd(entity.getConsultationEnd());
		// 面談場所
		fm.setConsultationRoom(entity.getConsultationRoom());
		// 担当相談員・ 担当相談員所属
		fm.setAdvicerUserKey(entity.getAdvicerUserKey());
		if (CommonConst.DEFAULT_LOCALE.getLanguage().equals(locale.getLanguage())) {
			fm.setAdvicerUserName(this.editUserName(entity.getUserFamilyNameAdvicer(), entity.getUserMiddleNameAdvicer(), entity.getUserNameAdvicer()));
			fm.setAdvicerUserNameAndParty(this.editUserName(entity.getUserFamilyNameAdvicer(), entity.getUserMiddleNameAdvicer(), entity.getUserNameAdvicer(), entity.getPartyNameAdvicer()));
			fm.setAdvicerPartyName(entity.getPartyNameAdvicer());
		}else{
			fm.setAdvicerUserName(this.editUserName(entity.getUserFamilyNameEnAdvicer(), entity.getUserMiddleNameEnAdvicer(), entity.getUserNameEnAdvicer()));
			fm.setAdvicerUserNameAndParty(this.editUserName(entity.getUserFamilyNameEnAdvicer(), entity.getUserMiddleNameEnAdvicer(), entity.getUserNameEnAdvicer(), entity.getPartyNameEnAdvicer()));
			fm.setAdvicerPartyName(entity.getPartyNameEnAdvicer());
		}
		// 担当窓口
		fm.setConsultationOrganization(entity.getConsultationOrganization());
		// 連絡先
		fm.setConsultationTelno(entity.getConsultationTelno());
		// 面談結果
		fm.setConsultationMemo(entity.getConsultationMemo());
		// 新規登録後１週間経過判定
		fm.setChangeBackColor(this.isPassedOneWeek(entity.getConsultationInsDate(), entity.getConsultationStatus()));
		// 写真（相談員）相談員
		fm.setAdvicerUploadKey(entity.getAdvicerUploadKey());
		// 更新日付
		fm.setUpdDate(entity.getUpdDate());
		// 更新ユーザ
		fm.setUpdUserKey(entity.getUpdUserKey());

		logger.infoCode("I0002", "getFormItem"); // I0002=メソッド終了:{0}
		return fm;
	}

	/**
	 * ユーザ名の編集（メール用）
	 *
	 * @param user
	 * @param locale
	 * @return
	 */
	public String editUserName(UsUserTbl user, Locale locale) {
		if (CommonConst.DEFAULT_LOCALE.getLanguage().equals(locale.getLanguage())) {
			return this.editUserName(user.getUserFamilyName(), user.getUserMiddleName(), user.getUserName(), "");
		}else{
			return this.editUserName(user.getUserFamilyNameEn(), user.getUserMiddleNameEn(), user.getUserNameEn(), "");
		}
	}

	 /**
	 * ユーザ名の編集（組織名なし）
	 *
	 * @param familyName 利用者姓
	 * @param middleName 利用者ミドルネーム
	 * @param name 利用者名
	 * @return
	 */
	public String editUserName(String familyName, String middleName, String name) {
		return this.editUserName(familyName, middleName, name, "");
	}

	/**
	 * 相談員名の編集（相談員検索）
	 *
	 * @param list
	 * @return
	 */
	public List<AdvicerDto> editAdvicerName(List<AdvicerDto> list){
		if (list != null) {
			for (AdvicerDto dto : list) {
				dto.setUserName(this.editUserName(dto.getUserFamilyName(), dto.getUserMiddleName(), dto.getUserName(), dto.getPartyName()));
			}
		}
		return list;
	}


	/**
	 * ユーザ名の編集（組織名あり）
	 *
	 * @param familyName 利用者姓
	 * @param middleName 利用者ミドルネーム
	 * @param name 利用者名
	 * @param partyName 組織名
	 * @return
	 */
	public String editUserName(String familyName, String middleName, String name, String partyName) {
		logger.infoCode("I0001", "editUserName"); // I0001=メソッド開始:{0}

		String str = "";
		// 利用者姓
		if (StringUtil.isNotNull(familyName)) {
			str = str.concat(familyName);
		}
		// 利用者ミドルネーム
		if (StringUtil.isNotNull(middleName)) {
			str = str.concat(" ").concat(middleName);
		}
		// 利用者名
		if (StringUtil.isNotNull(name)) {
			str = str.concat(" ").concat(name);
		}
		// 組織名称
		if (StringUtil.isNotNull(partyName)) {
			str = str.concat("（").concat(StringUtil.nvl(partyName, "")).concat("）");
		}
		logger.infoCode("I0002", "editUserName"); // I0002=メソッド終了:{0}
		return str;
	}

	/**
	 * 相談員配列情報の編集
	 *
	 * @param list
	 * @return
	 */
	public String getAdvicerText(List<AdvicerDto> list){
		logger.infoCode("I0001", "getAdvicerText"); // I0001=メソッド開始:{0}
		List<String> str = new ArrayList<String>();
		if (list != null) {
			for (AdvicerDto dto : list) {
				str.add(dto.getUserKey());
			}
		}
		logger.infoCode("I0002", "getAdvicerText"); // I0002=メソッド終了:{0}
		return String.join(",", str);
	}

	/**
	 * 依頼後1週間経過判定
	 *
	 * @param insDay 依頼日
	 * @param status 相談状態
	 * @return true:経過 / false:未経過
	 */
	public boolean isPassedOneWeek(Timestamp insDay, String sts){
		logger.infoCode("I0001", "isPassedOneWeek"); // I0001=メソッド開始:{0}

		Calendar calSys = getCalDate(DateUtil.toDate(DateUtil.getSysdate("yyyyMMdd")));
		Calendar calCon = getCalDate(insDay);
		calCon.add(Calendar.DAY_OF_MONTH, DAY_OF_ONE_WEEK - 1);
		if (calCon.compareTo(calSys) < 0 && CODE_CONSUL_STATUS_NEW.equals(sts)){
			return true;
		}
		logger.infoCode("I0002", "isPassedOneWeek"); // I0002=メソッド終了:{0}
		return false;
	}

	/**
	 * 日付をカレンダー日付に変換(時間切り捨て)
	 *
	 * @param 変換対象日付
	 * @return カレンダー日付
	 * @since 1.0
	 */
	private Calendar getCalDate(Date date){
		logger.infoCode("I0001", "getCalDate"); // I0001=メソッド開始:{0}

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		Date dt = DateUtil.toDate(sdf.format(date));

		Calendar cal = Calendar.getInstance();
		cal.setTime(dt);

		logger.infoCode("I0002", "getCalDate"); // I0002=メソッド終了:{0}
		return cal;
	}

	/**
	 * 日付をカレンダー日付に変換(時間切り捨て)
	 *
	 * @param form
	 * @param bindingResult
	 * @param locale
	 * @return
	 */
	public boolean checkSetting(ConsultationForm form, BindingResult bindingResult, Locale locale){
		logger.infoCode("I0001", "checkSetting"); // I0001=メソッド開始:{0}

		boolean check = true;

		// 面談日：妥当性チェック
		if (StringUtil.isNotNull(form.getConsultationDate())) {
			try {
				SimpleDateFormat sdf = new SimpleDateFormat(CommonConst.DEFAULT_YYYYMMDD);
				sdf.setLenient(false);
				String dt = String.format(form.getConsultationDate());
				sdf.parse(dt);
			} catch (Exception e) {
				// エラーメッセージ設定
				bindingResult.rejectValue("consultationDateYear", "message.validate.date");
				check = false;
			}
		}

		// 面談時間：範囲チェック
		if (form.getConsultationStart().compareTo(form.getConsultationEnd()) > 0) {
			// エラーメッセージ設定
			bindingResult.rejectValue("consultationStart", "message.validate.field.range", new Object[]{MessageUtil.getCodes("consultationStart"),messageSource.getMessage("consultation.list.time", null, locale)}, null);
			bindingResult.rejectValue("consultationEnd", "message.validate.field.range", new Object[]{MessageUtil.getCodes("consultationEnd"),messageSource.getMessage("consultation.list.time", null, locale)}, null);
			check = false;
		}

		logger.infoCode("I0002", "checkSetting"); // I0002=メソッド終了:{0}
		return check;
	}
}
