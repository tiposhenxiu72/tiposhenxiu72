package jp.co.sraw.controller.skill;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.BidiMap;
import org.apache.commons.collections.bidimap.DualHashBidiMap;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Service;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.oxm.rubric.Rubric;
import jp.co.sraw.oxm.rubric.RubricCategory;
import jp.co.sraw.util.PoiBook;
import jp.co.sraw.util.PoiHelper;

/**
 * 能力養成科目管理 Excel入出力ヘルパー
 *
 */
@Service
public class SkillBuildMgmtPoiHelper extends PoiHelper<CurriculumForm> {

	private final String SHEET_NAME_1 = "能力養成科目";
	private final String SHEET_NAME_2 = "DATA";


	@Override
	public Sheet getSheet(Workbook workbook) {
		return workbook.getSheet(SHEET_NAME_1);
	}

	static public final String DATE_PATTERN ="yyyy/MM/dd";

	/**
	 * ヘッダ部の能力養成科目を設定する
	 * @param workbook Excel
	 * @param rinfo ルーブリック情報
	 */
	public void buildExcelDocumentHeader(PoiBook workbook, Rubric rinfo) {
		workbook.activeSheet = workbook.book.getSheet(SHEET_NAME_1);

		int mainPos = 0;
		int mainSize = 0;
		int subPos = 0;
		int subSize = 0;
		int colNum = 0;
		for (RubricCategory mainCt : rinfo.getCategoryList()) {
			// 能力養成名
			workbook.changeValue(2, mainPos + 22, mainCt.getName());

			for (RubricCategory subCt : mainCt.getChildList()) {
				// 中項目
				// 能力養成名
				workbook.changeValue(3, subPos + 22, subCt.getName());

				for (RubricCategory item : subCt.getChildList()) {
					// 小項目
					// RDF No.
					workbook.changeValue(4, colNum + 22, item.getAbilityCode());
					// 能力養成名
					workbook.changeValue(5, colNum + 22, item.getName());

					colNum++;
					subSize++;
					mainSize++;
				}
				// 中項目のセルを結合
				workbook.mergeCell(3, 22 + subPos, 0, subSize - 1);
				subPos = subPos + subSize;
				subSize = 0;
			}
			// 大項目のセルを結合
			workbook.mergeCell(2, mainPos + 22, 0, mainSize - 1);
			mainPos = mainPos + mainSize;
			mainSize = 0;
		}
		workbook.mergeCell(1, 22, 0, mainPos - 1);
	}

	/**
	 * エクセルファイル出力
	 * @see jp.co.sraw.util.PoiHelper#buildExcelDocument(jp.co.sraw.util.PoiBook, java.util.List)
	 */
	public void buildExcelDocument(PoiBook workbook, List<CurriculumForm> list
			, Map<String, String> partyMap, Map<String, String> targetMap
			, Map<String, String> listenMap, Map<String, String> relayMap
			, Map<String, String> kbnMap, Map<String, String> compulsorMap) {
		workbook.activeSheet = workbook.book.getSheet(SHEET_NAME_1);
		// データ部
		for (int i = 0; i < list.size(); i++) {
			CurriculumForm form = list.get(i);
			int rowno = i + 6;
			// No.
			workbook.changeValue(rowno, 0, Integer.toString(i));
			// 機関名
			workbook.changeValue(rowno, 1, partyMap.get(form.getPartyCode()));
			// 期間内講義コード
			workbook.changeValue(rowno, 2, form.getLessonCode());
			// 開講部局
			workbook.changeValue(rowno, 3, form.getLessonDepartment());
			// 授業科目・プログラム名
			workbook.changeValue(rowno, 4, form.getLessonName());
			// 担当教員名
			workbook.changeValue(rowno, 5, form.getUserName());
			// 学内聴講対象者
			workbook.changeValue(rowno, 6, targetMap.get(form.getLessonTarget()));
			// 外学聴講/傍聴の可否
			workbook.changeValue(rowno, 7, listenMap.get(form.getListenFlag()));
			// 開講期
			workbook.changeValue(rowno, 8, form.getLessonDate());
			// 曜日時限
			workbook.changeValue(rowno, 9, form.getLessonPeriod());
			// 中継の有無
			workbook.changeValue(rowno, 10, relayMap.get(form.getRelayFlag()));
			// 中継聴講場所
			workbook.changeValue(rowno, 11, form.getRelayPlace());
			// 授業形態
			workbook.changeValue(rowno, 12, kbnMap.get(form.getLessonKbn()));
			// 単位数
			workbook.changeValue(rowno, 13, form.getUnit());
			// 学外受講生の単位互換
			workbook.changeValue(rowno, 14, form.getUnitInterchangeable());
			// 必修選択の別
			workbook.changeValue(rowno, 15, compulsorMap .get(form.getLessonCompulsory()));
			// 成績評価基準
			workbook.changeValue(rowno, 16, form.getLessonBase());
			// 授業の目的・概要
			workbook.changeValue(rowno, 17, form.getLessonIntention());
			// 授業計画
			workbook.changeValue(rowno, 18, form.getLessonPlan());
			// 備考
			workbook.changeValue(rowno, 19, form.getLessonMemo());
			// eラーニングリンク
			workbook.changeValue(rowno, 20, form.geteLink());
			// シラバスリンク
			workbook.changeValue(rowno, 21, form.getsLink());

			// RDF Noの行のデータを取得
			int colNum = 0;
			Row headRow = workbook.activeSheet.getRow(4);
			while (getCellValue(headRow,  22 + colNum) != null && getCellValue(headRow,  22 + colNum).length() != 0) {
				String val = getCellValue(headRow, 22 + colNum);
				if (form.getLinkageMap().containsKey(val)) {
					workbook.changeValue(rowno, 22 + colNum, getRelationLvVal(form.getLinkageMap().get(val)));
				}
				colNum++;
			}
		}
	}

	/**
	 * セレクトボックスに格納するデータ
	 * @param workbook
	 * @param partyMap
	 * @param targetMap
	 * @param listenMap
	 * @param relayMap
	 * @param kbnMap
	 * @param compulsorMap
	 */
	public void buildExcelDocumentDataSheet(PoiBook workbook
			, Map<String, String> partyMap, Map<String, String> targetMap
			, Map<String, String> listenMap, Map<String, String> relayMap
			, Map<String, String> kbnMap, Map<String, String> compulsorMap) {
		workbook.activeSheet = workbook.book.getSheet(SHEET_NAME_2);

		int rowno = 0;

		// 組織名
		rowno = 0;
		for (Map.Entry<String, String> item : partyMap.entrySet()) {
			workbook.changeValue(rowno, 0, item.getKey());
			workbook.changeValue(rowno, 1, item.getValue());
			rowno++;
		}
		// 学内聴講対象者
		rowno = 0;
		for (Map.Entry<String, String> item : targetMap.entrySet()) {
			workbook.changeValue(rowno, 2, item.getKey());
			workbook.changeValue(rowno, 3, item.getValue());
			rowno++;
		}
		// 学外聴講／傍聴の可否
		rowno = 0;
		for (Map.Entry<String, String> item : listenMap.entrySet()) {
			workbook.changeValue(rowno, 4, item.getKey());
			workbook.changeValue(rowno, 5, item.getValue());
			rowno++;
		}
		// 中継の有無
		rowno = 0;
		for (Map.Entry<String, String> item : relayMap.entrySet()) {
			workbook.changeValue(rowno, 6, item.getKey());
			workbook.changeValue(rowno, 7, item.getValue());
			rowno++;
		}
		// 授業形態
		rowno = 0;
		for (Map.Entry<String, String> item : kbnMap.entrySet()) {
			workbook.changeValue(rowno, 8, item.getKey());
			workbook.changeValue(rowno, 9, item.getValue());
			rowno++;
		}
		// 必修選択の別
		rowno = 0;
		for (Map.Entry<String, String> item : compulsorMap.entrySet()) {
			workbook.changeValue(rowno, 10, item.getKey());
			workbook.changeValue(rowno, 11, item.getValue());
			rowno++;
		}
	}

	/**
	 * Excelファイル読み込み（データ部のみ）
	 * @see jp.co.sraw.util.PoiHelper#getForm(org.apache.poi.ss.usermodel.Row)
	 */
	public CurriculumForm getForm(Row row
			, Map<String, String> partyMap, Map<String, String> targetMap, Map<String, String> listenMap
			, Map<String, String> relayMap, Map<String, String> kbnMap, Map<String, String> compulsorMap) {
		CurriculumForm form = new CurriculumForm();

		BidiMap bPartyMap = new DualHashBidiMap(partyMap);
		BidiMap bTargetMap = new DualHashBidiMap(targetMap);
		BidiMap bListenMap = new DualHashBidiMap(listenMap);
		BidiMap bRelayMap = new DualHashBidiMap(relayMap);
		BidiMap bKbnMap = new DualHashBidiMap(kbnMap);
		BidiMap bCompulsorMap = new DualHashBidiMap(compulsorMap);

		// 機関名
		form.setPartyCode((String) bPartyMap.getKey(getCellValue(row, 1)));
		// 期間内講義コード
		form.setLessonKey(getCellValue(row, 2));
		// 開講部局
		form.setLessonDepartment(getCellValue(row, 3));
		// 授業科目・プログラム名
		form.setLessonName(getCellValue(row, 4));
		// 担当教員名
		form.setUserName(getCellValue(row, 5));
		// 学内聴講対象者
		form.setLessonTarget((String) bTargetMap.getKey(getCellValue(row, 6)));
		// 外学聴講/傍聴の可否
		form.setListenFlag((String) bListenMap.getKey(getCellValue(row, 7)));
		// 開講期
		form.setLessonDate(getCellValue(row, 8));
		// 曜日時限
		form.setLessonPeriod(getCellValue(row, 9));
		// 中継の有無
		form.setRelayFlag((String) bRelayMap.getKey(getCellValue(row, 10)));
		// 中継聴講場所
		form.setRelayPlace(getCellValue(row, 11));
		// 授業形態
		form.setLessonKbn((String) bKbnMap.getKey(getCellValue(row, 12)));
		// 単位数
		form.setUnit(getCellValue(row, 13));
		// 学外受講生の単位互換
		form.setUnitInterchangeable(getCellValue(row, 14));
		// 必修選択の別
		form.setLessonCompulsory((String) bCompulsorMap.getKey(getCellValue(row, 15)));
		// 成績評価基準
		form.setLessonBase(getCellValue(row, 16));
		// 授業の目的・概要
		form.setLessonIntention(getCellValue(row, 17));
		// 授業計画
		form.setLessonPlan(getCellValue(row, 18));
		// 備考
		form.setLessonMemo(getCellValue(row, 19));
		// eラーニングリンク
		form.seteLink(getCellValue(row, 20));
		// シラバスリンク
		form.setsLink(getCellValue(row, 21));

		return form;
	}


	/**
	 * 科目情報を読み込む
	 * @param workbook Excelブック
	 * @return 読み込んだデータ一覧
	 */
	public List<CurriculumForm> getLinkageLessonAbilityCode (PoiBook workbook
			, Map<String, String> partyMap, Map<String, String> targetMap, Map<String, String> listenMap
			, Map<String, String> relayMap, Map<String, String> kbnMap, Map<String, String> compulsorMap) {
		Map<String, String> map = new HashMap<String, String>();
		Row headRow = workbook.activeSheet.getRow(4);

		List<CurriculumForm> list = new ArrayList<CurriculumForm>();

		int rowNum = 6;	// データは6行目から
		do {
			Row dataRow = workbook.activeSheet.getRow(rowNum);
			if (dataRow == null || getCellValue(dataRow, 0) == null || getCellValue(dataRow, 0).length() == 0) {
				break;
			}
			CurriculumForm form = getForm(dataRow
					, partyMap, targetMap, listenMap, relayMap, kbnMap, compulsorMap);

			int colNum = 0;
			while (getCellValue(headRow, 22 + colNum) != null) {
				if (!"".equals(getCellValue(dataRow, 22 + colNum))) {
					map.put(getCellValue(headRow, 22 + colNum), getCellValue(dataRow, 22 + colNum));
				}
				colNum++;
			}
			form.setLinkageMap(map);

			list.add(form);
			rowNum++;
		} while(true);

		return list;
	}

	@Override
	public CurriculumForm getForm(Row row) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	/**
	 * 紐付きレベルを画面表示用からシステム内用のコードに変換する
	 * @param relationLvVal 画面表示用文字列
	 * @return システム用コード
	 */
	private String getRelationLvCode (String relationLvVal) {
		return CommonConst.RELATION_LEVEL_BEST_V.equals(relationLvVal) ? CommonConst.RELATION_LEVEL_BEST
				: CommonConst.RELATION_LEVEL_NORMAL_V.equals(relationLvVal) ? CommonConst.RELATION_LEVEL_NORMAL
						: null;
	}

	/**
	 * 紐付きレベルを画面表示用からシステム内用のコードに変換する
	 * @param relationLbStr 画面表示用文字列
	 * @return システム用コード
	 */
	private String getRelationLvVal (String relationLvCd) {
		return CommonConst.RELATION_LEVEL_BEST.equals(relationLvCd) ? CommonConst.RELATION_LEVEL_BEST_V
				: CommonConst.RELATION_LEVEL_NORMAL.equals(relationLvCd) ? CommonConst.RELATION_LEVEL_NORMAL_V
						: null;
	}
}
