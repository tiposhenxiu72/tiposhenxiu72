package jp.co.sraw.controller.portfolio.excel;

import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Service;

import jp.co.sraw.common.CommonForm;
import jp.co.sraw.controller.portfolio.form.GyCareerForm;
import jp.co.sraw.util.PoiBook;

@Service
public class CareerExcelHelper extends PortfolioExcelHelper<GyCareerForm> {

	public CareerExcelHelper() {
		this.DATA_SHEET_NAME = "CAREER";
	}

	@Override
	public void buildExcelDocument(PoiBook workbook, List<GyCareerForm> list) {
		workbook.activeSheet = workbook.book.getSheet(DATA_SHEET_NAME);

		for (int i = 0; i < list.size(); i++) {
			GyCareerForm form = list.get(i);
			form.setViewType(CommonForm.VIEW_TYPE_EXCEL);
			int rowno = i + 1;
			// 言語区分
			// workbook.changeValue(rowno, 0, form.getLanguage());
			// 年月(From)
			workbook.changeValue(rowno, 0, form.getFromdate());
			// 年月(To)
			workbook.changeValue(rowno, 1, form.getTodate());
			// 所属
			workbook.changeValue(rowno, 2, form.getDivision());
			// 部署
			workbook.changeValue(rowno, 3, form.getSection());
			// 職位・身分
			workbook.changeValue(rowno, 4, form.getJob());
			// 公開範囲
			workbook.changeValue(rowno, 5, form.getPublicFlag());
		}
	}

	@Override
	public Sheet getSheet(Workbook workbook) {
		return workbook.getSheet(DATA_SHEET_NAME);
	}

	@Override
	public GyCareerForm getForm(Row row) {

		GyCareerForm form = new GyCareerForm();
		// 言語区分
		// form.setLanguage(getCellValue(row, 0));
		// 年月(From)
		form.setFromdate(getCellValue(row, 0));
		// 年月(To)
		form.setTodate(getCellValue(row, 1));
		// 所属
		form.setDivision(getCellValue(row, 2));
		// 部署
		form.setSection(getCellValue(row, 3));
		// 職位・身分
		form.setJob(getCellValue(row, 4));
		// 公開範囲
		form.setPublicFlag(getCellValue(row, 5));

		return form;
	}

}