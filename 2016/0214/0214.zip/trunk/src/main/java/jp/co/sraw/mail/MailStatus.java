package jp.co.sraw.mail;

public class MailStatus {

	public static final String SUCCESS = "SUCCESS";
	public static final String ERROR = "ERROR";

	private final String[] bcc;
	private final String subject;
	private final String body;

	private String status;
	private String errorMessage;

	public MailStatus(String[] bcc, String subject, String body) {
		this.bcc = bcc;
		this.subject = subject;
		this.body = body;
	}

	public MailStatus success() {
		this.status = SUCCESS;
		return this;
	}

	public MailStatus error(String errorMessage) {
		this.status = ERROR;
		this.errorMessage = errorMessage;
		return this;
	}

	public boolean isSuccess() {
		return SUCCESS.equals(this.status);
	}

	public boolean isError() {
		return ERROR.equals(this.status);
	}

	public String[] getBcc() {
		return bcc;
	}

	public String getSubject() {
		return subject;
	}

	public String getBody() {
		return body;
	}

	public String getStatus() {
		return status;
	}

	public String getErrorMessage() {
		return errorMessage;
	}
}
