package jp.co.sraw.controller.portfolio.excel;

import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.sraw.controller.portfolio.form.PortfolioForm;
import jp.co.sraw.dto.MsCodeDto;
import jp.co.sraw.entity.MsResearchAreaTbl;
import jp.co.sraw.file.AbstractExcelHelper;
import jp.co.sraw.service.MsResearchAreaServiceImpl;
import jp.co.sraw.util.DbUtil;
import jp.co.sraw.util.PoiBook;
import jp.co.sraw.util.StringUtil;

@Service
public abstract class PortfolioExcelHelper<F extends PortfolioForm> extends AbstractExcelHelper<F> {

	public static final String DELIMITER = ":";

	private final String CONTENTS_SHEET_NAME = "CONTENTS";

	protected String DATA_SHEET_NAME = "";

	@Autowired
	public MsResearchAreaServiceImpl serviceImpl;

	public String getSeetName() {
		return DATA_SHEET_NAME;
	}

	public void clearSheets(PoiBook workbook) {
		for (int i = workbook.book.getNumberOfSheets() - 1; i >= 0; i--) {
			Sheet tmpSheet = workbook.book.getSheetAt(i);
			if (!tmpSheet.getSheetName().equals(CONTENTS_SHEET_NAME)
					&& !tmpSheet.getSheetName().equals(DATA_SHEET_NAME)) {
				workbook.book.removeSheetAt(i);
			}
		}
	}

	public String getSummaryFORMFormat(String areaCode) {
		if (StringUtil.isNull(areaCode)) {
			return "";
		}
		MsResearchAreaTbl tbl = serviceImpl.findOne(areaCode);
		if (tbl != null) {
			return tbl.getResearchAreaName();
		}
		return areaCode;
	}

	public String getSummaryExcelFormat(String areaCode) {
		if (StringUtil.isNull(areaCode)) {
			return "";
		}
		MsResearchAreaTbl tbl = serviceImpl.findOne(areaCode);
		if (tbl != null) {
			return tbl.getResearchAreaCode() + DELIMITER + tbl.getResearchAreaName();
		}
		return areaCode + DELIMITER + "";
	}

	public String getTitle(String title, String code) {
		if (StringUtil.isNull(code)) {
			return "";
		}
		Map<String, MsCodeDto> map = DbUtil.getJosuMap(code);
		MsCodeDto dto = map.get(title);
		if (dto != null) {
			return title + DELIMITER + dto.getValue();
		}
		return title + DELIMITER + "";
	}

	private String[] codelist = new String[] { "0024", "0204", "0206", "0203", "0209", "0210", "0208", "0213", "0201",
			"2011", "0221", "0222", "0017" };

	public void buildSelectItemList(PoiBook workbook) {
		workbook.activeSheet = workbook.book.getSheet(CONTENTS_SHEET_NAME);

		int colno = 0;
		List<MsCodeDto> langlist = DbUtil.getJosuList("0041");
		for (int i = 0; i < langlist.size(); i++) {
			MsCodeDto dto = langlist.get(i);
			workbook.changeValue(i, colno, dto.getValue() + DELIMITER + dto.getValue());
		}

		for (int i = 0; i < codelist.length; i++) {
			colno++;
			List<MsCodeDto> list = DbUtil.getJosuList(codelist[i]);
			for (int j = 0; j < list.size(); j++) {
				MsCodeDto dto = list.get(j);
				workbook.changeValue(j, colno, dto.getCode() + DELIMITER + dto.getValue());
			}
		}

		colno++;

		List<MsResearchAreaTbl> list1 = serviceImpl.findAllResearchArea();
		for (int i = 0; i < list1.size(); i++) {
			MsResearchAreaTbl dto = list1.get(i);
			workbook.changeValue(i, colno, dto.getResearchAreaCode() + DELIMITER + dto.getResearchAreaName());
		}

	}
}
