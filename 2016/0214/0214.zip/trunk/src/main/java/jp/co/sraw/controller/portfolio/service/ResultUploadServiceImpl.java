/*
* ファイル名：UserServiceImpl.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.portfolio.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.sraw.controller.portfolio.form.ResultUploadForm;
import jp.co.sraw.entity.UsResultUploadTbl;
import jp.co.sraw.file.FileDto;
import jp.co.sraw.file.FileService;
import jp.co.sraw.repository.UsResultUploadTblRepository;

/**
 * <B>ResultUploadServiceImplクラス</B>
 * <P>
 * ユーザーサービスのメソッドを提供する
 */
@Scope("prototype")
@Service
@Transactional(readOnly = true)
public class ResultUploadServiceImpl
		extends MultiHandleServiceImpl<UsResultUploadTbl, ResultUploadForm, UsResultUploadTblRepository> {

	@Autowired
	private FileService fileService;

	@Override
	public ResultUploadForm getPortfolioForm(UsResultUploadTbl tbl) {
		if (tbl == null)
			return null;
		//
		ResultUploadForm dto = new ResultUploadForm();
		dto = (ResultUploadForm) objectUtil.getObjectCopyValue(dto, tbl);
		FileDto fileDto = fileService.getFileUploalDto(dto.getUploadKey());
		if (fileDto != null) {
			dto.setFileName(fileDto.getUploadName());
		}
		return dto;
	}

	protected Sort orderBy() {
		// 登録日（降順）
		return new Sort(Sort.Direction.DESC, "insDate");
	}

}
