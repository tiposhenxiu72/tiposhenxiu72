/*
* ファイル名：PortfolioServiceImpl.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.sraw.common.CommonService;
import jp.co.sraw.common.UserInfo;
import jp.co.sraw.dto.UsResultUploadDto;
import jp.co.sraw.entity.UsCompetitionTbl;
import jp.co.sraw.entity.UsPrmovieUploadTbl;
import jp.co.sraw.entity.UsResultUploadTbl;
import jp.co.sraw.entity.UsUserTbl;
import jp.co.sraw.file.FileDto;
import jp.co.sraw.file.FileService;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.repository.UsCompetitionTblRepository;
import jp.co.sraw.repository.UsPrmovieUploadTblRepository;
import jp.co.sraw.repository.UsResultUploadTblRepository;
import jp.co.sraw.repository.UsUserTblRepository;

/**
 * <B>PortfolioServiceImplクラス</B>
 * <P>
 * ユーザーサービスのメソッドを提供する
 */
@Scope("prototype")
@Service
@Transactional(readOnly = true)
public class PortfolioProfileServiceImpl extends CommonService {

	@Autowired
	private UsUserTblRepository usUserTblRepository;

	@Autowired
	private FileService fileService;

	@Autowired
	private UsCompetitionTblRepository usCompetitionTblRepository;

	@Autowired
	private UsResultUploadTblRepository usResultUploadTblRepository;

	@Autowired
	private UsPrmovieUploadTblRepository usPrmovieUploadTblRepository;

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(UserServiceImpl.class);

	@PostConstruct
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	// ユーザ情報テーブル
	public List<UsUserTbl> findAllUser() {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		List<UsUserTbl> list = usUserTblRepository.findAll();

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return list;
	}

	public UsUserTbl findOneUser(String userKey) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		UsUserTbl u = usUserTblRepository.findOne(userKey);

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return u;
	}

	// 成果物ファイル
	public List<UsResultUploadTbl> findAllUsResultUpload() {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		List<UsResultUploadTbl> list = usResultUploadTblRepository.findAll();

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return list;
	}

	/**
	 *
	 * @param form
	 * @param userInfo
	 * @return
	 */
	public List<UsResultUploadDto> getUploadFileList() {
		logger.infoCode("I0001");

		List<UsResultUploadDto> uploadFileList = new ArrayList<>();
		try {
			List<UsResultUploadTbl> uploadList = usResultUploadTblRepository.findAll();
			for (UsResultUploadTbl tbl : uploadList) {
				FileDto dto = fileService.getFileUploalDto(tbl.getUploadKey());
				UsResultUploadDto row = new UsResultUploadDto();
				row.setInsDate(tbl.getInsDate());
				row.setTitle(tbl.getTitle());
				row.setUploadName(dto.getUploadName());
				uploadFileList.add(row);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return uploadFileList;
	}

	// コンペティションファイルVIEW
	public List<UsCompetitionTbl> findAllUsCompetition(UserInfo userInfo, String[] publicFlags) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		//
		Specification<UsCompetitionTbl> whereUserKey = new Specification<UsCompetitionTbl>() {
			public Predicate toPredicate(Root<UsCompetitionTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.get("usUserTbl").get("userKey"), userInfo.getTargetUserKey());
			}
		};

		// 取得条件：
		Specification<UsCompetitionTbl> wherePublicFlags = publicFlags == null ? null : new Specification<UsCompetitionTbl>() {
			@Override
			public Predicate toPredicate(Root<UsCompetitionTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				Predicate predicate = cb.conjunction();
				for (int i = 0; i < publicFlags.length; i++) {
					String keyword = publicFlags[i];
					if (i == 0) {
						predicate = cb.and(predicate, cb.equal(root.get("publicFlag"), keyword));
					} else {
						predicate = cb.or(predicate, cb.equal(root.get("publicFlag"), keyword));
					}
				}
				return predicate;
			}
		};

		List<UsCompetitionTbl> list = (List<UsCompetitionTbl>) usCompetitionTblRepository
				.findAll((Specification<UsCompetitionTbl>) Specifications.where(whereUserKey).and(wherePublicFlags), orderBy());

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return list;
	}

	private Sort orderBy() {
		// 登録日昇順
		return new Sort(Sort.Direction.ASC, "insDate");
	}

	/**
	 * PR動画ファイル取得
	 *
	 * @param userKey
	 * @return
	 */
	public List<UsPrmovieUploadTbl> findAllPrFile(String userKey) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		// 取得条件：ユーザキー
		Specification<UsPrmovieUploadTbl> whereUserKey =
			new Specification<UsPrmovieUploadTbl>() {
				@Override
				public Predicate toPredicate(Root<UsPrmovieUploadTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
					return cb.equal(root.get("id").get("userKey"), userKey);
				}
			};

		List<UsPrmovieUploadTbl> list = usPrmovieUploadTblRepository.findAll(Specifications.where(whereUserKey));

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return list;
	}

}
