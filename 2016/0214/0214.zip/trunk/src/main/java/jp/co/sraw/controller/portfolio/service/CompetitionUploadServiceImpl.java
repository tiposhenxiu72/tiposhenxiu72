/*
* ファイル名：UserServiceImpl.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.portfolio.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.sraw.controller.portfolio.form.CompetitionUploadForm;
import jp.co.sraw.entity.UsCompetitionTbl;
import jp.co.sraw.file.FileDto;
import jp.co.sraw.file.FileService;
import jp.co.sraw.repository.UsCompetitionTblRepository;

/**
 * <B>CompetitionUploadServiceImplクラス</B>
 * <P>
 * ユーザーサービスのメソッドを提供する
 */
@Service
@Transactional(readOnly = true)
public class CompetitionUploadServiceImpl
		extends MultiHandleServiceImpl<UsCompetitionTbl, CompetitionUploadForm, UsCompetitionTblRepository> {

	@Autowired
	private FileService fileService;

	@Override
	public CompetitionUploadForm getPortfolioForm(UsCompetitionTbl tbl) {
		if (tbl == null)
			return null;
		//
		CompetitionUploadForm dto = new CompetitionUploadForm();
		dto = (CompetitionUploadForm) objectUtil.getObjectCopyValue(dto, tbl);
		if (dto.getInsKbn().equals("1")) {
			FileDto fileDto = fileService.getFileUploalDto(dto.getUploadKey());
			if (fileDto != null) {
				dto.setFileName(fileDto.getUploadName());
			}
		} else {
			dto.setFileName(dto.getLink());
		}
		return dto;
	}

	protected Sort orderBy() {
		// 登録日（降順）
		return new Sort(Sort.Direction.DESC, "insDate");
	}
}
