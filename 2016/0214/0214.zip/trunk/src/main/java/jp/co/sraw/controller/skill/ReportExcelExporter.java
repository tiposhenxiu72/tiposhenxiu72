package jp.co.sraw.controller.skill;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.poi.hssf.usermodel.HSSFShapeGroup;
import org.apache.poi.hssf.util.HSSFColor;

import jp.co.sraw.dto.SkillAnswerStatsDto;
import jp.co.sraw.dto.SkillLessonTakenDto;
import jp.co.sraw.dto.SkillReportDto;
import jp.co.sraw.entity.NrAchievementReportBkupTbl;
import jp.co.sraw.entity.NrAchievementReportTbl;
import jp.co.sraw.oxm.rubric.Rubric;
import jp.co.sraw.oxm.rubric.RubricCategory;
import jp.co.sraw.util.DateUtil;
import jp.co.sraw.util.PoiBook;

/**
 * 自己評価レポートをExcelへエクスポートする。
 *
 *
 */
public class ReportExcelExporter {
	private static final String SHNAME_TOP = "自己評価レポート（表）";
	private static final String SHNAME_BOTTOM = "自己評価レポート（裏）";
	private static final String FORMAT_SAVEDDATE = "yyyy年M月";
	private static final String FORMAT_ACHIEVEMENT = "%d項目中 %d項目達成";
	private static final String NA = "-";
	private static final String DONE = "達成済";
	private static final String NOTYET = "未達成";
	private static final CharSequence EOL = "\r\n";

	private static final int LEVEL_CAT = 0;
	private static final int LEVEL_SUBCAT = 1;
	private static final int LEVEL_ITEM = 2;
	private static final int[] ALL_LEVELS = { LEVEL_CAT, LEVEL_SUBCAT, LEVEL_ITEM };
	private static final int[][] RGB_CATS = { { 157, 220, 249, HSSFColor.AQUA.index },
			{ 186, 201, 231, HSSFColor.PINK.index }, { 165, 212, 218, HSSFColor.DARK_TEAL.index },
			{ 211, 191, 221, HSSFColor.LAVENDER.index } };
	private static final int[] RGB_DONE = { 255, 0, 0, HSSFColor.RED.index };
	private static final int[] RGB_NOTYET = { 0, 176, 80, HSSFColor.DARK_GREEN.index };

	// コンフィグ情報。
	// int配列は、{row, col}の意味。
	private static final int[] SAVED_DATE = { 2, 1 };
	private static final int[] USER_NAME = { 1, 5 };
	private static final int[] LENS_NAME = { 6, 1 };
	private static final int[] ACHIEVEMENT = { 8, 2 };
	private static final int[] WHOLE_TARGET = { 11, 0 };
	private static final int[] ANNUAL_TARGET = { 14, 0 };
	private static final int RTABLE_TOP = 19;
	private static final int CTABLE = 0;

	private static final int NUM_ROWS = 100;
	private static final short HEIGHT_ITEM = 27;
	private static final int NUM_ROWS_REVIEW = 3;
	private static final int ROFF_REVIEW_BODY = 2;
	private static final short HEIGHT_REVIEW = 70;

	private PoiBook book;

	public ReportExcelExporter(PoiBook book) {
		this.book = book;
	}

	/**
	 * エクスポートする。
	 */
	public void export(Integer level, SkillReportDto dto, SkillAnswerStatsDto stats) {
		prepareTopSheet(level);
		preparePalette();
		exportTop(level, dto, stats);

		book.selectSheet(SHNAME_BOTTOM);
		//		exportBottom(level, dto, stats);

		book.selectSheet(levelToSheetName(level));
	}

	private void exportTop(Integer level, SkillReportDto dto, SkillAnswerStatsDto stats) {
		exportSavedDate(stats.getSavedDate());
		exportUserInfo(dto);
		exportLensName(dto);
		exportAchievement(dto, stats);
		exportTarget(dto, stats);
		exportTable(level, dto, stats);
	}

	private void exportBottom(Integer level, SkillReportDto dto, SkillAnswerStatsDto stats) {
		IntStream.range(RTABLE_TOP, RTABLE_TOP + NUM_ROWS).forEach(r -> {
			book.fill(r, 0, colorIndex(RGB_CATS[r % 4]));
			book.setRowHeight(r, HEIGHT_ITEM);
		});
		book.changeValue(RTABLE_TOP, 1, "hoge");
		book.setFontColor(RTABLE_TOP, 1, colorIndex(RGB_DONE));
		book.mergeCell(RTABLE_TOP, 1, 3, 0);

		deleteUnusedRows(RTABLE_TOP + 8);
		book.setRowHeight(RTABLE_TOP + 8 + ROFF_REVIEW_BODY, HEIGHT_REVIEW);

		book.selectSheet(SHNAME_BOTTOM);
		List<HSSFShapeGroup> sgs = book.topLevelShapeGroup();
		sgs.forEach(sg -> {
			if (sg.getChildren().size() == 4) {
				sg.forEach(pie -> {
					int angle = pie.getRotationDegree();
					if (angle < 0) {
						angle = 360 + angle;
					}
					int d = angle * 256 / 360;
					pie.setFillColor(d, 0, d);
				});
			} else {
				sg.forEach(pie -> {
					int angle = pie.getRotationDegree();
					if (angle < 0) {
						angle = 360 + angle;
					}
					int d = angle * 256 / 360;
					pie.setFillColor(0, d, d);
				});
			}
		});
	}

	private void exportSavedDate(Date savedDate) {
		savedDate = savedDate == null ? new Date() : savedDate;
		book.changeValue(SAVED_DATE[0], SAVED_DATE[1], DateUtil.dateTimeFormat(savedDate, FORMAT_SAVEDDATE));
	}

	private void exportUserInfo(SkillReportDto dto) {
		book.changeValue(USER_NAME[0], USER_NAME[1], dto.getUserName());
		book.changeValue(USER_NAME[0] + 1, USER_NAME[1], dto.getDegreeName());
		book.changeValue(USER_NAME[0] + 2, USER_NAME[1], dto.getPartyName());
		book.changeValue(USER_NAME[0] + 3, USER_NAME[1], dto.getMajorName());
	}

	private void exportLensName(SkillReportDto dto) {
		book.changeValue(LENS_NAME[0], LENS_NAME[1], dto.getLensName());
	}

	private void exportAchievement(SkillReportDto dto, SkillAnswerStatsDto stats) {
		if (dto.isCanEditDone()) {
			book.changeValue(ACHIEVEMENT[0], ACHIEVEMENT[1], String.valueOf(stats.getRatio()) + "%");
			book.changeValue(ACHIEVEMENT[0], ACHIEVEMENT[1] + 1,
					String.format(FORMAT_ACHIEVEMENT, stats.getDenom(), stats.getNume()));
		} else {
			book.deleteRows(ACHIEVEMENT[0], ACHIEVEMENT[0] + 1, 0);
		}
	}

	private void exportTarget(SkillReportDto dto, SkillAnswerStatsDto stats) {
		String whole;
		String annual;
		if (stats.getSavedDate() == null) { // 最新?
			NrAchievementReportTbl repo = dto.getReport();
			whole = repo == null ? "" : repo.getAllAchievement();
			annual = repo == null ? "" : repo.getYearlyAchievement();
		} else { // 過去。
			NrAchievementReportBkupTbl repo = dto.getSavedReport();
			whole = repo == null ? "" : repo.getAllAchievement();
			annual = repo == null ? "" : repo.getYearlyAchievement();
		}
		book.changeValue(WHOLE_TARGET[0], WHOLE_TARGET[1], whole);
		book.changeValue(ANNUAL_TARGET[0], ANNUAL_TARGET[1], annual);
	}

	private void exportTable(Integer level, SkillReportDto dto, SkillAnswerStatsDto stats) {
		if (level == LEVEL_CAT) {
			exportCatTable(dto, stats);
		} else if (level == LEVEL_SUBCAT) {
			exportSubcatTable(dto, stats);
		} else {
			exportItemTable(dto, stats);
		}
	}

	private void exportCatTable(SkillReportDto dto, SkillAnswerStatsDto stats) {
		Rubric rub = dto.getRubric();
		IntStream.range(0, rub.getCategoryList().size()).forEach(i -> {
			RubricCategory cat = rub.getCategoryList().get(i);
			AnswerForm ans = dto.getAnswers().get(i);
			book.changeValue(RTABLE_TOP + i, CTABLE, cat.getCaption());
			book.fill(RTABLE_TOP + i, CTABLE, colorIndex(RGB_CATS[i]));
			if (ans.allAchieved()) {
				book.changeValue(RTABLE_TOP + i, CTABLE + 1, DONE);
				book.setFontColor(RTABLE_TOP + i, CTABLE + 1, colorIndex(RGB_DONE));
			} else {
				book.changeValue(RTABLE_TOP + i, CTABLE + 1, NOTYET);
				book.setFontColor(RTABLE_TOP + i, CTABLE + 1, colorIndex(RGB_NOTYET));
			}
			List<SkillLessonTakenDto> lessons = dto.getLessonMap().get(cat.getAbilityCode());
			if (lessons != null) {
				book.changeValue(RTABLE_TOP + i, CTABLE + 2, lessons.stream()
						.map(less -> less.getName() + "(" + less.getParty() + ")").collect(Collectors.joining(EOL)));
			}
		});
	}

	private void exportSubcatTable(SkillReportDto dto, SkillAnswerStatsDto stats) {
	}

	private void exportItemTable(SkillReportDto dto, SkillAnswerStatsDto stats) {
	}

	private void deleteUnusedRows(int rfrom) {
		book.deleteRows(rfrom, RTABLE_TOP + NUM_ROWS, NUM_ROWS_REVIEW);
	}

	private void prepareTopSheet(int level) {
		book.selectSheet(levelToSheetName(level));
		book.setSheetName(SHNAME_TOP);
		deleteUnusedSheets(level);
	}

	private void preparePalette() {
		Arrays.stream(RGB_CATS).forEach(rgbi -> book.customizeColor(rgbi, colorIndex(rgbi)));
		book.customizeColor(RGB_DONE, colorIndex(RGB_DONE));
		book.customizeColor(RGB_NOTYET, colorIndex(RGB_NOTYET));
	}

	private short colorIndex(int[] rgbi) {
		return (short) rgbi[3];
	}

	private String levelToSheetName(int level) {
		return String.valueOf(level);
	}

	private void deleteUnusedSheets(int level) {
		Arrays.stream(ALL_LEVELS).filter(lv -> lv != level).forEach(lv -> book.deleteSheet(levelToSheetName(lv)));
	}
}
