/*
* ファイル名：ConsultationController.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/01/15   matsuo      新規作成
*/
package jp.co.sraw.controller.consultation;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonController;
import jp.co.sraw.dto.AdvicerDto;
import jp.co.sraw.dto.ConsultationDto;
import jp.co.sraw.dto.MsCodeDto;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.service.ConsultationServiceImpl;
import jp.co.sraw.util.DbUtil;

/**
 * <B>ConsultationControllerクラス</B>
 * <P>
 * Controllerのメソッドを提供する
 */
@Controller
@RequestMapping("/")
public class ConsultationController extends CommonController {

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(ConsultationController.class);

	@Autowired
	private ConsultationServiceImpl service;

	// URL
	private static final String REDIRECT_LIST = "redirect:/consultation/list";
	private static final String REDIRECT_LIST_MGMT = "redirect:/mgmt/consultation/list";
	private static final String LIST_PAGE = "consultation/list";
	private static final String ADVICER_LIST_PAGE = "consultation/advicerList";
	private static final String REQUEST_PAGE = "consultation/request";
	private static final String DETAIL_PAGE = "consultation/detail";
	private static final String SETTING_PAGE = "consultation/setting";
	private static final String RESULT_PAGE = "consultation/result";

	// 定数
	public static final String CODE_REQUEST_CARRER = "1";		// 依頼内容:キャリア相談
	public static final String CODE_REQUEST_MENTOR = "2";		// 依頼内容:メンター依頼
	public static final String CODE_ADVICER_NEED = "2";			// 希望相談員:あり

	@PostConstruct
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	@ModelAttribute(CommonConst.FORM_NAME)
	public ConsultationForm setupForm() {
		ConsultationForm form = new ConsultationForm();
		return form;
	}

	/**
	 * 面談一覧画面
	 *
	 * @param name
	 * @param model
	 * @return
	 */
	@RequestMapping({ "consultation", "consultation/", "consultation/list"})
	public String list(@ModelAttribute(CommonConst.FORM_NAME) ConsultationForm form, Model model, Locale locale) {
		logger.infoCode("I0001", "list"); // I0001=メソッド開始:{0}

		if (logger.isDebugEnabled() && userInfo != null) {
			logger.debug("LoginUserKey=" + userInfo.getLoginUserKey());
			logger.debug("TargetUserKey=" + userInfo.getTargetUserKey());
		}

		// 面談一覧情報の取得
		List<ConsultationDto> consulList = new ArrayList<>();
		if (userInfo.isUser5()) {
			// 相談者の場合
			consulList = service.findConsulAdvicerList(userInfo);
		}else{
			// 若手研究者
			consulList = service.findConsulList(userInfo);
		}

		// 画面出力情報の編集
		List<ConsultationForm> consultationList = new ArrayList<>();
		if (consulList != null) {
			for (ConsultationDto entity : consulList) {
				consultationList.add(service.getFormItem(locale, entity));
			}
		}

		// modelセット
		model.addAttribute("consultationList", consultationList);

		// dump
		modelDump(logger, model, "list");
		logger.infoCode("I0002", "list"); // I0002=メソッド終了:{0}

		// 一覧画面
		if (userInfo.isUser5()) {
			return ADVICER_LIST_PAGE;	// 相談者
		}else{
			return LIST_PAGE;			// 若手研究者
		}
	}

	/**
	 * 面談依頼画面
	 *
	 * @param name
	 * @param model
	 * @return
	 */
	@RequestMapping({ "consultation/request" })
	public String request(@ModelAttribute(CommonConst.FORM_NAME) ConsultationForm form, Model model, Locale locale) {
		logger.infoCode("I0001", "request"); // I0001=メソッド開始:{0}

		if (logger.isDebugEnabled() && userInfo != null) {
			logger.debug("LoginUserKey=" + userInfo.getLoginUserKey());
			logger.debug("TargetUserKey=" + userInfo.getTargetUserKey());
		}

		// 定数マスタLIST
		List<MsCodeDto> requestKbnList = DbUtil.getJosuList(ConsultationServiceImpl.CODE_REQUEST_KBN, locale);	// 依頼項目
		List<MsCodeDto> advicerKbnList = DbUtil.getJosuList(ConsultationServiceImpl.CODE_ADVICER_KBN, locale);	// 希望相談員
		List<MsCodeDto> consulKbnList = DbUtil.getJosuList(ConsultationServiceImpl.CODE_CONSUL_KBN, locale);	// 相談項目

		// 相談員リスト
		List<AdvicerDto> advicerList = service.findAllAdvicer(locale);

		// 初期値設定
		form.setRequestKbn(CODE_REQUEST_CARRER);	// 依頼内容：キャリア面談
		form.setAdvicerKbn(CODE_ADVICER_NEED);		// 希望相談員：あり
		form.setConfirmMessageRegist(messageSource.getMessage("consultation.message.confirm.request", null, locale));

		// modelセット
		model.addAttribute("form", form);
		model.addAttribute("requestKbnList", requestKbnList);
		model.addAttribute("advicerKbnList", advicerKbnList);
		model.addAttribute("consulKbnList", consulKbnList);
		model.addAttribute("advicerList", service.editAdvicerName(advicerList));

		// dump
		modelDump(logger, model, "request");
		logger.infoCode("I0002", "request"); // I0002=メソッド終了:{0}

		return REQUEST_PAGE;
	}

	/**
	 * 面談内容詳細画面（メール遷移）
	 *
	 * @param consultationKey
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = { "consultation/detail/{consultationKey}" }, method = RequestMethod.GET)
	public String detailDirect(@PathVariable("consultationKey") String consultationKey, Model model, Locale locale) {
		// 面談内容詳細画面
		return this.detail(consultationKey, model, locale);
	}

	/**
	 * 面談内容詳細画面
	 *
	 * @param name
	 * @param model
	 * @return
	 */
	@RequestMapping(value = { "consultation/detail" }, method = RequestMethod.POST)
	public String detail(@RequestParam String consultationKey, Model model, Locale locale) {
		logger.infoCode("I0001", "detail"); // I0001=メソッド開始:{0}

		// 面談依頼内容詳細情報の取得
		ConsultationDto entity = service.findConsul(consultationKey);

		// 画面出力情報の編集
		ConsultationForm fm = new ConsultationForm();
		if (entity != null) {
			fm = service.getFormItem(locale, entity);
		}

		// modelにセット
		model.addAttribute(CommonConst.FORM_NAME, fm);

		// dump
		modelDump(logger, model, "detail");
		logger.infoCode("I0002", "detail"); // I0002=メソッド終了:{0}

		// 面談内容詳細画面
		return DETAIL_PAGE;
	}

	/**
	 * 面談設定画面（メール遷移）
	 *
	 * @param consultationKey
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = { "consultation/setting/{consultationKey}", "mgmt/consultation/setting/{consultationKey}" }, method = RequestMethod.GET)
	public String settingDirect(@PathVariable("consultationKey") String consultationKey, Model model, Locale locale) {
		// 面談設定画面
		return this.setting(consultationKey, model, locale);
	}

	/**
	 * 面談設定画面
	 *
	 * @param name
	 * @param model
	 * @return
	 */
	@RequestMapping(value = { "consultation/setting", "mgmt/consultation/setting" }, method = RequestMethod.POST)
	public String setting(@RequestParam String consultationKey, Model model, Locale locale) {
		logger.infoCode("I0001", "setting"); // I0001=メソッド開始:{0}

		// 面談依頼内容詳細情報の取得
		ConsultationDto entity = service.findConsul(consultationKey);

		// 画面出力情報の編集
		ConsultationForm form = new ConsultationForm();
		if (entity != null) {
			form = service.getFormItem(locale, entity);
			if ((userInfo.isUser5() && !userInfo.getTargetUserKey().equals(entity.getAdvicerUserKey()))
					|| ConsultationServiceImpl.CODE_CONSUL_STATUS_END.equals(entity.getConsultationStatus())){
				form.setEnabledConfirmButton(false);
			}else{
				form.setEnabledConfirmButton(true);
			}
		}

		// 相談員リスト
		List<AdvicerDto> advicerList = service.findAllAdvicer(locale);

		// メッセージ用
		form.setConfirmMessageRegist(messageSource.getMessage("consultation.message.confirm.regist", null, locale));

		// modelにセット
		if (userInfo.isUser5()) {
			form.setPageActionUrl("");
		}else{
			form.setPageActionUrl(CommonConst.PATH_MGMT);
		}
		model.addAttribute(CommonConst.FORM_NAME, form);
		model.addAttribute("advicerList", service.editAdvicerName(advicerList));

		// dump
		modelDump(logger, model, "setting");
		logger.infoCode("I0002", "setting"); // I0002=メソッド終了:{0}

		// 面談設定画面
		return SETTING_PAGE;
	}

	/**
	 * 面談結果画面（メール遷移）
	 *
	 * @param consultationKey
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = { "consultation/result/{consultationKey}" }, method = RequestMethod.GET)
	public String resultDirect(@PathVariable("consultationKey") String consultationKey, Model model, Locale locale) {
		// 面談結果画面
		return this.result(consultationKey, model, locale);
	}

	/**
	 * 面談結果画面
	 *
	 * @param name
	 * @param model
	 * @return
	 */
	@RequestMapping(value = { "consultation/result" }, method = RequestMethod.POST)
	public String result(@RequestParam String consultationKey, Model model, Locale locale) {
		logger.infoCode("I0001", "result"); // I0001=メソッド開始:{0}

		// 面談依頼内容詳細情報の取得
		ConsultationDto entity = service.findConsul(consultationKey);

		// 画面出力情報の編集
		ConsultationForm form = new ConsultationForm();
		if (entity != null) {
			form = service.getFormItem(locale, entity);
			if (userInfo.getTargetUserKey().equals(entity.getAdvicerUserKey())) {
				form.setEnabledConfirmButton(true);
			}
		}

		// 公開者情報の編集
		List<AdvicerDto> publicAdvicerList = service.getPublicAdvicer(consultationKey, locale, userInfo);
		List<AdvicerDto> nonPublicAdvicerList = service.getNotPublicAdvicer(consultationKey, locale, userInfo);
		form.setPublicAdvicerText(service.getAdvicerText(publicAdvicerList));
		form.setNonPublicAdvicerText(service.getAdvicerText(nonPublicAdvicerList));
		form.setPublicAdvicerList(service.editAdvicerName(publicAdvicerList));
		form.setNonPublicAdvicerList(service.editAdvicerName(nonPublicAdvicerList));

		// メッセージ用
		form.setConfirmMessageRegist(messageSource.getMessage("consultation.message.confirm.regist", null, locale));

		// modelにセット
		model.addAttribute(CommonConst.FORM_NAME, form);

		// dump
		modelDump(logger, model, "result");
		logger.infoCode("I0002", "result"); // I0002=メソッド終了:{0}

		// 面談設定画面
		return RESULT_PAGE;
	}

	/**
	 * 面談依頼・登録処理
	 *
	 * @param name
	 * @param model
	 * @return
	 */
	@RequestMapping(value = { "consultation/registRequest" }, method = RequestMethod.POST)
	public String registRequest(@ModelAttribute(CommonConst.FORM_NAME) @Validated(ConsultationForm.group1.class) ConsultationForm form, Model model, BindingResult bindingResult, RedirectAttributes attributes, Locale locale) {
		logger.infoCode("I0001", "registRequest"); // I0001=メソッド開始:{0}

		// 定数マスタLIST
		List<MsCodeDto> requestKbnList = DbUtil.getJosuList(ConsultationServiceImpl.CODE_REQUEST_KBN, locale);	// 依頼項目
		List<MsCodeDto> advicerKbnList = DbUtil.getJosuList(ConsultationServiceImpl.CODE_ADVICER_KBN, locale);	// 希望相談員
		List<MsCodeDto> consulKbnList = DbUtil.getJosuList(ConsultationServiceImpl.CODE_CONSUL_KBN, locale);	// 相談項目

		// 相談員リスト
		List<AdvicerDto> advicerList = service.findAllAdvicer(locale);

		// modelセット
		model.addAttribute(CommonConst.FORM_NAME, form);
		model.addAttribute("requestKbnList", requestKbnList);
		model.addAttribute("advicerKbnList", advicerKbnList);
		model.addAttribute("consulKbnList", consulKbnList);
		model.addAttribute("advicerList", service.editAdvicerName(advicerList));

		// バリデーション
		if (bindingResult.hasErrors()) {
			if (logger.isDebugEnabled()) {
				logger.debugCode("W1010", bindingResult.getFieldError()); // W1010=Validationチェックエラーがありました。
			}
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.valid.data"); // error.data.message.valid.data=入力項目に誤りがあります。

			logger.infoCode("I0002", "registRequest"); // I0002=メソッド終了:{0}
			return REQUEST_PAGE;
		}

		try {
			// 登録処理
			service.registRequest(form, userInfo, locale);
			// 成功
			attributes.addFlashAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.create.success");	// message.data.create.success=データを新規追加しました。
			// 操作ログ
			super.operationHistory(CommonConst.OP_FUNC_CARRER, CommonConst.OP_ACTION_INSERT);

			// メール配信
			try {
				service.sendMailRequest(form, userInfo, locale);
				// メール配信成功
				logger.infoCode("I0002", "registRequest");		// I0002=メソッド終了:{0}
				// 面談一覧画面に遷移
				return REDIRECT_LIST;

			}catch(Exception e){
				e.printStackTrace();
				model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.mail.send"); // error.data.message.mail.send=メール配信が失敗しました。
			}

		}catch(Exception e){
			e.printStackTrace();
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.regist"); // error.data.message.db.regist=登録が失敗しました。
		}

		// 面談依頼画面
		logger.errorCode("E0014", "registRequest");	// E0014=メソッド異常終了:{0}
		return REQUEST_PAGE;
	}

	/**
	 * 面談一覧・削除処理
	 *
	 * @param name
	 * @param model
	 * @return
	 */
	@RequestMapping(value = { "consultation/registDelete", "mgmt/consultation/registDelete" }, method = RequestMethod.POST)
	public String registDelete(@RequestParam String consultationKey, @RequestParam Timestamp updDate, Model model, RedirectAttributes attributes, Locale locale) {
		logger.infoCode("I0001", "registDelete"); // I0001=メソッド開始:{0}

		try {
			// 削除処理
			service.registDelete(consultationKey, updDate);
			// 成功
			attributes.addFlashAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.delete.success");	// message.data.delete.success=データを削除しました。
			// 操作ログ
			super.operationHistory(CommonConst.OP_FUNC_CARRER, CommonConst.OP_ACTION_DELETE);
			logger.infoCode("I0002", "registDelete");		// I0002=メソッド終了:{0}

		} catch (Exception e) {
			// 失敗
			e.printStackTrace();
			attributes.addFlashAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.remove");	// error.data.message.db.remove=削除が失敗しました。
			logger.errorCode("E0014", "registDelete");	// E0014=メソッド異常終了:{0}
		}

		// 面談一覧画面に遷移
		if (userInfo.isUser5()) {
			return REDIRECT_LIST;
		}else{
			return REDIRECT_LIST_MGMT;
		}
	}

	/**
	 * 面談設定・更新処理
	 *
	 * @param name
	 * @param model
	 * @return
	 */
	@RequestMapping(value = { "consultation/registSetting", "mgmt/consultation/registSetting" }, method = RequestMethod.POST)
	public String registSetting(@Validated(ConsultationForm.group2.class) @ModelAttribute(CommonConst.FORM_NAME) final ConsultationForm form, BindingResult bindingResult, Model model, RedirectAttributes attributes, Locale locale) {
		logger.infoCode("I0001", "registSetting"); // I0001=メソッド開始:{0}

		// 相談員リスト
		List<AdvicerDto> advicerList = service.findAllAdvicer(locale);
		model.addAttribute("advicerList", service.editAdvicerName(advicerList));

		// 入力チェック処理
		service.checkSetting(form, bindingResult, locale);

		// バリデーション
		if (bindingResult.hasErrors()) {
			if (logger.isDebugEnabled()) {
				logger.debugCode("W1010", bindingResult.getFieldError()); // W1010=Validationチェックエラーがありました。
			}
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.valid.data"); // error.data.message.valid.data=入力項目に誤りがあります。
			logger.infoCode("I0002", "registSetting"); // I0002=メソッド終了:{0}
			return SETTING_PAGE;
		}

		try {
			// 更新処理
			service.registSetting(form, userInfo, locale);
			// 成功
			attributes.addFlashAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.update.success");	// message.data.update.success=データを更新しました。
			// 操作ログ
			super.operationHistory(CommonConst.OP_FUNC_CARRER_SETTING, CommonConst.OP_ACTION_INSERT);

			// メール配信
			try {
				service.sendMailSetting(form, locale);
				// メール配信成功
				logger.infoCode("I0002", "registSetting");		// I0002=メソッド終了:{0}
				// 面談一覧画面に遷移
				if (userInfo.isUser5()){
					return REDIRECT_LIST;
				}else{
					return REDIRECT_LIST_MGMT;
				}

			}catch(Exception e){
				e.printStackTrace();
				model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.mail.send"); // error.data.message.mail.send=メール配信が失敗しました。
			}

		}catch(Exception e ){
			e.printStackTrace();
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.regist"); // error.data.message.db.regist=登録が失敗しました。
		}

		// 面談設定画面
		logger.errorCode("E0014", "registSetting");	// E0014=メソッド異常終了:{0}
		return SETTING_PAGE;
	}

	/**
	 * 面談結果・更新処理
	 *
	 * @param name
	 * @param model
	 * @return
	 */
	@RequestMapping(value = { "consultation/registResult" }, method = RequestMethod.POST)
	public String registResult(@ModelAttribute(CommonConst.FORM_NAME) ConsultationForm form, Model model, BindingResult bindingResult, RedirectAttributes attributes, Locale locale) {
		logger.infoCode("I0001", "registResult"); // I0001=メソッド開始:{0}

		// キャリア相談公開者情報の編集
		List<AdvicerDto> publicAdvicerList = service.getPublicAdvicer(form.getPublicAdvicerArray(), locale, userInfo);
		List<AdvicerDto> nonPublicAdvicerList = service.getPublicAdvicer(form.getNonPublicAdvicerArray(), locale, userInfo);
		form.setPublicAdvicerText(service.getAdvicerText(publicAdvicerList));
		form.setNonPublicAdvicerText(service.getAdvicerText(nonPublicAdvicerList));
		form.setPublicAdvicerList(service.editAdvicerName(publicAdvicerList));
		form.setNonPublicAdvicerList(service.editAdvicerName(nonPublicAdvicerList));

		try {
			// 更新処理
			this.service.registResult(form, userInfo, locale);
			// 成功
			attributes.addFlashAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.update.success");	// message.data.update.success=データを更新しました。
			// 操作ログ
			super.operationHistory(CommonConst.OP_FUNC_CARRER_RESULTS, CommonConst.OP_ACTION_INSERT);

			// メール配信
			try {
				service.sendMailResult(form, locale);
				// メール配信成功
				logger.infoCode("I0002", "registResult");	// I0002=メソッド終了:{0}
				// 面談一覧画面に遷移
				return REDIRECT_LIST;

			}catch(Exception e){
				e.printStackTrace();
				model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.mail.send"); // error.data.message.mail.send=メール配信が失敗しました。
			}

		}catch (Exception e){
			e.printStackTrace();
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.regist"); // error.data.message.db.regist=登録が失敗しました。
		}

		// 面談結果画面
		logger.errorCode("E0014", "registResult");	// E0014=メソッド異常終了:{0}
		return RESULT_PAGE;
	}

	/**
	 * ダイレクトアクセス対策
	 *
	 * @return
	 */
	@RequestMapping(value = {"consultation/detail", "consultation/setting", "consultation/result", "consultation/delete", "consultation/registRequest", "consultation/registSetting", "consultation/registResult", "consultation/registDelete"}, method = RequestMethod.GET)
	public String redirect() {
		logger.warnCode("W1009"); // W1009=URLダイレクトアクセスがありました。
		return CommonConst.REDIRECT_INDEX;
	}
}
