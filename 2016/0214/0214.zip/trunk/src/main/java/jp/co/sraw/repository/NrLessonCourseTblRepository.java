package jp.co.sraw.repository;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import jp.co.sraw.entity.NrLessonCourseTbl;
import jp.co.sraw.entity.NrLessonCourseTblPK;

@Scope("prototype")
@Repository
public interface NrLessonCourseTblRepository extends JpaRepository<NrLessonCourseTbl, NrLessonCourseTblPK>, JpaSpecificationExecutor<NrLessonCourseTbl> {

	public NrLessonCourseTbl findByIdLessonKeyAndIdUserKey(String lessonKey, String userKey);

	/**
	 * ユーザに紐づく履修状況の情報を全て取得する
	 * @param useurLey ユーザキー
	 * @return
	 */
	public List<NrLessonCourseTbl> findByIdUserKey (String userKey);
}
