package jp.co.sraw.repository;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import jp.co.sraw.entity.GyOthersTbl;

@Scope("prototype")
@Repository
public interface GyOthersTblRepository extends GyRepository<GyOthersTbl> {

}
