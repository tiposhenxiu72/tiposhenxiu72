/*
* ファイル名：IndexController.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.messagebox;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonController;
import jp.co.sraw.dto.MessageBoxDto;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.service.MessageBoxServiceImpl;
import jp.co.sraw.util.ObjectUtil;
import jp.co.sraw.util.StringUtil;

/**
 * <B>SupportControllerクラス</B>
 * <P>
 * Controllerのメソッドを提供する
 */
@Controller
@RequestMapping("/messagebox")
public class MessageBoxController extends CommonController {

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(MessageBoxController.class);

	@PostConstruct
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	@Autowired
	private MessageBoxServiceImpl messageBoxServiceImpl;

	private static final String REDIRECT_LIST_RECV = "redirect:/messagebox/recv/";
	private static final String REDIRECT_LIST_SEND = "redirect:/messagebox/send/";

	private static final String LIST_PAGE_RECV = "messagebox/recvlist";
	private static final String LIST_PAGE_SEND = "messagebox/sendlist";

	private static final String EDIT_PAGE = "messagebox/edit";

	private static final String VIEW_PAGE_RECV = "messagebox/recvview";
	private static final String VIEW_PAGE_SEND = "messagebox/sendview";

	private static final String PAGE_ACTION_URL_RECV_VIEW = "/messagebox/recv/view";
	private static final String PAGE_ACTION_URL_PORTFOLIO_DETAIL = "/portfolio/detail/"; // ProfileControllerの詳細表示のパスを確認




	@ModelAttribute(CommonConst.FORM_NAME)
	public MessageBoxForm setupForm() {
		MessageBoxForm form = new MessageBoxForm();
		return form;
	}

	/**
	 * 受信トレイ
	 *
	 * @param form
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping({"", "/", "/recv", "/recv/", "/recv/list" })
	public String recvlist(@ModelAttribute(CommonConst.FORM_NAME) final MessageBoxForm form, Model model, Locale locale) {

		logger.infoCode("I0001", "recvlist"); // I0001=メソッド開始:{0}


		if (logger.isDebugEnabled()) {
			logger.debug("LoginUserKey=" + userInfo.getLoginUserKey());
			logger.debug("TargetUserKey=" + userInfo.getTargetUserKey());
		}

		List<MessageBoxDto> messageboxList = new ArrayList<>();

		messageboxList = messageBoxServiceImpl.findAll(userInfo, false, locale);

		model.addAttribute("messageboxList", messageboxList);

		// dump
		modelDump(logger, model, "recvlist");

		logger.infoCode("I0002", "recvlist"); // I0002=メソッド終了:{0}

		return LIST_PAGE_RECV;


	}

	/**
	 * 送信トレイ
	 *
	 * @param form
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping({ "/send", "/send/", "/send/list" })
	public String sendlist(@ModelAttribute(CommonConst.FORM_NAME) final MessageBoxForm form, Model model, Locale locale) {

		logger.infoCode("I0001", "sendlist"); // I0001=メソッド開始:{0}

		if (logger.isDebugEnabled()) {
			logger.debug("LoginUserKey=" + userInfo.getLoginUserKey());
			logger.debug("TargetUserKey=" + userInfo.getTargetUserKey());
		}

		List<MessageBoxDto> messageboxList = new ArrayList<>();

		messageboxList = messageBoxServiceImpl.findAll(userInfo, true, locale);

		model.addAttribute("messageboxList", messageboxList);

		// dump
		modelDump(logger, model, "sendlist");

		logger.infoCode("I0002", "sendlist"); // I0002=メソッド終了:{0}

		return LIST_PAGE_SEND;
	}

	/**
	 * 受信詳細
	 *
	 * @param form
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = "/recv/view", method = RequestMethod.POST)
	public String recvview(@ModelAttribute(CommonConst.FORM_NAME) MessageBoxForm form, Model model, Locale locale) {
		logger.infoCode("I0001", "recvview"); // I0001=メソッド開始:{0}

		MessageBoxDto m = messageBoxServiceImpl.findOne(userInfo, form, false, locale);
		if (m == null) {
			// DB更新が失敗した場合
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.valid.data"); // error.data.message.valid.data=入力項目に誤りがあります。

			logger.errorCode("E0014", "recvview"); // E0014=メソッド異常終了:{0}

			return REDIRECT_LIST_RECV;
		}
		ObjectUtil objectUtil = new ObjectUtil();
		objectUtil.getObjectCopyValue(form, m);

		model.addAttribute(CommonConst.FORM_NAME, form);
		logger.infoCode("I0002", "recvview"); // I0002=メソッド終了:{0}
		return VIEW_PAGE_RECV;
	}

	/**
	 * 送信詳細
	 *
	 * @param form
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = "/send/view", method = RequestMethod.POST)
	public String sendview(@ModelAttribute(CommonConst.FORM_NAME) MessageBoxForm form, Model model, Locale locale) {
		logger.infoCode("I0001", "sendview"); // I0001=メソッド開始:{0}

		MessageBoxDto m = messageBoxServiceImpl.findOne(userInfo, form, true, locale);
		if (m == null) {
			// DB更新が失敗した場合
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.valid.data"); // error.data.message.valid.data=入力項目に誤りがあります。

			logger.errorCode("E0014", "sendview"); // E0014=メソッド異常終了:{0}

			return REDIRECT_LIST_SEND;
		}
		ObjectUtil objectUtil = new ObjectUtil();
		objectUtil.getObjectCopyValue(form, m);

		model.addAttribute(CommonConst.FORM_NAME, form);
		logger.infoCode("I0002", "sendview"); // I0002=メソッド終了:{0}
		return VIEW_PAGE_SEND;
	}

	/**
	 * 新規メッセージ作成
	 *
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public String create(@ModelAttribute(CommonConst.FORM_NAME) MessageBoxForm form, Model model, Locale locale) {

		logger.infoCode("I0001", "create"); // I0001=メソッド開始:{0}

		// ポートフォリオのメッセージ送信より宛先を受け取る。
		// 宛先を設定(返信と同じ画面を使用するため)
		form.setToUserFullName(form.getUserFullName());
		form.setToUserKey(form.getUserKey());
		// 差出人
		form.setUserKey(userInfo.getTargetUserKey());
		form.setFromUserKey(userInfo.getTargetUserKey());
		form.setFromUserFullName(userInfo.getTargetUserName());

		// 確認ダイアログのメッセージ
		form.setConfirmMessageRegist(messageSource.getMessage("message.confirm.send", null, locale));

		// 戻り先設定
		form.setPageMode(CommonConst.PAGE_MODE_ADD);
		form.setPageActionUrl(PAGE_ACTION_URL_PORTFOLIO_DETAIL + form.getToUserKey());
		model.addAttribute(CommonConst.FORM_NAME, form);

		logger.infoCode("I0002", "create"); // I0002=メソッド終了:{0}
		return EDIT_PAGE;
	}

	/**
	 * 返信(編集画面)
	 *
	 * @param form
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public String edit(@ModelAttribute(CommonConst.FORM_NAME) MessageBoxForm form, Model model, Locale locale) {
		logger.infoCode("I0001", "edit"); // I0001=メソッド開始:{0}

		MessageBoxDto m = messageBoxServiceImpl.findOne(userInfo, form, false, locale);
		if (m == null) {
			// DB更新が失敗した場合
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.valid.data"); // error.data.message.valid.data=入力項目に誤りがあります。

			logger.errorCode("E0014", "edit"); // E0014=メソッド異常終了:{0}

			return REDIRECT_LIST_RECV;
		}
		ObjectUtil objectUtil = new ObjectUtil();
		objectUtil.getObjectCopyValue(form, m);

		// 返信
		String toUserKey = form.getToUserKey();
		String toUserFullName = form.getToUserFullName();
		String fromUserKey = form.getFromUserKey();
		String fromUserFullName = form.getFromUserFullName();
		form.setToUserKey(fromUserKey);
		form.setToUserFullName(fromUserFullName);
		form.setFromUserKey(toUserKey);
		form.setFromUserFullName(toUserFullName);
		form.setMessageTitle(appendResvMessageTitle(form.getMessageTitle()));
		form.setMessageContents(appendResvMessageContents(form.getMessageContents()));

		// 確認ダイアログのメッセージ
		form.setConfirmMessageRegist(messageSource.getMessage("message.confirm.send", null, locale));

		// 戻り先設定
		form.setPageMode(CommonConst.PAGE_MODE_EDIT);
		form.setPageActionUrl(PAGE_ACTION_URL_RECV_VIEW);
		model.addAttribute(CommonConst.FORM_NAME, form);

		logger.infoCode("I0002", "edit"); // I0002=メソッド終了:{0}
		return EDIT_PAGE;
	}

	/**
	 * 返信実行(送信)
	 *
	 * @param form
	 * @param bindingResult
	 * @param model
	 * @param attributes
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public String update(@Validated @ModelAttribute(CommonConst.FORM_NAME) final MessageBoxForm form, BindingResult bindingResult, Model model, RedirectAttributes attributes, Locale locale) {

		logger.infoCode("I0001", "update"); // I0001=メソッド開始:{0}

		String rtn = REDIRECT_LIST_RECV;
		// 戻り先設定
		if (CommonConst.PAGE_MODE_EDIT.equals(form.getPageMode())) {
			form.setPageMode(CommonConst.PAGE_MODE_EDIT);
			form.setPageActionUrl(PAGE_ACTION_URL_RECV_VIEW);
		} else {
			form.setPageMode(CommonConst.PAGE_MODE_ADD);
			form.setPageActionUrl(PAGE_ACTION_URL_PORTFOLIO_DETAIL + form.getToUserKey());
			rtn = "redirect:"+ form.getPageActionUrl();
		}

		///////////////////////////////////////////////////////////////////////////////////
		// バリデーションエラーがある場合
		if (bindingResult.hasErrors()) {
			if (logger.isDebugEnabled()) {
				logger.debugCode("W1010", bindingResult.getFieldError()); // W1010=Validationチェックエラーがありました。
			}
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.valid.data"); // error.data.message.valid.data=入力項目に誤りがあります。

			model.addAttribute(CommonConst.FORM_NAME, form);

			logger.infoCode("I0002", "update"); // I0002=メソッド終了:{0}
			return EDIT_PAGE;
		}

		String newMessageKey = "";
		try {
			if (messageBoxServiceImpl.update(userInfo, form, newMessageKey)) {
				// DB更新が成功した場合
				String key = "messageKey=" + newMessageKey;
				logger.infoCode("I1005", key); // I1005=新規作成しました。{0}

				super.operationHistory(CommonConst.OP_FUNC_MESSAGEBOX, CommonConst.OP_ACTION_INSERT); // 操作ログ保存

				attributes.addFlashAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.messagebox.success"); // message.data.messagebox.success=メッセージを送信しました。

				logger.infoCode("I0002", "update"); // I0002=メソッド終了:{0}
				return rtn;
			}
		} catch (Exception e) {
			if (logger.isDebugEnabled()) {
				e.printStackTrace();
			}
		}

		logger.infoCode("I0002", "update"); // I0002=メソッド終了:{0}

		// DB更新が失敗した場合
		model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.regist"); // error.data.message.db.regist=登録が失敗しました。
		logger.errorCode("E0014", "update"); // E0014=メソッド異常終了:{0}
		return rtn;
	}

	/**
	 * 受信メッセージ削除
	 *
	 * @param form
	 * @param model
	 * @param attributes
	 * @return
	 */
	@RequestMapping(value = "/recv/delete", method = RequestMethod.POST)
	public String recvdelete(@ModelAttribute(CommonConst.FORM_NAME) final MessageBoxForm form, Model model, RedirectAttributes attributes) {

		logger.infoCode("I0001", "recvdelete"); // I0001=メソッド開始:{0}

		String key = "messageKey=" + form.getMessageKey();

		if (messageBoxServiceImpl.delete(userInfo, form)) {
			// DB更新が成功した場合
			logger.infoCode("I1003", key); // I1003=削除しました。{0}

			super.operationHistory(CommonConst.OP_FUNC_MESSAGEBOX, CommonConst.OP_ACTION_DELETE); // 操作ログ保存

			attributes.addFlashAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.delete.success"); // message.data.delete.success=データを削除しました。

			attributes.addFlashAttribute(CommonConst.FORM_NAME, form);
			logger.infoCode("I0002", "recvdelete"); // I0002=メソッド終了:{0}
			return REDIRECT_LIST_RECV;
		} else {

			attributes.addFlashAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.remove"); // error.data.message.db.remove=削除が失敗しました。

			model.addAttribute(CommonConst.FORM_NAME, form);
			logger.errorCode("E0014", "recvdelete"); // E0014=メソッド異常終了:{0}
			return REDIRECT_LIST_RECV;
		}
	}

	/**
	 * 送信メッセージ削除
	 *
	 * @param form
	 * @param model
	 * @param attributes
	 * @return
	 */
	@RequestMapping(value = "/send/delete", method = RequestMethod.POST)
	public String senddelete(@ModelAttribute(CommonConst.FORM_NAME) final MessageBoxForm form, Model model, RedirectAttributes attributes) {

		logger.infoCode("I0001", "senddelete"); // I0001=メソッド開始:{0}

		String key = "messageKey=" + form.getMessageKey();

		if (messageBoxServiceImpl.delete(userInfo, form)) {
			// DB更新が成功した場合
			logger.infoCode("I1003", key); // I1003=削除しました。{0}

			super.operationHistory(CommonConst.OP_FUNC_MESSAGEBOX, CommonConst.OP_ACTION_DELETE); // 操作ログ保存

			attributes.addFlashAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.delete.success"); // message.data.delete.success=データを削除しました。

			attributes.addFlashAttribute(CommonConst.FORM_NAME, form);
			logger.infoCode("I0002", "senddelete"); // I0002=メソッド終了:{0}
			return REDIRECT_LIST_SEND;
		} else {

			attributes.addFlashAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.remove"); // error.data.message.db.remove=削除が失敗しました。

			model.addAttribute(CommonConst.FORM_NAME, form);
			logger.errorCode("E0014", "senddelete"); // E0014=メソッド異常終了:{0}
			return REDIRECT_LIST_SEND;
		}
	}

	/**
	 * ダイレクトアクセス対策
	 *
	 * @return
	 */
	@RequestMapping(value = {"/edit", "/recv/view", "/send/view", "/create", "/update", "/recv/delete", "/send/delete"}, method = RequestMethod.GET)
	public String redirect() {
		logger.warnCode("W1009"); // W1009=URLダイレクトアクセスがありました。
		return CommonConst.REDIRECT_INDEX;
	}

	/**
	 * 返信時の件名に引用符「Re:」追加
	 *
	 * @param message
	 * @return
	 */
	private String appendResvMessageTitle(String messageTitle) {
		String appendStr = "Re:";
		if (messageTitle != null) {
			if (!messageTitle.startsWith(appendStr)) {
				return appendStr +" "+ messageTitle;
			}
		} else {
			return "";
		}
		return messageTitle;
	}

	/**
	 * 返信時の本文に引用符「>」追加
	 *
	 * @param message
	 * @return
	 */
	private String appendResvMessageContents(String messageContents) {
		StringBuilder b = new StringBuilder();
		String appendStr = ">";
		if (messageContents != null) {
			String tmp = StringUtil.nl2Lf(messageContents);
			String[] lines = tmp.split("\r?\n");
			b.append("\n"); // 一行目に空文字追加
			for (String s : lines) {
				b.append("\n"); // 一行目に空文字追加
				if (s.startsWith(appendStr +" ")) {
					b.append(appendStr + s );
				} else {
					b.append(appendStr +" "+ s);
				}
			}
		} else {
			return "";
		}
		return b.toString();
	}

}
