package jp.co.sraw.repository;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import jp.co.sraw.entity.GyCompetitionTbl;

@Scope("prototype")
@Repository
public interface GyCompetitionTblRepository extends GyRepository<GyCompetitionTbl> {

}
