#!/bin/sh
SHELL=/bin/bash
PATH=/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin:/home/srahira/bin
MAILTO=srahira
HOME=/home/srahira
LANG=ja_JP.UTF-8

_LOGDATA_DIR="/home/srahira/log"         # ログ格納Dir
_HOSTNAME=`hostname`            # ホスト名情報取得
_LOGNAME="eportfolio_file_`date '+%Y%m%d%H%M%S'`" 
_LOGFILE01="${_LOGDATA_DIR}/${_LOGNAME}.log"        # 出力ログファイル
_DATE="`date +%y%m%d`"          # 日付情報取得
_TIME="`date +%H%M%S`"          # 時間情報取得
FILEHOST="172.16.2.231"         # ファイルサーバーのホスト名またはIP
FILEUSER="srahira"              # ファイルサーバーのユーザー

# バックアップ元のディレクトリ
_TARGETDIR="/opt/eportfolio/data/"
# バックアップ先ディレクトリ
_BKUPDIR="/opt/eportfolio/backup/file/"


# ファイル名を定義(※ファイル名で日付がわかるようにしておきます)

#
# 処理開始
#
echo "`date '+%Y/%m/%d %H:%M:%S'` -- eportfolio START -- " > ${_LOGFILE01}

# pg_dump実行
echo "rsync -auvze "ssh -p 22" --delete ${FILEUSER}@${FILEHOST}:${_TARGETDIR} ${_BKUPDIR}" >> ${_LOGFILE01} 2>> ${_LOGFILE01}
cd ${_BKUPDIR}
/usr/bin/rsync -auvze "ssh -p 22" --delete ${FILEUSER}@${FILEHOST}:${_TARGETDIR} ${_BKUPDIR}   >> ${_LOGFILE01} 2>> ${_LOGFILE01}


#
# 処理終了
#
echo "`date '+%Y/%m/%d %H:%M:%S'` -- eportfolio END   -- "  >> ${_LOGFILE01} 2>> ${_LOGFILE01}


###########################################################################
#ssh キー手順。srahiraで実施
#※ アクセス元
#$ cd /home/srahira
#$ ssh-keygen -t rsa
#$ scp /home/srahira/.ssh/id_rsa.pub srahira@対象ホスト:/home/srahira/eportfolio_id_rsa.pub
#
#※アクセス先
#$ ssh srahira@対象ホスト
#$ cat eportfolio_id_rsa.pub >> /home/srahira/.ssh/authorized_keys
#$ chmod 600 /home/srahira/.ssh/authorized_keys
#

