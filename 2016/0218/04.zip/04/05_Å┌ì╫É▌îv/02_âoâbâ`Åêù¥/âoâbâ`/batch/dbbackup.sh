#!/bin/sh
SHELL=/bin/bash
PATH=/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin:/home/srahira/bin
MAILTO=srahira
HOME=/home/srahira
LANG=ja_JP.UTF-8

_LOGDATA_DIR="/home/srahira/log"         # ログ格納Dir
_HOSTNAME=`hostname`            # ホスト名情報取得
_LOGNAME="eportfolio_db_`date '+%Y%m%d%H%M%S'`" 
_LOGFILE01="${_LOGDATA_DIR}/${_LOGNAME}.log"        # 出力ログファイル
_DATE="`date +%y%m%d`"          # 日付情報取得
_TIME="`date +%H%M%S`"          # 時間情報取得
DBHOST="172.16.2.231"
#DBNAME="eportfolio"
DBNAME="pfolio"
#DBUSER="eportfolio"
DBUSER="pfolio"

# バックアップファイルを何日分残しておくか
_PERIOD=7
# バックアップファイルを保存するディレクトリ
_BKUPDIR="/opt/eportfolio/backup/db"

# ファイル名を定義(※ファイル名で日付がわかるようにしておきます)

#
# 処理開始
#
echo "`date '+%Y/%m/%d %H:%M:%S'` -- eportfolio START -- " > ${_LOGFILE01}

# pg_dump実行
echo "pg_dump -U${DBUSER} -h${DBHOST} -d ${DBNAME}" >> ${_LOGFILE01} 2>> ${_LOGFILE01}
cd ${_BKUPDIR}
/usr/bin/pg_dump -Ft -b -U${DBUSER} -h${DBHOST} -d ${DBNAME} | gzip > ${_BKUPDIR}/eportfolio_db_${_DATE}_${_TIME}.tar.gz 2>> ${_LOGFILE01}

# vacuumdb実行
echo "vacuumdb --full --analyze -h${DBHOST} -U${DBUSER} -d ${DBNAME}" >> ${_LOGFILE01} 2>> ${_LOGFILE01}
/usr/bin/vacuumdb --full --analyze -h${DBHOST} -U${DBUSER} -d ${DBNAME} 2>> ${_LOGFILE01}

# 古いバックアップファイルを削除
_OLDFILE=`date --date "${_PERIOD} days ago" +%y%m%d`
rm -f ${_BKUPDIR}/eportfolio_db_${_OLDFILE}_*

#
# 処理終了
#
echo "`date '+%Y/%m/%d %H:%M:%S'` -- eportfolio END   -- "  >> ${_LOGFILE01} 2>> ${_LOGFILE01}

