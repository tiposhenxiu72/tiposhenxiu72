/*
* ファイル名：MultiViewForm.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.form;

import java.util.Map;

import jp.co.sraw.common.CommonForm;
import jp.co.sraw.dto.MsCodeDto;
import jp.co.sraw.util.DbUtil;
import jp.co.sraw.util.StringUtil;

/*;
 * Formのメソッドを提供する
 */
public class MultiViewForm extends CommonForm {

	public static final String DELIMITER = ":";

	public MultiViewForm() {

	}

	protected String getContent(String value, String code) {
		if (this.viewType.equals(VIEW_TYPE_FORM)) {
			return getFormFormat(value, code);
		}
		if (this.viewType.equals(VIEW_TYPE_EXCEL)) {
			return getExcelFormat(value, code);
		}
		return value;
	}

	public String getExcelFormat(String title, String code) {
		if (StringUtil.isNull(code)) {
			return "";
		}
		Map<String, MsCodeDto> map = DbUtil.getJosuMap(code);
		MsCodeDto dto = map.get(title);
		if (dto != null) {
			return title + DELIMITER + dto.getValue();
		}
		return title + DELIMITER + "";
	}

	public String getFormFormat(String title, String code) {
		if (StringUtil.isNull(code)) {
			return "";
		}
		Map<String, MsCodeDto> map = DbUtil.getJosuMap(code);
		MsCodeDto dto = map.get(title);
		if (dto != null) {
			return dto.getValue();
		}
		return title;
	}
}
