/*
* ファイル名：GySocietyForm.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.portfolio.form;

import org.hibernate.validator.constraints.NotBlank;
import org.maru.m4hv.extensions.constraints.CharLength;

import jp.co.sraw.util.StringUtil;

/**
 * <B>GyHasTitleFormクラス</B>
 * <P>
 * Formのメソッドを提供する
 */
public class GyHasTitleForm extends PortfolioForm {

	@NotBlank
	@CharLength(max = 255)
	private String title;

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	private String prePublicFlag;

	public String getPrePublicFlag() {
		if (StringUtil.isNull(this.prePublicFlag)) {
			this.prePublicFlag = this.getPublicFlag();
		}
		return prePublicFlag;
	}

	public void setPrePublicFlag(String prePublicFlag) {
		this.prePublicFlag = prePublicFlag;
	}

}
