/*
* ファイル名：CommonController.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.common;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.client.RestTemplate;

import jp.co.sraw.context.AppContextService;
import jp.co.sraw.dto.OperateInfoDto;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.security.gakunin.Gakunin;
import jp.co.sraw.service.MenuServiceImpl;
import jp.co.sraw.service.OperationHistoryServiceImpl;
import jp.co.sraw.util.DateUtil;
import jp.co.sraw.util.ObjectUtil;
import jp.co.sraw.util.StringUtil;

/**
 * <B>CommonControllerクラス</B>
 * <P>
 * Controllerのメソッドを提供する
 */
public abstract class CommonController {

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(CommonController.class);

	// ユーザー情報
	protected UserInfo userInfo;

	@Autowired
	protected MessageSource messageSource;

	@Autowired
	protected SystemSetting systemSetting;

	@Autowired
	protected MenuServiceImpl menuServiceImpl;

	@Autowired
	protected OperationHistoryServiceImpl operationHistoryServiceImpl;

	@Autowired
	protected AppContextService appContext;

	@PostConstruct
	protected abstract void init();

	/**
	 * ログインユーザー情報を取得しuserInfoをModelにセット
	 *
	 * @return
	 */
	@Order(-10)
	@ModelAttribute("userInfo")
	public UserInfo userInfo() {
		//
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		if (authentication != null) {
			Object principal = authentication.getPrincipal();
			if (principal instanceof UserInfo) {
				this.userInfo = (UserInfo) principal;
				// メニュー
				this.userInfo.setMenuList(menuServiceImpl.findAllRoleMenu(userInfo.getTargetRoleCode()));
				this.userInfo.setAccessUriList(menuServiceImpl.findAllRoleUri(userInfo.getTargetRoleCode()));
				return this.userInfo;
			}
		}
		return null;
	}

	/**
	 * 設定ロールに合わせてURIアクセス許可チェックをModelにセット
	 *
	 * @return
	 */
	@Order(10)
	@ModelAttribute("accessUri")
	protected boolean accessUri(HttpServletRequest request) {

		boolean rlt = false;
		// 対象外(メニューテーブルに存在しないURI)
		Set<String> na = new HashSet<String>();
		if (!CollectionUtils.isEmpty(systemSetting.getAccessUriList())) {
			for (String u : systemSetting.getAccessUriList()) {
				if (!u.startsWith("/")) {
					u = "/" + u;
				}
				if (!u.endsWith("/")) {
					u = u + "/";
				}
				na.add(u);
			}
		}
		// ログイン済み
		if (userInfo != null) {
			Set<String> accessUriList = this.userInfo.getAccessUriList();
			accessUriList.addAll(na); // 対象外追加

			// 最後に「/」があるかチェック
			String rContext = request.getContextPath();
			String rUri = request.getRequestURI();
			rUri = rUri.replaceFirst(rContext, "");
			if (!rUri.endsWith("/")) {
				rUri = rUri + "/";
			}
			// メニュー存在チェック
			for (String u : accessUriList) {
				if (rUri.startsWith(u)) {
					rlt = true;
					break;
				}
			}
			// 「/」の場合
			if ("/".equals(rUri)) {
				rlt = true;
			}
			// システム管理者の場合
			if (userInfo.isAdmin()) {
				rlt = true;
			}
		}
		return rlt;
	}

	/**
	 * 学認対象のドメイン取得(idpリスト)
	 *
	 * @return
	 */
	protected List<Gakunin> getGakuninList() {
		List<Gakunin> gakuninList = new ArrayList<Gakunin>();
		try {
			boolean gakuninFlag = systemSetting.isGakuninFlag();
			String targetIdpListUrl = systemSetting.getGakuninIdpListUrl();
			if (gakuninFlag && StringUtil.isNotNull(targetIdpListUrl)) {

				HttpHeaders headers = new HttpHeaders();
				List<MediaType> supportedMediaTypes = new ArrayList<MediaType>();
				supportedMediaTypes.add(MediaType.ALL);
				// supportedMediaTypes.add(MediaType.APPLICATION_OCTET_STREAM);
				// supportedMediaTypes.add(MediaType.APPLICATION_JSON_UTF8);
				// supportedMediaTypes.add(MediaType.APPLICATION_JSON);
				HttpEntity<?> requestEntity = new HttpEntity<Object>(headers);

				RestTemplate restTemplate = new RestTemplate();

				// jsonで取得するメディアタイプ指定 ※重要
				MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
				converter.setSupportedMediaTypes(supportedMediaTypes);

				restTemplate.getMessageConverters().add(converter);

				ResponseEntity<Gakunin[]> responseEntity = restTemplate.exchange(targetIdpListUrl, HttpMethod.GET,
						requestEntity, Gakunin[].class);

				Gakunin[] gakunins = responseEntity.getBody();
				gakuninList = Arrays.asList(gakunins);

				if (logger.isDebugEnabled()) {
					for (Gakunin g : gakuninList) {
						logger.debug("Idp EntityID={}", g.getEntityID());
					}
				}

			}
		} catch (Exception e) {
			if (logger.isDebugEnabled()) {
				e.printStackTrace();
			}
		}

		return gakuninList;
	}

	/**
	 * for dubug
	 *
	 * @param model
	 * @param m
	 */
	public void modelDump(LoggerWrapper logger, Model model, String modelName) {
		if (logger.isDebugEnabled()) {
			logger.debug("Model:{}", modelName);
			if (model != null) {
				Map<String, Object> mm = model.asMap();
				for (Entry<String, Object> entry : mm.entrySet()) {
					logger.debug("  key:{}=value:{}", entry.getKey(), mm.get(entry.getKey()));
				}
			} else {
				logger.debug("  Model is ", model);
			}
		}
	}

	/**
	 * 操作履歴
	 *
	 * @param operationFuncId
	 *            操作機能ID
	 * @param operationActionId
	 *            操作ID
	 */
	public void operationHistory(String operationFuncId, String operationActionId) {
		putOperationHistory(userInfo.getTargetUserKey(), operationFuncId, operationActionId,
				userInfo.getLoginUserKey());
	}

	/**
	 * 操作履歴テーブルに操作履歴を出力する。
	 *
	 * @param operationUserKey
	 * @param operationFuncId
	 * @param operationActionId
	 * @param updUserKey
	 */
	private void putOperationHistory(String operationUserKey, String operationFuncId, String operationActionId,
			String updUserKey) {
		try {
			OperateInfoDto operateInfoDto = new OperateInfoDto();
			operateInfoDto.setOerationFuncId(operationFuncId);
			operateInfoDto.setOperationActionId(operationActionId);
			operateInfoDto.setOperationDate(DateUtil.getNowTimestamp());
			operateInfoDto.setOperationUserKey(operationUserKey);
			operateInfoDto.setUpdDate(DateUtil.getNowTimestamp());
			operateInfoDto.setUpdUserKey(updUserKey);
			operationHistoryServiceImpl.insert(operateInfoDto);
		} catch (Exception e) {
			e.printStackTrace();
			;
		}
	}

	public Object setMapCopyValue(Object targetObject, Map sourceObject) {
		ObjectUtil util = new ObjectUtil();
		return util.setMapCopyValue(targetObject, sourceObject);
	}

	public Object getObjectCopyValue(Object targetObject, Object sourceObject) {
		ObjectUtil util = new ObjectUtil();
		return util.getObjectCopyValue(targetObject, sourceObject);
	}

	/**
	 * 表示公開フラグチェック
	 *
	 * @param userPublicFlag
	 *            ユーザーの公開設定
	 * @param targetPublicFlag
	 *            画面表示したい公開設定(ポートフォリオ表示の切り替えなど)
	 * @return
	 */
	public boolean isPortfolioPublicFlag(String userPublicFlag, String targetPublicFlag) {
		// すべて表示の場合
		if (CommonConst.USER_PUBLIC_FLAG_NOT.equals(targetPublicFlag)
				&& (CommonConst.USER_PUBLIC_FLAG_NOT.equals(userPublicFlag)
						|| CommonConst.USER_PUBLIC_FLAG_INSIDE.equals(userPublicFlag)
						|| CommonConst.USER_PUBLIC_FLAG_OUTSIDE.equals(userPublicFlag))) {
			return true;
		}
		// 内部公開の場合
		if (CommonConst.USER_PUBLIC_FLAG_INSIDE.equals(targetPublicFlag)
				&& (CommonConst.USER_PUBLIC_FLAG_INSIDE.equals(userPublicFlag)
						|| CommonConst.USER_PUBLIC_FLAG_OUTSIDE.equals(userPublicFlag))) {
			return true;
		}
		// 全(外部)公開の場合
		if (CommonConst.USER_PUBLIC_FLAG_OUTSIDE.equals(targetPublicFlag)
				&& CommonConst.USER_PUBLIC_FLAG_OUTSIDE.equals(userPublicFlag)) {
			return true;
		}

		return false;
	}

	/**
	 * 非表示公開フラグチェック(定数区分:0024)
	 *
	 * @param publicFlag
	 * @return
	 */
	public boolean isPublicFlagNot(String publicFlag) {
		// 非公開の場合
		if (CommonConst.USER_PUBLIC_FLAG_NOT.equals(publicFlag)) {
			return true;
		}
		return false;
	}

	/**
	 * 内部公開フラグチェック(定数区分:0024)
	 *
	 * @param publicFlag
	 * @return
	 */
	public boolean isPublicFlagInside(String publicFlag) {
		// 内部公開または全(外部)公開の場合
		if (CommonConst.USER_PUBLIC_FLAG_INSIDE.equals(publicFlag)
				|| CommonConst.USER_PUBLIC_FLAG_OUTSIDE.equals(publicFlag)) {
			return true;
		}
		return false;
	}

	/**
	 * 全(外部)公開フラグチェック(定数区分:0024)
	 *
	 * @param publicFlag
	 * @return
	 */
	public boolean isPublicFlagOutside(String publicFlag) {
		// 全(外部)公開の場合
		if (CommonConst.USER_PUBLIC_FLAG_OUTSIDE.equals(publicFlag)) {
			return true;
		}
		return false;
	}

}
