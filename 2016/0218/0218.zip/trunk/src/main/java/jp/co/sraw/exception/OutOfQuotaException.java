package jp.co.sraw.exception;

/**
 * ファイルストレージの容量割り当てを超過するときの例外。
 *
 */
public class OutOfQuotaException extends Exception {
	private static final long serialVersionUID = 1L;

	private String kbn; // ファイル区分。

	public OutOfQuotaException(String kbn) {
		this.kbn = kbn;
	}

	public String getFileKbn() {
		return kbn;
	}
}
