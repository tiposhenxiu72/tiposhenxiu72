/*
* ファイル名：SkillDiagServiceImpl.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/01/05   etoh        新規作成
*/
package jp.co.sraw.service;

import java.io.File;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonService;
import jp.co.sraw.common.UserInfo;
import jp.co.sraw.controller.skill.AnswerForm;
import jp.co.sraw.controller.skill.DiagForm;
import jp.co.sraw.controller.skill.ReportForm;
import jp.co.sraw.controller.skill.SkillDiagController;
import jp.co.sraw.dto.SkillAnswerDto;
import jp.co.sraw.entity.CmFileUploadTbl;
import jp.co.sraw.entity.NrAchievementReportBkupTbl;
import jp.co.sraw.entity.NrAchievementReportTbl;
import jp.co.sraw.entity.NrLessonRelSubjectTbl;
import jp.co.sraw.entity.NrSubjectAnswerBkupTbl;
import jp.co.sraw.entity.NrSubjectAnswerBkupTblPK;
import jp.co.sraw.entity.NrSubjectAnswerTbl;
import jp.co.sraw.entity.NrSubjectAnswerTblPK;
import jp.co.sraw.entity.NrSubjectUploadTbl;
import jp.co.sraw.entity.NrSubjectUploadTblPK;
import jp.co.sraw.entity.UsInfoTbl;
import jp.co.sraw.entity.UsScheduleTbl;
import jp.co.sraw.entity.UsUserTbl;
import jp.co.sraw.exception.OutOfQuotaException;
import jp.co.sraw.file.FileService;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.oxm.rubric.Rubric;
import jp.co.sraw.oxm.rubric.RubricCategory;
import jp.co.sraw.oxm.rubric.RubricPhase;
import jp.co.sraw.repository.NrAchievementReportBkupTblRepository;
import jp.co.sraw.repository.NrAchievementReportTblRepository;
import jp.co.sraw.repository.NrLessonRelSubjectTblRepository;
import jp.co.sraw.repository.NrSubjectAnswerBkupTblRepository;
import jp.co.sraw.repository.NrSubjectAnswerTblRepository;
import jp.co.sraw.repository.NrSubjectUploadBkupTblRepository;
import jp.co.sraw.repository.NrSubjectUploadTblRepository;
import jp.co.sraw.repository.UsInfoTblRepository;
import jp.co.sraw.repository.UsScheduleTblRepository;
import jp.co.sraw.util.DateUtil;
import jp.co.sraw.util.StringUtil;

/**
 * <B>能力診断関連のビジネスロジック</B>
 * <P>
 */
@Scope("prototype")
@Service
@Transactional(readOnly = true)
public class SkillDiagServiceImpl extends CommonService {
	private static final int TARGETKBN_WHOLE = 8253; // 全体目標。
	private static final int TARGETKBN_ANNUAL = 8254; // 年間目標。
	private static final String DATAKBN_REPORT = CommonConst.INFO_DATA_KBN_TRAINING;
	private static final int DAYRANGE_TO_INFORM = 7;
	private static final int[] CODE_GROUPING_LENS = { 1, 2, 100 };

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(SkillDiagServiceImpl.class);

	// nr_subject_answer_tblのdepth。
	private static final int ANSWERDEPTH_SUBCAT = 1;
	private static final int ANSWERDEPTH_ITEM = 2;

	// cm_file_upload_tblのfile_kbnとcalc_flag。
	private static final String FILEKBN_DEFAULT = CommonConst.UPLOAD_FILE_KBN_SUBJECT;
	private static final String CALCFLAG_DEFAULT = "0";

	private static final String RELLEVEL_FOR_RECOMMEND = "2";

	@Autowired
	private NrSubjectAnswerTblRepository answerRepository;

	@Autowired
	private CmFileUploadServiceImpl uploadService;

	@Autowired
	private FileService fileService;

	@Autowired
	private NrLessonRelSubjectTblRepository lessonSubjectRepository;

	@Autowired
	private NrSubjectAnswerBkupTblRepository backupAnswerRepository;

	@Autowired
	private NrSubjectUploadBkupTblRepository backupUploadRepository;

	@Autowired
	private NrAchievementReportBkupTblRepository backupReportRepository;

	@Autowired
	private NrSubjectUploadTblRepository evidenceRepository;

	@Autowired
	private NrAchievementReportTblRepository reportRepository;

	@Autowired
	private UsInfoTblRepository infoRepository;

	@Autowired
	private UsScheduleTblRepository scheduleRepository;

	@Override
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	/**
	 * 小項目かどうかを返す。
	 * @param abilityCode
	 * @return
	 */
	public static boolean isItem(String abilityCode) {
		return abilityCode.matches("[A-Z][0-9]+\\.[0-9]+");
	}

	public List<NrSubjectAnswerTbl> findAnswers(String userKey, String rubricKey) {
		return answerRepository.findByIdUserKeyAndIdRubricKeyOrderByUpdDateDesc(userKey, rubricKey);
	}

	public List<NrSubjectAnswerBkupTbl> findPastAnswers(String userKey, String rubricKey) {
		return backupAnswerRepository.findByIdUserKeyAndIdRubricKey(userKey, rubricKey);
	}

	public List<NrSubjectAnswerBkupTbl> findPastAnswers(String userKey, String rubricKey, Date savedDate) {
		return backupAnswerRepository.findByIdUserKeyAndIdRubricKeyAndIdSaveDateOrderByUpdDateDesc(userKey, rubricKey,
				savedDate);
	}

	public NrSubjectAnswerTbl findAnswerByAbilityCode(String userKey, String rubricKey, String abilityCode) {
		return answerRepository.findByIdUserKeyAndIdRubricKeyAndIdSubjectCode(userKey, rubricKey, abilityCode);
	}

	public NrSubjectAnswerBkupTbl findPastAnswerByAbilityCode(String userKey, String rubricKey, String abilityCode,
			Date savedDate) {
		return backupAnswerRepository.findByIdUserKeyAndIdRubricKeyAndIdSubjectCodeAndIdSaveDate(userKey, rubricKey,
				abilityCode, savedDate);
	}

	public List<NrLessonRelSubjectTbl> findAllLessons(String rubricKey) {
		return lessonSubjectRepository.findByIdRubricKeyAndRelationLevelOrderByIdSubjectCodeAscNrLessonTblLessonName(
				rubricKey, RELLEVEL_FOR_RECOMMEND);
	}

	public List<Object[]> findAllLessonsTaken(String rubricKey, String userKey, int level) {
		return lessonSubjectRepository.allLessonsTaken(rubricKey, userKey, CODE_GROUPING_LENS[level]);
	}

	public NrAchievementReportTbl findReport(String userKey) {
		return reportRepository.findByUserKey(userKey);
	}

	public NrAchievementReportBkupTbl findPastReport(String userKey, java.sql.Date savedDate) {
		return backupReportRepository.findByIdUserKeyAndIdSaveDate(userKey, savedDate);
	}

	public List<NrAchievementReportBkupTbl> findPastReports(String userKey) {
		return backupReportRepository.findByIdUserKeyOrderByUpdDateDesc(userKey);
	}

	public ReportForm reportForEdit(UserInfo userInfo) {
		NrAchievementReportTbl entity = reportRepository.findOne(userInfo.getTargetUserKey());
		ReportForm form = new ReportForm();
		if (entity != null) {
			form.setWholeInputDate(entity.getAllInputDate());
			form.setWholeDueDate(entity.getAllLimitDate());
			form.setWholeTarget(entity.getAllAchievement());
			form.setAnnualInputDate(entity.getYearlyInputDate());
			form.setAnnualDueDate(entity.getYearlyLimitDate());
			form.setAnnualTarget(entity.getYearlyAchievement());
		}
		return form;
	}

	// 最新回答と過去回答を統一的に扱うためのクラス(ダサいけど)。
	private class Answer {
		private NrSubjectAnswerTbl ans; // 最新。
		private NrSubjectAnswerBkupTbl past; // 過去。

		public Answer(NrSubjectAnswerTbl ans) {
			this.ans = ans;
		}

		public Answer(NrSubjectAnswerBkupTbl past) {
			this.past = past;
		}

		public AnswerPK getId() {
			if (ans != null) {
				return new AnswerPK(ans.getId());
			}
			return new AnswerPK(past.getId());
		}

		public String getActionPlan() {
			if (ans != null) {
				return ans.getActionPlan();
			}
			return past.getActionPlan();
		}

		public String getEvidence() {
			if (ans != null) {
				return ans.getEvidence();
			}
			return past.getEvidence();
		}

		public String fileIdIfAny() {
			if (ans != null) {
				if (ans.getNrSubjectUploadTbls() == null || ans.getNrSubjectUploadTbls().isEmpty()) {
					return null;
				}
				return ans.getNrSubjectUploadTbls().get(0).getId().getUploadKey();
			}
			if (past.getNrSubjectUploadBkupTbls() == null || past.getNrSubjectUploadBkupTbls().isEmpty()) {
				return null;
			}
			return past.getNrSubjectUploadBkupTbls().get(0).getId().getUploadKey();
		}

		public Integer getAnswer() {
			if (ans != null) {
				return ans.getAnswer();
			}
			return past.getAnswer();
		}

		public String getAchievePhase() {
			if (ans != null) {
				return ans.getAchievePhase();
			}
			return past.getAchievePhase();
		}
	}

	private class AnswerPK {
		private NrSubjectAnswerTblPK ans;
		private NrSubjectAnswerBkupTblPK past;

		public AnswerPK(NrSubjectAnswerTblPK ans) {
			this.ans = ans;
		}

		public AnswerPK(NrSubjectAnswerBkupTblPK past) {
			this.past = past;
		}

		public String getSubjectCode() {
			if (ans != null) {
				return ans.getSubjectCode();
			}
			return past.getSubjectCode();
		}
	}

	/**
	 * Formに、回答をセットする。最新回答用。<BR>
	 * DBにエントリがあるかどうかに関係なく、全オブジェクトを生成する。
	 *
	 * @param form
	 * @param answers
	 * @param rub
	 */
	public void populateForm(DiagForm form, List<NrSubjectAnswerTbl> answers, Rubric rub) {
		populateForm(form, answers.stream().map(Answer::new), rub);
	}

	/**
	 * Formに、回答をセットする。過去回答用。<BR>
	 * DBにエントリがあるかどうかに関係なく、全オブジェクトを生成する。
	 *
	 * @param form
	 * @param answers
	 * @param rub
	 */
	public void populateFormForPast(DiagForm form, List<NrSubjectAnswerBkupTbl> answers, Rubric rub) {
		populateForm(form, answers.stream().map(Answer::new), rub);
	}

	// 最新/過去、共用。
	private void populateForm(DiagForm form, Stream<Answer> answers, Rubric rub) {
		Map<String, List<Answer>> map = answers.collect(Collectors.groupingBy(ans -> ans.getId().getSubjectCode()));
		List<AnswerForm> cats = new ArrayList<AnswerForm>();
		rub.getCategoryList().forEach(cat -> {
			AnswerForm f = new AnswerForm(); // いまのところ大項目に対する回答は無いのだが、構造上、必要。
			populateFormCategory(f, map, cat);
			cats.add(f);
		});
		form.setCategoryList(cats);
	}

	// 大項目。
	private void populateFormCategory(AnswerForm form, Map<String, List<Answer>> map, RubricCategory cat) {
		form.setSubjectCode(cat.getAbilityCode()); // abilityCodeは常にセット。

		// 各中項目。
		List<AnswerForm> subcs = new ArrayList<AnswerForm>();
		cat.getChildList().forEach(subc -> {
			AnswerForm f = new AnswerForm();
			populateFormSubCat(f, map, subc);
			subcs.add(f);
		});
		form.setChildList(subcs);
	}

	// 中項目。
	private void populateFormSubCat(AnswerForm form, Map<String, List<Answer>> map, RubricCategory subc) {
		form.setSubjectCode(subc.getAbilityCode()); // abilityCodeは常にセット。

		// 中項目の回答。
		if (map.containsKey(subc.getAbilityCode())) { // DBに回答あり?
			populateFormWithBasicAnswer(form, map.get(subc.getAbilityCode()).get(0));
		}

		// 各小項目。
		List<AnswerForm> items = new ArrayList<AnswerForm>();
		subc.getChildList().forEach(item -> {
			AnswerForm f = new AnswerForm();
			if (map.containsKey(item.getAbilityCode())) { // DBに回答あり?
				// この中でabilityCodeをセットする。
				// つまり小項目の場合、DBに回答がある場合のみ、abilityCodeを持つ。
				populateFormItem(f, map.get(item.getAbilityCode()).get(0));
			}
			items.add(f); // DB有無に関係なくリストに追加。
		});
		form.setChildList(items);

	}

	// 小項目。
	private void populateFormItem(AnswerForm form, Answer ans) {
		form.setSubjectCode(ans.getId().getSubjectCode());

		populateFormWithBasicAnswer(form, ans);

		// 小項目独自の項目。
		form.setDone(ansToBoolean(ans.getAnswer()));
		form.setPhase(phaseToInteger(ans.getAchievePhase()));
	}

	/**
	 * 回答の中でも、中項目と小項目に共通するフィールドをセットする。
	 *
	 * @param form
	 * @param ans
	 */
	private void populateFormWithBasicAnswer(AnswerForm form, Answer ans) {
		form.setActionPlan(ans.getActionPlan());
		form.setEvidence(ans.getEvidence());
		String uploadKey = ans.fileIdIfAny();
		if (uploadKey != null) {
			CmFileUploadTbl file = uploadService.getOne(uploadKey);
			form.setEvidenceFileName(file.getFileName());
			form.setEvidenceFileId(file.getUploadKey());
		}
	}

	private Boolean ansToBoolean(Integer ans) {
		if (ans == null) {
			return null;
		}
		return ans == 1 ? true : false;
	}

	private Integer ansToInteger(Boolean ans) {
		if (ans == null) {
			return null;
		}
		return ans ? 1 : 0;
	}

	private Integer phaseToInteger(String phase) {
		if (StringUtil.isNull(phase)) {
			return null;
		}
		return Integer.valueOf(phase);
	}

	/**
	 * Dtoに小項目の情報と回答内容をセットする。
	 *
	 * @param dto
	 * @param ans
	 * @param item
	 */
	public void populateDto(SkillAnswerDto dto, String position, NrSubjectAnswerTbl ans, RubricCategory item) {
		populateDto(dto, position, ans != null ? new Answer(ans) : null, item);
	}

	public void populateDto(SkillAnswerDto dto, String position, NrSubjectAnswerBkupTbl ans, RubricCategory item) {
		populateDto(dto, position, ans != null ? new Answer(ans) : null, item);
	}

	private void populateDto(SkillAnswerDto dto, String position, Answer ans, RubricCategory item) {
		// 小項目の情報。
		dto.setAbilityCode(item.getAbilityCode());
		dto.setName(item.getName());
		RubricPhase[] pmap = item.getPhaseMap();
		dto.setPhaseTargets(
				(String[]) Arrays.stream(pmap).map(p -> p == null ? null : p.getTarget()).toArray(String[]::new));
		dto.setYourTargetPhase(item.getTargetMap().get(position));
		dto.setColSpans(colSpans(pmap));

		// 回答内容。
		dto.setCreating(ans == null);
		if (ans != null) {
			dto.setDone(ansToBoolean(ans.getAnswer()));
			dto.setPhase(phaseToInteger(ans.getAchievePhase()));
			dto.setActionPlan(ans.getActionPlan());
			dto.setEvidence(ans.getEvidence());
			String uploadKey = ans.fileIdIfAny();
			if (uploadKey != null) {
				CmFileUploadTbl file = uploadService.getOne(uploadKey);
				dto.setEvidenceFileName(file.getFileName());
				dto.setEvidenceFileId(file.getUploadKey());
			}
		}
	}

	// 「まとめる」を考慮して、table要素のcolspanを決める。
	private int[] colSpans(RubricPhase[] pmap) {
		int[] cp = new int[pmap.length];
		Arrays.fill(cp, 1);
		for (int i = cp.length - 1; i > 0; i--) {
			if (pmap[i] == null) {
				cp[i - 1] += cp[i];
				cp[i] = 0;
			}
		}
		return cp;
	}

	// 達成済みか? 過去結果の達成率計算用(達成レベルとは無関係)。
	public boolean isAchieved(NrSubjectAnswerBkupTbl ans) {
		return isAchieved(ans.getAnswer());
	}

	private boolean isAchieved(Integer ans) {
		return ans != null && ans == 1;
	}

	private boolean isAchieved(NrSubjectAnswerTbl ans) {
		return isAchieved(ans.getAnswer());
	}

	public boolean isAchieved(AnswerForm ans) {
		Boolean a = ans.getDone();
		return a != null && a;
	}

	// 回答テーブル更新用のentityを作る。
	private NrSubjectAnswerTbl answerForUpdate(String rkey, String userKey, AnswerForm form, int depth) {
		NrSubjectAnswerTbl entity = new NrSubjectAnswerTbl();
		NrSubjectAnswerTblPK id = new NrSubjectAnswerTblPK();
		id.setRubricKey(rkey);
		id.setUserKey(userKey);
		id.setSubjectCode(form.getSubjectCode());
		entity.setId(id);
		entity.setAnswer(ansToInteger(form.getDone()));
		entity.setAchievePhase(form.getPhase() == null ? null : String.valueOf(form.getPhase()));
		entity.setActionPlan(form.getActionPlan());
		entity.setEvidence(form.getEvidence());
		entity.setDepth(depth);
		return entity;
	}

	// アップロードファイルテーブル更新用のentityを作る。
	private CmFileUploadTbl fileForUpdate(String userKey, MultipartFile upload) {
		CmFileUploadTbl entity = new CmFileUploadTbl();
		entity.setFileName(upload.getOriginalFilename());
		entity.setFileSize(upload.getSize());
		entity.setFilePutPath(fileService.makeFilePath(userKey));
		entity.setUserKey(userKey);
		entity.setFileKbn(FILEKBN_DEFAULT);
		entity.setCalcFlag(CALCFLAG_DEFAULT);
		return entity;
	}

	// エビデンスファイルテーブル更新用のentityを作る。
	private NrSubjectUploadTbl evidenceFileForUpdate(String rkey, String userKey, String uploadKey,
			String abilityCode) {
		NrSubjectUploadTbl entity = new NrSubjectUploadTbl();
		NrSubjectUploadTblPK id = new NrSubjectUploadTblPK();
		id.setUserKey(userKey);
		id.setRubricKey(rkey);
		id.setSubjectCode(abilityCode);
		id.setUploadKey(uploadKey);
		entity.setId(id);
		return entity;
	}

	// 自己評価レポートテーブル更新用のentityを作る。
	private NrAchievementReportTbl reportForUpdate(String userKey, ReportForm form) {
		NrAchievementReportTbl entity = reportRepository.findOne(userKey);
		if (entity == null) {
			entity = new NrAchievementReportTbl();
			entity.setUserKey(userKey);
		}
		entity.setAllInputDate(form.getWholeInputDateInTS());
		entity.setAllLimitDate(form.getWholeDueDateInTS());
		entity.setAllAchievement(form.getWholeTarget());
		entity.setYearlyInputDate(form.getAnnualInputDateInTS());
		entity.setYearlyLimitDate(form.getAnnualDueDateInTS());
		entity.setYearlyAchievement(form.getAnnualTarget());
		return entity;
	}

	private UsInfoTbl infoForDueDate(String userKey, Timestamp ts, String ope, int kbn, Locale locale) {
		String refKey = String.valueOf(kbn);
		UsInfoTbl entity = infoRepository.findByUsUserTblUserKeyAndDataKbnAndInfoRefKey(userKey, DATAKBN_REPORT,
				refKey);
		if (entity == null) {
			entity = new UsInfoTbl();
			UsUserTbl user = new UsUserTbl();
			user.setUserKey(userKey);
			entity.setUsUserTbl(user);
			entity.setTitle(infoCaption(kbn, locale));
			entity.setMakeUserKey(userKey);
			entity.setInfoRefKey(refKey);
			entity.setDataKbn(DATAKBN_REPORT);
			entity.setUrl(SkillDiagController.editReportPath());
		}
		entity.setSendDate(ts);
		entity.setOpeKbn(ope);
		return entity;
	}

	private UsScheduleTbl scheduleForDelete(String userKey, int kbn) {
		return scheduleRepository.findByMakeUserKeyAndSchduleRefKey(userKey, String.valueOf(kbn));
	}

	private String scheduleCaption(int kbn, Locale locale) {
		return messageSource.getMessage(
				kbn == TARGETKBN_WHOLE ? "skill.diag.schedule.whole" : "skill.diag.schedule.annual", null, locale);
	}

	private String infoCaption(int kbn, Locale locale) {
		return messageSource.getMessage(
				kbn == TARGETKBN_WHOLE ? "skill.diag.info.whole" : "skill.diag.info.annual", null, locale);
	}

	private UsScheduleTbl scheduleForUpdate(String userKey, java.util.Date dueDate, int kbn, Locale locale) {
		String refKey = String.valueOf(kbn);
		UsScheduleTbl entity = scheduleRepository.findByMakeUserKeyAndSchduleRefKey(userKey, refKey);
		if (entity == null) {
			entity = new UsScheduleTbl();
			UsUserTbl user = new UsUserTbl();
			user.setUserKey(userKey);
			entity.setUsUserTbl(user);
			entity.setTitle(scheduleCaption(kbn, locale));
			entity.setMakeUserKey(userKey);
			entity.setSchduleRefKey(refKey);
			entity.setDataKbn(DATAKBN_REPORT);
		}
		entity.setSuhduleDate(dueDate);
		return entity;
	}

	/**
	 * 回答を保存する。 小項目、中項目、共用。<BR>
	 * 失敗したら例外。<BR>
	 * アップロードファイルがあれば、更新後のアップロードファイルテーブルentityを返す。 アップロードファイルがなければnull。
	 * 
	 * @param rkey
	 * @param userInfo
	 * @param form
	 * @param depth
	 * @return
	 */
	private CmFileUploadTbl saveAnswer(String rkey, UserInfo userInfo, AnswerForm form, int depth) {
		try {
			String ukey = userInfo.getLoginUserKey();

			CmFileUploadTbl upload = null;
			NrSubjectUploadTbl evidence = null;

			if (form.hasFile()) { // エビデンスファイル付きか?

				// アップロードファイルテーブルを更新。
				MultipartFile doc = form.getDoc();
				upload = fileForUpdate(userInfo.getTargetUserKey(), doc);
				upload.setUpdUserKey(ukey);
				upload.setUpdDate(DateUtil.getNowTimestamp());
				upload = uploadService.update(userInfo, upload);
				if (upload == null) {
					throw new RuntimeException("failed to saveAndFlush(upload).");
				}

				// エビデンスファイルテーブルを更新。
				evidenceRepository.deleteByIdUserKeyAndIdRubricKeyAndIdSubjectCode(userInfo.getTargetUserKey(), rkey,
						form.getSubjectCode());
				evidence = evidenceFileForUpdate(rkey, userInfo.getTargetUserKey(), upload.getUploadKey(),
						form.getSubjectCode());
				evidence.setUpdUserKey(ukey);
				evidence.setUpdDate(DateUtil.getNowTimestamp());
				evidence = evidenceRepository.saveAndFlush(evidence);
				if (evidence == null) {
					throw new RuntimeException("failed to saveAndFlush(evidence).");
				}

				// ファイルを所定の場所へ転送。
				File file = new File(upload.getRealPath());
				FileUtils.forceMkdir(file.getParentFile());
				doc.transferTo(file.getAbsoluteFile());
			}

			// 回答テーブルを更新。
			NrSubjectAnswerTbl entity = answerForUpdate(rkey, userInfo.getTargetUserKey(), form, depth);
			entity.setUpdUserKey(ukey);
			entity.setUpdDate(DateUtil.getNowTimestamp());
			entity = answerRepository.saveAndFlush(entity);
			if (entity == null) {
				throw new RuntimeException("failed to saveAndFlush(answer).");
			}
			return upload;
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	// 小項目の回答を保存。
	@Transactional
	public SkillAnswerDto updateItemAnswer(String rkey, SkillAnswerDto dto, UserInfo userInfo) {
		logger.infoCode("I0001");

		AnswerForm form = dto.copyToForm(); // DTOをForm形式へ変換。

		try {
			CmFileUploadTbl upload = saveAnswer(rkey, userInfo, form, ANSWERDEPTH_ITEM);

			// 小項目を保存した場合、
			// 保存後のエビデンスファイル情報をクライアントへ返すため
			// dtoへ格納する。
			dto.setDoc(null);
			if (upload != null) {
				dto.setEvidenceFileId(upload.getUploadKey());
				dto.setEvidenceFileName(upload.getFileName());
			}

			logger.infoCode("I0002");
			return dto;
		} catch (Exception e) {
			logger.errorCode("E1007", e);
			throw e;
		}
	}

	/**
	 * アップロードされたファイルが、ストレージ容量に収まるかどうか確認する。
	 * 
	 * @param userInfo
	 * @param delta
	 * @throws OutOfQuotaException
	 */
	public void validateQuota(UserInfo userInfo, Long delta) throws OutOfQuotaException {
		Long usage = uploadService.calcUsage(userInfo.getTargetUserKey(), FILEKBN_DEFAULT);
		long quota = CommonConst.EVIDENCE_FILE_QUOTA; // warning(dead code)対策。
		if (quota >= 0 && usage + delta > CommonConst.EVIDENCE_FILE_QUOTA) {
			throw new OutOfQuotaException(FILEKBN_DEFAULT);
		}
	}

	// 中項目の回答を保存。
	@Transactional
	public void updateAnswer(String rkey, DiagForm form, UserInfo userInfo) {
		logger.infoCode("I0001");

		try {
			form.getCategoryList().forEach(cat -> {
				cat.getChildList().forEach(ans -> {
					saveAnswer(rkey, userInfo, ans, ANSWERDEPTH_SUBCAT);
				});
			});
			logger.infoCode("I0002");
			return;
		} catch (UncheckedIOException e) {
			logger.errorCode("E1007", e);
			throw new RuntimeException(e);
		}
	}

	@Transactional
	public void deleteEvidence(String rkey, String abilityCode, UserInfo userInfo) {
		logger.infoCode("I0001");

		evidenceRepository.deleteByIdUserKeyAndIdRubricKeyAndIdSubjectCode(userInfo.getTargetUserKey(), rkey,
				abilityCode);

		logger.infoCode("I0002");
	}

	// 回答をバックアップ(バッチ用)。
	@Transactional
	public void backup() {
		Date now = new Date(System.currentTimeMillis());
		backupAnswerRepository.backup(now);
		backupUploadRepository.backup(now);
		backupReportRepository.backup(now);
	}

	// 自己評価レポート目標設定の期限日に応じて、us_info_tblへお知らせを追加/削除する。
	@Transactional
	public void addDeleteInfo() {
		List<NrAchievementReportTbl> lis = reportRepository.findAll();
		lis.forEach(repo -> {
			addDeleteInfo(repo.getUserKey(), repo.getAllLimitDate(), TARGETKBN_WHOLE, localeInBatch());
			addDeleteInfo(repo.getUserKey(), repo.getYearlyLimitDate(), TARGETKBN_ANNUAL, localeInBatch());
		});
	}

	private Locale localeInBatch() {
		return Locale.getDefault();
	}

	// お知らせ情報に入れるべきか?
	private boolean shouldBeInformed(Timestamp ts) {
		LocalDateTime now = LocalDateTime.now();
		LocalDateTime dueDate = ts.toLocalDateTime();
		return now.isAfter(dueDate.minusDays(DAYRANGE_TO_INFORM)) &&
				now.isBefore(dueDate.plusDays(DAYRANGE_TO_INFORM));
	}

	private void addDeleteInfo(String userKey, Timestamp ts, int kbn, Locale locale) {
		if (ts == null) { // 期限未設定?
			deleteInfo(userKey, kbn);
			return;
		}
		if (!shouldBeInformed(ts)) { // 期限日遠し?
			deleteInfo(userKey, kbn);
		} else { // 期限日近し。
			updateInfo(userKey, ts, "operation.action.skillreport.duedate", kbn, locale);
		}
	}

	private void updateInfo(String userKey, Timestamp ts, String ope, int kbn, Locale locale) {
		UsInfoTbl info = infoForDueDate(userKey, ts, ope, kbn, locale);
		info.setUpdUserKey(CommonConst.USER_KEY_DUMMY);
		info.setUpdDate(DateUtil.getNowTimestamp());
		info = infoRepository.saveAndFlush(info);
		if (info == null) {
			throw new RuntimeException("failed to saveAndFlush(info).");
		}
	}

	private void deleteInfo(String userKey, int kbn) {
		UsInfoTbl entity = infoRepository.findByUsUserTblUserKeyAndDataKbnAndInfoRefKey(userKey, DATAKBN_REPORT,
				String.valueOf(kbn));
		if (entity != null) {
			infoRepository.delete(entity);
		}
	}

	// 自己評価レポートの目標を保存。
	@Transactional
	public void updateReport(ReportForm form, UserInfo userInfo, Locale locale) {
		NrAchievementReportTbl entity = reportForUpdate(userInfo.getTargetUserKey(), form);
		entity.setUpdUserKey(userInfo.getLoginUserKey());
		entity.setUpdDate(DateUtil.getNowTimestamp());
		entity = reportRepository.saveAndFlush(entity);
		if (entity == null) {
			throw new RuntimeException("failed to saveAndFlush(report).");
		}
		if (form.getWholeDueDate() != null) {
			updateDueDate(userInfo, form.getWholeDueDate(), TARGETKBN_WHOLE, locale);
		} else {
			deleteDueDate(userInfo, TARGETKBN_WHOLE);
		}
		if (form.getAnnualDueDate() != null) {
			updateDueDate(userInfo, form.getAnnualDueDate(), TARGETKBN_ANNUAL, locale);
		} else {
			deleteDueDate(userInfo, TARGETKBN_ANNUAL);
		}
	}

	private void deleteDueDate(UserInfo userInfo, int kbn) {
		UsScheduleTbl sche = scheduleForDelete(userInfo.getTargetUserKey(), kbn);
		if (sche != null) {
			scheduleRepository.delete(sche);
		}
	}

	private void updateDueDate(UserInfo userInfo, java.util.Date dueDate, int kbn, Locale locale) {
		UsScheduleTbl sche = scheduleForUpdate(userInfo.getTargetUserKey(), dueDate, kbn, locale);
		sche.setUpdUserKey(userInfo.getLoginUserKey());
		sche.setUpdDate(DateUtil.getNowTimestamp());
		sche = scheduleRepository.saveAndFlush(sche);
		if (sche == null) {
			throw new RuntimeException("failed to saveAndFlush(schedule).");
		}
	}

	public Map<String, Boolean> buildAchievementMap(List<NrSubjectAnswerTbl> answers) {
		return answers.stream().filter(ans -> ans.getDepth() == ANSWERDEPTH_ITEM)
				.collect(Collectors.toMap(ans -> ans.getId().getSubjectCode(), ans -> isAchieved(ans)));
	}

	public Map<String, Boolean> buildAchievementMapForPast(List<NrSubjectAnswerBkupTbl> answers) {
		return answers.stream().filter(ans -> ans.getDepth() == ANSWERDEPTH_ITEM)
				.collect(Collectors.toMap(ans -> ans.getId().getSubjectCode(), ans -> isAchieved(ans)));
	}

	public Map<String, Boolean> buildAchievementMap(List<String> codeList, Map<String, Boolean> allAchievementMap,
			int level) {
		Map<String, List<String>> map = codeList.stream()
				.collect(Collectors
						.groupingBy(code -> code.substring(0, 0 + Math.min(code.length(), CODE_GROUPING_LENS[level]))));
		return map.entrySet().stream().collect(Collectors.toMap(Entry::getKey, e -> {
			return e.getValue().stream().allMatch(code -> {
				return allAchievementMap.containsKey(code) && allAchievementMap.get(code);
			});
		}));
	}
}
