package jp.co.sraw.repository;

import java.util.Date;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import jp.co.sraw.entity.CmScheduleTbl;

@Scope("prototype")
@Repository
public interface CmScheduleTblRepository extends JpaRepository<CmScheduleTbl, String>, JpaSpecificationExecutor<CmScheduleTbl> {

	@Modifying
	@Query(name="CmScheduleTbl.delete")
	public int delete(String refKey, String dataKbn);

	@Modifying
	@Query(name = "CmScheduleTbl.findAllByPartyOrRoll")
	public List<CmScheduleTbl> findAllByPartyOrRoll(@Param("startDate") Date startDate,
													@Param("endDate") Date endDate,
													@Param("partyCode1") String partyCode1,
													@Param("role1") String role1,
													@Param("partyCode2") String partyCode2,
													@Param("role2") String role2);

}
