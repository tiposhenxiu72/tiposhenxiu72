/*
* ファイル名：UserServiceImpl.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonService;
import jp.co.sraw.common.UserInfo;
import jp.co.sraw.controller.messagebox.MessageBoxForm;
import jp.co.sraw.dto.MessageBoxDto;
import jp.co.sraw.entity.UsMessageBoxTbl;
import jp.co.sraw.entity.UsUserTbl;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.repository.UsMessageBoxTblRepository;
import jp.co.sraw.util.DateUtil;
import jp.co.sraw.util.StringUtil;

/**
 * <B>UserServiceクラス</B>
 * <P>
 * ユーザーサービスのメソッドを提供する
 */
@Scope("prototype")
@Service
@Transactional(readOnly = true)
public class MessageBoxServiceImpl extends CommonService {

	@Autowired
	private UsMessageBoxTblRepository usMessageBoxTblRepository;

	@Autowired
	private UserServiceImpl userServiceImpl;

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(MessageBoxServiceImpl.class);

	@PostConstruct
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	/**
	 * orderBy
	 *
	 * @return
	 */
	private Sort orderBy() {
		// 日付（降順）
		return new Sort(Sort.Direction.DESC, "sendDate");
	}

	/**
	 * メッセージ取得
	 *
	 * @param userKey
	 * @return
	 */
	public List<MessageBoxDto> findAll(UserInfo userInfo, boolean sendFlag, Locale locale) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		// 条件
		Specification<UsMessageBoxTbl> whereUserKey =  new Specification<UsMessageBoxTbl>() {
			@Override
			public Predicate toPredicate(Root<UsMessageBoxTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.get("usUserTbl").get("userKey"), userInfo.getTargetUserKey());
			}
		};
		// 送信者
		Specification<UsMessageBoxTbl> whereSendUserKey =  new Specification<UsMessageBoxTbl>() {
			@Override
			public Predicate toPredicate(Root<UsMessageBoxTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				if (sendFlag) {
					return cb.equal(root.get("fromUserKey"), userInfo.getTargetUserKey());
				} else {
					return cb.equal(root.get("toUserKey"), userInfo.getTargetUserKey());
				}
			}
		};

		List<UsMessageBoxTbl> mList = usMessageBoxTblRepository.findAll(Specifications.where(whereUserKey).and(whereSendUserKey), orderBy());

		List<MessageBoxDto> rltList = new ArrayList<MessageBoxDto>();
		Map<String, UsUserTbl> userMap = new HashMap<String, UsUserTbl>();
		for (UsMessageBoxTbl m : mList) {
			MessageBoxDto dto = new MessageBoxDto();

			// 取得
			UsUserTbl toUser = new UsUserTbl();
			UsUserTbl fromUser = new UsUserTbl();
			if (StringUtil.isNotNull(m.getFromUserKey())) {
				//
				if (userMap.containsKey(m.getFromUserKey())) {
					fromUser = userMap.get(m.getFromUserKey());
				} else {
					fromUser = userServiceImpl.findOne(m.getFromUserKey());
					userMap.put(m.getFromUserKey(), fromUser);
				}
			}
			if (StringUtil.isNotNull(m.getToUserKey())) {
				//
				if (userMap.containsKey(m.getToUserKey())) {
					toUser = userMap.get(m.getToUserKey());
				} else {
					toUser = userServiceImpl.findOne(m.getToUserKey());
					userMap.put(m.getToUserKey(), toUser);
				}
			}
			setDto(m, dto, toUser, fromUser, locale);

			rltList.add(dto);
		}

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return rltList;
	}


	/**
	 * メッセージ作成(常に新規)
	 *
	 * @param userInfo
	 * @param form
	 * @param newMessageKey
	 * @return
	 */
	@Transactional
	public boolean update(UserInfo userInfo, MessageBoxForm form, String newMessageKey) throws Exception {
		logger.infoCode("I0001");
		try {
			Timestamp nowtime = DateUtil.getNowTimestamp();

			// 送信宛
			UsMessageBoxTbl toEntity = new UsMessageBoxTbl();
			UsUserTbl toUsUserTbl = new UsUserTbl();
			toUsUserTbl.setUserKey(form.getToUserKey());
			toEntity.setUsUserTbl(toUsUserTbl);
			toEntity.setToUserKey(form.getToUserKey());
			toEntity.setFromUserKey(userInfo.getTargetUserKey());
			toEntity.setMessageContents(form.getMessageContents());
			toEntity.setMessageTitle(form.getMessageTitle());
			toEntity.setRefMessageKey(form.getRefMessageKey());
			toEntity.setSendDate(nowtime);
			//
			toEntity.setUpdDate(nowtime);
			toEntity.setUpdUserKey(userInfo.getLoginUserKey());
			//
			toEntity = usMessageBoxTblRepository.save(toEntity);

			// 自分宛
			UsMessageBoxTbl fromEntity = new UsMessageBoxTbl();
			UsUserTbl fromUsUserTbl = new UsUserTbl();
			fromUsUserTbl.setUserKey(userInfo.getTargetUserKey());
			fromEntity.setUsUserTbl(fromUsUserTbl);
			fromEntity.setToUserKey(form.getToUserKey());
			fromEntity.setFromUserKey(userInfo.getTargetUserKey());
			fromEntity.setMessageContents(form.getMessageContents());
			fromEntity.setMessageTitle(form.getMessageTitle());
			fromEntity.setRefMessageKey(form.getRefMessageKey());
			fromEntity.setSendDate(nowtime);
			//
			fromEntity.setUpdDate(nowtime);
			fromEntity.setUpdUserKey(userInfo.getLoginUserKey());
			//
			fromEntity = usMessageBoxTblRepository.save(fromEntity);


			if (toEntity != null) {
				usMessageBoxTblRepository.flush();
				newMessageKey = toEntity.getMessageKey();
				logger.infoCode("I0002");
				return true;
			}

		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
			throw e;
		}
		return false;
	}

	@Transactional
	public boolean delete(UserInfo userInfo, MessageBoxForm form) {
		logger.infoCode("I0001");
		try {

			int c = usMessageBoxTblRepository.delete(form.getMessageKey(), form.getUpdDate());

			if (c > 0) {
				usMessageBoxTblRepository.flush();
				logger.infoCode("I0002");
				return true;
			}
		} catch (Exception e) {
			logger.errorCode("E1009", e); // E1009=削除に失敗しました。{0}
		}
		return false;
	}

	/**
	 * eventKey指定取得
	 *
	 * @param eventKey
	 * @return
	 */
	public UsMessageBoxTbl getOne(final String messageKey) {
		return usMessageBoxTblRepository.getOne(messageKey);
	}


	public MessageBoxDto findOne(UserInfo userInfo, MessageBoxForm form, boolean sendFlag, Locale locale) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		// 条件
		Specification<UsMessageBoxTbl> whereUserKey =  new Specification<UsMessageBoxTbl>() {
			@Override
			public Predicate toPredicate(Root<UsMessageBoxTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.get("usUserTbl").get("userKey"), userInfo.getTargetUserKey());
			}
		};
		// 送信者
		Specification<UsMessageBoxTbl> whereSendUserKey =  new Specification<UsMessageBoxTbl>() {
			@Override
			public Predicate toPredicate(Root<UsMessageBoxTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				if (sendFlag) {
					return cb.equal(root.get("fromUserKey"), userInfo.getTargetUserKey());
				} else {
					return cb.equal(root.get("toUserKey"), userInfo.getTargetUserKey());
				}
			}
		};
		Specification<UsMessageBoxTbl> whereMessageKey = new Specification<UsMessageBoxTbl>() {
			@Override
			public Predicate toPredicate(Root<UsMessageBoxTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.get("messageKey"), form.getMessageKey ());
			}
		};
		Specification<UsMessageBoxTbl> whereUpdDate = DateUtil.isNull(form.getUpdDate()) ? null
			: new Specification<UsMessageBoxTbl>() {
				@Override
				public Predicate toPredicate(Root<UsMessageBoxTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
					return cb.equal(root.get("updDate"), form.getUpdDate());
				}
			};

		UsMessageBoxTbl m = usMessageBoxTblRepository.findOne(Specifications.where(whereUserKey).and(whereSendUserKey).and(whereMessageKey).and(whereUpdDate));
		MessageBoxDto dto = new MessageBoxDto();
		setDto(m, dto, userServiceImpl.findOne(m.getToUserKey()), userServiceImpl.findOne(m.getFromUserKey()), locale);

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return dto;
	}

	/**
	 * EntityからDtoにセット
	 *
	 * @param from
	 * @param toDto
	 * @param toUser
	 * @param fromUser
	 * @param locale
	 */
	private void setDto(UsMessageBoxTbl from, MessageBoxDto toDto, UsUserTbl toUser, UsUserTbl fromUser, Locale locale) {
		String userFullName ="";
		String toUserFullName = "";
		String fromUserFullName = "";
		toDto.setMessageKey(from.getMessageKey());
		toDto.setUserKey(from.getUsUserTbl().getUserKey()); // 持ち主
		toDto.setToUserKey(from.getToUserKey()); // 受信者キー
		toDto.setFromUserKey(from.getFromUserKey()); // 送信者キー
		toDto.setMessageContents(from.getMessageContents());
		toDto.setMessageTitle(from.getMessageTitle());
		toDto.setRefMessageKey(from.getRefMessageKey());
		toDto.setSendDate(from.getSendDate());
		toDto.setUpdDate(from.getUpdDate());
		toDto.setUpdUserKey(from.getUpdUserKey());

		// 表示する氏名
		if (CommonConst.DEFAULT_LOCALE.getLanguage().equals(locale.getLanguage())) {
			userFullName = StringUtil.getUserName(from.getUsUserTbl().getUserKbn(), from.getUsUserTbl().getUserFamilyName(), from.getUsUserTbl().getUserMiddleName(), from.getUsUserTbl().getUserName());
			toUserFullName = StringUtil.getUserName(toUser.getUserKbn(), toUser.getUserFamilyName(), toUser.getUserMiddleName(), toUser.getUserName());
			fromUserFullName = StringUtil.getUserName(fromUser.getUserKbn(), fromUser.getUserFamilyName(), fromUser.getUserMiddleName(), fromUser.getUserName());
		} else {
			userFullName = StringUtil.getUserNameEn(from.getUsUserTbl().getUserKbn(), from.getUsUserTbl().getUserFamilyNameEn(), from.getUsUserTbl().getUserMiddleNameEn(), from.getUsUserTbl().getUserNameEn());
			toUserFullName = StringUtil.getUserNameEn(toUser.getUserKbn(), toUser.getUserFamilyNameEn(), toUser.getUserMiddleNameEn(), toUser.getUserNameEn());
			fromUserFullName = StringUtil.getUserNameEn(fromUser.getUserKbn(), fromUser.getUserFamilyNameEn(), fromUser.getUserMiddleNameEn(), fromUser.getUserNameEn());
		}
		toDto.setUserFullName(userFullName); // 持ち主
		toDto.setToUserFullName(toUserFullName); // 送信者名(受信のとき相手。送信のとき自分)
		toDto.setFromUserFullName(fromUserFullName); // 送信者名(受信のとき相手。送信のとき自分)
	}

}
