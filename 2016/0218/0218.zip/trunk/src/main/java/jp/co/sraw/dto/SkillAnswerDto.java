package jp.co.sraw.dto;

import java.io.Serializable;

import org.springframework.web.multipart.MultipartFile;

import jp.co.sraw.controller.skill.AjaxDto;
import jp.co.sraw.controller.skill.AnswerForm;

/**
 * 小項目1つに対する回答。回答内容だけでなく、小項目のルーブリック情報も保持する。
 *
 */
public class SkillAnswerDto extends AjaxDto implements Serializable {
	private static final long serialVersionUID = 1L;

	private String abilityCode;
	private String name;
	private String[] phaseTargets;

	private Boolean done;
	private Integer phase;

	private String actionPlan;
	private String evidence;
	private String evidenceFileName;
	private String evidenceFileId;

	private int yourTargetPhase;
	private int[] colSpans;

	private MultipartFile doc;

	private boolean creating; // 新規回答か? JS側で、save後にこの値を見ると、回答率を上げるべきかどうか分かる。

	public void setYourTargetPhase(Integer yourTargetPhase) {
		if (yourTargetPhase == null) {
			yourTargetPhase = 0;
		}

		this.yourTargetPhase = yourTargetPhase;
	}

	/**
	 * 添付ファイル有無。
	 * 
	 * @return
	 */
	public boolean hasFile() {
		return doc != null && !doc.isEmpty();
	}

	/**
	 * 添付ファイルサイズ。
	 * 
	 * @return
	 */
	public long getEvidenceFileSize() {
		if (!hasFile()) {
			return 0;
		}
		return doc.getSize();
	}

	/**
	 * 回答内容を、Formへ移し替える。
	 * 
	 * @return
	 */
	public AnswerForm copyToForm() {
		AnswerForm form = new AnswerForm();
		form.setSubjectCode(abilityCode);
		form.setActionPlan(actionPlan);
		form.setEvidence(evidence);
		form.setDoc(doc);
		form.setDone(done);
		form.setPhase(phase);

		return form;
	}

	public String getAbilityCode() {
		return abilityCode;
	}

	public void setAbilityCode(String abilityCode) {
		this.abilityCode = abilityCode;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String[] getPhaseTargets() {
		return phaseTargets;
	}

	public void setPhaseTargets(String[] phaseTargets) {
		this.phaseTargets = phaseTargets;
	}

	public Boolean getDone() {
		return done;
	}

	public void setDone(Boolean done) {
		this.done = done;
	}

	public Integer getPhase() {
		return phase;
	}

	public void setPhase(Integer phase) {
		this.phase = phase;
	}

	public String getActionPlan() {
		return actionPlan;
	}

	public void setActionPlan(String actionPlan) {
		this.actionPlan = actionPlan;
	}

	public String getEvidence() {
		return evidence;
	}

	public void setEvidence(String evidence) {
		this.evidence = evidence;
	}

	public String getEvidenceFileName() {
		return evidenceFileName;
	}

	public void setEvidenceFileName(String evidenceFileName) {
		this.evidenceFileName = evidenceFileName;
	}

	public String getEvidenceFileId() {
		return evidenceFileId;
	}

	public void setEvidenceFileId(String evidenceFileId) {
		this.evidenceFileId = evidenceFileId;
	}

	public int getYourTargetPhase() {
		return yourTargetPhase;
	}

	public void setYourTargetPhase(int yourTargetPhase) {
		this.yourTargetPhase = yourTargetPhase;
	}

	public int[] getColSpans() {
		return colSpans;
	}

	public void setColSpans(int[] colSpans) {
		this.colSpans = colSpans;
	}

	public MultipartFile getDoc() {
		return doc;
	}

	public void setDoc(MultipartFile doc) {
		this.doc = doc;
	}

	public boolean isCreating() {
		return creating;
	}

	public void setCreating(boolean creating) {
		this.creating = creating;
	}

}
