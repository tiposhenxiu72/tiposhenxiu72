/*
* ファイル名：ConsultationForm.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/01/08   matsuo      新規作成
*/
package jp.co.sraw.controller.consultation;

import java.sql.Timestamp;
import java.util.List;

import org.hibernate.validator.constraints.NotBlank;
import org.maru.m4hv.extensions.constraints.CharLength;

import jp.co.sraw.common.CommonForm;
import jp.co.sraw.dto.AdvicerDto;
import jp.co.sraw.dto.MsCodeDto;
import jp.co.sraw.util.StringUtil;
import jp.co.sraw.validation.AlphaNumberSymbol;

/**
 * <B>ConsultationFormクラス</B>
 * <P>
 * Formのメソッドを提供する
 */
public class ConsultationForm extends CommonForm {

	 public static interface group1{};
	 public static interface group2{};

	 /**
	 * 面談依頼キー
	 */
	private String consultationKey;

	/**
	 * ユーザキー（依頼者）
	 */
	private String userKey;

	/**
	 * ユーザ名（依頼者）
	 */
	private String userName;

	/**
	 * 所属名（依頼者）
	 */
	private String userPartyName;

	/**
	 * ユーザ名（依頼者）＋所属名
	 */
	private String userNameAndParty;

	/**
	 * 面談登録日
	 */
	private String consultationInsDate;

	/**
	 * 依頼内容区分
	 */
	@NotBlank(groups=group1.class)
	private String requestKbn;

	/**
	 * 依頼内容区分名
	 */
	private String requestKbnName;

	/**
	 * 相談項目
	 */
	@NotBlank(groups=group1.class)
	private String consultationKbn;

	/**
	 * 相談項目名
	 */
	private String consultationKbnName;

	/**
	 * 相談者メモ
	 */
	private String userMemo;

	/**
	 * 面談日
	 */
	@NotBlank(groups=group2.class)
	private String consultationDate;

	/**
	 * 面談時刻（開始～終了）
	 */
	private String consultationStartEnd;

	/**
	 * 面談時刻（開始）
	 */
	@NotBlank(groups=group2.class)
	@CharLength(max = 5, groups=group2.class)
	@AlphaNumberSymbol(groups=group2.class)
	private String consultationStart;

	/**
	 * 面談時刻（終了）
	 */
	@NotBlank(groups=group2.class)
	@CharLength(max = 5, groups=group2.class)
	@AlphaNumberSymbol(groups=group2.class)
	private String consultationEnd;

	/**
	 * 面談場所
	 */
	@NotBlank(groups=group2.class)
	@CharLength(max = 100, groups=group2.class)
	private String consultationRoom;

	/**
	 * 担当窓口
	 */
	@NotBlank(groups=group2.class)
	@CharLength(max = 100, groups=group2.class)
	private String consultationOrganization;

	/**
	 * 連絡先
	 */
	@NotBlank(groups=group2.class)
	@CharLength(max = 100, groups=group2.class)
	@AlphaNumberSymbol(groups=group2.class)
	private String consultationTelno;

	/**
	 * 相談状態
	 */
	private String consultationStatus;

	/**
	 * 相談状態名
	 */
	private String consultationStatusName;

	/**
	 * 相談員あり・なし
	 */
	private String advicerKbn;

	/**
	 * ユーザキー（担当相談員）
	 */
	@NotBlank(groups=group2.class)
	private String advicerUserKey;

	/**
	 * 担当相談員名
	 */
	private String advicerUserName;

	/**
	 * 担当相談員名＋担当相談員所属名
	 */
	private String advicerUserNameAndParty;

	/**
	 * 担当相談員所属名
	 */
	private String advicerPartyName;

	/**
	 * 背景色変更判定
	 */
	private boolean changeBackColor;

	/**
	 * 確定ボタン制御
	 */
	private boolean enabledConfirmButton;

	/**
	 * 公開者リスト
	 */
	private List<AdvicerDto> publicAdvicerList;

	/**
	 * 公開者リスト文字列
	 */
	private String publicAdvicerText;

	/**
	 * 非公開者リスト
	 */
	private List<AdvicerDto> nonPublicAdvicerList;

	/**
	 * 非公開者リスト文字列
	 */
	private String nonPublicAdvicerText;

	/**
	 * 面談結果
	 */
	private String consultationMemo;

	/**
	 * 検索：キーワード
	 */
	private String searchKeyword;

	/**
	 * 検索：所属機関
	 */
	private String searchParty;

	/**
	 * 検索：状態
	 */
	private String searchStatus;

	/**
	 * 写真（相談員）
	 */
	private String advicerUploadKey;

	/**
	 * 更新日付
	 */
	private Timestamp updDate;

	/**
	 * 更新ユーザキー
	 */
	private String updUserKey;

	/**
	 * 希望相談員List
	 */
	private List<MsCodeDto> advicerKbnList;

	/**
	 * 相談項目List
	 */
	private List<MsCodeDto> consulKbnList;

	/**
	 * 依頼項目List
	 */
	private List<MsCodeDto> requestKbnList;

	/**
	 * 相談員List
	 */
	private List<AdvicerDto> advicerList;

	/**
	 * 面談依頼キーを取得します。
	 * @return 面談依頼キー
	 */
	public String getConsultationKey() {
	    return consultationKey;
	}

	/**
	 * 面談依頼キーを設定します。
	 * @param consultationKey 面談依頼キー
	 */
	public void setConsultationKey(String consultationKey) {
	    this.consultationKey = consultationKey;
	}

	/**
	 * ユーザキー（依頼者）を取得します。
	 * @return ユーザキー（依頼者）
	 */
	public String getUserKey() {
	    return userKey;
	}

	/**
	 * ユーザキー（依頼者）を設定します。
	 * @param userKey ユーザキー（依頼者）
	 */
	public void setUserKey(String userKey) {
	    this.userKey = userKey;
	}

	/**
	 * ユーザ名（依頼者）を取得します。
	 * @return ユーザ名（依頼者）
	 */
	public String getUserName() {
	    return userName;
	}

	/**
	 * ユーザ名（依頼者）を設定します。
	 * @param userName ユーザ名（依頼者）
	 */
	public void setUserName(String userName) {
	    this.userName = userName;
	}

	/**
	 * 所属名（依頼者）を取得します。
	 * @return 所属名（依頼者）
	 */
	public String getUserPartyName() {
	    return userPartyName;
	}

	/**
	 * 所属名（依頼者）を設定します。
	 * @param userPartyName 所属名（依頼者）
	 */
	public void setUserPartyName(String userPartyName) {
	    this.userPartyName = userPartyName;
	}

	/**
	 * ユーザ名（依頼者）＋所属名を取得します。
	 * @return ユーザ名（依頼者）＋所属名
	 */
	public String getUserNameAndParty() {
	    return userNameAndParty;
	}

	/**
	 * ユーザ名（依頼者）＋所属名を設定します。
	 * @param userNameAndParty ユーザ名（依頼者）＋所属名
	 */
	public void setUserNameAndParty(String userNameAndParty) {
	    this.userNameAndParty = userNameAndParty;
	}

	/**
	 * 面談登録日を取得します。
	 * @return 面談登録日
	 */
	public String getConsultationInsDate() {
	    return consultationInsDate;
	}

	/**
	 * 面談登録日を設定します。
	 * @param consultationInsDate 面談登録日
	 */
	public void setConsultationInsDate(String consultationInsDate) {
	    this.consultationInsDate = consultationInsDate;
	}

	/**
	 * 依頼内容区分を取得します。
	 * @return 依頼内容区分
	 */
	public String getRequestKbn() {
	    return requestKbn;
	}

	/**
	 * 依頼内容区分を設定します。
	 * @param requestKbn 依頼内容区分
	 */
	public void setRequestKbn(String requestKbn) {
	    this.requestKbn = requestKbn;
	}

	/**
	 * 依頼内容区分名を取得します。
	 * @return 依頼内容区分名
	 */
	public String getRequestKbnName() {
	    return requestKbnName;
	}

	/**
	 * 依頼内容区分名を設定します。
	 * @param requestKbnName 依頼内容区分名
	 */
	public void setRequestKbnName(String requestKbnName) {
	    this.requestKbnName = requestKbnName;
	}

	/**
	 * 相談項目を取得します。
	 * @return 相談項目
	 */
	public String getConsultationKbn() {
	    return consultationKbn;
	}

	/**
	 * 相談項目を設定します。
	 * @param consultationKbn 相談項目
	 */
	public void setConsultationKbn(String consultationKbn) {
	    this.consultationKbn = consultationKbn;
	}

	/**
	 * 相談項目名を取得します。
	 * @return 相談項目名
	 */
	public String getConsultationKbnName() {
	    return consultationKbnName;
	}

	/**
	 * 相談項目名を設定します。
	 * @param consultationKbnName 相談項目名
	 */
	public void setConsultationKbnName(String consultationKbnName) {
	    this.consultationKbnName = consultationKbnName;
	}

	/**
	 * 相談者メモを取得します。
	 * @return 相談者メモ
	 */
	public String getUserMemo() {
	    return userMemo;
	}

	/**
	 * 相談者メモを設定します。
	 * @param userMemo 相談者メモ
	 */
	public void setUserMemo(String userMemo) {
	    this.userMemo = userMemo;
	}

	/**
	 * 面談日を取得します。
	 * @return 面談日
	 */
	public String getConsultationDate() {
	    return consultationDate;
	}

	/**
	 * 面談日を設定します。
	 * @param consultationDate 面談日
	 */
	public void setConsultationDate(String consultationDate) {
	    this.consultationDate = consultationDate;
	}

	/**
	 * 面談時刻（開始～終了）を取得します。
	 * @return 面談時刻（開始～終了）
	 */
	public String getConsultationStartEnd() {
	    return consultationStartEnd;
	}

	/**
	 * 面談時刻（開始～終了）を設定します。
	 * @param consultationStartEnd 面談時刻（開始～終了）
	 */
	public void setConsultationStartEnd(String consultationStartEnd) {
	    this.consultationStartEnd = consultationStartEnd;
	}

	/**
	 * 面談時刻（開始）を取得します。
	 * @return 面談時刻（開始）
	 */
	public String getConsultationStart() {
	    return consultationStart;
	}

	/**
	 * 面談時刻（開始）を設定します。
	 * @param consultationStart 面談時刻（開始）
	 */
	public void setConsultationStart(String consultationStart) {
	    this.consultationStart = consultationStart;
	}

	/**
	 * 面談時刻（終了）を取得します。
	 * @return 面談時刻（終了）
	 */
	public String getConsultationEnd() {
	    return consultationEnd;
	}

	/**
	 * 面談時刻（終了）を設定します。
	 * @param consultationEnd 面談時刻（終了）
	 */
	public void setConsultationEnd(String consultationEnd) {
	    this.consultationEnd = consultationEnd;
	}

	/**
	 * 面談場所を取得します。
	 * @return 面談場所
	 */
	public String getConsultationRoom() {
	    return consultationRoom;
	}

	/**
	 * 面談場所を設定します。
	 * @param consultationRoom 面談場所
	 */
	public void setConsultationRoom(String consultationRoom) {
	    this.consultationRoom = consultationRoom;
	}

	/**
	 * 担当窓口を取得します。
	 * @return 担当窓口
	 */
	public String getConsultationOrganization() {
	    return consultationOrganization;
	}

	/**
	 * 担当窓口を設定します。
	 * @param consultationOrganization 担当窓口
	 */
	public void setConsultationOrganization(String consultationOrganization) {
	    this.consultationOrganization = consultationOrganization;
	}

	/**
	 * 連絡先を取得します。
	 * @return 連絡先
	 */
	public String getConsultationTelno() {
	    return consultationTelno;
	}

	/**
	 * 連絡先を設定します。
	 * @param consultationTelno 連絡先
	 */
	public void setConsultationTelno(String consultationTelno) {
	    this.consultationTelno = consultationTelno;
	}

	/**
	 * 相談状態を取得します。
	 * @return 相談状態
	 */
	public String getConsultationStatus() {
	    return consultationStatus;
	}

	/**
	 * 相談状態を設定します。
	 * @param consultationStatus 相談状態
	 */
	public void setConsultationStatus(String consultationStatus) {
	    this.consultationStatus = consultationStatus;
	}

	/**
	 * 相談状態名を取得します。
	 * @return 相談状態名
	 */
	public String getConsultationStatusName() {
	    return consultationStatusName;
	}

	/**
	 * 相談状態名を設定します。
	 * @param consultationStatusName 相談状態名
	 */
	public void setConsultationStatusName(String consultationStatusName) {
	    this.consultationStatusName = consultationStatusName;
	}

	/**
	 * 相談員あり・なしを取得します。
	 * @return 相談員あり・なし
	 */
	public String getAdvicerKbn() {
	    return advicerKbn;
	}

	/**
	 * 相談員あり・なしを設定します。
	 * @param advicerKbn 相談員あり・なし
	 */
	public void setAdvicerKbn(String advicerKbn) {
	    this.advicerKbn = advicerKbn;
	}

	/**
	 * ユーザキー（担当相談員）を取得します。
	 * @return ユーザキー（担当相談員）
	 */
	public String getAdvicerUserKey() {
	    return advicerUserKey;
	}

	/**
	 * ユーザキー（担当相談員）を設定します。
	 * @param advicerUserKey ユーザキー（担当相談員）
	 */
	public void setAdvicerUserKey(String advicerUserKey) {
	    this.advicerUserKey = advicerUserKey;
	}

	/**
	 * 担当相談員名を取得します。
	 * @return 担当相談員名
	 */
	public String getAdvicerUserName() {
	    return advicerUserName;
	}

	/**
	 * 担当相談員名を設定します。
	 * @param advicerUserName 担当相談員名
	 */
	public void setAdvicerUserName(String advicerUserName) {
	    this.advicerUserName = advicerUserName;
	}

	/**
	 * 担当相談員名＋担当相談員所属名を取得します。
	 * @return 担当相談員名＋担当相談員所属名
	 */
	public String getAdvicerUserNameAndParty() {
	    return advicerUserNameAndParty;
	}

	/**
	 * 担当相談員名＋担当相談員所属名を設定します。
	 * @param advicerUserNameAndParty 担当相談員名＋担当相談員所属名
	 */
	public void setAdvicerUserNameAndParty(String advicerUserNameAndParty) {
	    this.advicerUserNameAndParty = advicerUserNameAndParty;
	}

	/**
	 * 担当相談員所属名を取得します。
	 * @return 担当相談員所属名
	 */
	public String getAdvicerPartyName() {
	    return advicerPartyName;
	}

	/**
	 * 担当相談員所属名を設定します。
	 * @param advicerPartyName 担当相談員所属名
	 */
	public void setAdvicerPartyName(String advicerPartyName) {
	    this.advicerPartyName = advicerPartyName;
	}

	/**
	 * 背景色変更判定を取得します。
	 * @return 背景色変更判定
	 */
	public boolean getChangeBackColor() {
	    return changeBackColor;
	}

	/**
	 * 背景色変更判定を設定します。
	 * @param changeBackColor 背景色変更判定
	 */
	public void setChangeBackColor(boolean changeBackColor) {
	    this.changeBackColor = changeBackColor;
	}

	/**
	 * 確定ボタン制御を取得します。
	 * @return 確定ボタン制御
	 */
	public boolean isEnabledConfirmButton() {
	    return enabledConfirmButton;
	}

	/**
	 * 確定ボタン制御を設定します。
	 * @param enabledConfirmButton 確定ボタン制御
	 */
	public void setEnabledConfirmButton(boolean enabledConfirmButton) {
	    this.enabledConfirmButton = enabledConfirmButton;
	}

	/**
	 * 公開者リストを取得します。
	 * @return 公開者リスト
	 */
	public List<AdvicerDto> getPublicAdvicerList() {
	    return publicAdvicerList;
	}

	/**
	 * 公開者リストを設定します。
	 * @param publicAdvicerList 公開者リスト
	 */
	public void setPublicAdvicerList(List<AdvicerDto> publicAdvicerList) {
	    this.publicAdvicerList = publicAdvicerList;
	}

	/**
	 * 公開者リスト文字列を取得します。
	 * @return 公開者リスト文字列
	 */
	public String getPublicAdvicerText() {
	    return publicAdvicerText;
	}

	/**
	 * 公開者リスト文字列を取得します。
	 * @return 公開者リスト文字列
	 */
	public String[] getPublicAdvicerArray() {
		String[] array = new String[] {};
		if (this.publicAdvicerText != null)
			array = this.publicAdvicerText.split(",");
		return array;
	}

	/**
	 * 公開者リスト文字列を設定します。
	 * @param publicAdvicerText 公開者リスト文字列
	 */
	public void setPublicAdvicerText(String publicAdvicerText) {
	    this.publicAdvicerText = publicAdvicerText;
	}

	/**
	 * 非公開者リストを取得します。
	 * @return 非公開者リスト
	 */
	public List<AdvicerDto> getNonPublicAdvicerList() {
	    return nonPublicAdvicerList;
	}

	/**
	 * 非公開者リストを設定します。
	 * @param nonPublicAdvicerList 非公開者リスト
	 */
	public void setNonPublicAdvicerList(List<AdvicerDto> nonPublicAdvicerList) {
	    this.nonPublicAdvicerList = nonPublicAdvicerList;
	}

	/**
	 * 非公開者リスト文字列を取得します。
	 * @return 公開者リスト文字列
	 */
	public String getNonPublicAdvicerText() {
	    return nonPublicAdvicerText;
	}

	/**
	 * 非公開者リスト文字列を取得します。
	 * @return 公開者リスト文字列
	 */
	public String[] getNonPublicAdvicerArray() {
		String[] array = new String[] {};
		if (this.nonPublicAdvicerText != null)
			array = this.nonPublicAdvicerText.split(",");
		return array;
	}

	/**
	 * 非公開者リスト文字列を設定します。
	 * @param publicAdvicerText 公開者リスト文字列
	 */
	public void setNonPublicAdvicerText(String nonPublicAdvicerText) {
	    this.nonPublicAdvicerText = nonPublicAdvicerText;
	}

	/**
	 * 面談結果を取得します。
	 * @return 面談結果
	 */
	public String getConsultationMemo() {
	    return consultationMemo;
	}

	/**
	 * 面談結果を設定します。
	 * @param consultationMemo 面談結果
	 */
	public void setConsultationMemo(String consultationMemo) {
	    this.consultationMemo = consultationMemo;
	}

	/**
	 * 検索：キーワードを取得します。
	 * @return 検索：キーワード
	 */
	public String getSearchKeyword() {
	    return searchKeyword;
	}

	/**
	 * 検索：キーワードを設定します。
	 * @param searchKeyword 検索：キーワード
	 */
	public void setSearchKeyword(String searchKeyword) {
	    this.searchKeyword = searchKeyword;
	}

	/**
	 * 検索：所属機関を取得します。
	 * @return 検索：所属機関
	 */
	public String getSearchParty() {
	    return searchParty;
	}

	/**
	 * 検索：所属機関を設定します。
	 * @param searchParty 検索：所属機関
	 */
	public void setSearchParty(String searchParty) {
	    this.searchParty = searchParty;
	}

	/**
	 * 検索：状態を取得します。
	 * @return 検索：状態
	 */
	public String getSearchStatus() {
	    return StringUtil.nvl(searchStatus, "");
	}

	/**
	 * 検索：状態を取得します。
	 * @return 状態リスト文字列
	 */
	public String[] getSearchStatusArray() {
		String[] array = new String[] {};
		if (this.searchStatus != null)
			array = this.searchStatus.split(",");
		return array;
	}

	/**
	 * 検索：状態を取得します。
	 * @return 状態リスト文字列
	 */
	public String getSearchStatusSql() {
		String[] array = new String[] {};
		if (this.searchStatus != null)
		array = this.searchStatus.split(",");
		if (array.length == 0) {
			return "";
		}else{
			return "'" + String.join("','", array) + "'" ;
		}
	}

	/**
	 * 検索：状態を設定します。
	 * @param searchStatus 検索：状態
	 */
	public void setSearchStatus(String searchStatus) {
	    this.searchStatus = searchStatus;
	}

	/**
	 * 写真（相談員）を取得します。
	 * @return 写真（相談員）
	 */
	public String getAdvicerUploadKey() {
	    return advicerUploadKey;
	}

	/**
	 * 写真（相談員）を設定します。
	 * @param advicerUploadKey 写真（相談員）
	 */
	public void setAdvicerUploadKey(String advicerUploadKey) {
	    this.advicerUploadKey = advicerUploadKey;
	}

	/**
	 * 更新日付を取得します。
	 * @return 更新日付
	 */
	public Timestamp getUpdDate() {
	    return updDate;
	}

	/**
	 * 更新日付を設定します。
	 * @param updDate 更新日付
	 */
	public void setUpdDate(Timestamp updDate) {
	    this.updDate = updDate;
	}

	/**
	 * 更新ユーザキーを取得します。
	 * @return 更新ユーザキー
	 */
	public String getUpdUserKey() {
	    return updUserKey;
	}

	/**
	 * 更新ユーザキーを設定します。
	 * @param updUserKey 更新ユーザキー
	 */
	public void setUpdUserKey(String updUserKey) {
	    this.updUserKey = updUserKey;
	}

	/**
	 * 希望相談員Listを取得します。
	 * @return 希望相談員List
	 */
	public List<MsCodeDto> getAdvicerKbnList() {
	    return advicerKbnList;
	}

	/**
	 * 希望相談員Listを設定します。
	 * @param advicerKbnList 希望相談員List
	 */
	public void setAdvicerKbnList(List<MsCodeDto> advicerKbnList) {
	    this.advicerKbnList = advicerKbnList;
	}

	/**
	 * 相談項目Listを取得します。
	 * @return 相談項目List
	 */
	public List<MsCodeDto> getConsulKbnList() {
	    return consulKbnList;
	}

	/**
	 * 相談項目Listを設定します。
	 * @param consulKbnList 相談項目List
	 */
	public void setConsulKbnList(List<MsCodeDto> consulKbnList) {
	    this.consulKbnList = consulKbnList;
	}

	/**
	 * 依頼項目Listを取得します。
	 * @return 依頼項目List
	 */
	public List<MsCodeDto> getRequestKbnList() {
	    return requestKbnList;
	}

	/**
	 * 依頼項目Listを設定します。
	 * @param requestKbnList 依頼項目List
	 */
	public void setRequestKbnList(List<MsCodeDto> requestKbnList) {
	    this.requestKbnList = requestKbnList;
	}

	/**
	 * 相談員Listを取得します。
	 * @return 相談員List
	 */
	public List<AdvicerDto> getAdvicerList() {
	    return advicerList;
	}

	/**
	 * 相談員Listを設定します。
	 * @param advicerList 相談員List
	 */
	public void setAdvicerList(List<AdvicerDto> advicerList) {
	    this.advicerList = advicerList;
	}

}
