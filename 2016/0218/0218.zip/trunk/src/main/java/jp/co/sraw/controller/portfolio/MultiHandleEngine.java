package jp.co.sraw.controller.portfolio;

import java.util.List;
import java.util.Locale;

import org.springframework.stereotype.Component;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.controller.portfolio.excel.PortfolioExcelHelper;
import jp.co.sraw.controller.portfolio.form.GyHasTitleForm;
import jp.co.sraw.controller.portfolio.service.MultiHandleServiceImpl;
import jp.co.sraw.dto.MsCodeDto;
import jp.co.sraw.util.DbUtil;

@Component("mengine")
public class MultiHandleEngine<C extends PortfolioController, F extends GyHasTitleForm, S extends MultiHandleServiceImpl, H extends PortfolioExcelHelper>
		extends PortfolioEngine<C, F, S, H> {
	/**
	 *
	 * @param form
	 * @param model
	 * @return
	 */
	public String editMulti(C controller, S serviceImpl, F form, Model model, Locale locale) {

		start(controller, serviceImpl);

		logger.infoCode("I0001");

		this.setListToModel(model, CODE_PUBLICCODE, locale);

		this.setListToModel(model, CODE_LANGUEGE, locale);

		form = (F) serviceImpl.findOne(controller.userInfo(), form);

		if (form == null) {
			// DB更新が失敗した場合
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.valid.data"); // error.data.message.valid.data=入力項目に誤りがあります。

			logger.errorCode("E0014", form.getPageActionUrl()); //
			// E0014=メソッド異常終了:{0}

			return controller.REDIRECT_LIST;
		}

		//
		List<F> list = serviceImpl.findAllSameFormList(userInfo, form);

		String title = "";
		String splitChar = "";
		for (int i = 0; i < list.size(); i++) {
			F f = list.get(i);
			title = title + splitChar + f.getTitle();
			splitChar = "\r\n";
		}
		form.setTitle(title);

		List<MsCodeDto> publicFlagList = DbUtil.getJosuList(CODE_PUBLICCODE, locale);
		model.addAttribute("publicFlagList", publicFlagList);

		form.setPageMode(CommonConst.PAGE_MODE_EDIT);
		model.addAttribute(CommonConst.FORM_NAME, form);
		logger.infoCode("I0002", controller.EDIT_PAGE); // I0002=メソッド終了:{0}

		return controller.EDIT_PAGE;
	}

	/**
	 *
	 * @param form
	 * @param model
	 * @param attributes
	 * @return
	 */
	public String updateMulti(C controller, S serviceImpl, F form, BindingResult bindingResult, Model model,
			RedirectAttributes attributes, Locale locale) {
		start(controller, serviceImpl);
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		List<MsCodeDto> publicFlagList = DbUtil.getJosuList(CODE_PUBLICCODE, locale);
		model.addAttribute("publicFlagList", publicFlagList);

		this.setListToModel(model, "0024", locale);

		if (serviceImpl.updateSame(controller.userInfo(), form)) {
			// DB更新が成功した場合
			logger.infoCode("I1004", ""); // I1004=更新しました。{0}

			if (form.getPageMode().equals(CommonConst.PAGE_MODE_EDIT)) {
				this.controller.operationHistory(this.controller.OP_FUNCID, CommonConst.OP_ACTION_UPDATE);
			} else {
				this.controller.operationHistory(this.controller.OP_FUNCID, CommonConst.OP_ACTION_INSERT);
			}

			attributes.addFlashAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.update.success"); // message.data.update.success=データを更新しました。
			model.addAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.update.success"); // message.data.update.success=データを更新しました。

			logger.infoCode("I0002", form.getPageActionUrl()); //
			// I0002=メソッド終了:{0}
			return controller.REDIRECT_LIST;
		}

		logger.infoCode("I0002", controller.LIST_PAGE); // I0002=メソッド終了:{0}

		// DB更新が失敗した場合
		attributes.addFlashAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.regist"); // error.data.message.db.regist=登録が失敗しました。
		model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.regist"); // error.data.message.db.regist=登録が失敗しました。
		logger.errorCode("E0014", form.getPageActionUrl()); //
		// E0014=メソッド異常終了:{0}
		return controller.REDIRECT_LIST;
	}

}
