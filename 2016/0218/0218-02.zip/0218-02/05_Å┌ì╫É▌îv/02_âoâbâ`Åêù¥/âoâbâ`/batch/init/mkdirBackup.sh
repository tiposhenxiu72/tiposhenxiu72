#!/bin/sh
#
# Backup Server
#
#sudo mkdir -p /home/srahira/eportfolio
sudo mkdir -p /home/srahira/log
sudo mkdir -p /home/srahira/tmp
sudo mkdir -p /home/srahira/batch
sudo mkdir -p /home/srahira/data
sudo mkdir -p /home/srahira/backup
sudo chown -R srahira:srahira /home/srahira/

sudo mkdir -p /opt/eportfolio/backup/web
sudo mkdir -p /opt/eportfolio/backup/db
sudo mkdir -p /opt/eportfolio/backup/file
sudo chown -R srahira:srahira /opt/eportfolio/

chmod +x /home/srahira/batch/webbackup.sh
chmod +x /home/srahira/batch/dbbackup.sh
chmod +x /home/srahira/batch/filebackup.sh
crontab /home/srahira/batch/crontab.txt
