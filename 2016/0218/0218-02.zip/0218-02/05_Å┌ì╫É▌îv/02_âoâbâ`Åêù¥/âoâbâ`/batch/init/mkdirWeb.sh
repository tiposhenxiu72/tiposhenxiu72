#!/bin/sh
#
# Web Server
#
sudo mkdir -p /home/srahira/eportfolio
sudo mkdir -p /home/srahira/log
sudo mkdir -p /home/srahira/tmp
sudo mkdir -p /home/srahira/batch
sudo mkdir -p /home/srahira/data
sudo mkdir -p /home/srahira/backup
sudo chown -R srahira:srahira /home/srahira/

sudo mkdir -p /var/logs/eportfolio
sudo chown -R srahira:srahira /var/logs/eportfolio

