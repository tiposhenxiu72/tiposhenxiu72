package jp.co.sraw.repository;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import jp.co.sraw.entity.GyPrizeTbl;

@Scope("prototype")
@Repository
public interface GyPrizeTblRepository extends GyRepository<GyPrizeTbl> {

}
