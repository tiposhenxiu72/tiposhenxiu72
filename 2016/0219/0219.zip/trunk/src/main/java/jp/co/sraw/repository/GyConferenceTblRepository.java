package jp.co.sraw.repository;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import jp.co.sraw.entity.GyConferenceTbl;

@Scope("prototype")
@Repository
public interface GyConferenceTblRepository extends GyRepository<GyConferenceTbl> {

}
