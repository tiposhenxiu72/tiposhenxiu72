/*
* ファイル名：HomeController.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.portfolio;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.context.AppContextService;
import jp.co.sraw.context.RoleObject;
import jp.co.sraw.controller.portfolio.form.PortfolioProfileForm;
import jp.co.sraw.controller.portfolio.form.ProfileForm;
import jp.co.sraw.entity.CmFileUploadTbl;
import jp.co.sraw.entity.UsPrmovieUploadTbl;
import jp.co.sraw.entity.UsUserTbl;
import jp.co.sraw.file.FileDto;
import jp.co.sraw.file.FileService;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.service.CmFileUploadServiceImpl;
import jp.co.sraw.service.PortfolioProfileServiceImpl;
import jp.co.sraw.service.UserServiceImpl;
import jp.co.sraw.util.DbUtil;
import jp.co.sraw.util.StringUtil;

/**
 * <B>ProfileControllerクラス</B>
 * <P>
 * Controllerのメソッドを提供する
 */
@Controller
@RequestMapping("/portfolio")
public class ProfileController extends ProfileCommonController {

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(ProfileController.class);

	@Autowired
	private ApplicationContext context;

	@Autowired
	private UserServiceImpl userServiceImpl;

	@Autowired
	private PortfolioProfileServiceImpl portfolioProfileServiceImpl;

	@Autowired
	private CmFileUploadServiceImpl cmFileUploadServiceImpl;

	@Autowired
	private FileService fileService;

	@Autowired
	private AppContextService appContext;

	private static final String REDIRECT_LIST = "redirect:../../";
	// 編集画面
	private static final String EDITPAGE_DOCTOR = "portfolio/profile/editDoctor"; // 若手研究者
	private static final String EDITPAGE_TEACHER = "portfolio/profile/editTeacher"; // 教職員
	private static final String EDITPAGE_CONSUL = "portfolio/profile/editConsul"; // 相談員
	private static final String EDITPAGE_MGMT = "portfolio/profile/editMgmt"; // 事務局
	private static final String EDITPAGE_PARTY = "portfolio/profile/editParty"; // 企業
	// 公開設定区分
	private static final String KBN_USERPUBLICFLAG = "0024";
	// 学年／職位区分
	private static final String KBN_DEGREE = "0035";
	// 性別区分
	private static final String KBN_SEX = "0025";
	// PR動画
	private static final String FILEKBN_PR = "01";
	// 求める人材
	private static final String FILEKBN_SEEK = "02";
	// 活躍中の博士
	private static final String FILEKBN_DOCTOR = "03";

	private static final String PUBLIC_FLAG = "1"; // 固定値: 公開

	@PostConstruct
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	/**
	 * ポートフォリオ表示
	 *
	 * @param form
	 * @param model
	 * @param locale
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = { "", "/" })
	public String profile(@ModelAttribute(CommonConst.FORM_NAME) PortfolioProfileForm form, Model model, Locale locale)
			throws Exception {

		logger.infoCode("I0001", "profile"); // I0001=メソッド開始:{0}

		this.setListToModel(model, "0042", locale);

		// ユーザ情報取得
		UsUserTbl usUserTbl = userServiceImpl.findOne(userInfo.getTargetUserKey());
		form.setUsUserTbl(usUserTbl);
		model.addAttribute("usUserTbl", usUserTbl);
		// プロフィール表示
		form.setButtonFlag("1");
		this.setListToModel(form, model, userInfo.getTargetUserKey());
		model.addAttribute(CommonConst.FORM_NAME, form);

		RoleObject roleObject = appContext.getRole(usUserTbl.getUserKbn());

		// dump
		modelDump(logger, model, "profile");

		logger.infoCode("I0002", "profile"); // I0002=メソッド終了:{0}

		return roleObject.getDetailPageUrl();
	}

	/**
	 * ポートフォリオ編集
	 *
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = { "/profile/edit" })
	public String edit(Model model, Locale locale) {

		logger.infoCode("I0001", "edit"); // I0001=メソッド開始:{0}

		// ユーザ情報取得
		UsUserTbl usUserTbl = userServiceImpl.findOne(userInfo.getTargetUserKey());
		// ファイルアップロード取得
		CmFileUploadTbl cmFileUploadTblImage = new CmFileUploadTbl();
		if (usUserTbl.getUploadKey() != null && StringUtil.isNotNull(usUserTbl.getUploadKey())) {
			cmFileUploadTblImage = cmFileUploadServiceImpl.findOne(usUserTbl.getUploadKey());
		}

		// 公開設定区分
		model.addAttribute("listUserPublicFlag", DbUtil.getJosuList(KBN_USERPUBLICFLAG, locale));
		// 学年／職位区分
		model.addAttribute("listDegree", DbUtil.getJosuList(KBN_DEGREE, locale));
		// 性別区分
		model.addAttribute("listSex", DbUtil.getJosuList(KBN_SEX, locale));

		// 機関指定 必須切り替え「学籍ID/職員IDなど」
		String[] requiredPartyList = new String[]{};
		if (!CollectionUtils.isEmpty(systemSetting.getUserParamRequiredPartyCodeList())) {
			requiredPartyList = (String[])systemSetting.getUserParamRequiredPartyCodeList().toArray(new String[0]);
		}
		model.addAttribute("requiredPartyList", requiredPartyList);

		String editPage = "";

		ProfileForm form = new ProfileForm();
		form.setUserPublicFlag(usUserTbl.getUserPublicFlag());
		form.setDegree(usUserTbl.getDegree());
		form.setUserKbn(usUserTbl.getUserKbn());
		form.setUserFamilyName(usUserTbl.getUserFamilyName());
		form.setUserMiddleName(usUserTbl.getUserMiddleName());
		form.setUserName(usUserTbl.getUserName());
		form.setUserFamilyNameKn(usUserTbl.getUserFamilyNameKn());
		form.setUserMiddleNameKn(usUserTbl.getUserMiddleNameKn());
		form.setUserNameKn(usUserTbl.getUserNameKn());
		form.setUserFamilyNameEn(usUserTbl.getUserFamilyNameEn());
		form.setUserMiddleNameEn(usUserTbl.getUserMiddleNameEn());
		form.setUserNameEn(usUserTbl.getUserNameEn());
		form.setSex(usUserTbl.getSex());
		form.setTelno(usUserTbl.getTelno());
		form.setPartyCode(usUserTbl.getPartyCode());
		form.setAffiliationName(usUserTbl.getAffiliationName());
		form.setResearchSubject(usUserTbl.getResearchSubject());
		form.setStudentId(usUserTbl.getStudentId());
		form.setTeacherName(usUserTbl.getTeacherName());
		form.setCountry(usUserTbl.getCountry());
		form.setJstCode(usUserTbl.getJstCode());
		form.setFreeInput1(usUserTbl.getFreeInput1());
		form.setFreeInput2(usUserTbl.getFreeInput2());
		form.setFreeInput3(usUserTbl.getFreeInput3());
		form.setFreeInput4(usUserTbl.getFreeInput4());
		form.setFreeInput5(usUserTbl.getFreeInput5());
		form.setUploadKey(usUserTbl.getUploadKey());
		if (cmFileUploadTblImage != null) {
			form.setImageFileName(cmFileUploadTblImage.getFileName());
		}
		form.setUpdDate(usUserTbl.getUpdDate());

		// PR動画取得
		List<UsPrmovieUploadTbl> listPrFile = new ArrayList<UsPrmovieUploadTbl>();
		if (CommonConst.USER_KBN_MGMT4.equals(usUserTbl.getUserKbn())) {
			listPrFile = portfolioProfileServiceImpl.findAllPrFile(userInfo.getTargetUserKey());
			for (UsPrmovieUploadTbl usPrmovieUploadTbl : listPrFile) {
				CmFileUploadTbl cmFileUploadTblPrMovie = cmFileUploadServiceImpl
						.findOne(usPrmovieUploadTbl.getId().getUploadKey());
				if (FILEKBN_PR.equals(cmFileUploadTblPrMovie.getFileKbn())) {
					form.setPrMovieFileName(cmFileUploadTblPrMovie.getFileName());
					form.setPrMovieFileUploadKey(cmFileUploadTblPrMovie.getUploadKey());
				} else if (FILEKBN_SEEK.equals(cmFileUploadTblPrMovie.getFileKbn())) {
					form.setSeekFileName(cmFileUploadTblPrMovie.getFileName());
					form.setSeekFileUploadKey(cmFileUploadTblPrMovie.getUploadKey());
				} else if (FILEKBN_DOCTOR.equals(cmFileUploadTblPrMovie.getFileKbn())) {
					form.setDoctorFileName(cmFileUploadTblPrMovie.getFileName());
					form.setDoctorFileUploadKey(cmFileUploadTblPrMovie.getUploadKey());
				}

				form.setPrMovieFileUpdDate(usPrmovieUploadTbl.getUpdDate());
			}
		}
		model.addAttribute(CommonConst.FORM_NAME, form);

		if (CommonConst.USER_KBN_USER1.equals(usUserTbl.getUserKbn())
				|| CommonConst.USER_KBN_USER2.equals(usUserTbl.getUserKbn())
				|| CommonConst.USER_KBN_USER3.equals(usUserTbl.getUserKbn())) {
			// 若手研究員
			editPage = EDITPAGE_DOCTOR;
		} else if (CommonConst.USER_KBN_USER4.equals(usUserTbl.getUserKbn())) {
			// 教職員
			editPage = EDITPAGE_TEACHER;
		} else if (CommonConst.USER_KBN_USER5.equals(usUserTbl.getUserKbn())) {
			// 相談員
			editPage = EDITPAGE_CONSUL;
		} else if (CommonConst.USER_KBN_MGMT1_3.equals(usUserTbl.getUserKbn())) {
			// 事務局・大学
			editPage = EDITPAGE_MGMT;
		} else if (CommonConst.USER_KBN_MGMT4.equals(usUserTbl.getUserKbn())) {
			// 企業
			editPage = EDITPAGE_PARTY;
		}

		logger.infoCode("I0002", "edit"); // I0002=メソッド終了:{0}

		return editPage;
	}

	@RequestMapping(value = { "/profile/update/" + CommonConst.USER_KBN_USER1,
			"/profile/update/" + CommonConst.USER_KBN_USER2,
			"/profile/update/" + CommonConst.USER_KBN_USER3 }, method = RequestMethod.POST)
	public String updateDoctor(
			@Validated(ProfileForm.Doctor.class) @ModelAttribute(CommonConst.FORM_NAME) final ProfileForm form,
			MultipartHttpServletRequest request, BindingResult bindingResult, Model model,
			RedirectAttributes attributes, Locale locale) {

		logger.infoCode("I0001", "updateDoctor"); // I0001=メソッド開始:{0}

		if (update(form, request, bindingResult, model, attributes, locale)) {
			// 成功
			logger.infoCode("I0002", "updateDoctor"); // I0002=メソッド終了:{0}
			return REDIRECT_LIST;
		}
		// 失敗
		logger.errorCode("E0014", "updateDoctor"); // E0014=メソッド異常終了:{0}
		return EDITPAGE_DOCTOR;
	}

	@RequestMapping(value = "/profile/update/" + CommonConst.USER_KBN_USER4, method = RequestMethod.POST)
	public String updateTeacher(
			@Validated(ProfileForm.Teacher.class) @ModelAttribute(CommonConst.FORM_NAME) final ProfileForm form,
			MultipartHttpServletRequest request, BindingResult bindingResult, Model model,
			RedirectAttributes attributes, Locale locale) {

		logger.infoCode("I0001", "updateTeacher"); // I0001=メソッド開始:{0}

		if (update(form, request, bindingResult, model, attributes, locale)) {
			// 成功
			logger.infoCode("I0002", "updateTeacher"); // I0002=メソッド終了:{0}
			return REDIRECT_LIST;
		}
		// 失敗
		logger.errorCode("E0014", "updateTeacher"); // E0014=メソッド異常終了:{0}
		return EDITPAGE_TEACHER;
	}

	@RequestMapping(value = "/profile/update/" + CommonConst.USER_KBN_USER5, method = RequestMethod.POST)
	public String updateConsul(
			@Validated(ProfileForm.Consul.class) @ModelAttribute(CommonConst.FORM_NAME) final ProfileForm form,
			MultipartHttpServletRequest request, BindingResult bindingResult, Model model,
			RedirectAttributes attributes, Locale locale) {

		logger.infoCode("I0001", "updateConsul"); // I0001=メソッド開始:{0}

		if (update(form, request, bindingResult, model, attributes, locale)) {
			// 成功
			logger.infoCode("I0002", "updateConsul"); // I0002=メソッド終了:{0}
			return REDIRECT_LIST;
		}
		// 失敗
		logger.errorCode("E0014", "updateConsul"); // E0014=メソッド異常終了:{0}
		return EDITPAGE_CONSUL;
	}

	@RequestMapping(value = "/profile/update/" + CommonConst.USER_KBN_MGMT1_3, method = RequestMethod.POST)
	public String updateMgmt(
			@Validated(ProfileForm.Mgmt.class) @ModelAttribute(CommonConst.FORM_NAME) final ProfileForm form,
			MultipartHttpServletRequest request, BindingResult bindingResult, Model model,
			RedirectAttributes attributes, Locale locale) {

		logger.infoCode("I0001", "updateMgmt"); // I0001=メソッド開始:{0}

		if (update(form, request, bindingResult, model, attributes, locale)) {
			// 成功
			logger.infoCode("I0002", "updateMgmt"); // I0002=メソッド終了:{0}
			return REDIRECT_LIST;
		}
		// 失敗
		logger.errorCode("E0014", "updateMgmt"); // E0014=メソッド異常終了:{0}
		return EDITPAGE_MGMT;
	}

	@RequestMapping(value = "/profile/update/" + CommonConst.USER_KBN_MGMT4, method = RequestMethod.POST)
	public String updateParty(
			@Validated(ProfileForm.Party.class) @ModelAttribute(CommonConst.FORM_NAME) final ProfileForm form,
			MultipartHttpServletRequest request, BindingResult bindingResult, Model model,
			RedirectAttributes attributes, Locale locale) {

		logger.infoCode("I0001", "updateParty"); // I0001=メソッド開始:{0}

		if (update(form, request, bindingResult, model, attributes, locale)) {
			// 成功
			logger.infoCode("I0002", "updateParty"); // I0002=メソッド終了:{0}
			return REDIRECT_LIST;
		}
		// 失敗
		logger.errorCode("E0014", "updateParty"); // E0014=メソッド異常終了:{0}
		return EDITPAGE_PARTY;
	}

	public boolean update(ProfileForm form, MultipartHttpServletRequest request, BindingResult bindingResult,
			Model model, RedirectAttributes attributes, Locale locale) {

		logger.infoCode("I0001", "update"); // I0001=メソッド開始:{0}

		// 公開設定区分
		model.addAttribute("listUserPublicFlag", DbUtil.getJosuList(KBN_USERPUBLICFLAG, locale));
		// 学年／職位区分
		model.addAttribute("listDegree", DbUtil.getJosuList(KBN_DEGREE, locale));
		// 性別区分
		model.addAttribute("listSex", DbUtil.getJosuList(KBN_SEX, locale));

		Iterator<String> itrator = request.getFileNames();

		List<FileDto> fileList = new ArrayList<>();

		while (itrator.hasNext()) {
			String fileName = itrator.next();
			List<MultipartFile> fList = request.getFiles(fileName);
			for (MultipartFile file : fList) {
				FileDto fileDto = new FileDto();
				if (fileName.startsWith("image")) {
					fileDto.SetFileKbn("03");
				} else if (fileName.startsWith("movie")) {
					fileDto.SetFileKbn("02");
				} else {
					fileDto.SetFileKbn("01");
				}
				fileDto.setUploadName(file.getOriginalFilename());
				fileDto.setFile(file);
				fileList.add(fileDto);
			}
		}

		List<FileDto> uploadFile = fileService.publicUploadFileList(userInfo.getTargetUserKey(),
				userInfo.getLoginUserKey(), fileList);

		if (fileList.size() != uploadFile.size()) {
			for (FileDto dto : uploadFile) {
				fileService.deleteFileUploadTbl(dto.getUploadKey());
			}
			if (uploadFile.size() > 0) {
				model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.regist"); // error.data.message.db.regist=登録が失敗しました。
				logger.errorCode("E0014", "update"); // E0014=メソッド異常終了:{0}
				return false;
			}
		}

		// 学位/役職をユーザー区分にセット
		if (StringUtil.isNotNull(form.getDegree()) && !form.getUserKbn().equals(form.getDegree())) {
			form.setUserKbn(form.getDegree());
		}
		boolean result = updateData(uploadFile, form, bindingResult, model, attributes, locale);

		if (!result) {
			for (FileDto dto : uploadFile) {
				fileService.deleteFileUploadTbl(dto.getUploadKey());
			}
		}

		logger.infoCode("I0002", "update"); // I0002=メソッド終了:{0}
		return result;

	}

	public boolean updateData(List<FileDto> uploadFile, ProfileForm form, BindingResult bindingResult, Model model,
			RedirectAttributes attributes, Locale locale) {
		logger.infoCode("I0001", "updateData"); // I0001=メソッド開始:{0}

		String key = "userKey=" + userInfo.getTargetUserKey() + ", UserKbn = " + form.getUserKbn();
		logger.infoCode("I1009", key); // I1009=入力したデータ。key={0}

		///////////////////////////////////////////////////////////////////////////////////
		// バリデーションエラーがある場合
		if (bindingResult.hasErrors()) {
			if (logger.isDebugEnabled()) {
				logger.debugCode("W1010", bindingResult.getFieldError()); // W1010=Validationチェックエラーがありました。
			}
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.valid.data"); // error.data.message.valid.data=入力項目に誤りがあります。

			logger.infoCode("I0002", "UserKbn = " + form.getUserKbn()); // I0002=メソッド終了:{0}
			return false;
		}

		///////////////////////////////////////////////////////////////////////////////////
		// DB登録
		///////////////////////////////////////////////////////////////////////////////////
		if (userServiceImpl.update(uploadFile, form, userInfo)) {
			///////////////////////////////////////////////////////////////////////////////////
			// DB更新が成功した場合
			logger.infoCode("I1004", key); // I1004=更新しました。{0}
			attributes.addFlashAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.update.success"); // message.data.update.success=データを更新しました。
			logger.infoCode("I0002", "updateData"); // I0002=メソッド終了:{0}

			// 操作履歴
			this.operationHistory(CommonConst.OP_FUNC_USER_BASE, CommonConst.OP_ACTION_UPLOAD);

			return true;
		}

		// DB更新が失敗した場合
		logger.errorCode("E1007", key); // E1007=登録に失敗しました。{0}
		model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.regist"); // error.data.message.db.regist=登録が失敗しました。
		logger.errorCode("E0014", "updateData"); // E0014=メソッド異常終了:{0}

		return false;
	}

	/**
	 * ダイレクトアクセス対策
	 *
	 * @return
	 */
	@RequestMapping(value = { "/copy", "/create", "/update", "/delete" }, method = RequestMethod.GET)
	public String redirect() {
		logger.warnCode("W1009"); // W1009=URLダイレクトアクセスがありました。
		return CommonConst.REDIRECT_INDEX;
	}

}
