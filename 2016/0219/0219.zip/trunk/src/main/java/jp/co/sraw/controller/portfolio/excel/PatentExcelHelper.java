package jp.co.sraw.controller.portfolio.excel;

import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Service;

import jp.co.sraw.common.CommonForm;
import jp.co.sraw.controller.portfolio.form.GyPatentForm;
import jp.co.sraw.util.PoiBook;

@Service
public class PatentExcelHelper extends PortfolioExcelHelper<GyPatentForm> {

	public PatentExcelHelper() {
		this.DATA_SHEET_NAME = "PATENT";
	}

	@Override
	public void buildExcelDocument(PoiBook workbook, List<GyPatentForm> list) {
		workbook.activeSheet = workbook.book.getSheet(DATA_SHEET_NAME);

		for (int i = 0; i < list.size(); i++) {
			GyPatentForm form = list.get(i);
			form.setViewType(CommonForm.VIEW_TYPE_EXCEL);
			int rowno = i + 1;
			// 言語区分
			// workbook.changeValue(rowno, 0, form.getLanguage());
			// 出願番号
			workbook.changeValue(rowno, 0, form.getApplicationid());
			// 出願日
			workbook.changeValue(rowno, 1, form.getApplicationdate());
			// 公開番号
			workbook.changeValue(rowno, 2, form.getPublicid());
			// 公開日
			workbook.changeValue(rowno, 3, form.getPublicdate());
			// 公表番号
			workbook.changeValue(rowno, 4, form.getTranslationid());
			// 公表日
			workbook.changeValue(rowno, 5, form.getTranslationdate());
			// 特許番号
			workbook.changeValue(rowno, 6, form.getPatentid());
			// 発行日
			workbook.changeValue(rowno, 7, form.getPatentdate());
			// 発明の名称
			workbook.changeValue(rowno, 8, form.getTitle());
			// 出願人
			workbook.changeValue(rowno, 9, form.getApplicationperson());
			// 発明者
			workbook.changeValue(rowno, 10, form.getAuthor());
			// 公開範囲
			workbook.changeValue(rowno, 11, form.getPublicFlag());
		}
	}

	@Override
	public Sheet getSheet(Workbook workbook) {
		return workbook.getSheet(DATA_SHEET_NAME);
	}

	@Override
	public GyPatentForm getForm(Row row) {
		GyPatentForm form = new GyPatentForm();

		// 言語区分
		// form.setLanguage(getCellValue(row, 0));
		// 出願番号
		form.setApplicationid(getCellValue(row, 0));
		// 出願日
		form.setApplicationdate(getCellValue(row, 1, true));
		// 公開番号
		form.setPublicid(getCellValue(row, 2));
		// 公開日
		form.setPublicdate(getCellValue(row, 3, true));
		// 公表番号
		form.setTranslationid(getCellValue(row, 4));
		// 公表日
		form.setTranslationdate(getCellValue(row, 5, true));
		// 特許番号
		form.setPatentid(getCellValue(row, 6));
		// 発行日
		form.setPatentdate(getCellValue(row, 7, true));
		// 発明の名称
		form.setTitle(getCellValue(row, 8));
		// 出願人
		form.setApplicationperson(getCellValue(row, 9));
		// 発明者
		form.setAuthor(getCellValue(row, 10));
		// 公開範囲
		form.setPublicFlag(getCellValue(row, 11));

		return form;
	}

}