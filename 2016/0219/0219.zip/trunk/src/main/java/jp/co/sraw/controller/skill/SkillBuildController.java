/*
* ファイル名：SkillBuildController.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/01/14   tsutsumi    新規作成
*/
package jp.co.sraw.controller.skill;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonController;
import jp.co.sraw.dto.SkillBuildDto;
import jp.co.sraw.entity.NrLessonRelSubjectTbl;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.oxm.rubric.Rubric;
import jp.co.sraw.oxm.rubric.RubricCategory;
import jp.co.sraw.service.RubricServiceImpl;
import jp.co.sraw.service.SkillBuildServiceImpl;
import jp.co.sraw.util.DbUtil;

@Controller
@RequestMapping("/skill/build")
public class SkillBuildController extends CommonController {

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(SkillBuildController.class);

	// 遷移先。
	private static final String INDEX_PAGE = "/skill/build/index";
	private static final String LIST_PAGE = "/skill/build/list";
	private static final String DETAIL_PAGE = "/skill/build/detail";

	private static final String REDIRECT_LIST = "redirect:/skill/build/list";
	private static final String REDIRECT_DETAIL = "redirect:/skill/build/viewLesson";

	// 定数コード
	private static final String JOSU_TARGET = "0045";		// 学内聴講対象者
	private static final String JOSU_LISTEN = "0046";		// 学外聴講／傍聴の可否
	private static final String JOSU_RELAY = "0023";		// 中継の有無
	private static final String JOSU_KBN = "0047";			// 授業形態
	private static final String JOSU_COMPULSOR = "0048";	// 必修選択の別

	@Autowired
	private RubricServiceImpl rubricService;

	@Autowired
	private SkillBuildServiceImpl skillBuildService;

	@Override
	protected void init() {
		logger.setMessageSource(messageSource);
	}


	// 全能力養成科目画面 表示
	@RequestMapping({"", "/", "/index"})
	public String index(HttpServletRequest request
			, Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		String rkey = skillBuildService.getDefaultRubricKey(locale);
		return index(request, rkey, model, locale);
	}

	// 全能力養成科目画面 表示
	@RequestMapping("/index/{rkey}")
	public String index(HttpServletRequest request
			, @PathVariable("rkey") String rkey
			, Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		// ルーブリック内容取得
		Rubric rub = rubricService.findOne(rkey);
		model.addAttribute("rubric", rub);

		// 推奨科目情報取得
		Map<String, List<SkillBuildDto>> subjectMap = new HashMap<String, List<SkillBuildDto>>();
		Map<String, String> rowspanMap = new HashMap<>();
		int cnt = 0;
		for (RubricCategory rubCt : rub.getCategoryList()) {
			for (RubricCategory subCt : rubCt.getChildList()) {
				for (RubricCategory grantCt : subCt.getChildList()) {
					List<SkillBuildDto> list = skillBuildService.getRecommendLesson(rkey, grantCt.getAbilityCode());
					subjectMap.put(grantCt.getAbilityCode(), list);
				}
				cnt = cnt + subCt.getChildList().size();
			}
			rowspanMap.put(rubCt.getAbilityCode(), Integer.toString(cnt));
			cnt = 0;
		}
		model.addAttribute("subjectMap", subjectMap);
		model.addAttribute("rowspanMap", rowspanMap);
		model.addAttribute("rubricChartDto", rubricService.getCharDto(rub));
		model.addAttribute("rkey", rkey);

		logger.infoCode("I0002", INDEX_PAGE);
		return INDEX_PAGE;
	}


	/**
	 * 能力養成科目一覧画面 表示
	 * @param request
	 * @param chkSts 表示条件
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping("/list")
	public String list(HttpServletRequest request
			, Model model, Locale locale) {
		String rkey = skillBuildService.getDefaultRubricKey(locale);
		return list(request, rkey, new BuildForm(), model, locale);
	}

	/**
	 * 能力養成科目一覧画面 表示
	 * @param request
	 * @param rkey ルーブリックキー
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = "/list/{rkey}", method = RequestMethod.GET)
	public String list(HttpServletRequest request
			, @PathVariable("rkey") String rkey
			, Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());
		return list(request, rkey, new BuildForm(), model, locale);

	}

	/**
	 * 能力養成科目一覧画面 表示
	 * @param request
	 * @param rkey ルーブリックキー
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = "/list/{rkey}", method = RequestMethod.POST)
	public String list(HttpServletRequest request
			, @PathVariable("rkey") String rkey
			, @ModelAttribute(CommonConst.FORM_NAME) BuildForm selForm
			, Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		// ルーブリック内容取得
		Rubric rub = rubricService.findOne(rkey);
		model.addAttribute("rubric", rub);

		// 表示状態
		List<Boolean> chkSts = new ArrayList<>();
		chkSts.add(selForm.getChkJoin());
		chkSts.add(selForm.getChkReserve());
		chkSts.add(selForm.getChkNone());

		// 履修状況・推奨科目情報取得
		Map<String, List<SkillBuildDto>> subjectMap = new HashMap<String, List<SkillBuildDto>>();
		for (RubricCategory rubCt : rub.getCategoryList()) {
			for (RubricCategory subCt : rubCt.getChildList()) {
				for (RubricCategory grantCt : subCt.getChildList()) {
					List<SkillBuildDto> list;
					if (userInfo.isUserWakate()) {
						// 若手ユーザの場合
						list = skillBuildService.searchNrLessonTblForLessonCode(userInfo.getTargetUserKey(), rkey, grantCt.getAbilityCode(), chkSts);
					} else {
						list = skillBuildService.getRecommendLesson(rkey, grantCt.getAbilityCode());
					}

					subjectMap.put(grantCt.getAbilityCode(), list);
				}
			}
		}
		model.addAttribute("subjectMap", subjectMap);
		model.addAttribute("rkey", rkey);

		mapInit(model, locale);

		logger.infoCode("I0002", LIST_PAGE);
		return LIST_PAGE;
	}

	/**
	 * 能力養成科目一覧画面 参加確定処理
	 *
	 * @param request
	 * @param selForm
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = "/fix", method = RequestMethod.POST)
	@ResponseBody
	public AjaxDto fix(HttpServletRequest request
			, @ModelAttribute(CommonConst.FORM_NAME) BuildForm selForm
			, Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		try {
			// チェックしている養成科目を「参加確定」に更新する。
			String[] selLesson = selForm.getSelLesson().split(",");
			skillBuildService.updateForCourseStatus(Arrays.asList(selLesson)
					, CommonConst.COURSE_STATUS_JOIN, userInfo.getTargetUserKey(), userInfo.getLoginUserKey());
		} catch (Exception e) {
			logger.errorCode("E1007", e);
			return new AjaxDto(messageSource.getMessage("error.data.message.db.regist", null, locale));
		}

		logger.infoCode("I0002");
		return new AjaxDto();
	}

	// 能力養成科目詳細画面 表示
	@RequestMapping("/viewLesson/{lessonKey}")
	public String detail(HttpServletRequest request
			, @PathVariable("lessonKey") String lessonKey
			, Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());
		String rkey = skillBuildService.getDefaultRubricKey(locale);
		return detail(request, lessonKey, rkey, model, locale);
	}

	// 能力養成科目詳細画面 表示
	@RequestMapping("/viewLesson/{lessonKey}/{rkey}")
	public String detail(HttpServletRequest request
			, @PathVariable("lessonKey") String lessonKey
			, @PathVariable("rkey") String rkey
			, Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		// 詳細情報取得
		CurriculumForm thisForm = skillBuildService.getDetailInfoForLesson(rkey, lessonKey);
		model.addAttribute("curriculum", thisForm);

		// ルーブリック内容取得
		Rubric rub = rubricService.findOne(rkey);

		// 紐付き状態取得
		List<NrLessonRelSubjectTbl> relList = skillBuildService.searchRelSubjectInfo(rkey, lessonKey);
		Map<String, String> relMap = new HashMap<>();
		for(NrLessonRelSubjectTbl rel : relList) {
			relMap.put(rel.getId().getSubjectCode(), rel.getRelationLevel());
		}


		SKillBuildRelateForm form = populateRelateForm(rub, relList);
		model.addAttribute("relation", form);
		model.addAttribute("lessonKey", lessonKey);
		model.addAttribute("rkey", rkey);

		mapInit(model, locale);

		logger.infoCode("I0002", DETAIL_PAGE);
		return DETAIL_PAGE;
	}

	// 能力養成科目詳細画面 参加予約
	@RequestMapping(value="/reserve/{lessonKey}/{rkey}")
	@ResponseBody
	public AjaxDto reserve(HttpServletRequest request
			, @PathVariable("lessonKey") String lessonKey
			, @PathVariable("rkey") String rkey
			, Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		try {
			// チェックしている養成科目を「参加予約」に更新する。
			skillBuildService.updateForCourseStatus(lessonKey
					, CommonConst.COURSE_STATUS_RESERVE, userInfo.getTargetUserKey(), userInfo.getLoginUserKey());
		} catch (Exception e) {
			logger.errorCode("E1007", e);
			return new AjaxDto(messageSource.getMessage("error.data.message.db.regist", null, locale));
		}

		logger.infoCode("I0002");
		return new AjaxDto();
	}

	// 能力養成科目詳細画面 参加取消
	@RequestMapping(value="/cancel/{lessonKey}/{rkey}")
	@ResponseBody
	public AjaxDto cancel(HttpServletRequest request
			, @PathVariable("lessonKey") String lessonKey
			, @PathVariable("rkey") String rkey
			, Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		try {
			// チェックしている養成科目を「参加取消」にする。
			skillBuildService.updateForCourseStatus(lessonKey
					, CommonConst.COURSE_STATUS_NONE, userInfo.getTargetUserKey(), userInfo.getLoginUserKey());
		} catch (Exception e) {
			logger.errorCode("E1007", e);
			return new AjaxDto(messageSource.getMessage("error.data.message.db.regist", null, locale));
		}

		logger.infoCode("I0002");
		return new AjaxDto();
	}

	// 詳細画面関連 ----------
	/**
	 * @param rub
	 * @param list
	 * @return
	 */
	private SKillBuildRelateForm populateRelateForm (Rubric rub, List<NrLessonRelSubjectTbl> list) {
		SKillBuildRelateForm form = new SKillBuildRelateForm();

		// 科目コードと紐付きレベルのmapを作る
		Map<String, String> map = new HashMap<>();
		for (NrLessonRelSubjectTbl item : list) {
			map.put(item.getId().getSubjectCode(), item.getRelationLevel());
		}

		// フォームの形に入れ替え
		List<SkillBuildRelateSubjectForm> relationList = formatRelateForm(rub.getCategoryList(), map);

		form.setRelationList(relationList);
		return form;
	}
	/**
	 * カテゴリ情報をひも付け一覧の表示フォームに変換
	 * @param catList
	 * @param subjectMap
	 * @return
	 */
	private List<SkillBuildRelateSubjectForm> formatRelateForm(List<RubricCategory> catList, Map<String, String> subjectMap) {
		if (catList == null) {
			return null;
		}
		List<SkillBuildRelateSubjectForm> parentList = new ArrayList<SkillBuildRelateSubjectForm>();
		for (RubricCategory cat : catList) {
			SkillBuildRelateSubjectForm item = new SkillBuildRelateSubjectForm();
			item.setSubjectCode(cat.getAbilityCode());
			item.setSubjectName(cat.getName());
			if (subjectMap.containsKey(cat.getAbilityCode())) {
				String relationCd = subjectMap.get(cat.getAbilityCode());
				if (CommonConst.RELATION_LEVEL_BEST.equals(relationCd)) {
					item.setRelation(CommonConst.RELATION_LEVEL_BEST_V);
				} else if (CommonConst.RELATION_LEVEL_NORMAL.equals(relationCd)) {
					item.setRelation(CommonConst.RELATION_LEVEL_NORMAL_V);
				}

			}
			// 子カテゴリをセット
			item.setChildList (formatRelateForm(cat.getChildList(), subjectMap));

			parentList.add(item);
		}
		return parentList;
	}

	private void mapInit (Model model, Locale locale) {
		// 学内聴講対象者
		Map<String, String> targetMap = DbUtil.getJosuAbbrMap(JOSU_TARGET, locale);
		model.addAttribute("targetMap", targetMap);

		// 学外聴講／傍聴の可否
		Map<String, String> listenMap = DbUtil.getJosuAbbrMap(JOSU_LISTEN, locale);
		model.addAttribute("listenMap", listenMap);

		// 中継の有無
		Map<String, String> relayMap = DbUtil.getJosuAbbrMap(JOSU_RELAY, locale);
		model.addAttribute("relayMap", relayMap);

		// 授業形態
		Map<String, String> kbnMap = DbUtil.getJosuAbbrMap(JOSU_KBN, locale);
		model.addAttribute("kbnMap", kbnMap);

		// 必修選択の別
		Map<String, String> compulsorMap = DbUtil.getJosuAbbrMap(JOSU_COMPULSOR, locale);
		model.addAttribute("compulsorMap", compulsorMap);
	}
}
