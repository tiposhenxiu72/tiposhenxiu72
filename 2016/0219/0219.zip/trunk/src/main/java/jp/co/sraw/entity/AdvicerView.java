package jp.co.sraw.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the advicer_view database table.
 *
 */
@Entity
@Table(name="advicer_view")
@NamedQuery(name="AdvicerView.findAll", query="SELECT c FROM AdvicerView c")
public class AdvicerView implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * ユーザキー
	 */
	@Id
	@Column(name="user_key")
	private String userKey;

	/**
	 * ユーザ名（姓）
	 */
	@Column(name="user_family_name")
	private String userFamilyName;

	/**
	 * ユーザ名（姓）・英
	 */
	@Column(name="user_family_name_en")
	private String userFamilyNameEn;

	/**
	 * ユーザ名（ミドルネーム）
	 */
	@Column(name="user_middle_name")
	private String userMiddleName;

	/**
	 * ユーザ名（ミドルネーム）・英
	 */
	@Column(name="user_middle_name_en")
	private String userMiddleNameEn;

	/**
	 * ユーザ名（名）
	 */
	@Column(name="user_name")
	private String userName;

	/**
	 * ユーザ名（名）・英
	 */
	@Column(name="user_name_en")
	private String userNameEn;

	/**
	 * 組織名称
	 */
	@Column(name="party_name")
	private String partyName;

	/**
	 * 組織名称・英
	 */
	@Column(name="party_name_en")
	private String partyNameEn;

	/**
	 * 組織名称（略）
	 */
	@Column(name="party_name_abbr")
	private String partyNameAbbr;

	/**
	 * 組織名称（略）・英
	 */
	@Column(name="party_name_abbr_en")
	private String partyNameAbbrEn;

	/**
	 * ユーザキーを取得します。
	 * @return ユーザキー
	 */
	public String getUserKey() {
	    return userKey;
	}

	/**
	 * ユーザキーを設定します。
	 * @param userKey ユーザキー
	 */
	public void setUserKey(String userKey) {
	    this.userKey = userKey;
	}

	/**
	 * ユーザ名（姓）を取得します。
	 * @return ユーザ名（姓）
	 */
	public String getUserFamilyName() {
	    return userFamilyName;
	}

	/**
	 * ユーザ名（姓）を設定します。
	 * @param userFamilyName ユーザ名（姓）
	 */
	public void setUserFamilyName(String userFamilyName) {
	    this.userFamilyName = userFamilyName;
	}

	/**
	 * ユーザ名（姓）・英を取得します。
	 * @return ユーザ名（姓）・英
	 */
	public String getUserFamilyNameEn() {
	    return userFamilyNameEn;
	}

	/**
	 * ユーザ名（姓）・英を設定します。
	 * @param userFamilyNameEn ユーザ名（姓）・英
	 */
	public void setUserFamilyNameEn(String userFamilyNameEn) {
	    this.userFamilyNameEn = userFamilyNameEn;
	}

	/**
	 * ユーザ名（ミドルネーム）を取得します。
	 * @return ユーザ名（ミドルネーム）
	 */
	public String getUserMiddleName() {
	    return userMiddleName;
	}

	/**
	 * ユーザ名（ミドルネーム）を設定します。
	 * @param userMiddleName ユーザ名（ミドルネーム）
	 */
	public void setUserMiddleName(String userMiddleName) {
	    this.userMiddleName = userMiddleName;
	}

	/**
	 * ユーザ名（ミドルネーム）・英を取得します。
	 * @return ユーザ名（ミドルネーム）・英
	 */
	public String getUserMiddleNameEn() {
	    return userMiddleNameEn;
	}

	/**
	 * ユーザ名（ミドルネーム）・英を設定します。
	 * @param userMiddleNameEn ユーザ名（ミドルネーム）・英
	 */
	public void setUserMiddleNameEn(String userMiddleNameEn) {
	    this.userMiddleNameEn = userMiddleNameEn;
	}

	/**
	 * ユーザ名（名）を取得します。
	 * @return ユーザ名（名）
	 */
	public String getUserName() {
	    return userName;
	}

	/**
	 * ユーザ名（名）を設定します。
	 * @param userName ユーザ名（名）
	 */
	public void setUserName(String userName) {
	    this.userName = userName;
	}

	/**
	 * ユーザ名（名）・英を取得します。
	 * @return ユーザ名（名）・英
	 */
	public String getUserNameEn() {
	    return userNameEn;
	}

	/**
	 * ユーザ名（名）・英を設定します。
	 * @param userNameEn ユーザ名（名）・英
	 */
	public void setUserNameEn(String userNameEn) {
	    this.userNameEn = userNameEn;
	}

	/**
	 * 組織名称を取得します。
	 * @return 組織名称
	 */
	public String getPartyName() {
	    return partyName;
	}

	/**
	 * 組織名称を設定します。
	 * @param partyName 組織名称
	 */
	public void setPartyName(String partyName) {
	    this.partyName = partyName;
	}

	/**
	 * 組織名称・英を取得します。
	 * @return 組織名称・英
	 */
	public String getPartyNameEn() {
	    return partyNameEn;
	}

	/**
	 * 組織名称・英を設定します。
	 * @param partyNameEn 組織名称・英
	 */
	public void setPartyNameEn(String partyNameEn) {
	    this.partyNameEn = partyNameEn;
	}

	/**
	 * 組織名称（略）を取得します。
	 * @return 組織名称（略）
	 */
	public String getPartyNameAbbr() {
	    return partyNameAbbr;
	}

	/**
	 * 組織名称（略）を設定します。
	 * @param partyNameAbbr 組織名称（略）
	 */
	public void setPartyNameAbbr(String partyNameAbbr) {
	    this.partyNameAbbr = partyNameAbbr;
	}

	/**
	 * 組織名称（略）・英を取得します。
	 * @return 組織名称（略）・英
	 */
	public String getPartyNameAbbrEn() {
	    return partyNameAbbrEn;
	}

	/**
	 * 組織名称（略）・英を設定します。
	 * @param partyNameAbbrEn 組織名称（略）・英
	 */
	public void setPartyNameAbbrEn(String partyNameAbbrEn) {
	    this.partyNameAbbrEn = partyNameAbbrEn;
	}


}