package jp.co.sraw.entity;

import java.io.Serializable;

import javax.persistence.MappedSuperclass;

/**
 * The persistent class for the gy_society_tbl database table.
 *
 */
@MappedSuperclass
public class GyHasTtitleTbl extends GyCommonTbl implements Serializable {
	private static final long serialVersionUID = 1L;

	private String title;

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
}