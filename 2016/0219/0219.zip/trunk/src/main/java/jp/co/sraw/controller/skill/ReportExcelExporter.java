package jp.co.sraw.controller.skill;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.poi.hssf.usermodel.HSSFShapeGroup;
import org.apache.poi.hssf.util.HSSFColor;

import jp.co.sraw.dto.SkillAnswerStatsDto;
import jp.co.sraw.dto.SkillLessonTakenDto;
import jp.co.sraw.dto.SkillReportDto;
import jp.co.sraw.entity.NrAchievementReportBkupTbl;
import jp.co.sraw.entity.NrAchievementReportTbl;
import jp.co.sraw.oxm.rubric.Rubric;
import jp.co.sraw.oxm.rubric.RubricCategory;
import jp.co.sraw.util.DateUtil;
import jp.co.sraw.util.PoiBook;

/**
 * 自己評価レポートをExcelへエクスポートする。
 *
 *
 */
public class ReportExcelExporter {
	private static final String SHNAME_TOP = "自己評価レポート";
	private static final String SHNAME_BOTTOM = "養成能力と目標";
	private static final String FORMAT_SAVEDDATE = "yyyy年M月";
	private static final String FORMAT_ACHIEVEMENT = "%d項目中 %d項目達成";
	private static final String FORMAT_NUMLESSONS = "全%d件";
	private static final String NA = "-";
	private static final String DONE = "達成済";
	private static final String NOTYET = "未達成";
	private static final String EOL = "\r\n";

	private static final int LEVEL_CAT = 0;
	private static final int LEVEL_SUBCAT = 1;
	private static final int LEVEL_ITEM = 2;
	private static final int[] ALL_LEVELS = { LEVEL_CAT, LEVEL_SUBCAT, LEVEL_ITEM };
	private static final int[][] RGB_CATS = { { 157, 220, 249, HSSFColor.AQUA.index },
			{ 186, 201, 231, HSSFColor.PINK.index }, { 165, 212, 218, HSSFColor.DARK_TEAL.index },
			{ 211, 191, 221, HSSFColor.LAVENDER.index } };
	private static final int[] RGB_DONE = { 255, 0, 0, HSSFColor.RED.index };
	private static final int[] RGB_NOTYET = { 0, 176, 80, HSSFColor.DARK_GREEN.index };
	private static final int[][] RGB_MAX = { { 58, 187, 242 }, { 107, 139, 203 }, { 93, 177, 187 }, { 163, 122, 183 } };
	private static final int[][] RGB_MIN = { { 231, 247, 254 }, { 237, 241, 249 }, { 235, 246, 247 },
			{ 244, 239, 246 } };
	private static final int[] RGB_WHITE = { 255, 255, 255 };

	// コンフィグ情報。
	// int[2]は、{row, col}の意味。
	// int[3]は、level=0～2。
	private static final int[] SAVED_DATE = { 2, 1 };
	private static final int[][] USER_NAME = { { 1, 6 }, { 1, 5 }, { 1, 5 } };
	private static final int[] LENS_NAME = { 6, 1 };
	private static final int[] ACHIEVEMENT_RATIO = { 8, 2 };
	private static final int[] WHOLE_TARGET = { 11, 0 };
	private static final int[] ANNUAL_TARGET = { 14, 0 };
	private static final int RPIECHART = 16;
	private static final int NUM_ROWS_PICHART = 20;
	private static final int RTABLE_TOP = 39;
	private static final int CTABLE = 0;
	private static final int[] COFF_NUMLESSONS = { 4, 6, 10 }; // levelにより値が違う。
	private static final int NUM_ROWS_TABLE_HEAD = 3;
	private static final int[] NUM_ROWS_TABLE = { 10, 30, 100 };
	private static final short HEIGHT_ITEM = 27;
	private static final int ROFF_REVIEW_BODY = 2;
	private static final int NUM_ROWS_REVIEW = 4;
	private static final short HEIGHT_REVIEW = 70;

	private PoiBook book;

	private class FreeVar { // 自由変数用のコンテナ。
		public int val = 0;

		public FreeVar(int val) {
			this.val = val;
		}
	}

	public ReportExcelExporter(PoiBook book) {
		this.book = book;
	}

	/**
	 * エクスポートする。
	 */
	public void export(Integer level, SkillReportDto dto, SkillAnswerStatsDto stats) {
		prepareTopSheet(level);
		preparePalette();
		exportTop(level, dto, stats);

		book.selectSheet(SHNAME_BOTTOM);
		exportBottom(dto.getRubricAll());

		book.selectSheet(levelToSheetName(level));
	}

	private void exportTop(Integer level, SkillReportDto dto, SkillAnswerStatsDto stats) {
		exportSavedDate(stats.getSavedDate());
		exportUserInfo(dto, level);
		exportLensName(dto);
		exportAchievementRatio(dto, stats);
		exportTarget(dto, stats);
		int numLinesDeleted = exportPieChart(dto, level);
		exportTable(level, dto, stats, -numLinesDeleted);
	}

	private void exportBottom(Rubric rub) {
		FreeVar roff = new FreeVar(0);
		IntStream.range(0, rub.getCategoryList().size()).forEach(catIx -> {
			RubricCategory cat = rub.getCategoryList().get(catIx);
			int numItemsInCat = cat.getChildList().stream().map(sc -> sc.getChildList().size()).reduce(0, Integer::sum);
			exportCaption(RTABLE_TOP + roff.val, 0, cat, catIx, numItemsInCat);

			IntStream.range(0, cat.getChildList().size()).forEach(subcIx -> {
				RubricCategory subc = cat.getChildList().get(subcIx);
				exportCaption(RTABLE_TOP + roff.val, 1, subc, catIx, subc.getChildList().size());

				IntStream.range(0, subc.getChildList().size()).forEach(itemIx -> {
					RubricCategory item = subc.getChildList().get(itemIx);
					exportCaption(RTABLE_TOP + roff.val, 2, item, catIx, 0);
					book.changeValue(RTABLE_TOP + roff.val, CTABLE + 3, item.getSummary());
					book.setRowHeight(RTABLE_TOP + roff.val, HEIGHT_ITEM);

					roff.val = roff.val + 1;
				});
			});
		});

		book.deleteRows(RTABLE_TOP + roff.val, RTABLE_TOP + NUM_ROWS_TABLE[LEVEL_ITEM], NUM_ROWS_REVIEW);
	}

	private void exportSavedDate(Date savedDate) {
		savedDate = savedDate == null ? new Date() : savedDate;
		book.changeValue(SAVED_DATE[0], SAVED_DATE[1], DateUtil.dateTimeFormat(savedDate, FORMAT_SAVEDDATE));
	}

	private void exportUserInfo(SkillReportDto dto, int level) {
		int[] rc = USER_NAME[level];
		book.changeValue(rc[0], rc[1], dto.getUserName());
		book.changeValue(rc[0] + 1, rc[1], dto.getDegreeName());
		book.changeValue(rc[0] + 2, rc[1], dto.getPartyName());
		book.changeValue(rc[0] + 3, rc[1], dto.getMajorName());
	}

	private void exportLensName(SkillReportDto dto) {
		book.changeValue(LENS_NAME[0], LENS_NAME[1], dto.getLensName());
	}

	private void exportAchievementRatio(SkillReportDto dto, SkillAnswerStatsDto stats) {
		if (dto.canEditDone()) {
			book.changeValue(ACHIEVEMENT_RATIO[0], ACHIEVEMENT_RATIO[1], String.valueOf(stats.getRatio()) + "%");
			book.changeValue(ACHIEVEMENT_RATIO[0], ACHIEVEMENT_RATIO[1] + 1,
					String.format(FORMAT_ACHIEVEMENT, stats.getDenom(), stats.getNume()));
		} else {
			book.deleteRows(ACHIEVEMENT_RATIO[0], ACHIEVEMENT_RATIO[0] + 1, 0);
		}
	}

	private void exportTarget(SkillReportDto dto, SkillAnswerStatsDto stats) {
		String whole;
		String annual;
		if (stats.getSavedDate() == null) { // 最新?
			NrAchievementReportTbl repo = dto.getReport();
			whole = repo == null ? "" : repo.getAllAchievement();
			annual = repo == null ? "" : repo.getYearlyAchievement();
		} else { // 過去。
			NrAchievementReportBkupTbl repo = dto.getSavedReport();
			whole = repo == null ? "" : repo.getAllAchievement();
			annual = repo == null ? "" : repo.getYearlyAchievement();
		}
		book.changeValue(WHOLE_TARGET[0], WHOLE_TARGET[1], whole);
		book.changeValue(ANNUAL_TARGET[0], ANNUAL_TARGET[1], annual);
	}

	private int exportPieChart(SkillReportDto dto, int level) {
		if (!dto.canEditDone()) {
			book.deleteAllShapes();
			book.deleteRows(RPIECHART, RPIECHART + NUM_ROWS_PICHART,
					NUM_ROWS_TABLE_HEAD + NUM_ROWS_TABLE[level] + NUM_ROWS_REVIEW);
			return NUM_ROWS_PICHART;
		}

		List<HSSFShapeGroup> sgs = book.topLevelShapeGroup();
		sgs.forEach(sg -> {
			if (sg.getChildren().size() == 4) { // cat?
				sg.forEach(pie -> {
					int angle = normalizeAngle(pie.getRotationDegree());
					int catIx = catIxFromAngle(angle);
					int[] rgb = calcRGB(catIx, dto.getAnswers().get(catIx));
					pie.setFillColor(rgb[0], rgb[1], rgb[2]);
				});
			} else if (sg.getChildren().size() == 12) { // sub cat?
				sg.forEach(pie -> {
					int angle = normalizeAngle(pie.getRotationDegree());
					int catIx = catIxFromAngle(angle);
					int subcIx = subcIxFromAngle(angle);
					int[] rgb = calcRGB(catIx, dto.getAnswers().get(catIx).getChildList().get(subcIx));
					pie.setFillColor(rgb[0], rgb[1], rgb[2]);
				});
			} else {
			}
		});
		return 0;
	}

	private int[] calcRGB(int catIx, AnswerForm ans) {
		int[] max = RGB_MAX[catIx];
		int[] min = RGB_MIN[catIx];
		double[] delta = { ((double) min[0] - max[0]) / 4, ((double) min[1] - max[1]) / 4,
				((double) min[2] - max[2]) / 4 };

		long lv = ans.getAchievementLevel();
		if (lv == 0) {
			return RGB_WHITE;
		} else if (lv < 25) {
			return min;
		} else if (lv < 50) {
			return new int[] { min[0] - ((int) delta[0]), min[1] - ((int) delta[1]), min[2] - ((int) delta[2]) };
		} else if (lv < 75) {
			return new int[] { min[0] - ((int) delta[0] * 2), min[1] - ((int) delta[1] * 2),
					min[2] - ((int) delta[2] * 2) };
		} else if (lv < 100) {
			return new int[] { min[0] - ((int) delta[0] * 3), min[1] - ((int) delta[1] * 3),
					min[2] - ((int) delta[2] * 3) };
		}
		return max;
	}

	private int normalizeAngle(int angle) {
		while (angle < 0) {
			angle += 360;
		}
		while (angle >= 360) {
			angle -= 360;
		}
		return angle;
	}

	private int catIxFromAngle(int angle) {
		angle = normalizeAngle(angle);
		return angle / 90;
	}

	private int subcIxFromAngle(int angle) {
		angle = normalizeAngle(angle);
		// 左側は逆順。
		if (angle >= 180) {
			return (89 - (angle % 90)) / 30;
		}
		return angle % 90 / 30;
	}

	private void exportTable(Integer level, SkillReportDto dto, SkillAnswerStatsDto stats, int rofftop) {
		if (level == LEVEL_CAT) {
			exportCatTable(dto, stats, level, rofftop);
		} else if (level == LEVEL_SUBCAT) {
			exportSubcatTable(dto, stats, level, rofftop);
		} else {
			exportItemTable(dto, stats, level, rofftop);
		}
	}

	private void exportCatTable(SkillReportDto dto, SkillAnswerStatsDto stats, int level, int rofftop) {
		int rtop = RTABLE_TOP + rofftop;
		Rubric rub = dto.getRubric();
		IntStream.range(0, rub.getCategoryList().size()).forEach(i -> {
			RubricCategory cat = rub.getCategoryList().get(i);
			exportCaption(rtop + i, 0, cat, i, 1);
			exportAchievement(rtop + i, 1, dto.getAchievementMap().get(cat.getAbilityCode()));
			List<SkillLessonTakenDto> lessons = dto.getLessonMap().get(cat.getAbilityCode());
			exportLessons(rtop + i, 2, COFF_NUMLESSONS[level], lessons);
			book.setRowHeight(rtop + i, HEIGHT_ITEM);
		});

		book.deleteRows(rtop + rub.getCategoryList().size(), rtop + NUM_ROWS_TABLE[level], NUM_ROWS_REVIEW);
		book.setRowHeight(rtop + rub.getCategoryList().size() + ROFF_REVIEW_BODY, HEIGHT_REVIEW);
	}

	private void exportSubcatTable(SkillReportDto dto, SkillAnswerStatsDto stats, int level, int rofftop) {
		int rtop = RTABLE_TOP + rofftop;
		Rubric rub = dto.getRubric();
		FreeVar roff = new FreeVar(0);
		IntStream.range(0, rub.getCategoryList().size()).forEach(catIx -> {
			RubricCategory cat = rub.getCategoryList().get(catIx);
			exportCaption(rtop + roff.val, 0, cat, catIx, cat.getChildList().size());

			IntStream.range(0, cat.getChildList().size()).forEach(subcIx -> {
				RubricCategory subc = cat.getChildList().get(subcIx);
				// ★中項目内に、選択レンズに該当する小項目が無い場合でも、当該中項目を表示する。
				exportCaption(rtop + roff.val, 1, subc, catIx, 1);

				AnswerForm ans = dto.getAnswers().get(catIx).getChildList().get(subcIx);
				exportAchievement(rtop + roff.val, 2, dto.getAchievementMap().get(subc.getAbilityCode()));

				book.changeValue(rtop + roff.val, CTABLE + 3, ans.getActionPlan());
				book.changeValue(rtop + roff.val, CTABLE + 4, ans.getEvidence());

				List<SkillLessonTakenDto> lessons = dto.getLessonMap().get(subc.getAbilityCode());
				exportLessons(rtop + roff.val, 5, COFF_NUMLESSONS[level], lessons);

				book.setRowHeight(rtop + roff.val, HEIGHT_ITEM);

				roff.val = roff.val + 1;
			});
		});

		book.deleteRows(rtop + roff.val, rtop + NUM_ROWS_TABLE[level], NUM_ROWS_REVIEW);
		book.setRowHeight(rtop + roff.val + ROFF_REVIEW_BODY, HEIGHT_REVIEW);
	}

	private void exportItemTable(SkillReportDto dto, SkillAnswerStatsDto stats, int level, int rofftop) {
		int rtop = RTABLE_TOP + rofftop;
		Rubric rub = dto.getRubric();
		FreeVar roff = new FreeVar(0);
		IntStream.range(0, rub.getCategoryList().size()).forEach(catIx -> {
			RubricCategory cat = rub.getCategoryList().get(catIx);
			exportCaption(rtop + roff.val, 0, cat, catIx, (int) dto.getAnswers().get(catIx).getNumGrandchildren());

			IntStream.range(0, cat.getChildList().size()).forEach(subcIx -> {
				RubricCategory subc = cat.getChildList().get(subcIx);
				if (subc.getChildList().size() > 0) { // 中項目内に、選択レンズに該当する小項目が無い場合は、中項目自体を表示しない。
					AnswerForm subcAns = dto.getAnswers().get(catIx).getChildList().get(subcIx);
					exportCaption(rtop + roff.val, 1, subc, catIx, (int) subcAns.getNumChildren());

					book.changeValue(rtop + roff.val, CTABLE + 2, subcAns.getActionPlan());
					book.mergeCell(rtop + roff.val, CTABLE + 2, (int) subcAns.getNumChildren() - 1, 0);
					book.changeValue(rtop + roff.val, CTABLE + 3, subcAns.getEvidence());
					book.mergeCell(rtop + roff.val, CTABLE + 3, (int) subcAns.getNumChildren() - 1, 0);

					IntStream.range(0, subc.getChildList().size()).forEach(itemIx -> {
						RubricCategory item = subc.getChildList().get(itemIx);
						AnswerForm itemAns = subcAns.getChildList().get(itemIx);
						exportCaption(rtop + roff.val, 4, item, catIx, 0);
						exportAchievement(rtop + roff.val, 5, dto.getAchievementMap().get(item.getAbilityCode()),
								item.forBasicLens());

						if (itemAns.isAnswered()) {
							if (itemAns.getPhase() != null) {
								book.changeValue(rtop + roff.val, CTABLE + 6, String.valueOf(itemAns.getPhase()));
							}
							book.changeValue(rtop + roff.val, CTABLE + 7, itemAns.getActionPlan());
							book.changeValue(rtop + roff.val, CTABLE + 8, itemAns.getEvidence());
						}

						List<SkillLessonTakenDto> lessons = dto.getLessonMap().get(item.getAbilityCode());
						exportLessons(rtop + roff.val, 9, COFF_NUMLESSONS[level], lessons);

						book.setRowHeight(rtop + roff.val, HEIGHT_ITEM);

						roff.val = roff.val + 1;
					});
				}
			});
		});

		book.deleteRows(rtop + roff.val, rtop + NUM_ROWS_TABLE[level], NUM_ROWS_REVIEW);
		book.setRowHeight(rtop + roff.val + ROFF_REVIEW_BODY, HEIGHT_REVIEW);
	}

	private void exportCaption(int row, int coff, RubricCategory cat, int catIx, int numRows) {
		book.changeValue(row, CTABLE + coff, cat.getCaption());
		book.fill(row, CTABLE + coff, colorIndex(RGB_CATS[catIx]));
		if (numRows > 1) {
			book.mergeCell(row, CTABLE + coff, numRows - 1, 0);
		}
	}

	private void exportAchievement(int row, int coff, Boolean ans) {
		exportAchievement(row, coff, ans, true);
	}

	private void exportAchievement(int row, int coff, Boolean ans, boolean forBasic) {
		// forBasicフラグは、小項目専用。
		// 基礎能力診断以外なら、NAを出したい。
		if (!forBasic || ans == null) {
			book.changeValue(row, CTABLE + coff, NA);
		} else if (ans) {
			book.changeValue(row, CTABLE + coff, DONE);
			book.setFontColor(row, CTABLE + coff, colorIndex(RGB_DONE));
		} else {
			book.changeValue(row, CTABLE + coff, NOTYET);
			book.setFontColor(row, CTABLE + coff, colorIndex(RGB_NOTYET));
		}
	}

	private void exportLessons(int row, int coff, int coffNum, List<SkillLessonTakenDto> lessons) {
		if (lessons != null) {
			book.changeValue(row, CTABLE + coff, lessons.stream()
					.map(less -> less.getName() + "(" + less.getParty() + ")").collect(Collectors.joining(EOL)));
			book.changeValue(row, CTABLE + coffNum,
					String.format(FORMAT_NUMLESSONS, lessons.size()));
		} else {
			book.changeValue(row, CTABLE + coffNum, String.format(FORMAT_NUMLESSONS, 0));
		}
	}

	private void prepareTopSheet(int level) {
		book.selectSheet(levelToSheetName(level));
		book.setSheetName(SHNAME_TOP);
		deleteUnusedSheets(level);
	}

	private void preparePalette() {
		Arrays.stream(RGB_CATS).forEach(rgbi -> book.customizeColor(rgbi, colorIndex(rgbi)));
		book.customizeColor(RGB_DONE, colorIndex(RGB_DONE));
		book.customizeColor(RGB_NOTYET, colorIndex(RGB_NOTYET));
	}

	private short colorIndex(int[] rgbi) {
		return (short) rgbi[3];
	}

	private String levelToSheetName(int level) {
		return String.valueOf(level);
	}

	private void deleteUnusedSheets(int level) {
		Arrays.stream(ALL_LEVELS).filter(lv -> lv != level).forEach(lv -> book.deleteSheet(levelToSheetName(lv)));
	}
}
