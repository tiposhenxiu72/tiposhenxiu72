package jp.co.sraw.repository;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import jp.co.sraw.dto.SkillBuildDto;
import jp.co.sraw.entity.NrLessonTbl;

@Scope("prototype")
@Repository
public interface NrLessonTblRepository extends JpaRepository<NrLessonTbl, String>, JpaSpecificationExecutor<NrLessonTbl> {

	/**
	 * 指定した関連レベルの科目名と部局名を取得する
	 * @param rubricKey ルーブリックキー
	 * @param subjectCode 養成能力コード
	 * @param relationLevel 関連レベル
	 * @return 科目名と部局名のリスト
	 */
	@Query(name = "NrLessonTbl.searchRecommendLesson")
	public List<SkillBuildDto> searchRecommendLesson (String rubricKey, String subjectCode, String relationLevel);



	public List<NrLessonTbl> findAllByOrderByLessonKeyDesc();

	public List<NrLessonTbl> findByLessonKeyInOrderByLessonKeyAsc(List<String> lessonKeys);

}
