/*
* ファイル名：SkillBuildUploadForm.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/01/29   tsutsumi    新規作成
*/
package jp.co.sraw.controller.skill;

import java.sql.Timestamp;

import org.springframework.web.multipart.MultipartFile;

import jp.co.sraw.common.CommonForm;

/**
 * 能力養成科目管理 ファイルアップロード用フォーム
 *
 */
public class SkillBuildUploadForm extends CommonForm {
	/** ルーブリックキー */
	private String rKey;
	/** 更新日 */
	private Timestamp updDate;
	/** アップロードしたファイル */
	private MultipartFile doc;

	public String getrKey() {
		return rKey;
	}
	public void setrKey(String rKey) {
		this.rKey = rKey;
	}
	public Timestamp getUpdDate() {
		return updDate;
	}
	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}
	public MultipartFile getDoc() {
		return doc;
	}
	public void setDoc(MultipartFile doc) {
		this.doc = doc;
	}

}
