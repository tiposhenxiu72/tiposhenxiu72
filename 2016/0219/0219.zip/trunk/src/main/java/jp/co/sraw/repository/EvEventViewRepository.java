package jp.co.sraw.repository;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import jp.co.sraw.entity.EvEventView;

@Scope("prototype")
@Repository
public interface EvEventViewRepository extends ViewRepository<EvEventView> {

}
