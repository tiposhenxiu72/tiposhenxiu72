/*
* ファイル名：GySocietyForm.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.portfolio.form;

import org.maru.m4hv.extensions.constraints.CharLength;

/**
 * <B>GyUploadFormクラス</B>
 * <P>
 * Formのメソッドを提供する
 */
public class GyUploadForm extends GyHasTitleForm {

	private String uploadKey;

	@CharLength(max = 256)
	private String fileName;

	private boolean uploadFileNotNull;

	public String getUploadKey() {
		return this.uploadKey;
	}

	public void setUploadKey(String uploadKey) {
		this.uploadKey = uploadKey;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public boolean getUploadFileNotNull() {
		return true;
	}

}
