/*
* ファイル名：UserServiceImpl.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.portfolio.service;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.UserInfo;
import jp.co.sraw.controller.portfolio.form.GyHasTitleForm;
import jp.co.sraw.entity.GyHasTtitleTbl;
import jp.co.sraw.entity.UsUserTbl;
import jp.co.sraw.repository.GyRepository;
import jp.co.sraw.util.DateUtil;
import jp.co.sraw.util.StringUtil;

/**
 * <B>MultiHandleServiceImplクラス</B>
 * <P>
 * ユーザーサービスのメソッドを提供する
 */
@Scope("prototype")
@Service
@Transactional(readOnly = true)
public abstract class MultiHandleServiceImpl<T extends GyHasTtitleTbl, F extends GyHasTitleForm, R extends GyRepository>
		extends PortfolioServiceImpl<T, F, R> {

	/**
	 *
	 * @param userInfo
	 * @param form
	 * @return
	 */
	public List<F> findAllSameFormList(UserInfo userInfo, F form) {
		return getDtoList(findAllSameTblList(userInfo, form));
	}

	public List<T> findAllSameTblList(UserInfo userInfo, F form) {
		logger.infoCode("I0001");

		// 必須
		Specification<T> whereUserKey = new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.get("usUserTbl").get("userKey"), userInfo.getTargetUserKey());
			}
		};

		// 言語
		Specification<T> wherePublic = StringUtil.isNull(form.getPrePublicFlag()) ? null : new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.get("publicFlag"), form.getPrePublicFlag());
			}
		};

		List<T> list = (List<T>) repository
				.findAll((Specification<T>) Specifications.where(whereUserKey).and(wherePublic));

		logger.infoCode("I0002");
		return list;
	}

	@Transactional
	public boolean updateSame(UserInfo userInfo, F form) {
		logger.infoCode("I0001");
		try {
			List<T> entities = new ArrayList<>();

			if (form.getPageMode().equals(CommonConst.PAGE_MODE_EDIT)) {
				entities = findAllSameTblList(userInfo, form);
				if (entities.size() > 0) {
					repository.delete(entities);
				} else {
					throw new Exception();
				}
			}

			entities = new ArrayList<>();

			String[] titles = form.getTitle().split("\r\n");

			for (int i = 0; i < titles.length; i++) {
				String title = titles[i];
				T entity = (T) form.getNewTbl();
				entity = (T) getPortfolioTbl(form, entity);
				entity.setTitle(title);
				UsUserTbl usUserTbl = new UsUserTbl();
				usUserTbl.setUserKey(userInfo.getTargetUserKey());
				entity.setUsUserTbl(usUserTbl);
				entity.setUpdUserKey(userInfo.getLoginUserKey());
				entity.setUpdDate(DateUtil.getNowTimestamp());

				entities.add(entity);
			}

			entities = repository.save(entities);

			logger.infoCode("I0002");
			return true;

		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
		}
		return false;
	}
}