/**
 *
 */
package jp.co.sraw.dto;

import java.io.Serializable;
import java.util.List;

/**
 * 養成能力設定画面からの戻り値のオブジェクト
 * @author SRAW tsutsumi
 *
 */
public class RelationSkillDto implements Serializable {

	/** 科目コード */
	private String lesson;
	/** 紐付きレベル */
	private String level;
	/** 養成能力コード */
	private List<String> skill;

	private List<RelationSkillDto> relationList;

	public String getLesson() {
		return lesson;
	}

	public void setLesson(String lesson) {
		this.lesson = lesson;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public List<String> getSkill() {
		return skill;
	}

	public void setSkill(List<String> skill) {
		this.skill = skill;
	}

	public List<RelationSkillDto> getRelationList() {
		return relationList;
	}

	public void setRelationList(List<RelationSkillDto> relationList) {
		this.relationList = relationList;
	}
}
