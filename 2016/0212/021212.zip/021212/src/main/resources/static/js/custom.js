$(function(){
  $('.clickToolTip').click(function(){
    // リンクの #note** を取得
    var targetNote = $(this).attr('target');
 
    // [?]の座標を取得
    var position = $(this).position();
    var newPositionTop = position.top -11;        /* + 数値で下方向へ移動 */
    var newPositionLeft = position.left + 25;      /* + 数値で右方向へ移動 */
 
    // ツールチップの位置を調整
    $('p'+targetNote).css({'top': newPositionTop + 'px', 'left': newPositionLeft + 'px'});
 
    // ツールチップの class="invisible" を削除
    $('p'+targetNote).removeClass('invisible');
  });
 
  // 表示されたツールチップを隠す処理（マウスクリックで全て隠す）
  $('html').mousedown(function(event){
      // イベント発生源である要素を取得（クリックされた要素を取得）
      var clickedElement = event.target;

      // ツールチップを隠す。
      // ただし、取得要素が"tips"クラスを持っている(ツールチップ上の余白でクリックしたときとか)場合は除く。
      // さらに、tipsNoHideクラスを持っている場合も除く(非表示化のトリガにしたくない要素に、このクラスを付ける)。
      if(!$(clickedElement).hasClass('tips') && !$(clickedElement).hasClass('tipsNoHide')){
          $('p.tips').addClass('invisible');
      }
  });
});