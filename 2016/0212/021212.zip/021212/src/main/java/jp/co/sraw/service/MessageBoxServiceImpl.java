/*
* ファイル名：UserServiceImpl.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonService;
import jp.co.sraw.common.UserInfo;
import jp.co.sraw.controller.messagebox.MessageBoxForm;
import jp.co.sraw.dto.MessageBoxDto;
import jp.co.sraw.entity.UsMessageBoxTbl;
import jp.co.sraw.entity.UsUserTbl;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.repository.UsMessageBoxTblRepository;
import jp.co.sraw.util.DateUtil;
import jp.co.sraw.util.StringUtil;

/**
 * <B>UserServiceクラス</B>
 * <P>
 * ユーザーサービスのメソッドを提供する
 */
@Scope("prototype")
@Service
@Transactional(readOnly = true)
public class MessageBoxServiceImpl extends CommonService {

	@Autowired
	private UsMessageBoxTblRepository usMessageBoxTblRepository;

	@Autowired
	private UserServiceImpl userServiceImpl;

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(MessageBoxServiceImpl.class);

	@PostConstruct
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	/**
	 * orderBy
	 *
	 * @return
	 */
	private Sort orderBy() {
		// 日付（降順）
		return new Sort(Sort.Direction.DESC, "sendDate");
	}

	/**
	 * メッセージ取得
	 *
	 * @param userKey
	 * @return
	 */
	public List<MessageBoxDto> findAll(UserInfo userInfo, boolean sendFlag, Locale locale) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		// 条件
		Specification<UsMessageBoxTbl> whereUserKey =  new Specification<UsMessageBoxTbl>() {
					@Override
					public Predicate toPredicate(Root<UsMessageBoxTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						if (sendFlag) {
							return cb.equal(root.get("makeUserKey"), userInfo.getTargetUserKey());
						} else {
							return cb.equal(root.get("usUserTbl").get("userKey"), userInfo.getTargetUserKey());
						}
					}
				};

		List<UsMessageBoxTbl> mList = usMessageBoxTblRepository.findAll(Specifications.where(whereUserKey), orderBy());

		List<MessageBoxDto> rltList = new ArrayList<MessageBoxDto>();
		Map<String, UsUserTbl> userMap = new HashMap<String, UsUserTbl>();
		for (UsMessageBoxTbl m : mList) {
			MessageBoxDto dto = new MessageBoxDto();

			// 送信者取得(受信のとき相手。送信のとき自分)
			UsUserTbl makeUser = new UsUserTbl();
			if (StringUtil.isNotNull(m.getMakeUserKey())) {
				if (userMap.containsKey(m.getMakeUserKey())) {
					makeUser = userMap.get(m.getMakeUserKey());
				} else {
					makeUser = userServiceImpl.findOne(m.getMakeUserKey());
					userMap.put(m.getMakeUserKey(), makeUser);
				}
			}
			setDto(m, dto, makeUser, locale);

			rltList.add(dto);
		}

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return rltList;
	}


	/**
	 * メッセージ作成(常に新規)
	 *
	 * @param userInfo
	 * @param form
	 * @param newMessageKey
	 * @return
	 */
	@Transactional
	public boolean update(UserInfo userInfo, MessageBoxForm form, String newMessageKey) {
		logger.infoCode("I0001");
		try {
			UsMessageBoxTbl entity = new UsMessageBoxTbl();

			UsUserTbl usUserTbl = new UsUserTbl();
			usUserTbl.setUserKey(form.getMakeUserKey());
			entity.setUsUserTbl(usUserTbl);
			entity.setMakeUserKey(userInfo.getTargetUserKey());
			entity.setMessageContents(form.getMessageContents());
			entity.setMessageTitle(form.getMessageTitle());
			entity.setRefMessageKey(form.getRefMessageKey());
			entity.setSendDate(DateUtil.getNowTimestamp());
			//
			entity.setUpdDate(DateUtil.getNowTimestamp());
			entity.setUpdUserKey(userInfo.getLoginUserKey());
			//
			entity = usMessageBoxTblRepository.saveAndFlush(entity);

			if (entity != null) {
				newMessageKey = entity.getMessageKey();
				logger.infoCode("I0002");
				return true;
			}

		} catch (Exception e) {
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
		}
		return false;
	}

	@Transactional
	public boolean delete(UserInfo userInfo, MessageBoxForm form) {
		logger.infoCode("I0001");
		try {

			int c = usMessageBoxTblRepository.delete(form.getMessageKey(), form.getUpdDate());

			if (c > 0) {
				usMessageBoxTblRepository.flush();
				logger.infoCode("I0002");
				return true;
			}
		} catch (Exception e) {
			logger.errorCode("E1009", e); // E1009=削除に失敗しました。{0}
		}
		return false;
	}

	/**
	 * eventKey指定取得
	 *
	 * @param eventKey
	 * @return
	 */
	public UsMessageBoxTbl getOne(final String messageKey) {
		return usMessageBoxTblRepository.getOne(messageKey);
	}


	public MessageBoxDto findOne(UserInfo userInfo, MessageBoxForm form, boolean sendFlag, Locale locale) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		// 条件
		Specification<UsMessageBoxTbl> whereUserKey =  new Specification<UsMessageBoxTbl>() {
					@Override
					public Predicate toPredicate(Root<UsMessageBoxTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						if (sendFlag) {
							return cb.equal(root.get("makeUserKey"), userInfo.getTargetUserKey());
						} else {
							return cb.equal(root.get("usUserTbl").get("userKey"), userInfo.getTargetUserKey());
						}
					}
				};
		Specification<UsMessageBoxTbl> whereMessageKey = new Specification<UsMessageBoxTbl>() {
					@Override
					public Predicate toPredicate(Root<UsMessageBoxTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("messageKey"), form.getMessageKey ());
					}
				};
		Specification<UsMessageBoxTbl> whereUpdDate = DateUtil.isNull(form.getUpdDate()) ? null
				: new Specification<UsMessageBoxTbl>() {
					@Override
					public Predicate toPredicate(Root<UsMessageBoxTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("updDate"), form.getUpdDate());
					}
				};

		UsMessageBoxTbl m = usMessageBoxTblRepository.findOne(Specifications.where(whereUserKey).and(whereMessageKey).and(whereUpdDate));
		MessageBoxDto dto = new MessageBoxDto();
		setDto(m, dto, userServiceImpl.findOne(m.getMakeUserKey()), locale);

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return dto;
	}

	/**
	 * EntityからDtoにセット
	 *
	 * @param from
	 * @param toDto
	 */
	private void setDto(UsMessageBoxTbl from, MessageBoxDto toDto, UsUserTbl makeUser, Locale locale) {
		String userFullName ="";
		String makeUserFullName = "";
		toDto.setMessageKey(from.getMessageKey());
		toDto.setUserKey(from.getUsUserTbl().getUserKey()); // 宛先者キー(受信のとき自分。送信のとき相手)
		toDto.setMakeUserKey(from.getMakeUserKey()); // 送信者キー(受信のとき相手。送信のとき自分)
		toDto.setMessageContents(from.getMessageContents());
		toDto.setMessageTitle(from.getMessageTitle());
		toDto.setRefMessageKey(from.getRefMessageKey());
		toDto.setSendDate(from.getSendDate());
		toDto.setUpdDate(from.getUpdDate());
		toDto.setUpdUserKey(from.getUpdUserKey());

		// 表示する氏名
		if (CommonConst.DEFAULT_LOCALE.getLanguage().equals(locale.getLanguage())) {
			userFullName = StringUtil.getUserName(from.getUsUserTbl().getUserKbn(), from.getUsUserTbl().getUserFamilyName(), from.getUsUserTbl().getUserMiddleName(), from.getUsUserTbl().getUserName());
			makeUserFullName = StringUtil.getUserName(makeUser.getUserKbn(), makeUser.getUserFamilyName(), makeUser.getUserMiddleName(), makeUser.getUserName());
		} else {
			userFullName = StringUtil.getUserNameEn(from.getUsUserTbl().getUserKbn(), from.getUsUserTbl().getUserFamilyNameEn(), from.getUsUserTbl().getUserMiddleNameEn(), from.getUsUserTbl().getUserNameEn());
			makeUserFullName = StringUtil.getUserNameEn(makeUser.getUserKbn(), makeUser.getUserFamilyNameEn(), makeUser.getUserMiddleNameEn(), makeUser.getUserNameEn());
		}
		toDto.setUserFullName(userFullName); // 宛先者名(受信のとき自分。送信のとき相手)
		toDto.setMakeUserFullName(makeUserFullName); // 送信者名(受信のとき相手。送信のとき自分)
	}

}
