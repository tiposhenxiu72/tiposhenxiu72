package jp.co.sraw.controller.skill;

import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

import org.apache.poi.hssf.usermodel.HSSFPatriarch;
import org.apache.poi.hssf.usermodel.HSSFShape;
import org.apache.poi.hssf.usermodel.HSSFShapeGroup;
import org.apache.poi.hssf.util.HSSFColor;

import jp.co.sraw.util.PoiBook;

/**
 * 自己評価レポートをExcelへエクスポートする。
 *
 *
 */
public class ReportExcelExporter {
	private static final String SHNAME_TOP = "自己評価レポート（表）";
	private static final String SHNAME_BOTTOM = "自己評価レポート（裏）";
	private static final int[] ALL_LEVELS = { 0, 1, 2 };
	private static final int[][] RGB_CATS = { { 157, 220, 249, HSSFColor.AQUA.index },
			{ 186, 201, 231, HSSFColor.PINK.index }, { 165, 212, 218, HSSFColor.DARK_TEAL.index },
			{ 211, 191, 221, HSSFColor.LAVENDER.index } };
	private static final int[] RGB_DONE = { 255, 0, 0, HSSFColor.RED.index };
	private static final int[] RGB_NOTYET = { 0, 176, 80, HSSFColor.DARK_GREEN.index };

	// コンフィグ情報。
	private static final int RITEM_TOP = 19;
	private static final int NUM_ITEMS = 100;
	private static final short HEIGHT_ITEM = 27;
	private static final int NUM_ROWS_REVIEW = 3;
	private static final int ROFF_REVIEW_BODY = 2;
	private static final short HEIGHT_REVIEW = 70;

	private PoiBook book;

	public ReportExcelExporter(PoiBook book) {
		this.book = book;
	}

	/**
	 * エクスポートする。
	 */
	public void export(int level) {
		prepareTopSheet(level);
		preparePalette();

		IntStream.range(RITEM_TOP, RITEM_TOP + NUM_ITEMS).forEach(r -> {
			book.fill(r, 0, colorIndex(RGB_CATS[r % 4]));
			book.setRowHeight(r, HEIGHT_ITEM);
		});
		book.changeValue(RITEM_TOP, 1, "hoge");
		book.setFontColor(RITEM_TOP, 1, colorIndex(RGB_DONE));
		book.mergeCell(RITEM_TOP, 1, 3, 0);

		deleteUnusedRows(RITEM_TOP + 8);
		book.setRowHeight(RITEM_TOP + 8 + ROFF_REVIEW_BODY, HEIGHT_REVIEW);

		book.selectSheet(SHNAME_BOTTOM);
		List<HSSFShapeGroup> sgs = book.topLevelShapeGroup();
		sgs.forEach(sg -> {
			if (sg.getChildren().size() == 4) {
				sg.forEach(pie -> {
					int angle = pie.getRotationDegree();
					if (angle < 0) {
						angle = 360 + angle;
					}
					int d = angle * 256 / 360;
					pie.setFillColor(d, 0, d);
				});
			} else {
				sg.forEach(pie -> {
					int angle = pie.getRotationDegree();
					if (angle < 0) {
						angle = 360 + angle;
					}
					int d = angle * 256 / 360;
					pie.setFillColor(0, d, d);
				});
			}
		});
	}

	private void deleteUnusedRows(int rfrom) {
		book.deleteRows(rfrom, RITEM_TOP + NUM_ITEMS, NUM_ROWS_REVIEW);
	}

	private void prepareTopSheet(int level) {
		book.selectSheet(levelToSheetName(level));
		book.setSheetName(SHNAME_TOP);
		deleteUnusedSheets(level);
	}

	private void preparePalette() {
		Arrays.stream(RGB_CATS).forEach(rgbi -> book.customizeColor(rgbi, colorIndex(rgbi)));
		book.customizeColor(RGB_DONE, colorIndex(RGB_DONE));
		book.customizeColor(RGB_NOTYET, colorIndex(RGB_NOTYET));
	}

	private short colorIndex(int[] rgbi) {
		return (short) rgbi[3];
	}

	private String levelToSheetName(int level) {
		return String.valueOf(level);
	}

	private void deleteUnusedSheets(int level) {
		Arrays.stream(ALL_LEVELS).filter(lv -> lv != level).forEach(lv -> book.deleteSheet(levelToSheetName(lv)));
	}
}
