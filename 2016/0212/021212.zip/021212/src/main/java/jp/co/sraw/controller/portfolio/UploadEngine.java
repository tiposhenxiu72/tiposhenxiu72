package jp.co.sraw.controller.portfolio;

import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.controller.portfolio.excel.PortfolioExcelHelper;
import jp.co.sraw.controller.portfolio.form.GyUploadForm;
import jp.co.sraw.controller.portfolio.service.MultiHandleServiceImpl;
import jp.co.sraw.dto.MsCodeDto;
import jp.co.sraw.file.FileDto;
import jp.co.sraw.file.FileService;
import jp.co.sraw.util.DbUtil;
import jp.co.sraw.util.StringUtil;

@SuppressWarnings("rawtypes")
@Component("uengine")
public class UploadEngine<C extends PortfolioController, F extends GyUploadForm, S extends MultiHandleServiceImpl, H extends PortfolioExcelHelper>
		extends PortfolioEngine<C, F, S, H> {

	@Autowired
	private FileService fileService;

	@SuppressWarnings("unchecked")
	public String editUpload(C controller, S serviceImpl, F form, Model model, Locale locale) {
		String nextUrl = this.edit(controller, serviceImpl, form, model, locale);
		Map map = (Map) model.asMap();
		form = (F) map.get(CommonConst.FORM_NAME);
		String uploadKey = form.getUploadKey();
		FileDto fileDto = fileService.getFileUploalDto(uploadKey);
		if (fileDto != null) {
			form.setFileName(fileDto.getUploadName());
		}
		return nextUrl;
	}

	/**
	 *
	 * @param controller
	 * @param serviceImpl
	 * @param form
	 * @param request
	 * @param model
	 * @param result
	 * @param attributes
	 * @param locale
	 * @return
	 */
	public String updateUpload(C controller, S serviceImpl, F form, MultipartHttpServletRequest request, Model model,
			BindingResult result, RedirectAttributes attributes, Locale locale) {

		logger.infoCode("I0001");

		String actionName = CommonConst.FILE_ACTION_NONE;

		String preUploadKey = null;
		String uploadKey = null;

		List<MsCodeDto> publicFlagList = DbUtil.getJosuList(CODE_PUBLICCODE, locale);
		model.addAttribute("publicFlagList", publicFlagList);

		this.setListToModel(model, "0024", locale);

		this.setListToModel(model, CODE_COMPETITIONMOVE, locale);

		this.setListToModel(model, CODE_LANGUEGE, locale);

		try {

			Iterator<String> itrator = request.getFileNames();
			MultipartFile mlf = request.getFile(itrator.next());

			if (form.getPageMode().equals(CommonConst.PAGE_MODE_EDIT)) {
				@SuppressWarnings("unchecked")
				GyUploadForm uploadForm = (GyUploadForm) serviceImpl.findOne(userInfo, form);
				//
				if (uploadForm == null) {
					// データは見つけることができません
					throw new Exception();
				}

				preUploadKey = uploadForm.getUploadKey();
				FileDto fileDto = fileService.getFile(preUploadKey);

				// 先回のアップロードファイルが必要です
				if (uploadForm.getUploadFileNotNull()) {
					if (fileDto == null) {
						// 必要なファイルが存在しません。
						throw new Exception();
					}
					// 本回のアップロードファイルが必要がない
					if (!form.getUploadFileNotNull()) {
						actionName = CommonConst.FILE_ACTION_DEL;
					}
				}

				// 本回のアップロードファイルが必要です
				if (form.getUploadFileNotNull()) {

					if (mlf.getSize() > 0 && StringUtil.isNotNull(mlf.getOriginalFilename())) {
						// アップロードファイルがあるの場合
						actionName = CommonConst.FILE_ACTION_CHANGE;
					} else {
						// アップロードファイルがないの場合
						if (form.getFileName().equals(fileDto.getUploadName())) {
							actionName = CommonConst.FILE_ACTION_NONE;
						} else {
							throw new Exception();
						}
					}
				}

			} else {
				// 新規の場合
				if (form.getUploadFileNotNull()) {
					// アップロードファイルが必要の場合
					if (mlf.getSize() > 0 && StringUtil.isNotNull(mlf.getOriginalFilename())) {
						actionName = CommonConst.FILE_ACTION_ADD;
					} else {
						// アップロードファイルがない
						throw new Exception();
					}
				}
			}

			if (actionName.equals(CommonConst.FILE_ACTION_ADD) || actionName.equals(CommonConst.FILE_ACTION_CHANGE)) {
				FileDto fileDto = new FileDto();
				fileDto.SetFileKbn(controller.UPLOAD_FILEKBN);
				fileDto.setUploadName(mlf.getOriginalFilename());
				fileDto.setFile(mlf);
				uploadKey = fileService.putUploadFile(fileDto, controller.userInfo().getTargetUserKey(),
						controller.userInfo().getLoginUserKey());
				if (uploadKey == null) {
					throw new Exception();
				}
				form.setUploadKey(uploadKey);
			} else {
				form.setUploadKey(preUploadKey);
			}

			String nextUrl = this.update(controller, serviceImpl, form, result, model, attributes, locale);

			if (nextUrl.equals(controller.EDIT_PAGE)) {
				// 編集の場合はエラーがある
				if (actionName.equals(CommonConst.FILE_ACTION_ADD)
						|| actionName.equals(CommonConst.FILE_ACTION_CHANGE)) {
					fileService.deleteUploadFile(uploadKey);
				}
			} else {
				// 成功するで
				if (StringUtil.isNull(preUploadKey)) {
					if (actionName.equals(CommonConst.FILE_ACTION_CHANGE)
							|| actionName.equals(CommonConst.FILE_ACTION_DEL))
						fileService.deleteUploadFile(preUploadKey);
				}
			}

			logger.infoCode("I0002"); // I0002=メソッド終了:{0}
			return nextUrl;

		} catch (Exception ex) {
			ex.printStackTrace();
		}

		attributes.addFlashAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.remove"); // error.data.message.db.remove=削除が失敗しました。

		model.addAttribute(CommonConst.FORM_NAME, form);
		logger.errorCode("E0014", form.getPageActionUrl()); //

		return controller.EDIT_PAGE;

	}

	/**
	 *
	 * @param controller
	 * @param serviceImpl
	 * @param form
	 * @param model
	 * @param attributes
	 * @param locale
	 * @return
	 */
	public String deleteUpload(C controller, S serviceImpl, F form, Model model, RedirectAttributes attributes,
			Locale locale) {

		@SuppressWarnings("unchecked")
		GyUploadForm f = (GyUploadForm) serviceImpl.findOne(userInfo, form);

		String uploadKey = f.getUploadKey();

		if (StringUtil.isNotNull(uploadKey)) {

			int deleteResult = fileService.deleteUploadFile(uploadKey);

			if (deleteResult > 0) {

				attributes.addFlashAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.remove"); // error.data.message.db.remove=削除が失敗しました。

				model.addAttribute(CommonConst.FORM_NAME, form);
				logger.errorCode("E0014", form.getPageActionUrl()); //

				return controller.REDIRECT_LIST;
			}
		}

		String nextUrl = this.delete(controller, serviceImpl, form, model, attributes, locale);

		return nextUrl;
	}

}