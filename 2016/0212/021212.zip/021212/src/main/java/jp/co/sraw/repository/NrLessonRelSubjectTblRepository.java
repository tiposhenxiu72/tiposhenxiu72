package jp.co.sraw.repository;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import jp.co.sraw.entity.NrLessonRelSubjectTbl;
import jp.co.sraw.entity.NrLessonRelSubjectTblPK;

@Scope("prototype")
@Repository
public interface NrLessonRelSubjectTblRepository extends JpaRepository<NrLessonRelSubjectTbl, NrLessonRelSubjectTblPK>, JpaSpecificationExecutor<NrLessonRelSubjectTbl> {
	public List<NrLessonRelSubjectTbl> findByIdRubricKeyAndRelationLevelOrderByIdSubjectCodeAscNrLessonTblLessonName(String rubricKey, String relationLevel);

	/**
	 * 養成能力コードに紐づく推奨科目を取得
	 * @param rubricKey ルーブリックキー
	 * @param subjectCode 養成能力コード
	 * @param relationLevel 関連レベル
	 * @return 紐づく科目情報のリスト
	 */
	public List<NrLessonRelSubjectTbl> findByIdRubricKeyAndIdSubjectCodeAndRelationLevelOrderByIdLessonKey(String rubricKey, String subjectCode, String relationLevel);

	/**
	 * ルーブリックキーに紐づく科目をチェック
	 * @param rubricKey ルーブリックキー
	 * @return
	 */
	public List<NrLessonRelSubjectTbl> findByIdRubricKeyOrderByIdLessonKey(String rubricKey);

	/**
	 * 科目に紐づく養成能力の情報を取得
	 * @param rubricKey ルーブリックキー
	 * @param lessonKey 科目キー
	 * @return
	 */
	public List<NrLessonRelSubjectTbl> findByIdRubricKeyAndIdLessonKey(String rubricKey, String lessonKey);

}
