/*
* ファイル名：RubricServiceImpl.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/01/05   etoh        新規作成
*/
package jp.co.sraw.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.oxm.Marshaller;
import org.springframework.oxm.Unmarshaller;
import org.springframework.oxm.XmlMappingException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonService;
import jp.co.sraw.common.UserInfo;
import jp.co.sraw.controller.skill.RubricEditForm;
import jp.co.sraw.dto.RubricChartDto;
import jp.co.sraw.entity.NrRubricTbl;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.oxm.rubric.Rubric;
import jp.co.sraw.oxm.rubric.RubricCategory;
import jp.co.sraw.repository.NrRubricTblRepository;
import jp.co.sraw.util.DateUtil;
import jp.co.sraw.util.DbUtil;

/**
 * <B>ルーブリック関連のビジネスロジック</B>
 * <P>
 */
@Scope("prototype")
@Service
@Transactional(readOnly = true)
public class RubricServiceImpl extends CommonService {

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(RubricServiceImpl.class);

	private static final String[] CHART_COLORS = { // チャートの色。
			"#3abbf2",
			"#6b8bcb",
			"#5db1bb",
			"#a37ab7" };

	private static final String JKBN_LENSNAME = "0001";

	@Autowired
	private NrRubricTblRepository rubricRepository;

	@Autowired
	private Marshaller xmlMarshaller;
	@Autowired
	private Unmarshaller xmlUnmarshaller;

	@Override
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	public List<NrRubricTbl> findAll() {
		return rubricRepository.findAllByOrderByRubricName();
	}

	private NrRubricTbl findOne(final String rkey, final Timestamp dt) {
		return rubricRepository.findByRubricKeyAndUpdDate(rkey, dt);
	}

	public String[] lensNames(int[] lensIds, Locale locale) {
		return Arrays.stream(lensIds)
				.mapToObj(lensId -> DbUtil.getJosuName(JKBN_LENSNAME, String.valueOf(lensId), locale))
				.toArray(String[]::new);
	}

	/**
	 * フル診断も含めた、全レンズのIDの配列。
	 * 
	 * @return
	 */
	public int[] allLensIds() {
		return new int[] { CommonConst.LENSID_BASIC, CommonConst.LENSID_CAREER, CommonConst.LENSID_FULL };
	}

	/**
	 * 大、中、小のレベル名。
	 * 
	 * @param locale
	 * @return
	 */
	public String[] allLevelNames(Locale locale) {
		String[] msgIds = { "skill.field.category", "skill.field.subcat", "skill.field.item" };
		return Arrays.stream(msgIds).map(msgId -> messageSource.getMessage(msgId, null, locale)).toArray(String[]::new);
	}

	/**
	 * View用。
	 *
	 * @param rkey
	 * @return
	 */
	public Rubric findOne(String rkey) {
		if (rkey == null) {
			return null;
		}
		NrRubricTbl entity = rubricRepository.findOne(rkey);
		if (entity == null) {
			return null;
		}
		return unmarshal(entity.getRubricContents());
	}

	/**
	 * 円グラフ用のDTOを生成する。
	 * 
	 * @param rub
	 * @return
	 */
	public RubricChartDto getCharDto(Rubric rub) {
		RubricChartDto dto = new RubricChartDto();
		dto.setChildren(
				IntStream.range(0, rub.getCategoryList().size()).mapToObj(i -> {
					RubricCategory cat = rub.getCategoryList().get(i);
					RubricChartDto cd = new RubricChartDto();
					cd.setCode(cat.getAbilityCode());
					cd.setCaption(cat.getName());
					cd.setColor(CHART_COLORS[i % rub.getCategoryList().size()]);
					List<RubricChartDto> scds = cat.getChildList().stream().map(subc -> {
						RubricChartDto scd = new RubricChartDto();
						scd.setCode(subc.getAbilityCode());
						scd.setCaption(subc.getName());
						return scd;
					}).collect(Collectors.toList());
					if (i >= rub.getCategoryList().size() / 2) { // 後半は逆順にする。
						Collections.reverse(scds);
					}
					cd.setChildren(scds);
					return cd;
				}).collect(Collectors.toList()));

		return dto;
	}

	/**
	 * update/insert。
	 * 
	 * @param form
	 * @param userInfo
	 * @return
	 */
	@Transactional
	public NrRubricTbl update(RubricEditForm form, UserInfo userInfo) {
		logger.infoCode("I0001", form.getPageMode());

		NrRubricTbl entity = new NrRubricTbl();
		// updateなら、既存データを取ってくる。
		if (form.getPageMode().equals(CommonConst.PAGE_MODE_EDIT)) {
			entity = findOne(form.getKey(), form.getUpdDate());
			if (entity == null) {
				throw new RuntimeException(form.getKey() + ": not such rubric, or edited by someone else.");
			}
		}
		entity.setRubricName(form.getName());
		entity.setRubricMemo(form.getSummary());
		Rubric rub = form.getRubric();
		rub.setName(form.getName());
		rub.setSummary(form.getSummary());
		entity.setRubricContents(marshal(rub));
		entity.setUpdUserKey(userInfo.getLoginUserKey());
		entity.setUpdDate(DateUtil.getNowTimestamp());
		entity = rubricRepository.saveAndFlush(entity);
		if (entity == null) {
			throw new RuntimeException("failed to saveAndFlush().");
		}

		logger.infoCode("I0002");
		return entity;
	}

	@Transactional
	public void delete(String rkey) {
		rubricRepository.delete(rkey);
	}

	// XML文字列からObjectへ。
	private Rubric unmarshal(String content) {
		ByteArrayInputStream bais = null;
		try {
			bais = new ByteArrayInputStream(content.getBytes(StandardCharsets.UTF_8.name()));
			StreamSource src = new StreamSource(bais);
			Rubric rubric = (Rubric) xmlUnmarshaller.unmarshal(src);
			if (rubric.getName() == null || rubric.getSummary() == null || rubric.getCategoryList() == null) {
				return null;
			}
			if (!rubric.getCategoryList().stream().allMatch(RubricCategory::validCategory)) {
				return null;
			}
			return rubric;
		} catch (UnsupportedEncodingException e) {
			logger.errorCode("E013", e);
		} catch (XmlMappingException e) {
			logger.error("failed to map from XML to Object.");
			logger.errorCode("E013", e);
		} catch (IOException e) {
			logger.errorCode("E013", e);
		}
		return null;
	}

	// ObjectからXML文字列へ。
	private String marshal(Rubric rub) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		StreamResult res = new StreamResult(baos);
		try {
			xmlMarshaller.marshal(rub, res);
			return baos.toString(StandardCharsets.UTF_8.name());
		} catch (XmlMappingException e) {
		} catch (UnsupportedEncodingException e) {
		} catch (IOException e) {
		}

		return null;
	}

	/**
	 * ルーブリックをDBから読んで、Formへ詰める。Edit専用。
	 *
	 * @param editForm
	 * @param rkey
	 */
	public void populateFormForEdit(RubricEditForm editForm, String rkey) {
		if (!editForm.getPageMode().equals(CommonConst.PAGE_MODE_EDIT)) {
			return;
		}
		NrRubricTbl rubric = rubricRepository.findOne(rkey);
		if (rubric == null) { // 見つからん?
			return;
		}
		editForm.setKey(rkey);
		editForm.setUpdDate(rubric.getUpdDate());

		populateRubric(editForm, rubric.getRubricContents());
	}

	/**
	 * アップロードされたルーブリックをFormへ詰める。Create/Edit共用。unmarshalに失敗したら、editform.
	 * rubricはnullになる。
	 *
	 * @param editForm
	 * @param rkey
	 *            Can be null/empty.
	 * @param updDate
	 *            Can be null/empty.
	 * @param xmlString
	 */
	public void populateFormForEdit(RubricEditForm editForm, String rkey, Timestamp updDate, String xmlString) {
		editForm.setKey(rkey); // can be null/empty.
		editForm.setUpdDate(updDate); // can be null/empty.

		populateRubric(editForm, xmlString);
	}

	// XML文字列をパースして、ルーブリック内容をFormへ詰める。
	private void populateRubric(RubricEditForm editForm, String xmlString) {
		Rubric rub = unmarshal(xmlString);
		if (rub != null) {
			editForm.setName(rub.getName());
			editForm.setSummary(rub.getSummary());
		}
		editForm.setRubric(rub);
	}

	/**
	 * ルーブリックから、特定のレンズに合わない小項目を削除する。 この結果、中項目のchildListがemptyになる可能性がある。
	 *
	 * @param rub
	 * @param lensId
	 */
	public void filterByLens(Rubric rub, int lensId) {
		if (lensId == CommonConst.LENSID_FULL) {
			return;
		}
		rub.getCategoryList().forEach(cat -> {
			cat.getChildList().forEach(subc -> {
				subc.setChildList(
						subc.getChildList().stream().filter(item -> item.forLens(lensId)).collect(Collectors.toList()));
			});
		});

	}

	/**
	 * ルーブリックから、特定のレンズに合う小項目のabilityCode一覧を生成。
	 *
	 * @param rub
	 * @param lensId
	 * @return
	 */
	public List<String> codesThroughLens(Rubric rub, int lensId) {
		List<String> codes = new ArrayList<String>();
		rub.getCategoryList().forEach(cat -> {
			cat.getChildList().forEach(subc -> {
				subc.getChildList().forEach(item -> {
					if (item.forLens(lensId)) {
						codes.add(item.getAbilityCode());
					}
				});
			});
		});
		return codes;
	}
}
