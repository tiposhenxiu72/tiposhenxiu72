/*
* ファイル名：HomeForm.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.index;

import jp.co.sraw.common.CommonForm;

/**
* <B>HomeFormクラス</B>
* <P>
* Formのメソッドを提供する
*/
public class IndexForm extends CommonForm {

}
