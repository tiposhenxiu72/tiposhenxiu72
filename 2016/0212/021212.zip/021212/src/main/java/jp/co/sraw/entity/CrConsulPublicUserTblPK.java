package jp.co.sraw.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * The primary key class for the cr_consul_public_user_tbl database table.
 *
 */
@Embeddable
public class CrConsulPublicUserTblPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="consultation_key")
	private String consultationKey;

	@Column(name="user_key")
	private String userKey;

	public CrConsulPublicUserTblPK() {
	}
	public String getConsultationKey() {
		return this.consultationKey;
	}
	public void setConsultationKey(String consultationKey) {
		this.consultationKey = consultationKey;
	}
	public String getUserKey() {
		return this.userKey;
	}
	public void setUserKey(String userKey) {
		this.userKey = userKey;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof CrConsulPublicUserTblPK)) {
			return false;
		}
		CrConsulPublicUserTblPK castOther = (CrConsulPublicUserTblPK)other;
		return
			this.consultationKey.equals(castOther.consultationKey)
			&& this.userKey.equals(castOther.userKey);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.consultationKey.hashCode();
		hash = hash * prime + this.userKey.hashCode();

		return hash;
	}
}