/*
* ファイル名：MessageBoxForm.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.messagebox;

import java.sql.Timestamp;

import org.hibernate.validator.constraints.NotBlank;
import org.maru.m4hv.extensions.constraints.CharLength;

import jp.co.sraw.common.CommonForm;

/**
 * <B>MessageBoxFormクラス</B>
 * <P>
 * Formのメソッドを提供する
 */
public class MessageBoxForm extends CommonForm {

	private String messageKey;

	@NotBlank
	private String userKey; // 宛先者キー(受信のとき自分。送信のとき相手)

	private String userFullName; // 宛先者名(受信のとき自分。送信のとき相手)

	private Timestamp sendDate;

	@NotBlank
	@CharLength(max = 100)
	private String messageTitle;

	@NotBlank
	private String messageContents;

	private String refMessageKey;

	private String makeUserKey; // 送信者キー(受信のとき相手。送信のとき自分)

	private String makeUserFullName; // 送信者名(受信のとき相手。送信のとき自分)

	private Timestamp updDate;

	private String updUserKey;

	/**
	 * @return messageKey
	 */
	public String getMessageKey() {
		return messageKey;
	}

	/**
	 * @param messageKey セットする messageKey
	 */
	public void setMessageKey(String messageKey) {
		this.messageKey = messageKey;
	}

	/**
	 * @return userKey
	 */
	public String getUserKey() {
		return userKey;
	}

	/**
	 * @param userKey セットする userKey
	 */
	public void setUserKey(String userKey) {
		this.userKey = userKey;
	}

	/**
	 * @return userFullName
	 */
	public String getUserFullName() {
		return userFullName;
	}

	/**
	 * @param userFullName セットする userFullName
	 */
	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	/**
	 * @return sendDate
	 */
	public Timestamp getSendDate() {
		return sendDate;
	}

	/**
	 * @param sendDate セットする sendDate
	 */
	public void setSendDate(Timestamp sendDate) {
		this.sendDate = sendDate;
	}

	/**
	 * @return messageTitle
	 */
	public String getMessageTitle() {
		return messageTitle;
	}

	/**
	 * @param messageTitle セットする messageTitle
	 */
	public void setMessageTitle(String messageTitle) {
		this.messageTitle = messageTitle;
	}

	/**
	 * @return messageContents
	 */
	public String getMessageContents() {
		return messageContents;
	}

	/**
	 * @param messageContents セットする messageContents
	 */
	public void setMessageContents(String messageContents) {
		this.messageContents = messageContents;
	}

	/**
	 * @return refMessageKey
	 */
	public String getRefMessageKey() {
		return refMessageKey;
	}

	/**
	 * @param refMessageKey セットする refMessageKey
	 */
	public void setRefMessageKey(String refMessageKey) {
		this.refMessageKey = refMessageKey;
	}

	/**
	 * @return makeUserKey
	 */
	public String getMakeUserKey() {
		return makeUserKey;
	}

	/**
	 * @param makeUserKey セットする makeUserKey
	 */
	public void setMakeUserKey(String makeUserKey) {
		this.makeUserKey = makeUserKey;
	}

	/**
	 * @return makeUserFullName
	 */
	public String getMakeUserFullName() {
		return makeUserFullName;
	}

	/**
	 * @param makeUserFullName セットする makeUserFullName
	 */
	public void setMakeUserFullName(String makeUserFullName) {
		this.makeUserFullName = makeUserFullName;
	}

	/**
	 * @return updDate
	 */
	public Timestamp getUpdDate() {
		return updDate;
	}

	/**
	 * @param updDate セットする updDate
	 */
	public void setUpdDate(Timestamp updDate) {
		this.updDate = updDate;
	}

	/**
	 * @return updUserKey
	 */
	public String getUpdUserKey() {
		return updUserKey;
	}

	/**
	 * @param updUserKey セットする updUserKey
	 */
	public void setUpdUserKey(String updUserKey) {
		this.updUserKey = updUserKey;
	}

}
