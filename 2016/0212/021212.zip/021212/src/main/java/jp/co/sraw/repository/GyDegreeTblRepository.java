package jp.co.sraw.repository;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import jp.co.sraw.entity.GyDegreeTbl;

@Scope("prototype")
@Repository
public interface GyDegreeTblRepository extends GyRepository<GyDegreeTbl> {

}
