package jp.co.sraw.controller.skill;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.util.StringUtil;

/**
 * <B>能力診断の回答用フォーム</B>
 * <P>
 * 個々の項目の回答1つ分。
 */
public class AnswerForm {
	private String subjectCode; // 小項目の場合、ここがnullなら未回答(isAnswered())。

	private String actionPlan;
	private String evidence;
	private String evidenceFileName;
	private String evidenceFileId;

	private Boolean done;
	private Integer phase;

	private List<AnswerForm> childList;

	private MultipartFile doc;

	/**
	 * 小項目が回答済み(テーブルにエントリがある)ならtrue。達成済かどうかは関係ない。
	 */
	private boolean isAnswered() {
		return StringUtil.isNotNull(subjectCode);
	}

	/**
	 * 小項目ならtrue。
	 * 
	 * @return
	 */
	private boolean isItem() {
		return childList == null;
	}

	/**
	 * 子供の数。
	 * 
	 * @return
	 */
	public long getNumChildren() {
		return getNumChildren(false);
	}

	/**
	 * 子供の数。
	 * 
	 * @param withAnswer
	 *            回答済みのみカウントする?
	 * @return
	 */
	private long getNumChildren(boolean withAnswer) {
		if (isItem()) {
			return (!withAnswer || isAnswered()) ? 1 : 0;
		}
		return childList.stream().map(i -> i.getNumChildren(withAnswer)).reduce(0L, Long::sum);
	}

	/**
	 * 孫の数。大項目用。
	 * 
	 * @return
	 */
	public long getNumGrandchildren() {
		if (isItem()) {
			return 0;
		}
		return childList.stream().map(c -> c.getNumChildren()).reduce(0L, Long::sum);
	}

	/**
	 * 回答率。大項目用。
	 * 
	 * @return
	 */
	public long getAnswerRatio() {
		return getAnswerRatio(getNumChildren(true), getNumChildren());
	}

	private long getAnswerRatio(long nume, long denom) {
		if (denom == 0) {
			return 100;
		}
		return nume * 100 / denom;
	}

	/**
	 * 回答率算出用の数値。大項目用。小項目回答時に再計算するため。
	 * 
	 * @return 回答率、分子、分母の配列。
	 */
	public long[] getAnswerStats() {
		long nume = getNumChildren(true);
		long denom = getNumChildren();

		return new long[] { getAnswerRatio(nume, denom), nume, denom };
	}

	/**
	 * 達成レベル算出の基になる指数を得る。
	 * 
	 * @return
	 */
	private int getScore() {
		if (isItem()) {
			return isAnswered() ? (phase == null ? 0 : phase) : 0;
		}
		return childList.stream().map(AnswerForm::getScore).reduce(0, Integer::sum);
	}

	/**
	 * 達成レベル。
	 * 
	 * @return
	 */
	public long getAchievementLevel() {
		long all = getNumChildren() * CommonConst.NUM_PHASES;
		if (all == 0) {
			return 0;
		}
		return getScore() * 100 / all;
	}

	/**
	 * 添付ファイル有無。
	 * 
	 * @return
	 */
	public boolean hasFile() {
		return doc != null && !doc.isEmpty();
	}

	/**
	 * 添付ファイルサイズ。
	 * 
	 * @return
	 */
	public long getEvidenceFileSize() {
		if (!hasFile()) {
			return 0;
		}
		return doc.getSize();
	}

	public String getSubjectCode() {
		return subjectCode;
	}

	public void setSubjectCode(String subjectCode) {
		this.subjectCode = subjectCode;
	}

	public String getActionPlan() {
		return actionPlan;
	}

	public void setActionPlan(String actionPlan) {
		this.actionPlan = actionPlan;
	}

	public String getEvidence() {
		return evidence;
	}

	public void setEvidence(String evidence) {
		this.evidence = evidence;
	}

	public String getEvidenceFileName() {
		return evidenceFileName;
	}

	public void setEvidenceFileName(String evidenceFileName) {
		this.evidenceFileName = evidenceFileName;
	}

	public Boolean getDone() {
		return done;
	}

	public void setDone(Boolean done) {
		this.done = done;
	}

	public Integer getPhase() {
		return phase;
	}

	public void setPhase(Integer phase) {
		this.phase = phase;
	}

	public List<AnswerForm> getChildList() {
		return childList;
	}

	public void setChildList(List<AnswerForm> childList) {
		this.childList = childList;
	}

	public String getEvidenceFileId() {
		return evidenceFileId;
	}

	public void setEvidenceFileId(String evidenceFileId) {
		this.evidenceFileId = evidenceFileId;
	}

	public MultipartFile getDoc() {
		return doc;
	}

	public void setDoc(MultipartFile doc) {
		this.doc = doc;
	}

}
