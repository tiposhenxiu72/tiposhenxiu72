/*
* ファイル名：SkillBuildMgmtController.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/01/27   tsutsumi    新規作成
*/
package jp.co.sraw.controller.skill;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonController;
import jp.co.sraw.dto.SkillBuildDto;
import jp.co.sraw.entity.MsPartyTbl;
import jp.co.sraw.entity.NrLessonRelSubjectTbl;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.oxm.rubric.Rubric;
import jp.co.sraw.oxm.rubric.RubricCategory;
import jp.co.sraw.service.MsPartyServiceImpl;
import jp.co.sraw.service.RubricServiceImpl;
import jp.co.sraw.service.SkillBuildServiceImpl;
import jp.co.sraw.util.DbUtil;
import jp.co.sraw.util.PoiBook;

/**
 * 能力養成科目管理機能Controller
 *
 */
@Controller
@RequestMapping("/mgmt/skill/build")
public class SkillBuildMgmtController extends CommonController {

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(SkillBuildMgmtController.class);

	// 遷移先
	private static final String INDEX_PAGE = "/skill/build/mgmt/index";
	private static final String LIST_PAGE = "/skill/build/mgmt/list";
	private static final String EDIT_PAGE = "/skill/build/mgmt/edit";
	private static final String RELATE_PAGE = "/skill/build/mgmt/relate";

	private static final String REDIRECT_LIST = "redirect:list";

	// export.
	private static final String XLS_TEMPLATE_PATH = CommonConst.RESPATH_DOC_TEMPLATE + "skillBuild.xls";
	private static final String DEFAULT_XLS_NAME = "skillBuild.xls";

	// 定数コード
	private static final String JOSU_TARGET = "0045";		// 学内聴講対象者
	private static final String JOSU_LISTEN = "0046";		// 学外聴講／傍聴の可否
	private static final String JOSU_RELAY = "0023";		// 中継の有無
	private static final String JOSU_KBN = "0047";			// 授業形態
	private static final String JOSU_COMPULSOR = "0048";	// 必修選択の別

	@Autowired
	private RubricServiceImpl rubricService;
	@Autowired
	private SkillBuildServiceImpl skillBuildService;
	@Autowired
	private SkillBuildMgmtPoiHelper poiHelper;
	@Autowired
	private MsPartyServiceImpl msPartyService;

	@Override
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	// 全能力養成科目画面（ホイールがある画面）--------------------------

	// 全能力養成科目画面 表示
	@RequestMapping({ "", "/", "/index" })
	public String index(HttpServletRequest request
			, Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		String rkey = skillBuildService.getDefaultRubricKey(locale);

		return index(request, rkey, model, locale);
	}

	// 全能力養成科目画面 表示
	@RequestMapping("/index/{rkey}")
	public String index(HttpServletRequest request
			, @PathVariable("rkey") String rkey
			, Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		// ルーブリック内容取得
		Rubric rub = rubricService.findOne(rkey);
		model.addAttribute("rubric", rub);

		// 推奨科目情報取得
		Map<String, List<SkillBuildDto>> subjectMap = new HashMap<String, List<SkillBuildDto>>();
		Map<String, String> rowspanMap = new HashMap<>();
		int cnt = 0;
		for (RubricCategory rubCt : rub.getCategoryList()) {
			for (RubricCategory subCt : rubCt.getChildList()) {
				for (RubricCategory grantCt : subCt.getChildList()) {
					List<SkillBuildDto> list = skillBuildService.getRecommendLesson(rkey, grantCt.getAbilityCode());
					subjectMap.put(grantCt.getAbilityCode(), list);
				}
				cnt = cnt + subCt.getChildList().size();
			}
			rowspanMap.put(rubCt.getAbilityCode(), Integer.toString(cnt));
			cnt = 0;
		}
		model.addAttribute("subjectMap", subjectMap);
		model.addAttribute("rowspanMap", rowspanMap);
		model.addAttribute("rubricChartDto", rubricService.getCharDto(rub));
		model.addAttribute("rkey", rkey);

		logger.infoCode("I0002", INDEX_PAGE);
		return INDEX_PAGE;
	}

	// 能力養成科目一覧 ------------------------------------
	@RequestMapping("/list")
	public String list (HttpServletRequest request
			, @ModelAttribute(CommonConst.FORM_NAME) BuildForm selForm
			, Model model, Locale locale) {
		String rkey = skillBuildService.getDefaultRubricKey(locale);
		return list(request, rkey,selForm, model, locale);
	}

	/**
	 * 能力養成科目一覧画面 表示
	 * @param request
	 * @param rkey ルーブリックキー
	 * @param chkSts 表示条件
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping("/list/{rkey}")
	public String list(HttpServletRequest request
			, @PathVariable("rkey") String rkey
			, @ModelAttribute(CommonConst.FORM_NAME) BuildForm selForm
			, Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		// ルーブリック内容取得
		Rubric rub = rubricService.findOne(rkey);
		model.addAttribute("rubric", rub);

		// 能力養成コードに紐づく推奨科目の一覧情報を取得
		Map<String, List<SkillBuildDto>> subjectMap = new HashMap<String, List<SkillBuildDto>>();
		for (RubricCategory rubCt : rub.getCategoryList()) {
			for (RubricCategory subCt : rubCt.getChildList()) {
				for (RubricCategory grantCt : subCt.getChildList()) {
					List<SkillBuildDto> list = skillBuildService.getRecommendLesson(rkey, grantCt.getAbilityCode());
					if (list != null) {
						subjectMap.put(grantCt.getAbilityCode(), list);
					}
				}
			}
		}
		model.addAttribute("subjectMap", subjectMap);
		model.addAttribute("rkey", rkey);

		logger.infoCode("I0002", LIST_PAGE);
		return LIST_PAGE;
	}


	/**
	 * 能力養成科目一覧画面 アップロード
	 *
	 * @param request
	 * @param rkey ルーブリックキー
	 * @param lessonkey 科目キー
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping(value="/upload", method = RequestMethod.POST)
	public String upload(HttpServletRequest request
			, SkillBuildUploadForm uploadForm
			, Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		// アップロードした内容を読み込んで、DBに登録する（登録済みのものは削除する）
		try (PoiBook book = PoiBook.fromResource(uploadForm.getDoc())) {
			// Excelの内容を読込
			List<CurriculumForm> list = poiHelper.getLinkageLessonAbilityCode(book);

			// 養成能力を更新する
			skillBuildService.updateSkillBuildLesson(uploadForm.getrKey(), list, userInfo);

		} catch (IOException e) {
			logger.error("IOException exporting a execlfile ");
			return null;
		} catch (Exception e) {
			logger.error("unexpected error while exporting a excelfile ");
			return null;
		}
		// 画面再描画
		logger.infoCode("I0002", REDIRECT_LIST);
		return REDIRECT_LIST;
	}

	/**
	 * 能力養成科目一覧画面 ダウンロード
	 *
	 * @param request
	 * @param rkey ルーブリックキー
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = "/download/{rkey}", method = RequestMethod.GET, produces = "application/vnd.ms-excel")
	@ResponseBody
	public Resource download(HttpServletRequest request
			, @PathVariable("rkey") String rkey
			, HttpServletResponse response, Model model, Locale locale) throws IOException {
		logger.infoCode("I0001", request.getRequestURI());

		ByteArrayOutputStream baos = prepareExcel(rkey, locale);
		if (baos == null) { // 失敗?
			// 500エラーとする。
			logger.errorCode("E0014", "failed to prepare excel file");
			throw new RuntimeException();
		}

		response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + DEFAULT_XLS_NAME);

		logger.infoCode("I0002");
		return new ByteArrayResource(baos.toByteArray());
	}

//	/**
//	 * 能力養成編集画面 登録完了
//	 *
//	 * @param request
//	 * @param rkey ルーブリックキー
//	 * @param lessonkey 科目キー
//	 * @param model
//	 * @param locale
//	 * @return
//	 */
//	@RequestMapping("/complete/")
//	public String complete (HttpServletRequest request
//			, @PathVariable("rkey") String rkey
//			, @PathVariable("lessonkey") String lessonkey
//			, Model model, Locale locale) {
//		logger.infoCode("I0001", request.getRequestURI());
//
//		// TODO フォームの内容を登録する
//
//		logger.infoCode("I0002", EDIT_PAGE);
//		return EDIT_PAGE;
//	}

	/**
	 * 能力養成一覧画面 削除
	 *
	 * @param request
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping(value="/delete", method = RequestMethod.POST)
	public String delete (HttpServletRequest request
			, @ModelAttribute(CommonConst.FORM_NAME) BuildForm thisForm
			, Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		// TODO 選択行の科目ひも付き情報を削除し、科目情報自体も削除する。その後再描画
		for (String rowNo : thisForm.getSelRow()) {
			// 選択した科目コード
			String lessonKey = thisForm.getCurriculumList().get(Integer.parseInt(rowNo)).getLessonKey();
			// 削除処理呼出
			skillBuildService.deleteAllForLesson(lessonKey);
		}
		// 画面再描画
		logger.infoCode("I0002", REDIRECT_LIST);
		return REDIRECT_LIST;
	}


	// 養成能力編集画面 -------------------------------------

	/**
	 * 能力養成編集画面(新規モード)
	 *
	 * @param request
	 * @param rkey ルーブリックキー
	 * @param lessonkey 科目キー
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping("/edit/{rkey}")
	public String edit(HttpServletRequest request
			, @PathVariable("rkey") String rkey
			, Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		editInit(model, locale);

		// そのまま表示する
		CurriculumForm curriculum = new CurriculumForm();;
		model.addAttribute("form", curriculum);
		model.addAttribute("rkey", rkey);
		model.addAttribute("lessonkey", "");

		logger.infoCode("I0002", EDIT_PAGE);
		return EDIT_PAGE;
	}

	/**
	 * 能力養成編集画面(編集モード)
	 *
	 * @param request
	 * @param rkey ルーブリックキー
	 * @param lessonkey 科目キー
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping("/edit/{rkey}/{lessonkey}")
	public String edit(HttpServletRequest request
			, @PathVariable("rkey") String rkey
			, @PathVariable("lessonkey") String lessonkey
			, Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		editInit(model, locale);


		// 科目情報詳細を取得する
		CurriculumForm curriculum = skillBuildService.getDetailInfoForLesson(rkey, lessonkey);

		model.addAttribute("form", curriculum);
		model.addAttribute("rkey", rkey);
		model.addAttribute("lessonkey", lessonkey);

		logger.infoCode("I0002", EDIT_PAGE);
		return EDIT_PAGE;
	}

	private void editInit (Model model, Locale locale) {
		// 組織名
		List<MsPartyTbl> partyList = msPartyService.findAll();
		model.addAttribute("partyList", partyList);

		// 学内聴講対象者
		Map<String, String> targetMap = DbUtil.getJosuAbbrMap(JOSU_TARGET, locale);
		model.addAttribute("targetMap", targetMap);

		// 学外聴講／傍聴の可否
		Map<String, String> listenMap = DbUtil.getJosuAbbrMap(JOSU_LISTEN, locale);
		model.addAttribute("listenMap", listenMap);

		// 中継の有無
		Map<String, String> relayMap = DbUtil.getJosuAbbrMap(JOSU_RELAY, locale);
		model.addAttribute("relayMap", relayMap);

		// 授業形態
		Map<String, String> kbnMap = DbUtil.getJosuAbbrMap(JOSU_KBN, locale);
		model.addAttribute("kbnMap", kbnMap);

		// 必修選択の別
		Map<String, String> compulsorMap = DbUtil.getJosuAbbrMap(JOSU_COMPULSOR, locale);
		model.addAttribute("compulsorMap", compulsorMap);
	}

	/**
	 * 能力養成編集画面 登録
	 *
	 * @param request
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping(value="/editFix/{rkey}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public AjaxDto editFix (HttpServletRequest request
			, @PathVariable("rkey") String rkey
			, @ModelAttribute(CommonConst.FORM_NAME) CurriculumForm thisForm
			, Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		try {
			// フォームの内容を登録する
			skillBuildService.updateNrlessonTbl(rkey, thisForm, userInfo);
		} catch (Exception e) {
			logger.errorCode("E1007", e);
			return new AjaxDto(messageSource.getMessage("error.data.message.db.regist", null, locale));
		}

		logger.infoCode("I0002", REDIRECT_LIST);
		return new AjaxDto();
	}

	// 養成科目紐付け画面 ----------------------------------------

	/**
	 * 養成科目紐付け画面 呼出
	 *
	 * @param request
	 * @param rkey ルーブリックキー
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping("/relate/{rkey}")
	public String relate (HttpServletRequest request
			, @PathVariable("rkey") String rkey
			, Model model, Locale locale) {

		// ルーブリック内容取得
		Rubric rub = rubricService.findOne(rkey);

		SKillBuildRelateForm form = populateRelateForm(rub, new ArrayList<>());
		model.addAttribute(CommonConst.FORM_NAME, form);

		model.addAttribute("rkey", rkey);
		model.addAttribute("lessonKey", 0);

		return RELATE_PAGE;
	}

	/**
	 * 養成科目紐付け画面 呼出
	 *
	 * @param request
	 * @param rkey ルーブリックキー
	 * @param lessonkey 科目キー
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping("/relate/{rkey}/{lessonKey}")
	public String relate (HttpServletRequest request
			, @PathVariable("rkey") String rkey
			, @PathVariable("lessonKey") String lessonKey
			, Model model, Locale locale) {

		// ルーブリック内容取得
		Rubric rub = rubricService.findOne(rkey);

		// ひも付け情報取得
		List<NrLessonRelSubjectTbl> list = skillBuildService.searchRelSubjectInfo(rkey, lessonKey);


		SKillBuildRelateForm form = populateRelateForm(rub, list);
		model.addAttribute(CommonConst.FORM_NAME, form);

		model.addAttribute("rkey", rkey);
		model.addAttribute("lessonKey", lessonKey);

		return RELATE_PAGE;
	}

	/**
	 * ひも付け画面 完了
	 * @param request
	 * @param selForm
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping(value="/relateFix", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Map<String, List<String>> relateFix(HttpServletRequest request
			, @ModelAttribute(CommonConst.FORM_NAME) SKillBuildRelateForm selForm
			, Model model, Locale locale) {

		// ◎
		List<String> bestList = new ArrayList<>();
		// ○
		List<String> normalList = new ArrayList<>();
		Map<String, List<String>> rtnMap = new HashMap<>();
		rtnMap.put(CommonConst.RELATION_LEVEL_BEST, bestList);
		rtnMap.put(CommonConst.RELATION_LEVEL_NORMAL, normalList);

		// 紐付きレベルで振り分け
		checkRelationiStatus(selForm.getRelationList(), rtnMap);

		return rtnMap;
	}


	// ------------------------------------------------------

	// 能力養成科目一覧画面(list)関連


	// Excel出力関連 --------------
	/**
	 * 養成能力一覧情報をExcelへエクスポートして、OutputStreamとして返す。
	 *
	 * @param rkey
	 *            ルーブリックキー
	 * @return
	 */
	private ByteArrayOutputStream prepareExcel(String rkey, Locale locale) {
		Rubric rub = rubricService.findOne(rkey);

		try (PoiBook book = PoiBook.fromResource(XLS_TEMPLATE_PATH)) {

			// マスタ情報を取得
			// 組織名
			List<MsPartyTbl> partyList = msPartyService.findAll();
			Map<String, String> partyMap = new HashMap<>();
			for (MsPartyTbl party : partyList) {
				partyMap.put(party.getPartyCode(), party.getPartyName());
			}
			// 学内聴講対象者
			Map<String, String> targetMap = DbUtil.getJosuAbbrMap(JOSU_TARGET, locale);
			// 学外聴講／傍聴の可否
			Map<String, String> listenMap = DbUtil.getJosuAbbrMap(JOSU_LISTEN, locale);
			// 中継の有無
			Map<String, String> relayMap = DbUtil.getJosuAbbrMap(JOSU_RELAY, locale);
			// 授業形態
			Map<String, String> kbnMap = DbUtil.getJosuAbbrMap(JOSU_KBN, locale);
			// 必修選択の別
			Map<String, String> compulsorMap = DbUtil.getJosuAbbrMap(JOSU_COMPULSOR, locale);

			// ヘッダ部分設定
			poiHelper.buildExcelDocumentHeader(book, rub);

			// ルーブリックに紐づく養成科目を習得
			List<CurriculumForm> list = skillBuildService.searchLessonByRubric(rkey);

			// データ部を設定
			poiHelper.buildExcelDocument(book, list
					, partyMap, targetMap, listenMap, relayMap, kbnMap, compulsorMap);

			// 2シート目設定
			poiHelper.buildExcelDocumentDataSheet(book
					, partyMap, targetMap, listenMap, relayMap, kbnMap, compulsorMap);

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			book.write(baos);
			return baos;
		} catch (IOException e) {
			logger.error("IOException while exporting a rublic: " + rkey, e);
			return null;
		} catch (Exception e) {
			logger.error("unexpected error while exporting a rublic: " + rkey, e);
			return null;
		}
	}

	// 紐付け画面関連 ----------
	/**
	 * @param rub
	 * @param list
	 * @return
	 */
	private SKillBuildRelateForm populateRelateForm (Rubric rub, List<NrLessonRelSubjectTbl> list) {
		SKillBuildRelateForm form = new SKillBuildRelateForm();

		// 科目コードと紐付きレベルのmapを作る
		Map<String, String> map = new HashMap<>();
		for (NrLessonRelSubjectTbl item : list) {
			map.put(item.getId().getSubjectCode(), item.getRelationLevel());
		}

		// フォームの形に入れ替え
		List<SkillBuildRelateSubjectForm> relationList = formatRelateForm(rub.getCategoryList(), map);

		form.setRelationList(relationList);
		return form;
	}

	/**
	 * カテゴリ情報をひも付け一覧の表示フォームに変換
	 * @param catList
	 * @param subjectMap
	 * @return
	 */
	private List<SkillBuildRelateSubjectForm> formatRelateForm(List<RubricCategory> catList, Map<String, String> subjectMap) {
		if (catList == null) {
			return null;
		}
		List<SkillBuildRelateSubjectForm> parentList = new ArrayList<SkillBuildRelateSubjectForm>();
		for (RubricCategory cat : catList) {
			SkillBuildRelateSubjectForm item = new SkillBuildRelateSubjectForm();
			item.setSubjectCode(cat.getAbilityCode());
			item.setSubjectName(cat.getName());
			if (subjectMap.containsKey(cat.getAbilityCode())) {
				item.setRelation(subjectMap.get(cat.getAbilityCode()));
			}
			// 子カテゴリをセット
			item.setChildList (formatRelateForm(cat.getChildList(), subjectMap));

			parentList.add(item);
		}
		return parentList;
	}

	/**
	 * 紐付きのチェック状態を調べる
	 * @param inList 紐付き画面の一覧情報リスト
	 * @param outMap 結果格納用Map
	 */
	private void checkRelationiStatus (List<SkillBuildRelateSubjectForm> inList, Map<String, List<String>> outMap) {
		if (inList == null) {
			return;
		}
		for (SkillBuildRelateSubjectForm item: inList) {
			if (item.getRelation() == null) {
				// 紐付きが設定されていない場合は、更に下層をチェックしに行く
				checkRelationiStatus (item.getChildList(), outMap);
			}
			if (CommonConst.RELATION_LEVEL_BEST.equals(item.getRelation())) {
				outMap.get(CommonConst.RELATION_LEVEL_BEST).add(item.getSubjectCode());
			} else if (CommonConst.RELATION_LEVEL_NORMAL.equals(item.getRelation())) {
				outMap.get(CommonConst.RELATION_LEVEL_NORMAL).add(item.getSubjectCode());
			}
		}
	}
}
