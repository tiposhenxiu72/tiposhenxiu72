/*
* ファイル名：GyBiblioForm.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.portfolio.form;

import java.math.BigDecimal;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.NotBlank;
import org.maru.m4hv.extensions.constraints.CharLength;

import jp.co.sraw.entity.GyBiblioTbl;
import jp.co.sraw.entity.GyCommonTbl;
import jp.co.sraw.validation.AlphaNumberSymbol;
import jp.co.sraw.validation.Date468;

/**
 * <B>GyBiblioFormクラス</B>
 * <P>
 * Formのメソッドを提供する
 */
public class GyBiblioForm extends PortfolioForm {

	public GyBiblioForm() {
		super();
	}

	public String getBiblioLanguage() {
		return this.getLanguage();
	}

	public void setBiblioLanguage(String biblioLanguage) {
		this.setLanguage(biblioLanguage);
	}

	@CharLength(max = 3000)
	private String author;

	@NotBlank
	private String authortypeid;

	@AlphaNumberSymbol
	@CharLength(max = 100)
	private String isbn;

	@NotBlank
	private String wlanguage;

	@Date468
	private String publicationdate;

	@CharLength(max = 255)
	private String publisher;

	@Min(0)
	@Max(9999)
	private BigDecimal reppagenumber;

	@Min(0)
	@Max(9999)
	private BigDecimal totalpagenumber;

	@NotBlank
	@CharLength(max = 255)
	private String title;

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return this.author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getAuthortypeid() {
		return this.getContent(this.authortypeid, "0211");
	}

	public void setAuthortypeid(String authortypeid) {
		this.authortypeid = authortypeid;
	}

	public String getIsbn() {
		return this.isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getWlanguage() {
		return this.getContent(this.wlanguage, "0206");
	}

	public void setWlanguage(String wlanguage) {
		this.wlanguage = wlanguage;
	}

	public String getPublicationdate() {
		return this.publicationdate;
	}

	public void setPublicationdate(String publicationdate) {
		this.publicationdate = publicationdate;
	}

	public String getPublisher() {
		return this.publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public BigDecimal getReppagenumber() {
		return this.reppagenumber;
	}

	public void setReppagenumber(BigDecimal reppagenumber) {
		this.reppagenumber = reppagenumber;
	}

	public BigDecimal getTotalpagenumber() {
		return this.totalpagenumber;
	}

	public void setTotalpagenumber(BigDecimal totalpagenumber) {
		this.totalpagenumber = totalpagenumber;
	}

	@Override
	public GyCommonTbl getNewTbl() {
		// TODO 自動生成されたメソッド・スタブ
		return new GyBiblioTbl();
	}

}
