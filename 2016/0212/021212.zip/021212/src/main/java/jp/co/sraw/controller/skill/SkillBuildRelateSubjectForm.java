/*
* ファイル名：RelateForm.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/01/27   tsutsumi    新規作成
*/
package jp.co.sraw.controller.skill;

import java.util.List;

import jp.co.sraw.common.CommonForm;
import jp.co.sraw.util.StringUtil;

/**
 * 養成能力の紐付状態
 * @author SRAW tsutsumi
 */
public class SkillBuildRelateSubjectForm extends CommonForm {


	/** 能力養成科目コード */
	private String subjectCode;
	/** 能力養成科目名 */
	private String subjectName;
	/** 紐付き状態(小項目でのみ必要) */
	private String relation;
	/** 子の紐付き状態 */
	private List<SkillBuildRelateSubjectForm> childList;

	/**
	 * 小項目が回答済み(テーブルにエントリがある)ならtrue。達成済かどうかは関係ない。
	 */
	private boolean isAnswered() {
		return StringUtil.isNotNull(subjectCode);
	}

	/**
	 * 小項目ならtrue。
	 *
	 * @return
	 */
	private boolean isItem() {
		return childList == null;
	}

	/**
	 * 子供の数。
	 *
	 * @return
	 */
	public long getNumChildren() {
		return getNumChildren(false);
	}

	/**
	 * 子供の数。
	 *
	 * @param withAnswer
	 *            回答済みのみカウントする?
	 * @return
	 */
	private long getNumChildren(boolean withAnswer) {
		if (isItem()) {
			long i = (!withAnswer || isAnswered()) ? 1 : 0;
			return i;
		}
		return childList.stream().map(i -> i.getNumChildren(withAnswer)).reduce(0L, Long::sum);
	}

	/**
	 * 孫の数。大項目用。
	 *
	 * @return
	 */
	public long getNumGrandchildren() {
		if (isItem()) {
			return 0;
		}
		return childList.stream().map(c -> c.getNumChildren()).reduce(0L, Long::sum);
	}

	public String getSubjectCode() {
		return subjectCode;
	}

	public void setSubjectCode(String subjectCode) {
		this.subjectCode = subjectCode;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public String getRelation() {
		return relation;
	}

	public void setRelation(String relation) {
		this.relation = relation;
	}

	public List<SkillBuildRelateSubjectForm> getChildList() {
		return childList;
	}

	public void setChildList(List<SkillBuildRelateSubjectForm> childList) {
		this.childList = childList;
	}
}
