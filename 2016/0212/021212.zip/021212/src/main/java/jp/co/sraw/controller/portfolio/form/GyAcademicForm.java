/*
* ファイル名：GyAcademicForm.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.portfolio.form;

import org.hibernate.validator.constraints.NotBlank;
import org.maru.m4hv.extensions.constraints.CharLength;

import jp.co.sraw.entity.GyAcademicTbl;
import jp.co.sraw.entity.GyCommonTbl;
import jp.co.sraw.validation.Date468;

/**
 * <B>GyAcademicFormクラス</B>
 * <P>
 * Formのメソッドを提供する
 */
public class GyAcademicForm extends PortfolioForm {

	public GyAcademicForm() {
		super();
	}

	public String getAcademicLanguage() {
		return this.getLanguage();
	}

	public void setAcademicLanguage(String academicLanguage) {
		this.setLanguage(academicLanguage);
	}

	@NotBlank
	@CharLength(max = 255)
	private String country;

	@NotBlank
	@CharLength(max = 255)
	private String departmentname;

	@NotBlank
	@CharLength(max = 255)
	private String subjectname;

	@NotBlank
	@Date468
	private String fromdate;

	@NotBlank
	@Date468
	private String todate;

	@NotBlank
	@CharLength(max = 255)
	private String title;

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getDepartmentname() {
		return this.departmentname;
	}

	public void setDepartmentname(String departmentname) {
		this.departmentname = departmentname;
	}

	public String getFromdate() {
		return this.fromdate;
	}

	public void setFromdate(String fromdate) {
		this.fromdate = fromdate;
	}

	public String getSubjectname() {
		return this.subjectname;
	}

	public void setSubjectname(String subjectname) {
		this.subjectname = subjectname;
	}

	public String getTodate() {
		return this.todate;
	}

	public void setTodate(String todate) {
		this.todate = todate;
	}

	@Override
	public GyCommonTbl getNewTbl() {
		// TODO 自動生成されたメソッド・スタブ
		return new GyAcademicTbl();
	}

}
