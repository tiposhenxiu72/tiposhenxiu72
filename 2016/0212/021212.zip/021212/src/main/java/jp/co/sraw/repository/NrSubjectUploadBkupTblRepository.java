package jp.co.sraw.repository;

import java.sql.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import jp.co.sraw.entity.NrSubjectUploadBkupTbl;
import jp.co.sraw.entity.NrSubjectUploadBkupTblPK;

@Repository
public interface NrSubjectUploadBkupTblRepository
		extends JpaRepository<NrSubjectUploadBkupTbl, NrSubjectUploadBkupTblPK>,
		JpaSpecificationExecutor<NrSubjectUploadBkupTbl> {
	@Modifying
	@Query(name = "NrSubjectUploadBkupTbl.backup")
	public int backup(@Param("savedDate") Date savedDate);

}
