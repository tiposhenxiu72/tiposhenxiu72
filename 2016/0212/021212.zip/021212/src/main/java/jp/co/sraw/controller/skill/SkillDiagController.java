/*
* ファイル名：SkillDiagController.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/01/05   etoh        新規作成
*/
package jp.co.sraw.controller.skill;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.util.HtmlUtils;

import jp.co.sraw.common.CommonConst;
/**
 * <B>能力診断・結果表示機能用コントローラ</B>
 * <P>
 * アクションプランやエビデンスの登録、表示など。
 */
import jp.co.sraw.common.CommonController;
import jp.co.sraw.dto.SkillAnswerDto;
import jp.co.sraw.dto.SkillPastAnswerDto;
import jp.co.sraw.entity.CmFileUploadTbl;
import jp.co.sraw.entity.NrLessonRelSubjectTbl;
import jp.co.sraw.entity.NrSubjectAnswerBkupTbl;
import jp.co.sraw.entity.NrSubjectAnswerTbl;
import jp.co.sraw.exception.OutOfQuotaException;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.oxm.rubric.Rubric;
import jp.co.sraw.oxm.rubric.RubricCategory;
import jp.co.sraw.service.CmFileUploadServiceImpl;
import jp.co.sraw.service.RubricServiceImpl;
import jp.co.sraw.service.SkillDiagServiceImpl;
import jp.co.sraw.util.DateUtil;
import jp.co.sraw.util.DbUtil;
import jp.co.sraw.util.PoiBook;
import jp.co.sraw.util.StringUtil;

@Controller
@RequestMapping("/skill/diag")
public class SkillDiagController extends CommonController {

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(SkillDiagController.class);

	// 遷移先。
	private static final String INDEX_PAGE = "skill/diag/index";
	private static final String EDIT_PAGE = "skill/diag/edit";
	private static final String EDIT_ITEM_PAGE = "skill/diag/edit_item";
	private static final String VIEW_LIST_PAGE = "skill/diag/view_list";
	private static final String VIEW_WHOLE_PAGE = "skill/diag/view_whole";
	private static final String VIEW_PAST_PAGE = "skill/diag/view_past";
	private static final String EDIT_REPORT_PAGE = "skill/diag/edit_report";
	private static final String CREATE_REPORT_PAGE = "skill/diag/create_report";
	private static final String ERROR_PAGE = "error";

	// 定数区分/コード。
	private static final String JKBN_LENSNAME = "0001";
	private static final String JKBN_DEGREE = "0036";
	private static final String JKBN_RKEY = "0044";
	private static final String JCODE_RKEY = "1";

	// export.
	private static final String XLS_TEMPLATE_PATH = CommonConst.RESPATH_DOC_TEMPLATE + "selfEvalReport.xls";
	private static final String DEFAULT_XLS_NAME = "selfEvalReport.xls";

	@Autowired
	private RubricServiceImpl rubricService;

	@Autowired
	private SkillDiagServiceImpl diagService;

	@Autowired
	private CmFileUploadServiceImpl fileService;

	@Override
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	// 能力診断トップ画面表示。
	@RequestMapping({ "", "/", "/index" })
	public String index(HttpServletRequest request, Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		String rkey = DbUtil.getJosuName(JKBN_RKEY, JCODE_RKEY, locale);
		Rubric rub = rubricService.findOne(rkey);
		if (rub == null) {
			return errorPage("skill.diag.message.error.norubric", model, locale);
		}

		model.addAttribute("rubricKey", rkey);
		model.addAttribute("rubricName", rub.getName());
		model.addAttribute("rubricSummary", rub.getSummary());

		logger.infoCode("I0002", INDEX_PAGE);
		return INDEX_PAGE;
	}

	// 能力診断入力画面表示。
	@RequestMapping("/edit/{rkey}/{lensId}")
	public String edit(HttpServletRequest request, @PathVariable("rkey") String rkey,
			@PathVariable("lensId") String lensId, Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		prepareModelForView(model, rkey, lensId, locale, null);

		logger.infoCode("I0002", EDIT_PAGE);
		return EDIT_PAGE;
	}

	// 保存して結果一覧へ遷移。
	// AJAXリクエストで来る。
	// 次画面へ遷移するのはJS側の仕事。
	@RequestMapping(value = "/save/{rkey}/{lensId}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public AjaxDto save(HttpServletRequest request, @PathVariable("rkey") String rkey,
			@PathVariable("lensId") String lensId, @Validated @ModelAttribute(CommonConst.FORM_NAME) DiagForm form,
			BindingResult bindingResult, Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		// DB登録。
		try {
			diagService.validateQuota(userInfo, form.totalFileSize());
			diagService.updateAnswer(rkey, form, userInfo);
			operationHistory(CommonConst.OP_FUNC_SKILL_DIAG_SUBCAT, CommonConst.OP_ACTION_UPDATE);
		} catch (OutOfQuotaException e) {
			logger.errorCode("E1007", e);
			return new AjaxDto(messageSource.getMessage("skill.diag.message.outofquota",
					new Long[] { CommonConst.EVIDENCE_FILE_QUOTA }, locale));
		} catch (Exception e) {
			logger.errorCode("E1007", e);
			return new AjaxDto(messageSource.getMessage("error.data.message.db.regist", null, locale));
		}

		prepareModelForView(model, rkey, lensId, locale, null);

		logger.infoCode("I0002");
		return new AjaxDto();
	}

	// 能力診断結果一覧画面表示。
	@RequestMapping("/viewList/{rkey}/{lensId}")
	public String viewList(HttpServletRequest request, @PathVariable("rkey") String rkey,
			@PathVariable("lensId") String lensId, Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		prepareModelForView(model, rkey, lensId, locale, null);

		logger.infoCode("I0002", VIEW_LIST_PAGE);
		return VIEW_LIST_PAGE;
	}

	// 能力診断結果一覧(過去)画面表示。
	@RequestMapping("/viewList/{rkey}/{lensId}/{savedDate}")
	public String viewList(HttpServletRequest request, @PathVariable("rkey") String rkey,
			@PathVariable("lensId") String lensId, @PathVariable("savedDate") String savedDate, Model model,
			Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		prepareModelForView(model, rkey, lensId, locale, savedDate);

		logger.infoCode("I0002", VIEW_LIST_PAGE);
		return VIEW_LIST_PAGE;
	}

	/**
	 * 診断結果表示用にモデルを準備する。実際は編集用にも使う。
	 * 
	 * @param model
	 * @param rkey
	 * @param lensId
	 * @param locale
	 * @param savedDate
	 *            過去結果を使う場合はYYYYMMDDを指定。最新ならnull。
	 */
	private Rubric prepareModelForView(Model model, String rkey, String lensId, Locale locale, String savedDate) {
		// ルーブリック情報(レンズを通す)。
		Rubric rub = rubricService.findOne(rkey);
		rubricService.filterByLens(rub, Integer.valueOf(lensId));
		model.addAttribute("rubric", rub);

		// 回答をDiagFormに詰めて。
		DiagForm form = new DiagForm();
		if (savedDate == null) { // 最新結果を表示?
			List<NrSubjectAnswerTbl> answers = diagService.findAnswers(userInfo.getTargetUserKey(), rkey);
			diagService.populateForm(form, answers, rub);
			model.addAttribute("lastModifiedStr",
					answers.isEmpty() ? "" : DateUtil.dateTimeFormat(answers.get(0).getUpdDate(), false));
		} else { // 過去結果を表示。
			List<NrSubjectAnswerBkupTbl> answers = diagService.findPastAnswers(userInfo.getTargetUserKey(), rkey,
					DateUtil.toDate(savedDate));
			diagService.populateFormForPast(form, answers, rub);
			model.addAttribute("lastModifiedStr",
					answers.isEmpty() ? "" : DateUtil.dateTimeFormat(answers.get(0).getUpdDate(), false));
			model.addAttribute("savedDate", savedDate);
		}
		model.addAttribute("answers", form);

		// そのほか。
		model.addAttribute("lensName", DbUtil.getJosuName(JKBN_LENSNAME, lensId, locale));
		model.addAttribute("degreeName", lookupDegreeName(locale));
		model.addAttribute("canEditDone", Integer.valueOf(lensId) == CommonConst.LENSID_BASIC);

		return rub;
	}

	// 「あなたのロール」用の文字列を作る。
	private String lookupDegreeName(Locale locale) {
		String name = DbUtil.getJosuName(JKBN_DEGREE, userInfo.getTargetDegree(), locale);
		if (StringUtil.isNull(name)) {
			return "";
		}
		String pos = positionStr();
		return StringUtil.isNull(pos) ? name : name + "(" + pos + ")";
	}

	// PとPDとか。
	private String positionStr() {
		String degree = userInfo.getTargetDegree();
		if (StringUtil.isNull(degree)) {
			return "";
		}
		String pos = DbUtil.getAttrText1(JKBN_DEGREE, degree);
		return StringUtil.isNull(pos) ? "" : pos;
	}

	// 能力診断結果全体画面表示。
	@RequestMapping("/viewWhole/{rkey}/{lensId}")
	public String viewWhole(HttpServletRequest request, @PathVariable("rkey") String rkey,
			@PathVariable("lensId") String lensId, Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		Rubric rub = prepareModelForView(model, rkey, lensId, locale, null);
		model.addAttribute("lessonMap", lessonMap(rkey)); // 推奨科目。
		model.addAttribute("rubricChartDto", rubricService.getCharDto(rub));

		logger.infoCode("I0002", VIEW_WHOLE_PAGE);
		return VIEW_WHOLE_PAGE;
	}

	// 能力診断結果全体(過去)画面表示。
	@RequestMapping("/viewWhole/{rkey}/{lensId}/{savedDate}")
	public String viewWhole(HttpServletRequest request, @PathVariable("rkey") String rkey,
			@PathVariable("lensId") String lensId, @PathVariable("savedDate") String savedDate, Model model,
			Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		Rubric rub = prepareModelForView(model, rkey, lensId, locale, savedDate);
		model.addAttribute("lessonMap", lessonMap(rkey)); // 推奨科目。
		model.addAttribute("rubricChartDto", rubricService.getCharDto(rub));

		logger.infoCode("I0002", VIEW_WHOLE_PAGE);
		return VIEW_WHOLE_PAGE;
	}

	// abilityCodeから推奨科目へのマップ。
	// 推奨科目はth:utextでレンダリングすること。
	private Map<String, List<String>> lessonMap(String rkey) {
		return diagService.findAllLessons(rkey).stream()
				.collect(Collectors.groupingBy(les -> les.getId().getSubjectCode(),
						Collectors.mapping(this::lessonPartyAnchor, Collectors.toList())));
	}

	// 「科目(大学)」形式のアンカーを作る。
	private String lessonPartyAnchor(NrLessonRelSubjectTbl ls) {
		return "<a class=\"viewLesson\" href=\"" + viewLessonPath(ls.getId().getLessonKey()) + "\">"
				+ HtmlUtils.htmlEscape(ls.getNrLessonTbl().getLessonName()) + "("
				+ HtmlUtils.htmlEscape(ls.getNrLessonTbl().getParty().getPartyName()) + ")</a>";
	}

	private String viewLessonPath(String lessonKey) {
		String base = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest()
				.getContextPath();
		return base + "/skill/build/viewLesson/" + lessonKey;
	}

	// 能力診断 能力別(編集画面)。
	// iframe要素を使って埋め込むので、JSONではなくHTMLを返す。
	// ↓URLパスの最後にピリオドが入る場合、Springがトリムしてしまう(books.jsonとか)ので、正規表現でマッチさせる。
	@RequestMapping(value = "/editItem/{rkey}/{lensId}/{abilityCode:.+}")
	public String editItem(HttpServletRequest request, @PathVariable("rkey") String rkey,
			@PathVariable("lensId") String lensId, @PathVariable("abilityCode") String abilityCode, Model model,
			Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		SkillAnswerDto dto = buildSkillAnswer(request, rkey, abilityCode, null);
		model.addAttribute("dto", dto);
		model.addAttribute("lensName", DbUtil.getJosuName(JKBN_LENSNAME, lensId, locale));
		model.addAttribute("degreeName", lookupDegreeName(locale));
		model.addAttribute("canEditDone", Integer.valueOf(lensId) == CommonConst.LENSID_BASIC);

		logger.infoCode("I0002", EDIT_ITEM_PAGE);
		return EDIT_ITEM_PAGE;
	}

	// 保存して結果一覧へ遷移。
	// AJAXリクエストで来る。
	// 次画面へ遷移するのはJS側の仕事。
	@RequestMapping(value = "/saveItem/{rkey}/{lensId}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public AjaxDto saveItem(HttpServletRequest request, @PathVariable("rkey") String rkey,
			@PathVariable("lensId") String lensId,
			@Validated @ModelAttribute(CommonConst.FORM_NAME) SkillAnswerDto form, BindingResult bindingResult,
			Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		// DB登録。
		try {
			diagService.validateQuota(userInfo, form.getEvidenceFileSize());
			form = diagService.updateItemAnswer(rkey, form, userInfo);
			operationHistory(CommonConst.OP_FUNC_SKILL_DIAG_ITEM, CommonConst.OP_ACTION_UPDATE);
		} catch (OutOfQuotaException e) {
			logger.errorCode("E1007", e);
			return new AjaxDto(messageSource.getMessage("skill.diag.message.outofquota",
					new Long[] { CommonConst.EVIDENCE_FILE_QUOTA }, locale));
		} catch (Exception e) {
			logger.errorCode("E1007", e);
			return new AjaxDto(messageSource.getMessage("error.data.message.db.regist", null, locale));
		}

		logger.infoCode("I0002");
		return form;
	}

	// 能力診断結果 能力別表示。
	// ↓URLパスの最後にピリオドが入る場合、Springがトリムしてしまう(books.jsonとか)ので、正規表現でマッチさせる。
	@RequestMapping(value = "/viewItem/{rkey}/{abilityCode:.+}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public SkillAnswerDto viewItem(HttpServletRequest request, @PathVariable("rkey") String rkey,
			@PathVariable("abilityCode") String abilityCode, Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		SkillAnswerDto dto = buildSkillAnswer(request, rkey, abilityCode, null);

		logger.infoCode("I0002");
		return dto;
	}

	// 能力診断結果 能力別表示(過去)。
	@RequestMapping(value = "/viewItem/{rkey}/{abilityCode}/{savedDate}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public SkillAnswerDto viewItem(HttpServletRequest request, @PathVariable("rkey") String rkey,
			@PathVariable("abilityCode") String abilityCode, @PathVariable("savedDate") String savedDate, Model model,
			Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		SkillAnswerDto dto = buildSkillAnswer(request, rkey, abilityCode, savedDate);

		logger.infoCode("I0002");
		return dto;
	}

	/**
	 * 小項目の情報や回答内容をDTOに詰めて返す。中項目に対して使うことは考慮してないよ。
	 * 
	 * @param request
	 * @param rkey
	 * @param abilityCode
	 * @param savedDate
	 *            過去結果を使う場合はYYYYMMDDを指定。最新ならnull。
	 * @return
	 */
	private SkillAnswerDto buildSkillAnswer(HttpServletRequest request, String rkey, String abilityCode,
			String savedDate) {
		Rubric rub = rubricService.findOne(rkey);
		RubricCategory item = rub.buildMap().get(abilityCode);

		SkillAnswerDto dto = new SkillAnswerDto();
		if (savedDate == null) { // 最新結果を表示?
			NrSubjectAnswerTbl ans = diagService.findAnswerByAbilityCode(userInfo.getTargetUserKey(), rkey,
					abilityCode);
			diagService.populateDto(dto, positionStr(), ans, item);
		} else { // 過去結果を表示。
			NrSubjectAnswerBkupTbl ans = diagService.findPastAnswerByAbilityCode(userInfo.getTargetUserKey(), rkey,
					abilityCode, DateUtil.toDate(savedDate));
			diagService.populateDto(dto, positionStr(), ans, item);
		}
		return dto;
	}

	// 過去の診断結果一覧画面表示。
	@RequestMapping("/pastIndex")
	public String pastIndex(HttpServletRequest request, Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		String rkey = DbUtil.getJosuName(JKBN_RKEY, JCODE_RKEY, locale);
		Rubric rub = rubricService.findOne(rkey);
		if (rub == null) {
			return errorPage("skill.diag.message.error.norubric", model, locale);
		}

		// 過去回答を日付でグループ化。
		Map<java.util.Date, List<NrSubjectAnswerBkupTbl>> dmap = diagService // savedDate=>ans
				.findPastAnswers(userInfo.getTargetUserKey(), rkey).stream()
				.collect(Collectors.<NrSubjectAnswerBkupTbl, java.util
						.Date> groupingBy(ans -> ans.getId().getSaveDate()));
		Map<java.util.Date, Map<String, NrSubjectAnswerBkupTbl>> amap = buildAnswerMap(dmap);

		// レンズ情報。
		int[] lensIds = rubricService.allLensIds();
		String[] lensNames = rubricService.lensNames(lensIds, locale);
		@SuppressWarnings("unchecked")
		List<String>[] codeLists = new List[lensIds.length];
		for (int ix = 0; ix < lensIds.length; ix++) {
			codeLists[ix] = rubricService.codesThroughLens(rub, lensIds[ix]);
		}

		// 達成率を調査。
		// レンズごとに、日付の新しいもの順に集計。
		@SuppressWarnings("unchecked")
		List<SkillPastAnswerDto>[] pastAnswers = Stream.generate(ArrayList<SkillPastAnswerDto>::new)
				.limit(lensIds.length).toArray(List[]::new);
		calcPastAnswerStats(amap, lensIds, codeLists, pastAnswers);

		model.addAttribute("rkey", rkey);
		model.addAttribute("lensNames", lensNames);
		model.addAttribute("lensIds", lensIds);
		model.addAttribute("pastAnswers", pastAnswers);

		logger.infoCode("I0002", VIEW_PAST_PAGE);
		return VIEW_PAST_PAGE;
	}

	// 回答のリストから
	// マップ(abilityCode => 回答)を生成。
	private Map<Date, Map<String, NrSubjectAnswerBkupTbl>> buildAnswerMap(
			Map<Date, List<NrSubjectAnswerBkupTbl>> dmap) {
		Map<Date, Map<String, NrSubjectAnswerBkupTbl>> amap = new HashMap<Date, Map<String, NrSubjectAnswerBkupTbl>>();
		dmap.entrySet().forEach(e -> {
			// amap.put(e.getKey(),
			// e.getValue().stream().collect(Collectors.groupingBy(v->v.getId().getSubjectCode(),
			// Collectors.mapping(a -> a, Collectors.)));
			amap.put(e.getKey(),
					e.getValue().stream().collect(Collectors.toMap(a -> a.getId().getSubjectCode(), a -> a)));

		});

		return amap;
	}

	// 達成率の調査(全レンズ、全日付)。
	private void calcPastAnswerStats(Map<Date, Map<String, NrSubjectAnswerBkupTbl>> amap, int[] lensIds,
			List<String>[] codeLists, List<SkillPastAnswerDto>[] pastAnswers) {
		IntStream.range(0, lensIds.length).forEach(ix -> {
			calcPastAnswerStats(amap, lensIds[ix], codeLists[ix], pastAnswers[ix]);
		});
	}

	// 達成率の調査(1レンズ、全日付)。
	private void calcPastAnswerStats(Map<Date, Map<String, NrSubjectAnswerBkupTbl>> amap, int lensId,
			List<String> codeList, List<SkillPastAnswerDto> ans) {
		int numItems = codeList.size();
		if (numItems <= 0) {
			return;
		}
		// 日付で逆ソートしてからイテレート。
		Comparator<Entry<Date, Map<String, NrSubjectAnswerBkupTbl>>> comp = Comparator.comparing(Entry::getKey);
		amap.entrySet().stream().sorted(comp.reversed()).forEach(e -> {
			SkillPastAnswerDto a = new SkillPastAnswerDto();
			a.setSavedDate(e.getKey());
			a.setDenom(numItems);
			a.setNume(countNumAchievements(e.getValue(), codeList));
			ans.add(a);
		});
	}

	// 対象abilityCodeの中で、達成済のものをカウント。
	private int countNumAchievements(Map<String, NrSubjectAnswerBkupTbl> ansmap, List<String> codeList) {
		return (int) codeList.stream().filter(code -> {
			return ansmap.containsKey(code) && diagService.isAchieved(ansmap.get(code));
		}).count();
	}

	// エビデンスダウンロード。
	@RequestMapping("/download/{ukey}")
	public void download(HttpServletRequest request, @PathVariable("ukey") String ukey, HttpServletResponse response,
			Model model, Locale locale) throws IOException {
		logger.infoCode("I0001", request.getRequestURI());

		// uploadKeyとtargetUserKeyで検索(他人のファイルをDLできないよう)。
		CmFileUploadTbl file = fileService.findOne(ukey, userInfo.getTargetUserKey());
		if (file == null) { // 見つからん?
			// 500エラーとする。
			logger.errorCode("E0014", "the file is not found.");
			throw new RuntimeException();
		}

		// 拡張子からContent-typeを推測(デフォはoctet-stream)。
		String mimeType = URLConnection.guessContentTypeFromName(file.getFileName());
		if (mimeType == null) {
			mimeType = "application/octet-stream";
		}
		File filepath = new File(file.getRealPath());
		response.setContentLength((int) filepath.length());
		response.setContentType(mimeType);
		response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + file.getFileName());

		// Resourceをreturnする方式だと、content-typeヘッダがtext/htmlになってしまった。
		// Springがオーバールールするのかな?
		// よって、直接responseへ書き込むことにする。
		FileCopyUtils.copy(new FileInputStream(filepath), response.getOutputStream());

		logger.infoCode("I0002");
	}

	// エビデンスファイル削除。
	// ↓URLパスの最後にピリオドが入る場合、Springがトリムしてしまう(books.jsonとか)ので、正規表現でマッチさせる。
	@RequestMapping(value = "/deleteEvidence/{rkey}/{abilityCode:.+}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public AjaxDto deleteEvidence(HttpServletRequest request, @PathVariable("rkey") String rkey,
			@PathVariable("abilityCode") String abilityCode, Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		AjaxDto dto = null;

		// DB更新。
		try {
			diagService.deleteEvidence(rkey, abilityCode, userInfo);
			operationHistory(CommonConst.OP_FUNC_SKILL_DIAG_EVIDENCE, CommonConst.OP_ACTION_DELETE);
			if (SkillDiagServiceImpl.isItem(abilityCode)) { // 小項目か?
				dto = buildSkillAnswer(request, rkey, abilityCode, null);
			} else { // 中項目。
				dto = new AjaxDto();
			}
		} catch (Exception e) {
			logger.errorCode("E1007", e);
			return new AjaxDto(messageSource.getMessage("error.data.message.db.remove", null, locale));
		}

		logger.infoCode("I0002");
		return dto;
	}

	private String errorPage(String msgKey, Model model, Locale locale) {
		model.addAttribute("error", HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		model.addAttribute("status", HttpStatus.INTERNAL_SERVER_ERROR);
		model.addAttribute("message", messageSource.getMessage(msgKey, null, locale));
		return ERROR_PAGE;
	}

	// 自己評価レポの目標設定。
	@RequestMapping("/editReport")
	public String editReport(HttpServletRequest request, Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		ReportForm form = diagService.reportForEdit(userInfo);
		model.addAttribute(CommonConst.FORM_NAME, form);

		logger.infoCode("I0002", EDIT_REPORT_PAGE);
		return EDIT_REPORT_PAGE;
	}

	// 自己評価レポの目標保存。
	// AJAXのPOST。
	@RequestMapping(value = "/saveReport", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public AjaxDto saveReport(HttpServletRequest request,
			@Validated @ModelAttribute(CommonConst.FORM_NAME) ReportForm form, BindingResult bindingResult,
			Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		// DB保存。
		try {
			diagService.updateReport(form, userInfo);
			operationHistory(CommonConst.OP_FUNC_SKILL_DIAG_REPORT, CommonConst.OP_ACTION_UPDATE);
		} catch (Exception e) {
			logger.errorCode("E1007", e);
			return new AjaxDto(messageSource.getMessage("error.data.message.db.regist", null, locale));
		}

		logger.infoCode("I0002");
		return new AjaxDto();
	}

	// 自己評価レポのレポート出力。
	@RequestMapping("/createReport")
	public String createReport(HttpServletRequest request, Model model, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		ReportForm form = diagService.reportForEdit(userInfo);
		model.addAttribute(CommonConst.FORM_NAME, form);

		int[] lensIds = rubricService.allLensIds();
		String[] lensNames = rubricService.lensNames(lensIds, locale);
		model.addAttribute("lensIds", lensIds);
		model.addAttribute("lensNames", lensNames);

		model.addAttribute("levelNames", rubricService.allLevelNames(locale));

		List<Date> dates = diagService.findPastReports(userInfo.getTargetUserKey()).stream()
				.map(repo -> repo.getId().getSaveDate())
				.collect(Collectors.toList());
		model.addAttribute("savedDates", dates);

		logger.infoCode("I0002", CREATE_REPORT_PAGE);
		return CREATE_REPORT_PAGE;
	}

	// 自己評価レポートのダウンロード。
	@RequestMapping(value = "/downloadReport/{lens}/{level}/{sd}", method = RequestMethod.POST, produces = "application/vnd.ms-excel")
	@ResponseBody
	public Resource downloadReport(HttpServletRequest request, HttpServletResponse response,
			@PathVariable("lens") String lensId, @PathVariable("level") String level,
			@PathVariable("sd") String savedDateOrLatest, Model model, Locale locale) throws IOException {
		logger.infoCode("I0001", request.getRequestURI());

		ByteArrayOutputStream baos = prepareExcel(1, 2, null);
		if (baos == null) { // 失敗?
			// 500エラーとする。
			logger.errorCode("E0014", "failed to prepare excel file");
			throw new RuntimeException();
		}

		response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + DEFAULT_XLS_NAME);

		logger.infoCode("I0002");
		return new ByteArrayResource(baos.toByteArray());
	}

	/**
	 * 自己評価レポートを作成して、OutputStreamとして返す。
	 *
	 * @param savedDate
	 * @return
	 */
	private ByteArrayOutputStream prepareExcel(int lensId, int level, Date savedDate) {
		try (PoiBook book = PoiBook.fromResource(XLS_TEMPLATE_PATH)) {
			ReportExcelExporter ree = new ReportExcelExporter(book);
			ree.export(level);
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			book.write(baos);
			return baos;
		} catch (IOException e) {
			logger.error("IOException while exporting self evaluation report.", e);
			return null;
		} catch (Exception e) {
			logger.error("unexpected error while exporting self evaluation report.", e);
			return null;
		}
	}
}
