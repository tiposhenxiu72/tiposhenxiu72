package jp.co.sraw.controller.portfolio.excel;

import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Service;

import jp.co.sraw.common.CommonForm;
import jp.co.sraw.controller.portfolio.form.GyResearchAreaForm;
import jp.co.sraw.util.PoiBook;

@Service
public class ResearchAreaExcelHelper extends PortfolioExcelHelper<GyResearchAreaForm> {

	public ResearchAreaExcelHelper() {
		this.DATA_SHEET_NAME = "RESEARCH_AREA";
	}

	@Override
	public void buildExcelDocument(PoiBook workbook, List<GyResearchAreaForm> list) {
		workbook.activeSheet = workbook.book.getSheet(DATA_SHEET_NAME);

		for (int i = 0; i < list.size(); i++) {
			GyResearchAreaForm form = list.get(i);
			form.setViewType(CommonForm.VIEW_TYPE_EXCEL);
			int rowno = i + 1;
			// 言語区分
			// workbook.changeValue(rowno, 0, form.getLanguage());
			// 大分類名称
			workbook.changeValue(rowno, 0, form.getFieldid());
			// 中分類名称
			workbook.changeValue(rowno, 1, form.getSubjectid());
			// 細目
			workbook.changeValue(rowno, 2, this.getSummaryExcelFormat(form.getSummaryid()));
			// 公開範囲
			workbook.changeValue(rowno, 3, form.getPublicFlag());
		}
	}

	@Override
	public Sheet getSheet(Workbook workbook) {
		return workbook.getSheet(DATA_SHEET_NAME);
	}

	@Override
	public GyResearchAreaForm getForm(Row row) {
		GyResearchAreaForm form = new GyResearchAreaForm();

		// 言語区分
		// form.setLanguage(getCellValue(row, 0));
		// 大分類名称
		form.setFieldname(getCellValue(row, 0));
		// 中分類名称
		form.setSubjectname(getCellValue(row, 1));
		// 細目
		form.setSummary(getCellValue(row, 2));
		// 公開範囲
		form.setPublicFlag(getCellValue(row, 3));

		return form;
	}

}