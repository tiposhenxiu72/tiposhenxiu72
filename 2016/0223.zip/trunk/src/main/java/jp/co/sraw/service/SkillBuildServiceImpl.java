/*
* ファイル名：SkillBuildServiceImpl.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/01/18   tsutsumi    新規作成
*/
package jp.co.sraw.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonService;
import jp.co.sraw.common.UserInfo;
import jp.co.sraw.controller.skill.CurriculumForm;
import jp.co.sraw.dto.SkillBuildDto;
import jp.co.sraw.entity.MsPartyTbl;
import jp.co.sraw.entity.NrLessonCourseTbl;
import jp.co.sraw.entity.NrLessonCourseTblPK;
import jp.co.sraw.entity.NrLessonRelSubjectTbl;
import jp.co.sraw.entity.NrLessonRelSubjectTblPK;
import jp.co.sraw.entity.NrLessonTbl;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.repository.MsPartyTblRepository;
import jp.co.sraw.repository.NrLessonCourseTblRepository;
import jp.co.sraw.repository.NrLessonRelSubjectTblRepository;
import jp.co.sraw.repository.NrLessonTblRepository;
import jp.co.sraw.util.DateUtil;
import jp.co.sraw.util.DbUtil;
import jp.co.sraw.util.StringUtil;

/**
 * <B>能力養成科目のビジネスロジック</B>
 * <P>
 */
@Scope("prototype")
@Service
@Transactional(readOnly = false)
public class SkillBuildServiceImpl extends CommonService {

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(SkillBuildServiceImpl.class);

	@Override
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	@Autowired
	private EntityManager entityManager;


	@Autowired
	private NrLessonCourseTblRepository nrLessonCourseTblRepository;
	@Autowired
	private NrLessonTblRepository nrLessonTblRepository;
	@Autowired
	private NrLessonRelSubjectTblRepository nrLessonRelSubjectTblRepository;
	@Autowired
	private MsPartyTblRepository msPartyTblRepository;
	@Autowired
	private MsPartyServiceImpl msPartyService;
	@Autowired
	private RelationSkillServiceImpl relationSkillService;

	// 定数区分/コード。
	private static final String JKBN_RKEY = "0044";
	private static final String JCODE_RKEY = "1";

	/**
	 * ルーブリックキーのデフォルト値を取得
	 * @param locale
	 * @return
	 */
	public String getDefaultRubricKey(Locale locale) {
		return DbUtil.getJosuName(JKBN_RKEY, JCODE_RKEY, locale);
	}

	/**
	 * 能力養成科目履修対象一覧取得
	 * @param userKey ユーザキー
	 * @param rubKey ルーブリックキー
	 * @param subjectCode 能力養成コード
	 * @param chkSts 表示対象。trueの場合、右記を表示対象にする。[0]参加確定済, [1]参加予定, [2]未参加。全てfalseの場合、全て表示対象にする。
	 * @return
	 */
	public List<SkillBuildDto> searchNrLessonTblForLessonCode (String userKey, String rubKey, String subjectCode, List<Boolean> chkSts) {
		// 検索（能力養成科目一覧）
		logger.infoCode("I0001");

		// 養成能力に紐づく科目を全て取得
		List<SkillBuildDto> subjList = nrLessonTblRepository.searchRecommendLesson(rubKey, subjectCode, CommonConst.RELATION_LEVEL_BEST);
		if (subjList == null) {
			return new ArrayList<SkillBuildDto>();
		}

		// ユーザの履修・参加状況を取得する
		List<NrLessonCourseTbl> learnList = nrLessonCourseTblRepository.findByIdUserKey(userKey);
		Map<String, String> learnMap = new HashMap<>();
		for (NrLessonCourseTbl learnObj : learnList) {
			learnMap.put(learnObj.getId().getLessonKey(), learnObj.getCourseStatus());
		}

		// 表示用リストに変換
		List<SkillBuildDto> resultList = new ArrayList<>();
		for (SkillBuildDto subjObj : subjList) {
			if (learnMap.containsKey(subjObj.getLessonKey())) {
				// 履修状況が「参加確定済」 または 参加予定 かつ 表示対象がtrueになっていること
				// または表示状態が全て未チェック
				if ((chkSts.get(0) && CommonConst.COURSE_STATUS_JOIN.equals(learnMap.get(subjObj.getLessonKey())))
						|| (chkSts.get(1) && CommonConst.COURSE_STATUS_RESERVE.equals(learnMap.get(subjObj.getLessonKey())))
						|| !(chkSts.get(0) || chkSts.get(1) || chkSts.get(2))) {
					subjObj.setCourseStatus(learnMap.get(subjObj.getLessonKey()));
					resultList.add(subjObj);
				}
			} else {
				if (chkSts.get(2) || !(chkSts.get(0) || chkSts.get(1) || chkSts.get(2))) {
					resultList.add(subjObj);
				}
			}
		}
		logger.infoCode("I0002");
		return resultList;
	}

	/**
	 * 複数の科目コードに対して、履修状況ステータスを一括更新する
	 * @param lessonKeyList 科目コードのリスト
	 * @param courseStatus 履修状態
	 * @param targetUserKey 対象ユーザキー
	 * @param loginUserKey ログインユーザキー
	 * @return
	 */
	@Transactional
	public int updateForCourseStatus(List<String> lessonKeyList, String courseStatus, String targetUserKey, String loginUserKey) {
		int cnt = 0;

		for (String lessonKey : lessonKeyList) {
			cnt += updateForCourseStatus(lessonKey, courseStatus, targetUserKey, loginUserKey);
		}

		return cnt;
	}

	/**
	 * 履修状況テーブルの該当科目の履修状態を指定した値で更新します。
	 * @param lessonKey 科目コード
	 * @param courseStatus 履修状態
	 * @param targetUserKey 対象ユーザキー
	 * @param loginUserKey ログインユーザキー
	 * @return
	 */
	@Transactional
	public int updateForCourseStatus(String lessonKey, String courseStatus, String targetUserKey, String loginUserKey) {
		logger.infoCode("I0001");

		try {
			// 更新前データ取得
			NrLessonCourseTbl entity = nrLessonCourseTblRepository.findByIdLessonKeyAndIdUserKey(
					lessonKey
					, targetUserKey);

			// 更新データ設定
			if (CommonConst.COURSE_STATUS_NONE.equals(courseStatus)) {
				if (entity == null) {
					// 取消済み
					return 0;
				}

				// 参加取消
				nrLessonCourseTblRepository.delete(entity);
			} else {
				// 参加予約・参加確定
				entity = new NrLessonCourseTbl();
				entity.setId(new NrLessonCourseTblPK());

				entity.getId().setLessonKey(lessonKey);
				entity.getId().setUserKey(targetUserKey);
				entity.setCourseStatus(courseStatus);
				entity.setUpdUserKey(loginUserKey);
				entity.setUpdDate(DateUtil.getNowTimestamp());
				entity = nrLessonCourseTblRepository.saveAndFlush(entity);
				if (entity == null) {
					throw new RuntimeException("failed to saveAndFlush().");
				}
			}
			logger.infoCode("I0002");
		} catch (Exception e) {
			logger.errorCode("E1007", e);
			throw new RuntimeException("failed to saveAndFlush().");
		}
		return 1;
	}

	/**
	 * 能力養成科目詳細情報取得
	 * @param lessonKey 科目キー
	 * @return 詳細画面のフォーム情報
	 */
	public CurriculumForm getDetailInfoForLesson (String rubricKey, String lessonKey) {
		// 科目情報を取得
		NrLessonTbl lessonInfo = nrLessonTblRepository.getOne(lessonKey);
		if (lessonInfo == null) {
			throw new RuntimeException();
		}

		// 組織情報取得
		MsPartyTbl partyInfo = msPartyTblRepository.getOne(lessonInfo.getParty().getPartyCode());

		// 戻り値にセット
		CurriculumForm curriculumForm = setCurriculumFormByLessonAndParty(lessonInfo, partyInfo);
		return curriculumForm;
	}

	/**
	 * 養成能力コードに紐づく推奨科目を取得
	 * @param rubricKey ルーブリックキー
	 * @param subjectCode 養成能力コード
	 * @return 推奨科目の一覧
	 */
	public List<SkillBuildDto> getRecommendLesson (String rubricKey, String subjectCode) {
		// 推奨科目情報を取得(関連レベル：◎)
		return nrLessonTblRepository.searchRecommendLesson(rubricKey, subjectCode, CommonConst.RELATION_LEVEL_BEST);
	}

	@Transactional
	public void updateSkillBuildLesson (String rubricKey, List<CurriculumForm> curriculumList, UserInfo userInfo) {

		// 能力養成科目 養成能力リレーション から削除
		List<NrLessonRelSubjectTbl> delLessonRelSubjList = nrLessonRelSubjectTblRepository.findByIdRubricKeyOrderByIdLessonKey(rubricKey);
		nrLessonRelSubjectTblRepository.delete(delLessonRelSubjList);

		// 対象科目キー
		List<String> delList = new ArrayList<>();
		for (NrLessonRelSubjectTbl tbl : delLessonRelSubjList) {
			// 能力養成科目キーの数だけ削除する
			delList.add(tbl.getId().getLessonKey());
		}

		// 履修情報とのひも付けを解除
		List<NrLessonCourseTbl> delLessonCourseList = nrLessonCourseTblRepository.findByIdLessonKeyIn(delList);
		nrLessonCourseTblRepository.delete(delLessonCourseList);

		// データ登録処理
		for (CurriculumForm curriculum : curriculumList) {
			NrLessonTbl insEntity = new NrLessonTbl();

			MsPartyTbl partyTbl = msPartyService.findOne(curriculum.getPartyCode());
			insEntity.setParty(partyTbl);

			insEntity.setLessonKey(curriculum.getLessonKey());
			insEntity.setLessonName(curriculum.getLessonName());
			insEntity.setLessonDepartment(curriculum.getLessonDepartment());
			insEntity.setLessonCode(curriculum.getLessonCode());
			insEntity.setUserName(curriculum.getUserName());
			insEntity.setLessonTarget(curriculum.getLessonTarget());
			insEntity.setListenFlag(curriculum.getListenFlag());
			if (curriculum.getLessonDate() != null || curriculum.getLessonDate().length() > 0) {
				insEntity.setLessonDate(DateUtil.getTimestamp(curriculum.getLessonDate(), CommonConst.DEFAULT_YYYYMMDD));
			}
			insEntity.setLessonPeriod(curriculum.getLessonPeriod());
			insEntity.setRelayFlag(curriculum.getRelayFlag());
			insEntity.setRelayPlace(curriculum.getRelayPlace());
			insEntity.setLessonKbn(curriculum.getLessonKbn());
			if (StringUtil.isNotNull(curriculum.getUnit())) {
				insEntity.setUnit(Integer.parseInt(curriculum.getUnit()));
			}
			insEntity.setUnitInterchangeable(curriculum.getUnitInterchangeable());
			insEntity.setLessonCompulsory(curriculum.getLessonCompulsory());
			insEntity.setLessonBase(curriculum.getLessonBase());
			insEntity.setLessonIntention(curriculum.getLessonIntention());
			insEntity.setLessonPlan(curriculum.getLessonPlan());
			insEntity.setLessonMemo(curriculum.getLessonMemo());
			insEntity.setELink(curriculum.geteLink());
			insEntity.setSLink(curriculum.getsLink());
			insEntity.setLessonName(curriculum.getLessonName());
			insEntity.setUpdUserKey(userInfo.getLoginUserKey());
			insEntity.setUpdDate(DateUtil.getNowTimestamp());

			insEntity = nrLessonTblRepository.saveAndFlush(insEntity);
			if (insEntity == null) {
				throw new RuntimeException("failed to saveAndFlush().");
			}

			for (String subjectCd : curriculum.getLinkageMap().keySet()) {
				NrLessonRelSubjectTbl inRelEntity = new NrLessonRelSubjectTbl();
				inRelEntity.setId(new NrLessonRelSubjectTblPK());

				inRelEntity.getId().setLessonKey(insEntity.getLessonKey());
				inRelEntity.getId().setRubricKey(rubricKey);
				inRelEntity.getId().setSubjectCode(subjectCd);
				inRelEntity.setRelationLevel(curriculum.getLinkageMap().get(subjectCd));
				inRelEntity.setUpdUserKey(userInfo.getLoginUserKey());
				inRelEntity.setUpdDate(DateUtil.getNowTimestamp());

				inRelEntity = nrLessonRelSubjectTblRepository.saveAndFlush(inRelEntity);
				if (inRelEntity == null) {
					throw new RuntimeException("failed to saveAndFlush().");
				}
			}
		}
	}

	@Transactional
	public void updateNrlessonTbl(String rubricKey, CurriculumForm curriculum, UserInfo userInfo) {
		String lessonKey = null;

		// 登録済みかチェク
		if (curriculum.getLessonKey() == null || curriculum.getLessonKey().length() == 0) {
//			lessonKey = getUniqueLessonKey();
		} else {
			lessonKey = curriculum.getLessonKey();

			List<NrLessonRelSubjectTbl> delEntityList = nrLessonRelSubjectTblRepository.findByIdRubricKeyAndIdLessonKey(rubricKey, lessonKey);
			nrLessonRelSubjectTblRepository.delete(delEntityList);
			nrLessonRelSubjectTblRepository.flush();
		}

		// 登録
		NrLessonTbl insEntity = new NrLessonTbl();
		MsPartyTbl partyTbl = msPartyService.findOne(curriculum.getPartyCode());
		insEntity.setParty(partyTbl);

		insEntity.setLessonKey(lessonKey);
		insEntity.setLessonName(curriculum.getLessonName());
		insEntity.setLessonDepartment(curriculum.getLessonDepartment());
		insEntity.setLessonCode(curriculum.getLessonCode());
		insEntity.setUserName(curriculum.getUserName());
		insEntity.setLessonTarget(curriculum.getLessonTarget());
		insEntity.setListenFlag(curriculum.getListenFlag());
		if (StringUtil.isNotNull(curriculum.getLessonDate())) {
			insEntity.setLessonDate(DateUtil.getTimestamp(curriculum.getLessonDate(), CommonConst.DEFAULT_YYYYMMDD));
		}
		insEntity.setLessonPeriod(curriculum.getLessonPeriod());
		insEntity.setRelayFlag(curriculum.getRelayFlag());
		insEntity.setRelayPlace(curriculum.getRelayPlace());
		insEntity.setLessonKbn(curriculum.getLessonKbn());
		insEntity.setUnit(isNumeric(curriculum.getUnit()) ? Integer.parseInt(curriculum.getUnit()) : null);
		insEntity.setUnitInterchangeable(curriculum.getUnitInterchangeable());
		insEntity.setLessonCompulsory(curriculum.getLessonCompulsory());
		insEntity.setLessonBase(curriculum.getLessonBase());
		insEntity.setLessonIntention(curriculum.getLessonIntention());
		insEntity.setLessonPlan(curriculum.getLessonPlan());
		insEntity.setLessonMemo(curriculum.getLessonMemo());
		insEntity.setELink(curriculum.geteLink());
		insEntity.setSLink(curriculum.getsLink());
		insEntity.setLessonName(curriculum.getLessonName());
		insEntity.setUpdUserKey(userInfo.getLoginUserKey());
		insEntity.setUpdDate(DateUtil.getNowTimestamp());

		insEntity = nrLessonTblRepository.saveAndFlush(insEntity);
		if (insEntity == null) {
			throw new RuntimeException("failed to saveAndFlush().");
		}

		relationSkillService.save(userInfo.getLoginUserKey(), CommonConst.RELATION_MODE_LESSON, insEntity.getLessonKey(), curriculum.getSkillJson(), rubricKey);
	}

	/**
	 * ルーブリックに紐づく能力養成科目の一覧を取得する。
	 * @param rKey ルーブリックキー
	 * @return
	 */
	public List<CurriculumForm> searchLessonByRubric (String rKey
			, Map<String, String> partyMap, Map<String, String> targetMap, Map<String, String> listenMap
			, Map<String, String> relayMap, Map<String, String> kbnMap, Map<String, String> compulsorMap) {
		// ルーブリックに紐づく科目情報を抽出
		List<NrLessonRelSubjectTbl> lessonList = nrLessonRelSubjectTblRepository.findByIdRubricKeyOrderByIdLessonKey(rKey);
		List<String> lessonKeyList = new ArrayList<>();
		for (NrLessonRelSubjectTbl lesson : lessonList) {
			lessonKeyList.add(lesson.getId().getLessonKey());
		}
		// 科目情報の詳細を取得
		List<NrLessonTbl> lessonDtlList = nrLessonTblRepository.findByLessonKeyInOrderByLessonKeyAsc(lessonKeyList);

		List<CurriculumForm> rtnList = new ArrayList<>();
		for (NrLessonTbl dtl : lessonDtlList) {
			CurriculumForm item = new CurriculumForm();

			// 詳細情報
			copyDtoToForm(dtl, item);
			// ひも付き情報
			List<NrLessonRelSubjectTbl> subjectList = nrLessonRelSubjectTblRepository.findByIdRubricKeyAndIdLessonKey(rKey, item.getLessonKey());
			Map<String, String> map = new HashMap<String, String>();
			for (NrLessonRelSubjectTbl subject : subjectList) {
				map.put(subject.getId().getSubjectCode(), subject.getRelationLevel());
			}
			item.setLinkageMap(map);
			rtnList.add(item);
		}
		return rtnList;
	}

	private void copyDtoToForm (NrLessonTbl tbl, CurriculumForm form) {
		form.setLessonKey(tbl.getLessonKey());
		form.setLessonName(tbl.getLessonName());
		form.setLessonCode(tbl.getLessonCode());
		form.setLessonDepartment(tbl.getLessonDepartment());
		form.setUserName(tbl.getUserName());
		form.setLessonTarget(tbl.getLessonTarget());
		form.setListenFlag(tbl.getListenFlag());
		if (tbl.getLessonDate() != null) {
			form.setLessonDate(DateUtil.getDate(tbl.getLessonDate(), CommonConst.DEFAULT_YYYYMMDD));
		}
		form.setLessonPeriod(tbl.getLessonPeriod());
		form.setRelayFlag(tbl.getRelayFlag());
		form.setRelayPlace(tbl.getRelayPlace());
		form.setLessonKbn(tbl.getLessonKbn());
		form.setUnit(tbl.getUnit() != null ? Integer.toString(tbl.getUnit()) : null);
		form.setUnitInterchangeable(tbl.getUnitInterchangeable());
		form.setLessonCompulsory(tbl.getLessonCompulsory());
		form.setLessonBase(tbl.getLessonBase());
		form.setLessonIntention(tbl.getLessonIntention());
		form.setLessonPlan(tbl.getLessonPlan());
		form.setLessonMemo(tbl.getLessonMemo());
		form.seteLink(tbl.getELink());
		form.setsLink(tbl.getSLink());
		form.setPartyCode(tbl.getParty().getPartyCode());
		form.setPartyName(tbl.getParty().getPartyName());

	}

	/**
	 * 養成科目への紐付き情報を取得する
	 * @param rKey ルーブリックキー
	 * @param lessonKey 科目キー
	 * @return
	 */
	public List<NrLessonRelSubjectTbl> searchRelSubjectInfo (String rKey, String lessonKey) {
		return nrLessonRelSubjectTblRepository.findByIdRubricKeyAndIdLessonKey(rKey, lessonKey);
	}

	@Transactional
	public void deleteAllForLesson (List<String> lessonKeyList) {
		for (String lessonKey : lessonKeyList) {
			// 能力養成科目 養成能力リレーション から削除
			List<NrLessonRelSubjectTbl> relSubList = nrLessonRelSubjectTblRepository.findByIdLessonKey(lessonKey);
			nrLessonRelSubjectTblRepository.delete(relSubList);

			// 履修紐付け
			List<NrLessonCourseTbl> lessonCoueseList =  nrLessonCourseTblRepository.findByIdLessonKey(lessonKey);
			nrLessonCourseTblRepository.delete(lessonCoueseList);
		}
	}

	/**
	 * @param lessonInfo
	 * @param partyInfo
	 * @return
	 */
	private CurriculumForm setCurriculumFormByLessonAndParty(NrLessonTbl lessonInfo, MsPartyTbl partyInfo) {
		CurriculumForm curriculumForm = new CurriculumForm();

		curriculumForm.setLessonKey(lessonInfo.getLessonKey());
		curriculumForm.setLessonName(lessonInfo.getLessonName());
		curriculumForm.setPartyCode(lessonInfo.getParty().getPartyCode());
		curriculumForm.setPartyName(partyInfo.getPartyName());
		curriculumForm.setLessonDepartment(lessonInfo.getLessonDepartment());
		curriculumForm.setUserName(lessonInfo.getUserName());
		curriculumForm.setLessonTarget(lessonInfo.getLessonTarget());
		curriculumForm.setListenFlag(lessonInfo.getListenFlag());
		curriculumForm.setLessonDate(lessonInfo.getLessonDate() == null ? null : DateUtil.getDate(lessonInfo.getLessonDate(), CommonConst.DEFAULT_YYYYMMDD));
		curriculumForm.setLessonPeriod(lessonInfo.getLessonPeriod());
		curriculumForm.setRelayFlag(lessonInfo.getRelayFlag());
		curriculumForm.setRelayPlace(lessonInfo.getRelayPlace());
		curriculumForm.setLessonKbn(lessonInfo.getLessonKbn());
		curriculumForm.setUnit(lessonInfo.getUnit() == null ? null : Integer.toString(lessonInfo.getUnit()));
		curriculumForm.setUnitInterchangeable(lessonInfo.getUnitInterchangeable());
		curriculumForm.setLessonCompulsory(lessonInfo.getLessonCompulsory());
		curriculumForm.setLessonBase(lessonInfo.getLessonBase());
		curriculumForm.setLessonIntention(lessonInfo.getLessonIntention());
		curriculumForm.setLessonPlan(lessonInfo.getLessonPlan());
		curriculumForm.setLessonMemo(lessonInfo.getLessonMemo());
		curriculumForm.seteLink(lessonInfo.getELink());
		curriculumForm.setsLink(lessonInfo.getSLink());
		curriculumForm.setUpdDate(lessonInfo.getUpdDate());

		return curriculumForm;
	}

	private boolean isNumeric (String str) {
		if (str == null) {
			return false;
		}

		boolean rtn = false;
		try {
			Integer.parseInt(str);
			rtn = true;
		} catch (NumberFormatException e) {
			rtn = false;
		}

		return rtn;
	}
}
