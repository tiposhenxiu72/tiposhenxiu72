package jp.co.sraw.file;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonService;
import jp.co.sraw.util.StringUtil;

public class UploadCtrlBean extends CommonService {

	@Autowired
	private FileService fileService;

	private String actionName = CommonConst.FILE_ACTION_NONE;

	private UploadForm form = null;

	public UploadForm getForm() {
		return form;
	}

	public void setForm(UploadForm form) {
		this.form = form;
	}

	@Override
	protected void init() {
		// TODO 自動生成されたメソッド・スタブ

	}

	private boolean hasUploadFile;

	public boolean isHasUploadFile() {
		return hasUploadFile;
	}

	public void setHasUploadFile(boolean hasUploadFile) {
		this.hasUploadFile = hasUploadFile;
	}

	/**
	 *
	 * @param request
	 * @return
	 */
	public int beoforeProcess(MultipartHttpServletRequest request) {

		List<FileDto> fileList = new ArrayList<>();

		String fieldName = form.getFieldName();

		if (StringUtil.isNull(fieldName)) {
			return 1;
		}

		List<MultipartFile> fList = request.getFiles(fieldName);
		//
		for (MultipartFile file : fList) {
			//
			if (file.getSize() > 0) {
				//
				hasUploadFile = true;
				String fileName = file.getOriginalFilename();
				File dummy = new File(fileName);
				fileName = dummy.getName();
				// 新規ファイル作成
				FileDto fileDto = new FileDto();
				fileDto.setFieldName(fieldName);
				fileDto.setCalcVolumn(form.getCalcVolumn());
				fileDto.setUploadName(fileName);
				fileDto.SetFileKbn("99");
				if (StringUtil.isNotNull(form.getFileKbn())) {
					fileDto.SetFileKbn(form.getFileKbn());
				}
				fileDto.setFile(file);
				fileList.add(fileDto);
			}
		}

		if (form.getPageMode().equals(CommonConst.PAGE_MODE_EDIT)) {

			// 先回のアップロードファイルが必要です
			if (form.getFileNotNull()) {
				if (form.getPreUploadFileList().size() == 0) {
					// 必要なファイルが存在しません。
					return 1;
				}
				// 本回のアップロードファイルが必要です
				if (hasUploadFile) {
					// アップロードファイルがあるの場合
					actionName = CommonConst.FILE_ACTION_CHANGE;
				} else {
					if (StringUtil.isNotNull(form.getFileTextName())) {
						// アップロードファイルがないの場合
						actionName = CommonConst.FILE_ACTION_NONE;
					} else {
						actionName = CommonConst.FILE_ACTION_DEL;
					}
				}

			} else {
				if (form.getPreUploadFileList().size() == 0) {
					if (hasUploadFile) {
						actionName = CommonConst.FILE_ACTION_ADD;
					} else {
						actionName = CommonConst.FILE_ACTION_NONE;
					}
				} else {
					if (hasUploadFile) {
						// アップロードファイルがないの場合
						actionName = CommonConst.FILE_ACTION_CHANGE;
					} else {
						if (StringUtil.isNotNull(form.getFileTextName())) {
							// アップロードファイルがないの場合
							actionName = CommonConst.FILE_ACTION_NONE;
						} else {
							actionName = CommonConst.FILE_ACTION_DEL;
						}
					}
				}
			}

		} else {
			// 新規の場合
			if (form.getFileNotNull()) {
				// アップロードファイルが必要の場合
				if (hasUploadFile) {
					actionName = CommonConst.FILE_ACTION_ADD;
				} else {
					// アップロードファイルがない
					return 1;
				}
			} else {
				if (hasUploadFile) {
					actionName = CommonConst.FILE_ACTION_ADD;
				}
			}
		}

		if (actionName.equals(CommonConst.FILE_ACTION_ADD) || actionName.equals(CommonConst.FILE_ACTION_CHANGE)) {

			List<FileDto> uploadFileList = fileService.publicUploadFileList(form.getUserInfo().getTargetUserKey(),
					form.getUserInfo().getLoginUserKey(), fileList);

			if (uploadFileList.size() == 0) {
				return 1;
			} else {
				form.setUploadFileList(uploadFileList);
			}
		}
		return 0;
	}

	/**
	 *
	 */
	public void afterProcessFailure() {
		// 編集の場合はエラーがある
		if (actionName.equals(CommonConst.FILE_ACTION_ADD) || actionName.equals(CommonConst.FILE_ACTION_CHANGE)) {
			for (FileDto dto : form.getUploadFileList()) {
				fileService.deleteUploadFile(dto.getUploadKey());
			}
		}
	}

	/**
	 *
	 */
	public void afterProcessSuccess() {
		// 成功するで
		if (actionName.equals(CommonConst.FILE_ACTION_CHANGE) || actionName.equals(CommonConst.FILE_ACTION_DEL)) {
			for (FileDto dto : form.getPreUploadFileList()) {
				fileService.deleteUploadFile(dto.getUploadKey());
			}
		}
	}

}
