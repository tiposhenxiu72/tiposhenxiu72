/*
* ファイル名：InternshipServiceImpl.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonService;
import jp.co.sraw.common.UserInfo;
import jp.co.sraw.controller.internship.InternshipForm;
import jp.co.sraw.controller.internship.ItInternRecruitForm;
import jp.co.sraw.controller.internship.SelectPassForm;
import jp.co.sraw.dto.InternshipViewDto;
import jp.co.sraw.dto.MsCodeDto;
import jp.co.sraw.entity.CmBatchTargetTbl;
import jp.co.sraw.entity.CmBatchTargetTblPK;
import jp.co.sraw.entity.CmInfoPublicTbl;
import jp.co.sraw.entity.CmInfoPublicTblPK;
import jp.co.sraw.entity.CmInfoTbl;
import jp.co.sraw.entity.ItInternPublicTbl;
import jp.co.sraw.entity.ItInternPublicTblPK;
import jp.co.sraw.entity.ItInternRecruitTbl;
import jp.co.sraw.entity.ItInternRecruitTblPK;
import jp.co.sraw.entity.ItInternRecruitUploadTbl;
import jp.co.sraw.entity.ItInternRecruitUploadTblPK;
import jp.co.sraw.entity.ItInternRecruitView;
import jp.co.sraw.entity.ItInternRelSubjectTbl;
import jp.co.sraw.entity.ItInternTbl;
import jp.co.sraw.entity.ItInternUploadTbl;
import jp.co.sraw.entity.ItInternUploadTblPK;
import jp.co.sraw.entity.ItInternView;
import jp.co.sraw.entity.UsInfoTbl;
import jp.co.sraw.entity.UsInternshipTbl;
import jp.co.sraw.entity.UsInternshipTblPK;
import jp.co.sraw.entity.UsUserTbl;
import jp.co.sraw.file.FileDto;
import jp.co.sraw.file.FileService;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.repository.CmBatchTargetTblRepository;
import jp.co.sraw.repository.CmInfoPublicTblRepository;
import jp.co.sraw.repository.CmInfoTblRepository;
import jp.co.sraw.repository.ItInternPublicTblRepository;
import jp.co.sraw.repository.ItInternRecruitTblRepository;
import jp.co.sraw.repository.ItInternRecruitUploadTblRepository;
import jp.co.sraw.repository.ItInternRecruitViewRepository;
import jp.co.sraw.repository.ItInternRelSubjectTblRepository;
import jp.co.sraw.repository.ItInternTblRepository;
import jp.co.sraw.repository.ItInternUploadTblRepository;
import jp.co.sraw.repository.ItInternViewRepository;
import jp.co.sraw.repository.UsInfoTblRepository;
import jp.co.sraw.repository.UsInternshipTblRepository;
import jp.co.sraw.security.Role;
import jp.co.sraw.util.DateUtil;
import jp.co.sraw.util.DbUtil;
import jp.co.sraw.util.StringUtil;

/**
 * <B>EventServiceクラス</B>
 * <P>
 * ユーザーサービスのメソッドを提供する
 */
@Scope("prototype")
@Service
@Transactional(readOnly = false)
public class InternshipServiceImpl extends CommonService {

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(InternshipServiceImpl.class);

	@Autowired
	private ItInternViewRepository itInternViewRepository;

	@Autowired
	private ItInternRecruitViewRepository itInternRecruitViewRepository;

	@Autowired
	private ItInternTblRepository itInternTblRepository;

	@Autowired
	private ItInternUploadTblRepository itInternUploadTblRepository;

	@Autowired
	private ItInternPublicTblRepository itInternPublicTblRepository;

	@Autowired
	private ItInternRecruitTblRepository itInternRecruitTblRepository;

	@Autowired
	private ItInternRecruitUploadTblRepository itInternRecruitUploadTblRepository;

	@Autowired
	private ItInternRelSubjectTblRepository itInternRelSubjectTblRepository;

	@Autowired
	private CmInfoTblRepository cmInfoTblRepository;

	@Autowired
	private CmInfoPublicTblRepository cmInfoPublicTblRepository;

	@Autowired
	private CmBatchTargetTblRepository cmBatchTargetTblRepository;

	@Autowired
	private UsInfoTblRepository usInfoTblRepository;

	@Autowired
	private FileService fileService;

	public static final String SEARCH_DATE_TYPE_BATCH = "batch"; // batch処理
	public static final String SEARCH_DATE_TYPE_CURRENT = "current"; // 公開期間中
	public static final String SEARCH_DATE_TYPE_PAST = "past"; // 過去情報
	public static final String SEARCH_DATE_TYPE_PRESENT = "present"; // 終了前
	public static final String SEARCH_DATE_TYPE_LIST = "list"; // 情報閲覧（一覧）
	public static final String SEARCH_DATE_TYPE_APPLICANT = "applicant"; // 応募状況一覧

	public static final String SEARCH_VIEW_TYPE_1 = "1"; // 個人ユーザの権限
	public static final String SEARCH_VIEW_TYPE_2 = "2"; // HIRAKU 運営協議会事務局の権限
	public static final String SEARCH_VIEW_TYPE_3 = "3"; // 共同実施機関窓口（山大・徳大）、連携大学の権限
	public static final String SEARCH_VIEW_TYPE_4 = "4"; // 連携期間窓口（企業、研究所）の権限

	public static final String INFO_URL= "/mgmt/internship/list"; // お知らせURL

	// インターンシップ区分
	private static final String KBN = "0002";

	private static final String DECISION_KBN = "0026"; // 定数区分[0026]＝0:未判定。1:合格。2:不合格。3:辞退。

	private static final String PUBLIC_FLAG = "1"; // 固定値: 公開

	@PostConstruct
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	public List<FileDto> getRcFileList(InternshipForm form, UserInfo userInfo) {
		return getUploadFileList(userInfo.getTargetUserKey(), form.getInternshipKey(), "rcFiles", "1");
	}

	public List<FileDto> getGkFileList(InternshipForm form, UserInfo userInfo) {
		return getUploadFileList(userInfo.getTargetUserKey(), form.getInternshipKey(), "gkFiles", "2");
	}

	/**
	 *
	 * @param form
	 * @param userInfo
	 * @return
	 */
	private List<FileDto> getUploadFileList(String userKey, String internshipKey, String fieldName, String fileKbn) {
		logger.infoCode("I0001");

		List<FileDto> uploadFileList = new ArrayList<>();
		try {
			List<ItInternUploadTbl> uploadTblList = getInternUploadFileList(internshipKey, fileKbn);

			for (ItInternUploadTbl tbl : uploadTblList) {
				FileDto dto = fileService.getFileUploadDto(tbl.getId().getUploadKey());
				dto.setFieldName(fieldName);
				uploadFileList.add(dto);
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return uploadFileList;
	}

	public List<ItInternUploadTbl> getInternUploadFileList(String internshipKey, String uploadKbn) {

		Specification<ItInternUploadTbl> whereIntershipKey = StringUtil.isNull(internshipKey) ? null
				: new Specification<ItInternUploadTbl>() {
					@Override
					public Predicate toPredicate(Root<ItInternUploadTbl> root, CriteriaQuery<?> query,
							CriteriaBuilder cb) {
						return cb.equal(root.get("id").get("internshipKey"), internshipKey);
					}
				};

		Specification<ItInternUploadTbl> whereUploadKbn = StringUtil.isNull(uploadKbn) ? null
				: new Specification<ItInternUploadTbl>() {
					@Override
					public Predicate toPredicate(Root<ItInternUploadTbl> root, CriteriaQuery<?> query,
							CriteriaBuilder cb) {
						return cb.equal(root.get("uploadKbn"), uploadKbn);
					}
				};
		// Query
		List<ItInternUploadTbl> resultList = itInternUploadTblRepository
				.findAll(Specifications.where(whereIntershipKey).and(whereUploadKbn));
		return resultList;
	}

	/**
	 *
	 * @param form
	 * @param userInfo
	 * @return
	 */
	public List<FileDto> getRecuritUploadFileList(ItInternRecruitForm form, UserInfo userInfo) {
		logger.infoCode("I0001");

		List<FileDto> uploadFileList = new ArrayList<>();
		try {
			ItInternRecruitTblPK pk = new ItInternRecruitTblPK();
			pk.setInternshipKey(form.getInternshipKey());
			pk.setUserKey(form.getUserKey());
			ItInternRecruitTbl entity = new ItInternRecruitTbl();
			entity = this.getOneInternRecruit(pk);

			List<ItInternRecruitUploadTbl> uploadList = entity.getItInternRecruitUploadTbls();

			for (ItInternRecruitUploadTbl tbl : uploadList) {
				FileDto dto = fileService.getFileUploadDto(tbl.getId().getUploadKey());
				dto.SetFileKbn(tbl.getUploadKbn());
				uploadFileList.add(dto);
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return uploadFileList;
	}

	@Transactional
	public boolean exeSelectionUpdate(UserInfo userInfo, SelectPassForm form) {

		Map selectMap = new HashMap();

		for (String key : form.getPassUserArray()) {
			selectMap.put(key, key);
		}

		try {

			InternshipViewDto inernship = this.findOneInternshipView(form.getInternshipKey());

			String internshipKey = inernship.getInternshipKey();

			List<ItInternRecruitView> entityList = findAllItInternRecruitView(internshipKey, null);

			for (ItInternRecruitView rv : entityList) {
				String userKey = rv.getUserKey();

				ItInternRecruitTblPK pk = new ItInternRecruitTblPK();
				pk.setInternshipKey(internshipKey);
				pk.setUserKey(userKey);

				ItInternRecruitTbl entity = this.getOneInternRecruit(pk);
				if (entity == null) {
					throw new Exception();
				}

				// 合否判定 チェックボックスがONの場合、合格（'1'）。OFFの場合、不合格（'2'）を設定する。
				if (selectMap.containsKey(pk.getUserKey())) {
					entity.setDecisionKbn("1");
				} else {
					entity.setDecisionKbn("2");
				}
				// 判定日 現在時刻を設定する。
				entity.setDecisionDate(DateUtil.getNowTimestamp());
				// 判定登録者 ターゲットユーザのユーザキーの値を設定する。
				entity.setDecisionUserKey(userInfo.getLoginUserKey());
				// データ更新日 データ更新日
				entity.setUpdDate(DateUtil.getNowTimestamp());
				// データ更新者 ログイン者のユーザキーの値を設定する。
				entity.setUpdUserKey(userInfo.getLoginUserKey());

				itInternRecruitTblRepository.save(entity);

				// 更新テーブル： ユーザお知らせ情報（画面に表示されているユーザ分）
				// お知らせ情報キー取得シーケンスからお知らせ情報キーを取得する
				UsInfoTbl cmInfo = new UsInfoTbl();
				// 該当データのユーザキー
				UsUserTbl user = new UsUserTbl();
				user.setUserKey(userKey);
				cmInfo.setUsUserTbl(user);
				// 配信日 現在時刻を設定する。
				cmInfo.setSendDate(DateUtil.getNowTimestamp());
				// タイトル 該当データのタイトル
				cmInfo.setTitle(inernship.getInternshipTitle());
				// データ区分 インターンシップ募集（’２’）を設定する。
				cmInfo.setDataKbn("2");
				// 操作区分 合否決定（）を設定する。
				cmInfo.setOpeKbn(CommonConst.OP_ACTION_RESULTS);
				// 参照キー 該当データのインターンシップキー
				cmInfo.setInfoRefKey(internshipKey);
				//リンク先 https://????/internship/application/list　を設定する。
				cmInfo.setUrl("/internship/application/list");
				// 作成ユーザキー ログイン者のユーザキーの値を設定する。
				cmInfo.setMakeUserKey(userInfo.getLoginUserKey());
				// データ更新日 現在時刻を設定する。
				cmInfo.setUpdDate(DateUtil.getNowTimestamp());
				// データ更新者 ログイン者のユーザキーの値を設定する。
				cmInfo.setUpdUserKey(userInfo.getLoginUserKey());
				//
				cmInfo = usInfoTblRepository.save(cmInfo);

				// 合格者、不合格者の全てに対して、繰り返し行う。
				// 登録テーブル：バッチ処理用抽出データ

				CmBatchTargetTbl batch = new CmBatchTargetTbl();
				CmBatchTargetTblPK id = new CmBatchTargetTblPK();
				// 処理日付 現在時刻を設定する。
				id.setMakeDate(DateUtil.getNowTimestamp());
				// データ区分 インターン募集・合格者登録（'23'）を設定する。
				id.setDataKbn("23");
				// 参照キー インターンシップキーを設定する。
				id.setRefDataKey(internshipKey);
				//
				batch.setId(id);
				// お知らせ情報作成フラグ 作成済み（’1’）を設定する。
				batch.setInfoMakeFlag("1");
				// スケジュール情報作成フラグ 作成済み（’1’）を設定する。
				batch.setMailMakeFlag("1");
				// eメール送信済みフラグ 未作成（’０’）を設定する。
				batch.setScheduleMakeFlag("0");
				// 送信対象ユーザキー ターゲットユーザのユーザキー
				batch.setSendUserKey(userKey);
				// 送信対象ロール NULL値を設定する。
				batch.setSendRole(null);
				// 送信対象組織 NULL値を設定する。
				batch.setSendPartyCode(null);
				// データ更新日 現在時刻を設定する。
				batch.setUpdDate(DateUtil.getNowTimestamp());
				// データ更新者 ログイン者のユーザキーの値を設定する。
				batch.setUpdUserKey(userInfo.getLoginUserKey());
				//
				batch = cmBatchTargetTblRepository.save(batch);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

		return true;
	}

	/**
	 *
	 * @param list
	 * @param locale
	 * @return
	 */
	public List<InternshipViewDto> getDtoList(List<ItInternTbl> list, Locale locale) {
		List<InternshipViewDto> dtoList = new ArrayList<>();

		for (int i = 0; i < list.size(); i++) {
			InternshipViewDto dto = new InternshipViewDto();
			dto = (InternshipViewDto) objectUtil.getObjectCopyValue(dto, list.get(i));
			dtoList.add(dto);
		}
		return dtoList;
	}

	/**
	 *
	 * @param userInfo
	 * @param locale
	 * @return
	 */
	public Map<String, List<InternshipViewDto>> getDataList(UserInfo userInfo, Locale locale) {

		Map<String, List<InternshipViewDto>> mapList = new HashMap<String, List<InternshipViewDto>>();

		List<MsCodeDto> kbnList = DbUtil.getJosuList(KBN, locale);

		List<ItInternView> resultList = new ArrayList<>();

		String type = SEARCH_VIEW_TYPE_1;
		String searchPartyCode = userInfo.getTargetPartyCode();
		String searchRole = null;
		String searchPublicFlag = PUBLIC_FLAG;

		if (userInfo.isMgmt1()) {
			// 事務局
			type = SEARCH_VIEW_TYPE_2;
			searchPublicFlag = null;
		} else if (userInfo.isMgmt2() || userInfo.isMgmt3()) {
			// 共同実施機関窓口、連携大学
			type = SEARCH_VIEW_TYPE_3;
		} else if (userInfo.isMgmt4()) {
			// 上記以外
			type = SEARCH_VIEW_TYPE_4;
		}

		resultList = this.findAllInternshipView(type, searchPartyCode, searchRole, searchPublicFlag, SEARCH_DATE_TYPE_APPLICANT);

		// 区分から一覧を生成
		for (int i = 0; i < kbnList.size(); i++) {
			MsCodeDto dto = kbnList.get(i);
			//
			List<InternshipViewDto> inteList = new ArrayList<InternshipViewDto>();
			for (int j = 0; j < resultList.size(); j++) {
				ItInternView itInternView = resultList.get(j);
				// 区分毎に振り分け
				if (itInternView.getInternshipKbn().contains(dto.getCode())) {
					InternshipViewDto row = getViewDto(itInternView);
					inteList.add(row);
				}
			}
			mapList.put(dto.getCode(), inteList);
		}
		return mapList;
	}

	/**
	 *
	 * @param itInternView
	 * @return
	 */
	public InternshipViewDto getViewDto(ItInternView itInternView) {
		if (itInternView == null)
			return null;
		InternshipViewDto row = new InternshipViewDto();
		row.setInternshipKey(itInternView.getInternshipKey());
		row.setInternshipKbn(itInternView.getInternshipKbn());
		row.setEventUnit(itInternView.getEventUnit());
		row.setInternshipEndDate(itInternView.getInternshipEndDate());
		row.setPartyCode(itInternView.getPartyCode());
		row.setSubjectInsKbn(itInternView.getSubjectInsKbn());
		row.setInternshipTelno(itInternView.getInternshipTelno());
		row.setInternshipRange(itInternView.getInternshipRange());
		row.setInternshipStartDate(itInternView.getInternshipStartDate());
		row.setInternshipMemo(itInternView.getInternshipMemo());
		row.setUpdDate(itInternView.getUpdDate());
		row.setUpdUserKey(itInternView.getUpdUserKey());
		row.setInternshipGkFileNeedKbn(itInternView.getInternshipGkFileNeedKbn());
		row.setInternshipTitle(itInternView.getInternshipTitle());
		row.setPartyName(itInternView.getPartyName());
		row.setPublicFlag(itInternView.getPublicFlag());
		row.setInternshipSendDate(itInternView.getInternshipSendDate());
		row.setInternshipRcFileNeedKbn(itInternView.getInternshipRcFileNeedKbn());
		row.setPartyNameEn(itInternView.getPartyNameEn());
		row.setInternshipPartyName(itInternView.getInternshipPartyName());
		return row;
	}

	public List<ItInternRecruitView> findAllItInternRecruitView(String internshipKey, String userKey) {

		// 取得条件：インターンシップキー
		Specification<ItInternRecruitView> whereIntershipKey = StringUtil.isNull(internshipKey) ? null
				: new Specification<ItInternRecruitView>() {
					@Override
					public Predicate toPredicate(Root<ItInternRecruitView> root, CriteriaQuery<?> query,
							CriteriaBuilder cb) {
						return cb.equal(root.get("internshipKey"), internshipKey);
					}
				};
		// 取得条件：ユーザキー
		Specification<ItInternRecruitView> whereUserKey = StringUtil.isNull(userKey) ? null
				: new Specification<ItInternRecruitView>() {
					@Override
					public Predicate toPredicate(Root<ItInternRecruitView> root, CriteriaQuery<?> query,
							CriteriaBuilder cb) {
						return cb.equal(root.get("userKey"), userKey);
					}
				};

		Sort orderSort = new Sort(Sort.Direction.DESC, "internshipSendDate");
		// Query
		List<ItInternRecruitView> resultList = itInternRecruitViewRepository
				.findAll(Specifications.where(whereIntershipKey).and(whereUserKey), orderSort);

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}

		return resultList;

	}

	public InternshipViewDto findOneInternshipViewDto(String internshipKey) {
		return this.getViewDto(findOneItInternView(internshipKey));
	}

	public ItInternView findOneItInternView(String internshipKey) {

		// Query
		ItInternView itInternView = itInternViewRepository.findOne(internshipKey);

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}

		return itInternView;

	}

	/**
	 * orderBy
	 *
	 * @return
	 */
	private Sort orderBy() {
		// 公開日（降順）
		return new Sort(Sort.Direction.DESC, "internshipSendDate");
	}

	/**
	 * インターンシップ養成能力リレーション
	 *
	 * @return
	 */
	public List<ItInternRelSubjectTbl> findAllItInternRelSubject(String internshipKey) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		// 取得条件：支援制度種別コード
		Specification<ItInternRelSubjectTbl> whereInternshipKey = StringUtil.isNull(internshipKey) ? null
				: new Specification<ItInternRelSubjectTbl>() {
					@Override
					public Predicate toPredicate(Root<ItInternRelSubjectTbl> root, CriteriaQuery<?> query,
							CriteriaBuilder cb) {
						return cb.equal(root.get("id").get("internshipKey"), internshipKey);
					}
				};

		List<ItInternRelSubjectTbl> list = itInternRelSubjectTblRepository
				.findAll(Specifications.where(whereInternshipKey), orderByItInternRelSubject());

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}
		return list;
	}

	/**
	 * orderByItInternRelSubject
	 *
	 * @return
	 */
	private Sort orderByItInternRelSubject() {
		// ルーブリックキー、養成能力コード
		return new Sort("id.rubricKey", "id.subjectCode");
	}

	public List<ItInternView> findAllInternshipView(String type, String searchPartyCode, String searchRole,
			String searchPublicFlag, String searchDateType) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		Date today = DateUtil.toDate(DateUtil.getSysdate("yyyyMMdd"));

		Specification<ItInternView> whereViewType = null;
		if (SEARCH_VIEW_TYPE_1.equals(type)) {
			// 取得条件：個人ユーザの権限（ROLE_USER1、ROLE_USER2、ROLE_USER3、ROLE_USER4）
			// WHERE
			// CURRENT_DATE >= A.INTERNSHIP_START_DATE
			// AND CURRENT_DATE <= A.INTERNSHIP_END_DATE
			// AND A.PUBLIC_FLAG = '1'
			// AND B.PARTY_CODE = :partyCode
			whereViewType = StringUtil.isNull(searchPartyCode) ? null : new Specification<ItInternView>() {
				@Override
				public Predicate toPredicate(Root<ItInternView> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
					return cb.like(root.get("searchPartyCode"), "%[" + searchPartyCode + "]%");
				}
			};
		} else if (SEARCH_VIEW_TYPE_2.equals(type)) {
			// 取得条件：HIRAKU 運営協議会事務局の権限（ROLE_MGMT1）
			// WHERE
			// 無し
			whereViewType = null;
		} else if (SEARCH_VIEW_TYPE_3.equals(type)) {
			// 取得条件：共同実施機関窓口（山大・徳大）、連携大学の権限（ROLE_MGMT2、ROLE_MGMT3）
			// WHERE
			// CURRENT_DATE >= A.INTERNSHIP_START_DATE
			// AND CURRENT_DATE <= A.INTERNSHIP_END_DATE
			// AND A.PUBLIC_FLAG = '1'
			// AND (A.PARTY_CODE = :partyCode OR B.PARTY_CODE = :partyCode)
			whereViewType = StringUtil.isNull(searchPartyCode) ? null : new Specification<ItInternView>() {

				@Override
				public Predicate toPredicate(Root<ItInternView> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
					Predicate predicate = cb.conjunction();
					predicate = cb.and(predicate, cb.equal(root.get("partyCode"), searchPartyCode));
					predicate = cb.or(predicate, cb.like(root.get("searchPartyCode"), "%[" + searchPartyCode + "]%"));
					return predicate;
				}
			};
		} else if (SEARCH_VIEW_TYPE_4.equals(type)) {
			// 取得条件：連携期間窓口（企業、研究所）の権限（ROLE_MGMT4）
			// WHERE
			// CURRENT_DATE >= A.INTERNSHIP_START_DATE
			// AND CURRENT_DATE <= A.INTERNSHIP_END_DATE
			// AND A.PUBLIC_FLAG = '1'
			// AND (A.PARTY_CODE = ? OR B.ROLE = ?)
			whereViewType = (StringUtil.isNull(searchPartyCode) || StringUtil.isNull(searchRole)) ? null
					: new Specification<ItInternView>() {
						@Override
						public Predicate toPredicate(Root<ItInternView> root, CriteriaQuery<?> query,
								CriteriaBuilder cb) {
							Predicate predicate = cb.conjunction();
							predicate = cb.and(predicate, cb.equal(root.get("partyCode"), searchPartyCode));
							predicate = cb.or(predicate, cb.like(root.get("searchRole"), "%[" + searchRole + "]%"));
							return predicate;
						}
					};
		}

		// 取得条件：公開
		Specification<ItInternView> wherePublicFlag = StringUtil.isNull(searchPublicFlag) ? null
				: new Specification<ItInternView>() {
					@Override
					public Predicate toPredicate(Root<ItInternView> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("publicFlag"), searchPublicFlag);
					}
				};

		// 取得条件：日付(期間)
		Specification<ItInternView> whereDate = StringUtil.isNull(searchDateType) ? null
				: new Specification<ItInternView>() {
					@Override
					public Predicate toPredicate(Root<ItInternView> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						// 情報管理（一覧）期間
						if (SEARCH_DATE_TYPE_CURRENT.equals(searchDateType)) {
							Predicate predicate = cb.conjunction();
							predicate = cb.and(predicate,
									cb.greaterThanOrEqualTo(root.get("internshipEndDate").as(Date.class), today));
							return predicate;
						}
						// 情報管理（一覧）過去情報
						if (SEARCH_DATE_TYPE_PAST.equals(searchDateType)) {
							return cb.lessThan(root.get("internshipEndDate").as(Date.class), today);
						}
						// 終了前
						if (SEARCH_DATE_TYPE_PRESENT.equals(searchDateType)) {
							return cb.greaterThanOrEqualTo(root.get("internshipEndDate").as(Date.class), today);
						}
						// 情報閲覧（一覧）
						if (SEARCH_DATE_TYPE_LIST.equals(searchDateType)) {
							Predicate predicate = cb.conjunction();
							predicate = cb.and(predicate,
									cb.lessThanOrEqualTo(root.get("internshipStartDate").as(Date.class), today));
							predicate = cb.and(predicate,
									cb.greaterThanOrEqualTo(root.get("internshipEndDate").as(Date.class), today));
							return predicate;
						}
						// 応募状況一覧
						if (SEARCH_DATE_TYPE_APPLICANT.equals(searchDateType)) {
							Predicate predicate = cb.conjunction();
							predicate = cb.and(predicate,
									cb.lessThanOrEqualTo(root.get("internshipStartDate").as(Date.class), today));
							return predicate;
						}
						return null;
					}
				};

		// Query
		List<ItInternView> resultList = itInternViewRepository
				.findAll(Specifications.where(wherePublicFlag).and(whereDate).and(whereViewType), orderBy());

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}

		return resultList;

	}

	/**
	 *
	 * @param internshipKey
	 * @return
	 */
	public InternshipViewDto findOneInternshipView(String internshipKey) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		// 取得条件：公開
		Specification<ItInternView> whereIntershipKey = StringUtil.isNull(internshipKey) ? null
				: new Specification<ItInternView>() {
					@Override
					public Predicate toPredicate(Root<ItInternView> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("internshipKey"), internshipKey);
					}
				};

		// Query
		List<ItInternView> resultList = itInternViewRepository.findAll(Specifications.where(whereIntershipKey));
		InternshipViewDto dto = null;
		if (resultList.size() > 0) {
			dto = getViewDto(resultList.get(0));
		}

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}

		return dto;

	}

	/**
	 *
	 * @param internshipKey
	 * @return
	 */
	public List<ItInternPublicTbl> findAllInternPublic(String internshipKey) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		// 取得条件：公開
		Specification<ItInternPublicTbl> whereIntershipKey = StringUtil.isNull(internshipKey) ? null
				: new Specification<ItInternPublicTbl>() {
					@Override
					public Predicate toPredicate(Root<ItInternPublicTbl> root, CriteriaQuery<?> query,
							CriteriaBuilder cb) {
						return cb.equal(root.get("id").get("internshipKey"), internshipKey);
					}
				};

		// Query
		List<ItInternPublicTbl> resultList = itInternPublicTblRepository
				.findAll(Specifications.where(whereIntershipKey));

		logger.infoCode("I0002"); // I0002=メソッド終了:{0}

		return resultList;

	}

	public ItInternRecruitTbl getOneInternRecruit(ItInternRecruitTblPK id) {
		return itInternRecruitTblRepository.findOne(id);
	}

	public ItInternRecruitTbl findOneInternRecruit(ItInternRecruitForm form) {
		boolean result = false;

		ItInternRecruitTblPK itInternRecruitTblPK = form.getId();
		// 取得条件
		Specification<ItInternRecruitTbl> whereInternshipKey = StringUtil
				.isNull(itInternRecruitTblPK.getInternshipKey()) ? null : new Specification<ItInternRecruitTbl>() {
					@Override
					public Predicate toPredicate(Root<ItInternRecruitTbl> root, CriteriaQuery<?> query,
							CriteriaBuilder cb) {
						return cb.equal(root.get("id").get("internshipKey"), itInternRecruitTblPK.getInternshipKey());
					}
				};
		Specification<ItInternRecruitTbl> whereUserKey = new Specification<ItInternRecruitTbl>() {
			@Override
			public Predicate toPredicate(Root<ItInternRecruitTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.get("id").get("userKey"), itInternRecruitTblPK.getUserKey());
			}
		};
		Specification<ItInternRecruitTbl> whereUpdDate = new Specification<ItInternRecruitTbl>() {
			@Override
			public Predicate toPredicate(Root<ItInternRecruitTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.get("updDate"), form.getUpdDate());
			}
		};

		ItInternRecruitTbl itInternRecruitTbl = itInternRecruitTblRepository
				.findOne(Specifications.where(whereInternshipKey).and(whereUserKey).and(whereUpdDate));

		return itInternRecruitTbl;
	}

	public ItInternTbl findOneIntern(InternshipForm form) {
		// 取得条件
		Specification<ItInternTbl> whereInternshipKey = StringUtil.isNull(form.getInternshipKey()) ? null
				: new Specification<ItInternTbl>() {
					@Override
					public Predicate toPredicate(Root<ItInternTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("internshipKey"), form.getInternshipKey());
					}
				};
		Specification<ItInternTbl> whereUpdDate = new Specification<ItInternTbl>() {
			@Override
			public Predicate toPredicate(Root<ItInternTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.get("updDate"), form.getUpdDate());
			}
		};

		ItInternTbl itInternTbl = itInternTblRepository
				.findOne(Specifications.where(whereInternshipKey).and(whereUpdDate));

		return itInternTbl;
	}

	public boolean insertInternRecruit(UserInfo userInfo, InternshipForm form) {
		boolean result = false;

		try {
			ItInternRecruitTbl entity = new ItInternRecruitTbl();
			ItInternRecruitTblPK id = new ItInternRecruitTblPK();
			id.setInternshipKey(form.getInternshipKey());
			id.setUserKey(userInfo.getTargetUserKey());
			entity.setId(id);
			entity.setPartyCode(userInfo.getTargetPartyCode());
			entity.setRecruitDate(DateUtil.getNowTimestamp());
			// 未判定（’0’）を設定する。
			entity.setSelectionKbn("0");
			// 応募済み（’0’）を設定する。
			entity.setDecisionKbn("0");
			// インターンシップ応募者添付ファイルにデータを登録している場合、登録有り（’１’）。以外の場合、登録なし（’０’）。
			entity.setRcFileInsKbn(form.getInternshipRcFileNeedKbn());
			// 登録なし（’０’）を設定する。
			entity.setGkFileInsKbn("0");
			// データ更新日現在時刻を設定する。
			entity.setUpdDate(DateUtil.getNowTimestamp());
			// データ更新者 ログイン者のユーザキーの値を設定する。
			entity.setUpdUserKey(userInfo.getLoginUserKey());

			itInternRecruitTblRepository.save(entity);

			List<FileDto> uploadList = form.getRcFileList();
			for (FileDto dto : uploadList) {
				ItInternRecruitUploadTbl uploadTbl = new ItInternRecruitUploadTbl();
				//
				ItInternRecruitUploadTblPK uploadTblPk = new ItInternRecruitUploadTblPK();
				uploadTblPk.setInternshipKey(form.getInternshipKey());
				uploadTblPk.setUserKey(userInfo.getTargetUserKey());
				uploadTblPk.setUploadKey(dto.getUploadKey());
				uploadTbl.setId(uploadTblPk);
				// 応募文書（’１’）を設定する。
				uploadTbl.setUploadKbn("1");
				// データ更新日現在時刻を設定する。
				uploadTbl.setUpdDate(DateUtil.getNowTimestamp());
				// データ更新者 ログイン者のユーザキーの値を設定する。
				uploadTbl.setUpdUserKey(userInfo.getLoginUserKey());
				itInternRecruitUploadTblRepository.save(uploadTbl);
			}

			// Role
			String role = Role.ROLE_MGMT2.getRole();
			if (systemSetting.getHirosimaUnivAcJpPartyCd().equals(userInfo.getTargetPartyCode())) {
				role = Role.ROLE_MGMT1.getRole();
			}
			// お知らせ情報、お知らせ情報公開範囲登録
			if (insertCmInfo(userInfo, //
					form.getInternshipTitle(), //
					form.getInternshipKey(), //
					CommonConst.OP_FUNC_INTERNSHIP_APPLY, //
					"3", // 公開種類
					role, //
					userInfo.getTargetPartyCode())) {

				CmBatchTargetTbl batch2 = new CmBatchTargetTbl();
				CmBatchTargetTblPK pk = new CmBatchTargetTblPK();
				// 処理日付 現在時刻を設定する。
				pk.setMakeDate(DateUtil.getNowTimestamp());
				// データ区分 インターン募集・応募（'22'）を設定する。
				pk.setDataKbn("22");
				// 参照キー インターンシップキーを設定する。
				pk.setRefDataKey(form.getInternshipKey());
				//
				batch2.setId(pk);
				// お知らせ情報作成フラグ 作成済み（’1’）を設定する。
				batch2.setInfoMakeFlag("1");
				// スケジュール情報作成フラグ 未作成（’０’）を設定する。
				batch2.setMailMakeFlag("0");
				// eメール送信済みフラグ 作成済み（’1’）を設定する。
				batch2.setScheduleMakeFlag("1");
				// 送信対象NULL値を設定する。
				batch2.setSendUserKey(null);
				// 送信対象ロール ターゲットユーザの所属が広島大学の場合、HIRAKU
				// 運営協議会事務局（’ROLE_MGMT1’）を設定する。
				// 以外の場合、共同実施機関窓口（山大・徳大）（’ROLE_MGMT2’）を設定する。
				if (systemSetting.getHirosimaUnivAcJpPartyCd().equals(userInfo.getTargetPartyCode())) {
					batch2.setSendRole(Role.ROLE_MGMT1.getRole());
				} else {
					batch2.setSendRole(Role.ROLE_MGMT2.getRole());
				}

				// 送信対象組織 ターゲットユーザの所属コードを設定する。
				batch2.setSendPartyCode(userInfo.getLoginPartyCode());
				// データ更新日 現在時刻を設定する。
				batch2.setUpdDate(DateUtil.getNowTimestamp());
				// データ更新者 ログイン者のユーザキーの値を設定する。
				batch2.setUpdUserKey(userInfo.getLoginUserKey());
				//
				batch2 = cmBatchTargetTblRepository.save(batch2);

				result = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.errorCode("E1008", e); // E1008=更新に失敗しました。{0}
		}

		return result;
	}

	/**
	 * 新規追加、更新
	 *
	 * @param form
	 * @param userInfo
	 * @return
	 */
	@Transactional
	public boolean update(InternshipForm form, UserInfo userInfo) {
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}
		try {

			Timestamp now = DateUtil.getNowTimestamp();

			ItInternTbl entity = this.updateIntern(form, userInfo);

			String internshipKey = entity.getInternshipKey();
			// 添付ファイルある場合登録
			if (form.getRcFileList().size() > 0 || form.getInternshipRcFileNeedKbn().equals("0")) {
				// 削除
				List<ItInternUploadTbl> rclist = this.getInternUploadFileList(internshipKey, "1");
				itInternUploadTblRepository.delete(rclist);
			}

			// 追加文書が有る場合、インターンシップ添付ファイルに登録する。
			for (FileDto dto : form.getRcFileList()) {
				ItInternUploadTbl fileUpload = new ItInternUploadTbl();
				ItInternUploadTblPK pk = new ItInternUploadTblPK();
				pk.setInternshipKey(internshipKey);
				pk.setUploadKey(dto.getUploadKey());
				fileUpload.setId(pk);
				// 応募文書の場合、’１’。合格文書の場合、’２’。
				fileUpload.setUploadKbn("1");
				// データ更新者 ログイン者のユーザキーの値を設定する。
				fileUpload.setUpdUserKey(userInfo.getLoginUserKey());
				// データ更新日 現在時刻を設定する。
				fileUpload.setUpdDate(now);
				itInternUploadTblRepository.save(fileUpload);
			}

			// 添付ファイルある場合登録
			if (form.getGkFileList().size() > 0 || form.getInternshipGkFileNeedKbn().equals("0")) {
				// 削除
				List<ItInternUploadTbl> gklist = this.getInternUploadFileList(internshipKey, "2");
				itInternUploadTblRepository.delete(gklist);
			}

			for (FileDto dto : form.getGkFileList()) {
				ItInternUploadTbl fileUpload = new ItInternUploadTbl();
				ItInternUploadTblPK pk = new ItInternUploadTblPK();
				pk.setInternshipKey(internshipKey);
				pk.setUploadKey(dto.getUploadKey());
				fileUpload.setId(pk);
				// 応募文書の場合、’１’。合格文書の場合、’２’。
				fileUpload.setUploadKbn("2");
				// データ更新者 ログイン者のユーザキーの値を設定する。
				fileUpload.setUpdUserKey(userInfo.getLoginUserKey());
				// データ更新日 現在時刻を設定する。
				fileUpload.setUpdDate(now);
				itInternUploadTblRepository.save(fileUpload);
			}

			// 公開範囲
			if (form.getPageMode().equals(CommonConst.PAGE_MODE_EDIT)) {
				// 削除
				itInternPublicTblRepository.delete(internshipKey);
			}
			List<ItInternPublicTbl> publicList = new ArrayList<>();
			int count = 1;

			// 企業・研究所などがチェックＯＮの場合、１件出力する。
			if (form.getPublicSociety().equals("1")) {
				ItInternPublicTbl tbl = new ItInternPublicTbl();
				ItInternPublicTblPK pk = new ItInternPublicTblPK();
				pk.setInternshipKey(entity.getInternshipKey());
				pk.setSeqNo(count);
				tbl.setId(pk);

				// 企業・研究所等が、設定されている分の出力を行う場合、１：ROLE。
				tbl.setPublicKbn("1");
				// 企業・研究所等が、設定されている分の出力を行う場合、ROLE_MGMT4。
				tbl.setRole(Role.ROLE_MGMT4.getRole());
				// 企業・研究所等が、設定されている分の出力を行う場合、NULL。
				tbl.setPartyCode(null);
				// 現在時刻を設定する。
				tbl.setUpdDate(now);
				// ログイン者のユーザキーの値を設定する。
				tbl.setUpdUserKey(userInfo.getLoginUserKey());
				publicList.add(tbl);
				count = count + 1;
			}
			if (form.getPublicUniversity().equals("2")) {
				// 大學がチェックＯＮの場合、公開範囲（公開）で選択されている件数出力する。
				for (int i = 0; i < form.getPublicPartyList().length; i++) {
					ItInternPublicTbl tbl = new ItInternPublicTbl();
					ItInternPublicTblPK pk = new ItInternPublicTblPK();
					pk.setInternshipKey(entity.getInternshipKey());
					pk.setSeqNo(count);
					tbl.setId(pk);

					// 大學が、設定されている分の出力を行う場合、２：組織。
					tbl.setPublicKbn("2");
					// 大學が、設定されている分の出力を行う場合、NULL。
					tbl.setRole(null);
					// 大學が、設定されている分の出力を行う場合、対象大学の組織コード。
					tbl.setPartyCode(form.getPublicPartyList()[i]);
					// 現在時刻を設定する。
					tbl.setUpdDate(now);
					// ログイン者のユーザキーの値を設定する。
					tbl.setUpdUserKey(userInfo.getLoginUserKey());
					publicList.add(tbl);
					count = count + 1;
				}
			}
			itInternPublicTblRepository.save(publicList);

			// ************************************
			// 能力養成未作成
			// ************************************

			// お知らせ情報
			// 新規、コピー
			boolean result = false;
			if (!CommonConst.PAGE_MODE_EDIT.equals(form.getPageMode())) {
				// お知らせ情報、お知らせ情報公開範囲登録
				//
				result = this.insertCmInfo(userInfo, //
						form.getInternshipTitle(), // タイトル
						internshipKey, // 参照キー
						CommonConst.OP_ACTION_UPDATE, // 操作区分
						"1", // 公開種類
						Role.ROLE_MGMT1.getRole(), // ロール:固定
						null);// 組織コード
			}

			if (!userInfo.isMgmt4() && !CommonConst.PAGE_MODE_EDIT.equals(form.getPageMode())) {
				CmBatchTargetTbl batch = new CmBatchTargetTbl();
				CmBatchTargetTblPK id = new CmBatchTargetTblPK();
				// 処理日付 現在時刻を設定する。
				id.setMakeDate(DateUtil.getNowTimestamp());
				// データ区分 インターン募集・合格者登録（'23'）を設定する。
				id.setDataKbn("21");
				// 参照キー インターンシップキーを設定する。
				id.setRefDataKey(internshipKey);
				//
				batch.setId(id);
				// お知らせ情報作成フラグ 作成済み（’1’）を設定する。
				batch.setInfoMakeFlag("1");
				// スケジュール情報作成フラグ 作成済み（’1’）を設定する。
				batch.setMailMakeFlag("1");
				// eメール送信済みフラグ 未作成（’０’）を設定する。
				batch.setScheduleMakeFlag("0");
				// 送信対象NULL値を設定する。
				batch.setSendUserKey(null);
				// 送信対象ロール HIRAKU 運営協議会事務局（’ROLE_MGMT1’）を設定する。
				batch.setSendRole(Role.ROLE_MGMT1.getRole());
				// 送信対象組織 NULL値を設定する。
				batch.setSendPartyCode(null);
				// データ更新日 現在時刻を設定する。
				batch.setUpdDate(DateUtil.getNowTimestamp());
				// データ更新者 ログイン者のユーザキーの値を設定する。
				batch.setUpdUserKey(userInfo.getLoginUserKey());
				//
				batch = cmBatchTargetTblRepository.save(batch);

			}

			Timestamp sendDate = DateUtil.getTimestamp(form.getInternshipSendDate(), CommonConst.DEFAULT_YYYYMMDD);
			// バッチ処理用抽出データ （当日日付が配信日以降の場合、行う）
			if (sendDate.before(DateUtil.getNowTimestamp())) {

				CmBatchTargetTbl batch2 = new CmBatchTargetTbl();
				CmBatchTargetTblPK pk = new CmBatchTargetTblPK();
				// 処理日付 現在時刻を設定する。
				pk.setMakeDate(DateUtil.getNowTimestamp());
				// データ区分 インターンシップ登録（'2'）を設定する。
				pk.setDataKbn("2");
				// 参照キー インターンシップキーを設定する。
				pk.setRefDataKey(internshipKey);
				//
				batch2.setId(pk);
				// お知らせ情報作成フラグ 作成済み（’1’）を設定する。
				batch2.setInfoMakeFlag("1");
				// スケジュール情報作成フラグ 未作成（’０’）を設定する。
				batch2.setMailMakeFlag("1");
				// eメール送信済みフラグ 作成済み（’1’）を設定する。
				batch2.setScheduleMakeFlag("1");
				// 送信対象NULL値を設定する。
				batch2.setSendUserKey(null);
				// 送信対象ロール NULL値を設定する。
				batch2.setSendRole(null);
				// 送信対象組織 NULL値を設定する。
				batch2.setSendPartyCode(null);
				// データ更新日 現在時刻を設定する。
				batch2.setUpdDate(DateUtil.getNowTimestamp());
				// データ更新者 ログイン者のユーザキーの値を設定する。
				batch2.setUpdUserKey(userInfo.getLoginUserKey());
				//
				batch2 = cmBatchTargetTblRepository.save(batch2);
			}

			logger.infoCode("I0002"); // I0002=メソッド終了:{0}
			return true;

		} catch (Exception e) {
			e.printStackTrace();
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
		}
		return false;
	}

	public ItInternTbl updateIntern(InternshipForm form, UserInfo userInfo) throws Exception {

		try {
			ItInternTbl entity = new ItInternTbl();

			// 更新の場合
			if (CommonConst.PAGE_MODE_EDIT.equals(form.getPageMode())) {
				entity = this.findOneIntern(form);
				if (entity == null) {
					throw new Exception();
				}
			}
			entity.setInternshipKbn(form.getInternshipKbn());
			entity.setInternshipStartDate(DateUtil.formatTimestampStart(
					DateUtil.getTimestamp(form.getInternshipStartDate(), CommonConst.DEFAULT_YYYYMMDD)));
			entity.setInternshipEndDate(DateUtil.formatTimestampStart(
					DateUtil.getTimestamp(form.getInternshipEndDate(), CommonConst.DEFAULT_YYYYMMDD)));
			entity.setInternshipTitle(form.getInternshipTitle());
			entity.setInternshipSendDate(DateUtil.formatTimestampStart(
					DateUtil.getTimestamp(form.getInternshipSendDate(), CommonConst.DEFAULT_YYYYMMDD)));
			entity.setInternshipRange(form.getInternshipRange());
			entity.setInternshipPartyName(form.getInternshipPartyName());
			entity.setInternshipTelno(form.getInternshipTelno());
			entity.setInternshipRcFileNeedKbn(form.getInternshipRcFileNeedKbn());
			entity.setInternshipGkFileNeedKbn(form.getInternshipGkFileNeedKbn());
			entity.setPartyCode(userInfo.getTargetPartyCode());
			entity.setEventUnit(form.getEventUnit());

			// TODO:
			// *****************************************************
			// 養成能力未完成？？？？
			if (StringUtil.isNull(form.getSubjectInsKbn())) {
				entity.setSubjectInsKbn("0");
			} else {
				entity.setSubjectInsKbn(form.getSubjectInsKbn());
			}
			// *****************************************************

			entity.setInternshipMemo(form.getInternshipMemo());

			entity.setBatchStatus(CommonConst.BATCH_STATUS_RUN_YET); // バッチ実行状況用
																		// 0:未処理

			if (userInfo.isMgmt1()) {
				entity.setPublicFlag(form.getPublicFlag());
			} else {
				entity.setPublicFlag("0");
			}
			entity.setUpdDate(DateUtil.getNowTimestamp());
			entity.setUpdUserKey(userInfo.getLoginUserKey());

			entity = itInternTblRepository.save(entity);

			return entity;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Autowired
	UsInternshipTblRepository usInternshipTblRepository;

	/**
	 * インターンシップ派遣情報登録 2． 登録処理 2-3． 登録処理実行
	 *
	 * @param userInfo
	 * @param form
	 * @return
	 * @throws Exception
	 */
	public boolean updateInternRecruit(UserInfo userInfo, ItInternRecruitForm form) {
		boolean result = false;

		try {
			ItInternRecruitTbl entity = new ItInternRecruitTbl();
			entity = this.findOneInternRecruit(form);

			if (entity != null) {
				// SQLを実行し、インターンシップ応募者テーブルのデータの更新を行う。
				entity.setId(form.getId());
				// 応募者学年 応募者学年を設定する。
				entity.setRecruitGrade(form.getRecruitGrade());
				// 応募者指導教員 応募者指導教員を設定する。
				entity.setRecruitTeacher(form.getRecruitTeacher());
				// 応募者派遣先 応募者派遣先を設定する。
				entity.setRecruitPartyName(form.getRecruitPartyName());
				// 企業派遣期間（FROM） 企業派遣期間（FROM）を設定する。
				entity.setRecruitStartDate(DateUtil.formatTimestampStart(
						DateUtil.getTimestamp(form.getRecruitStartDate(), CommonConst.DEFAULT_YYYYMMDD)));
				// 企業派遣期間（TO） 企業派遣期間（TO）を設定する。
				entity.setRecruitEndDate(DateUtil.formatTimestampEnd(
						DateUtil.getTimestamp(form.getRecruitEndDate(), CommonConst.DEFAULT_YYYYMMDD)));
				// 就職状況 就職状況を設定する。
				entity.setRecruitStatus(form.getRecruitStatus());
				// 備考 備考を設定する。
				entity.setRecruitMemo(form.getRecruitMemo());
				// entity.setDecisionKbn("3");
				// entity.setDecisionDate(DateUtil.getNowTimestamp());
				// entity.setDecisionUserKey(userInfo.getLoginUserKey());
				// データ更新日 現在時刻を設定する。
				entity.setUpdDate(DateUtil.getNowTimestamp());
				// データ更新者 ログイン者のユーザキーの値を設定する。
				entity.setUpdUserKey(userInfo.getLoginUserKey());
				itInternRecruitTblRepository.save(entity);

				// SQLを実行し、インターンシップ応募者テーブルのデータの更新を行う。
				UsInternshipTblPK pk = new UsInternshipTblPK();
				// 派遣期間（FROM） 企業派遣期間（FROM）を設定する。
				pk.setFromDate(DateUtil.formatTimestampStart(
						DateUtil.getTimestamp(form.getRecruitStartDate(), CommonConst.DEFAULT_YYYYMMDD)));
				// 派遣期間（TO） 企業派遣期間（TO）を設定する。
				pk.setToDate(DateUtil.formatTimestampEnd(
						DateUtil.getTimestamp(form.getRecruitEndDate(), CommonConst.DEFAULT_YYYYMMDD)));
				// 派遣先名称 応募者派遣先を設定する。
				pk.setPartyName(form.getRecruitPartyName());
				// ユーザキー 入力対象者のユーザキーを設定する。
				pk.setUserKey(userInfo.getTargetUserKey());
				UsInternshipTbl preUsInternshipTbl = usInternshipTblRepository.findOne(pk);
				if (preUsInternshipTbl != null) {
					usInternshipTblRepository.delete(preUsInternshipTbl);
				}

				// SQLを実行し、ユーザインターンシップ実績のデータの登録を行う。
				UsInternshipTbl usInternshipTbl = new UsInternshipTbl();
				usInternshipTbl.setId(pk);
				// 有効／無効フラグ 有効を設定する。
				usInternshipTbl.setUseFlag("");
				// データ更新日 現在時刻を設定する。
				usInternshipTbl.setUpdDate(DateUtil.getNowTimestamp());
				// データ更新者 ログイン者のユーザキーの値を設定する。
				usInternshipTbl.setUpdUserKey(userInfo.getLoginUserKey());

				usInternshipTblRepository.save(usInternshipTbl);
			}
			result = true;

		} catch (Exception e) {
			logger.errorCode("E1008", e); // E1008=更新に失敗しました。{0}
		}

		return result;
	}

	/**
	 * インターンシップ応募者テーブル：辞退
	 *
	 * @param userInfo
	 * @param form
	 * @return
	 * @throws Exception
	 */
	@Transactional
	public boolean refuseInternRecruit(UserInfo userInfo, ItInternRecruitForm form) throws Exception {
		boolean result = false;

		try {
			ItInternRecruitTbl entity = new ItInternRecruitTbl();
			entity = this.findOneInternRecruit(form);

			if (entity != null) {
				// インターンシップ応募者テーブル：辞退
				entity.setId(form.getId());
				// 合否判定 辞退（’３’）を設定する。
				entity.setDecisionKbn("3");
				// 判定日 現在時刻を設定する。
				entity.setDecisionDate(DateUtil.getNowTimestamp());
				// 判定登録者 ターゲットユーザのユーザキーの値を設定する。
				entity.setDecisionUserKey(userInfo.getLoginUserKey());
				// データ更新日 現在時刻を設定する。
				entity.setUpdDate(DateUtil.getNowTimestamp());
				// データ更新者 ログイン者のユーザキーの値を設定する。
				entity.setUpdUserKey(userInfo.getLoginUserKey());
				//
				itInternRecruitTblRepository.save(entity);

				//
				List<FileDto> uList = getRecuritUploadFileList(form, userInfo);

				List<ItInternRecruitUploadTbl> uploadlist = entity.getItInternRecruitUploadTbls();
				// インターンシップ応募者添付ファイル
				itInternRecruitUploadTblRepository.delete(uploadlist);

				for (FileDto dto : uList) {
					fileService.deleteUploadFile(dto.getUploadKey());
				}

				// 登録テーブル： お知らせ情報
				// 登録テーブル： お知らせ情報公開範囲
				// Role
				String role = Role.ROLE_MGMT2.getRole();
				if (systemSetting.getHirosimaUnivAcJpPartyCd().equals(userInfo.getTargetPartyCode())) {
					role = Role.ROLE_MGMT1.getRole();
				}
				result = this.insertCmInfo(userInfo, //
						entity.getItInternTbl().getInternshipTitle(), // タイトル
						form.getInternshipKey(), // 参照キー
						CommonConst.OP_ACTION_UPDATE, // 操作区分
						"3", // 公開種類
						role, // ロール
						userInfo.getTargetPartyCode());// 組織コード

				result = true;
			}

		} catch (Exception e) {
			logger.errorCode("E1008", e); // E1008=更新に失敗しました。{0}
			// rollback
			throw e;
		}

		return result;
	}

	/**
	 *
	 * @param userInfo
	 * @param form
	 * @return
	 */
	@Transactional
	public boolean updateInternRecruitForGohiKeka(UserInfo userInfo, InternshipForm form) {
		boolean result = false;

		try {
			ItInternRecruitTbl entity = new ItInternRecruitTbl();
			ItInternRecruitTblPK id = new ItInternRecruitTblPK();
			id.setInternshipKey(form.getInternshipKey());
			id.setUserKey(userInfo.getTargetUserKey());
			entity = itInternRecruitTblRepository.findOne(id);

			if (entity == null) {
				throw new Exception();
			}
			// 登録有り（’１’）を設定する。
			entity.setGkFileInsKbn("1");
			entity.setUpdDate(DateUtil.getNowTimestamp());
			entity.setUpdUserKey(userInfo.getLoginUserKey());

			itInternRecruitTblRepository.save(entity);

			List<FileDto> fileList = form.getGkFileList();
			for (FileDto dto : fileList) {
				ItInternRecruitUploadTbl uploadTbl = new ItInternRecruitUploadTbl();
				ItInternRecruitUploadTblPK uploadKey = new ItInternRecruitUploadTblPK();
				// 該当データのインターンシップキーを設定する。
				uploadKey.setInternshipKey(form.getInternshipKey());
				// ターゲットユーザのユーザキーの値を設定する。
				uploadKey.setUserKey(userInfo.getTargetUserKey());
				// 共通処理から返却されたファイルアップロードキー設定する。
				uploadKey.setUploadKey(dto.getUploadKey());
				uploadTbl.setId(uploadKey);

				// 合格文書（’２’）を設定する。
				uploadTbl.setUploadKbn("2");

				uploadTbl.setUpdDate(DateUtil.getNowTimestamp());
				uploadTbl.setUpdUserKey(userInfo.getLoginUserKey());
				itInternRecruitUploadTblRepository.save(uploadTbl);
			}
			// Role
			String role = Role.ROLE_MGMT2.getRole();
			if (systemSetting.getHirosimaUnivAcJpPartyCd().equals(userInfo.getTargetPartyCode())) {
				role = Role.ROLE_MGMT1.getRole();
			}
			// お知らせ情報、お知らせ情報公開範囲登録
			if (!insertCmInfo(userInfo, //
					form.getInternshipTitle(), //
					form.getInternshipKey(), //
					CommonConst.OP_ACTION_UPLOAD, //
					"1", //
					role, //
					null)) {
				throw new Exception();
			}

			result = true;

		} catch (Exception e) {
			e.printStackTrace();
			logger.errorCode("E1008", e); // E1008=更新に失敗しました。{0}
		}

		return result;
	}

	/**
	 *
	 * @param userInfo
	 * @param title
	 * @param internshipKey
	 * @param dataKbn
	 * @param opeKbn
	 * @param publicKbn
	 * @param role
	 * @param partyCode
	 * @return
	 */
	public boolean insertCmInfo(UserInfo userInfo, String title, String internshipKey, String opeKbn,
			String publicKbn, String role, String partyCode) {
		boolean result = false;

		try {
			CmInfoTbl entity = new CmInfoTbl();
			entity.setSendDate(DateUtil.getNowTimestamp());
			entity.setTitle(title);
			// データ区分
			entity.setDataKbn("2");
			// 操作区分
			entity.setOpeKbn(opeKbn);
			// 参照キー インターンシップキー取得で取得した値を設定する。
			entity.setInfoRefKey(internshipKey);
			entity.setMakeUserKey(userInfo.getLoginUserKey());
			// https:///????/mgmt/internship/list を設定する。
			entity.setUrl(INFO_URL);
			entity.setUpdDate(DateUtil.getNowTimestamp());
			entity.setUpdUserKey(userInfo.getLoginUserKey());

			entity = cmInfoTblRepository.save(entity);
			String infoKey = entity.getInfoKey();

			if (infoKey != null && StringUtil.isNotNull(infoKey)) {
				CmInfoPublicTbl entitySub = new CmInfoPublicTbl();
				CmInfoPublicTblPK id = new CmInfoPublicTblPK();
				id.setInfoKey(infoKey);
				// 連番 1を設定する
				id.setSeqNo(1);
				entitySub.setId(id);
				// 公開種類
				entitySub.setPublicKbn(publicKbn);
				// ロール HIRAKU 運営協議会事務局（’ROLE_MGMT1’）を設定する。
				entitySub.setRole(role);
				// 組織コード NULL
				entitySub.setPartyCode(null);
				// データ更新日 現在時刻を設定する
				entitySub.setUpdDate(DateUtil.getNowTimestamp());
				// データ更新者 ログイン者のユーザキーの値を設定する。
				entitySub.setUpdUserKey(userInfo.getLoginUserKey());

				cmInfoPublicTblRepository.save(entitySub);

				result = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.errorCode("E1007", e); // E1007=登録に失敗しました。{0}
		}

		return result;
	}

	@Transactional
	public boolean deleteIntern(UserInfo userInfo, InternshipForm form) {
		boolean result = false;

		try {
			ItInternTbl itInternTbl = findOneIntern(form);
			if (itInternTbl == null) {
				throw new Exception();
			}

			//
			List<ItInternRecruitTbl> itInternRecruitTblList = itInternTbl.getItInternRecruitTbls();
			for (ItInternRecruitTbl tbl : itInternRecruitTblList) {
				List<ItInternRecruitUploadTbl> uploadList = tbl.getItInternRecruitUploadTbls();
				itInternRecruitUploadTblRepository.delete(uploadList);
			}
			itInternRecruitTblRepository.delete(itInternRecruitTblList);

			//
			List<ItInternRelSubjectTbl> subjectList = itInternTbl.getItInternRelSubjectTbls();
			itInternRelSubjectTblRepository.delete(subjectList);
			//
			itInternUploadTblRepository.delete(form.getInternshipKey());

			itInternPublicTblRepository.delete(form.getInternshipKey());

			itInternTblRepository.delete(form.getInternshipKey(), form.getUpdDate());

			result = true;

		} catch (Exception e) {
			e.printStackTrace();
			logger.errorCode("E1009", e); // E1009=削除に失敗しました。{0}
		}

		return result;
	}

	public String setValue(Object obj) {
		if (obj == null) {
			return "";
		}
		return String.valueOf(obj);
	}

}
