/*
* ファイル名：UserServiceImpl.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.portfolio.service;

import org.springframework.context.annotation.Scope;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.sraw.controller.portfolio.form.GyDegreeForm;
import jp.co.sraw.entity.GyDegreeTbl;
import jp.co.sraw.repository.GyDegreeTblRepository;

/**
 * <B>DegreeServiceImplクラス</B>
 * <P>
 * ユーザーサービスのメソッドを提供する
 */
@Scope("prototype")
@Service
@Transactional(readOnly = true)
public class DegreeServiceImpl extends PortfolioServiceImpl<GyDegreeTbl, GyDegreeForm, GyDegreeTblRepository> {

	@Override
	public GyDegreeForm getPortfolioForm(GyDegreeTbl tbl) {
		if (tbl == null)
			return null;
		//
		GyDegreeForm dto = new GyDegreeForm();
		dto = (GyDegreeForm) objectUtil.getObjectCopyValue(dto, tbl);
		return dto;
	}


	protected Sort orderBy() {
		// 学位名（昇順）
		return new Sort(Sort.Direction.ASC, "degreename");
	}
}
