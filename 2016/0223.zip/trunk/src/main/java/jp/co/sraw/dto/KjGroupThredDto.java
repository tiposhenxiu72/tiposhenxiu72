package jp.co.sraw.dto;

import java.io.Serializable;
import java.util.List;

public class KjGroupThredDto implements Serializable {

	private String boardGroupKey;

	private String boardName;

	private List<KjThredDto> kjThredDto;

	public String getBoardGroupKey() {
		return boardGroupKey;
	}

	public void setBoardGroupKey(String boardGroupKey) {
		this.boardGroupKey = boardGroupKey;
	}

	public String getBoardName() {
		return boardName;
	}

	public void setBoardName(String boardName) {
		this.boardName = boardName;
	}

	public List<KjThredDto> getKjThredDto() {
		return kjThredDto;
	}

	public void setKjThredDto(List<KjThredDto> kjThredDto) {
		this.kjThredDto = kjThredDto;
	}


}
