/*
* ファイル名：SupportMgmtController.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.internship;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonController;
import jp.co.sraw.dto.InternshipViewDto;
import jp.co.sraw.dto.MsCodeDto;
import jp.co.sraw.entity.ItInternRecruitTbl;
import jp.co.sraw.entity.ItInternRecruitUploadTbl;
import jp.co.sraw.entity.ItInternRecruitView;
import jp.co.sraw.file.DownloadService;
import jp.co.sraw.file.ExcelService;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.service.InternshipServiceImpl;
import jp.co.sraw.util.DateUtil;
import jp.co.sraw.util.DbUtil;
import jp.co.sraw.util.ObjectUtil;

/**
 * <B>InternshipMgmtApplicationControllerクラス</B>
 * <P>
 * Controllerのメソッドを提供する
 */
@Controller
@RequestMapping(CommonConst.PATH_MGMT + "/internship/application")
public class InternshipMgmtApplicationController extends CommonController {

	private static final LoggerWrapper logger = LoggerWrapperFactory
			.getLogger(InternshipMgmtApplicationController.class);

	@Autowired
	private InternshipServiceImpl internshipServiceImpl;

	@Autowired
	private DownloadService dowloadService;

	@Autowired
	private ExcelService<ItInternRecruitView, ItInternRecruitExcelHelper> excelService;

	private static final String ITINTERNRECRUITFORM_NAME = "ItInternRecruitForm";

	private static final String SELECTPASSFORM_NAME = "SelectPassForm";

	private static final String REDIRECT_LIST = "redirect:list";

	private static final String REDIRECT_APPLICANT = "redirect:" + CommonConst.PATH_MGMT
			+ "/internship/application/applicant/list";

	private static final String LIST_PAGE = "internship/mgmt/application/list";

	private static final String APPLICANT_PAGE = "internship/mgmt/application/applicantlist";

	private static final String APPLICANT_EDIT = "internship/mgmt/application/applicantedit";

	private static final String SEL_LIST_PAGE = "internship/mgmt/application/selectionresult";

	private static final String ACTION_URL_UPDATE = "applicant/update";

	// インターンシップ区分
	private static final String KBN = "0002";

	private static final String PUBLIC_FLAG = "1"; // 固定値: 公開

	private ObjectUtil objectUtil = new ObjectUtil();

	@PostConstruct
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	@ModelAttribute(CommonConst.FORM_NAME)
	public InternshipForm setupForm() {
		InternshipForm form = new InternshipForm();
		return form;
	}

	@ModelAttribute(ITINTERNRECRUITFORM_NAME)
	public ItInternRecruitForm setupInternshiprecuitForm() {
		ItInternRecruitForm form = new ItInternRecruitForm();
		return form;
	}

	@ModelAttribute(SELECTPASSFORM_NAME)
	public SelectPassForm setupSelectPassForm() {
		SelectPassForm form = new SelectPassForm();
		return form;
	}

	/**
	 * 一覧画面表示
	 *
	 * @param form
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping({ "/selection/result" })
	public String selectionResult(@ModelAttribute(CommonConst.FORM_NAME) InternshipForm form, Model model,
			Locale locale) {

		logger.warnCode("W1009"); // W1009=URLダイレクトアクセスがありました。

		InternshipViewDto dto = internshipServiceImpl.findOneInternshipViewDto(form.getInternshipKey());

		model.addAttribute("dto", dto);

		List<ItInternRecruitView> entityList = internshipServiceImpl.findAllItInternRecruitView(form.getInternshipKey(),
				null);

		model.addAttribute("list", entityList);

		model.addAttribute("userInfo", userInfo);

		model.addAttribute(CommonConst.FORM_NAME, form);

		return SEL_LIST_PAGE;
	}

	/**
	 * インターンシップ合否結果入力 2． 更新処理
	 *
	 * @param form
	 * @param bindingResult
	 * @param model
	 * @param attributes
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = { "/selection/update" }, method = RequestMethod.POST)
	public String selectionUpdate(@ModelAttribute(SELECTPASSFORM_NAME) SelectPassForm form, BindingResult bindingResult,
			Model model, RedirectAttributes attributes, Locale locale) {
		logger.warnCode("W1009"); // W1009=URLダイレクトアクセスがありました。
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		String key = "internshipKey=" + form.getInternshipKey();
		logger.infoCode("I1009", key); // I1009=入力したデータ。key={0}

		try {

			///////////////////////////////////////////////////////////////////////////////////
			// 2-2． 入力チェック
			if (bindingResult.hasErrors()) {
				if (logger.isDebugEnabled()) {
					logger.debugCode("W1010", bindingResult.getFieldError()); // W1010=Validationチェックエラーがありました。
				}
				model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.valid.data"); // error.data.message.valid.data=入力項目に誤りがあります。

				logger.infoCode("I0002", form.getPageActionUrl()); // I0002=メソッド終了:{0}
				return SEL_LIST_PAGE;
			}

			///////////////////////////////////////////////////////////////////////////////////
			// 2-3． 登録処理実行
			///////////////////////////////////////////////////////////////////////////////////
			if (internshipServiceImpl.exeSelectionUpdate(userInfo, form)) {
				///////////////////////////////////////////////////////////////////////////////////
				// 成功の場合

				// 2-4． 操作履歴を出力する。
				this.operationHistory(CommonConst.OP_FUNC_INTERNSHIP_RESULTS, CommonConst.OP_ACTION_APPLY);
				// DB更新が成功した場合
				logger.infoCode("I1004", key); // I1004=更新しました。{0}
				attributes.addFlashAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.update.success"); // message.data.update.success=データを更新しました。

				// 検索条件
				attributes.addAttribute("internshipKey", form.getInternshipKey());

				logger.infoCode("I0002", form.getPageActionUrl()); // I0002=メソッド終了:{0}

				// 2-5． 画面遷移
				return REDIRECT_APPLICANT;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		// DB更新が失敗した場合
		logger.errorCode("E1007", key); // E1007=登録に失敗しました。{0}
		model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.regist"); // error.data.message.db.regist=登録が失敗しました。

		logger.errorCode("E0014", form.getPageActionUrl()); // E0014=メソッド異常終了:{0}

		//
		InternshipViewDto dto = internshipServiceImpl.findOneInternshipViewDto(form.getInternshipKey());

		model.addAttribute("dto", dto);

		List<ItInternRecruitView> entityList = internshipServiceImpl.findAllItInternRecruitView(form.getInternshipKey(),
				null);

		model.addAttribute("list", entityList);

		model.addAttribute("userInfo", userInfo);

		model.addAttribute(CommonConst.FORM_NAME, form);

		return SEL_LIST_PAGE;
	}

	/**
	 * 一覧画面表示
	 *
	 * @param form
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping({ "", "/", "/list" })
	public String list(@ModelAttribute(CommonConst.FORM_NAME) InternshipForm form, Model model, Locale locale) {

		logger.infoCode("I0001");

		if (logger.isDebugEnabled() && userInfo != null) {
			logger.debug("LoginUserKey=" + userInfo.getLoginUserKey());
			logger.debug("TargetUserKey=" + userInfo.getTargetUserKey());
		}

		List<MsCodeDto> kbnList = DbUtil.getJosuList(KBN, locale);

		Map<String, List<InternshipViewDto>> mapList = internshipServiceImpl.getDataList(userInfo, locale);

		model.addAttribute("kbnList", kbnList);
		model.addAttribute("list", mapList);

		model.addAttribute(CommonConst.FORM_NAME, form);

		// dump
		modelDump(logger, model, "list");

		logger.infoCode("I0002", LIST_PAGE); // I0002=メソッド終了:{0}
		return LIST_PAGE;
	}

	/**
	 * 【応募状況閲覧（応募者一覧） 画面】
	 *
	 * @return
	 */
	@RequestMapping(value = { "/applicant/list", "/applicant/list/{key}" })
	public String applicantlist(@ModelAttribute(CommonConst.FORM_NAME) InternshipForm form, Model model,
			Locale locale) {
		logger.warnCode("W1009"); // W1009=URLダイレクトアクセスがありました。

		InternshipViewDto dto = internshipServiceImpl.findOneInternshipViewDto(form.getInternshipKey());

		model.addAttribute("dto", dto);

		List<ItInternRecruitView> entityList = internshipServiceImpl.findAllItInternRecruitView(form.getInternshipKey(),
				null);

		model.addAttribute("list", entityList);

		model.addAttribute("userInfo", userInfo);

		model.addAttribute(CommonConst.FORM_NAME, form);

		logger.infoCode("I0002", APPLICANT_PAGE); // I0002=メソッド終了:{0}

		return APPLICANT_PAGE;
	}

	/**
	 * 【応募状況閲覧（応募者一覧） 画面】
	 *
	 * @return
	 */
	@RequestMapping(value = { "/applicant/edit" }, method = RequestMethod.POST)
	public String edit(@ModelAttribute(ITINTERNRECRUITFORM_NAME) ItInternRecruitForm form, Model model, Locale locale) {
		logger.warnCode("W1009"); // W1009=URLダイレクトアクセスがありました。

		ItInternRecruitTbl itInternRecruitTbl = internshipServiceImpl.getOneInternRecruit(form.getId());

		if (itInternRecruitTbl == null) {
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.empty.data"); // error.data.message.empty.data=データがありません。
		} else {
			form = (ItInternRecruitForm) objectUtil.getObjectCopyValue(form, itInternRecruitTbl);
			form.setRecruitStartDate(
					DateUtil.getDate(itInternRecruitTbl.getRecruitStartDate(), CommonConst.DEFAULT_YYYYMMDD));
			form.setRecruitEndDate(
					DateUtil.getDate(itInternRecruitTbl.getRecruitEndDate(), CommonConst.DEFAULT_YYYYMMDD));
		}

		// 編集の場合
		form.setPageMode(CommonConst.PAGE_MODE_EDIT);
		form.setPageActionUrl(ACTION_URL_UPDATE); // update

		model.addAttribute(CommonConst.FORM_NAME, form);
		logger.infoCode("I0002", "edit"); // I0002=メソッド終了:{0}

		return APPLICANT_EDIT;
	}

	/**
	 * インターンシップ派遣情報登録 2． 登録処理
	 *
	 * @return
	 */
	@RequestMapping(value = { "/applicant/update" }, method = RequestMethod.POST)
	public String update(@Validated @ModelAttribute(ITINTERNRECRUITFORM_NAME) final ItInternRecruitForm form,
			BindingResult bindingResult, Model model, RedirectAttributes attributes, Locale locale) {
		logger.warnCode("W1009"); // W1009=URLダイレクトアクセスがありました。
		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		String key = "internshipKey=" + form.getInternshipKey();
		logger.infoCode("I1009", key); // I1009=入力したデータ。key={0}

		///////////////////////////////////////////////////////////////////////////////////
		// 2-2． 入力チェック
		if (bindingResult.hasErrors()) {
			if (logger.isDebugEnabled()) {
				logger.debugCode("W1010", bindingResult.getFieldError()); // W1010=Validationチェックエラーがありました。
			}
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.valid.data"); // error.data.message.valid.data=入力項目に誤りがあります。

			logger.infoCode("I0002", form.getPageActionUrl()); // I0002=メソッド終了:{0}
			return APPLICANT_EDIT;
		}

		///////////////////////////////////////////////////////////////////////////////////
		// DB登録
		///////////////////////////////////////////////////////////////////////////////////
		if (internshipServiceImpl.updateInternRecruit(userInfo, form)) {
			///////////////////////////////////////////////////////////////////////////////////
			// 更新の場合
			if (CommonConst.PAGE_MODE_EDIT.equals(form.getPageMode())) {
				// DB更新が成功した場合
				logger.infoCode("I1004", key); // I1004=更新しました。{0}
				attributes.addFlashAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.update.success"); // message.data.update.success=データを更新しました。
			}

			// 2-4． 操作履歴を出力する。
			this.operationHistory(CommonConst.OP_FUNC_INTERNSHIP_RESULTS, CommonConst.OP_ACTION_UPDATE);

			// 検索条件
			attributes.addAttribute("internshipKey", form.getInternshipKey());

			logger.infoCode("I0002", form.getPageActionUrl()); // I0002=メソッド終了:{0}
			return REDIRECT_APPLICANT;
		}

		// DB更新が失敗した場合
		logger.errorCode("E1007", key); // E1007=登録に失敗しました。{0}
		model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.regist"); // error.data.message.db.regist=登録が失敗しました。


		// 編集の場合
		form.setPageMode(CommonConst.PAGE_MODE_EDIT);
		form.setPageActionUrl(ACTION_URL_UPDATE); // update

		model.addAttribute(CommonConst.FORM_NAME, form);

		logger.errorCode("E0014", form.getPageActionUrl()); // E0014=メソッド異常終了:{0}
		return APPLICANT_EDIT;
	}

	/**
	 *
	 * @param form
	 * @param request
	 * @param response
	 * @param model
	 * @param attributes
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = "/download/list", method = RequestMethod.POST)
	@ResponseBody
	public Resource downloadExcel(@ModelAttribute(ITINTERNRECRUITFORM_NAME) final ItInternRecruitForm form,
			HttpServletRequest request, HttpServletResponse response, Model model, RedirectAttributes attributes,
			Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());

		excelService.setXlsTemplateName("internship.xls");
		ItInternRecruitExcelHelper helper = new ItInternRecruitExcelHelper();

		List<ItInternRecruitView> entityList = internshipServiceImpl.findAllItInternRecruitView(form.getInternshipKey(),
				null);

		ByteArrayOutputStream baos = excelService.getExcel(userInfo, entityList, helper);
		if (baos == null) { // 失敗?
			// 500エラーとする。
			logger.errorCode("E0014", "failed to prepare excel file");
			throw new RuntimeException();
		}

		response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + "internship.xls");

		logger.infoCode("I0002");
		return new ByteArrayResource(baos.toByteArray());
	}

	/**
	 * ダイレクトアクセス対策
	 *
	 * @return
	 */
	@RequestMapping(value = { "/edit", "/copy", "/create", "/update", "/delete" }, method = RequestMethod.GET)
	public String redirect() {
		logger.warnCode("W1009"); // W1009=URLダイレクトアクセスがありました。
		return CommonConst.REDIRECT_INDEX;
	}

	/**
	 *
	 * @param request
	 * @param response
	 * @param form
	 * @throws Exception
	 */
	@RequestMapping({ "/download/apply" })
	public void downloadApply(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute(ITINTERNRECRUITFORM_NAME) final ItInternRecruitForm form) throws Exception {
		download(request, response, form, "1");
	}

	/**
	 *
	 * @param request
	 * @param response
	 * @param form
	 * @throws Exception
	 */
	@RequestMapping({ "/download/pass" })
	public void downloadPass(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute(ITINTERNRECRUITFORM_NAME) final ItInternRecruitForm form) throws Exception {
		download(request, response, form, "2");
	}

	/**
	 *
	 * @param request
	 * @param response
	 * @param form
	 * @param fileKbn
	 * @throws IOException
	 */
	private void download(HttpServletRequest request, HttpServletResponse response, ItInternRecruitForm form,
			String fileKbn) throws IOException {

		ServletContext context = request.getServletContext();
		String appPath = context.getRealPath("");
		System.out.println("appPath = " + appPath);

		ItInternRecruitTbl itInternRecruitTbl = internshipServiceImpl.getOneInternRecruit(form.getId());

		List<ItInternRecruitUploadTbl> uploadTabList = itInternRecruitTbl.getItInternRecruitUploadTbls();

		List<String> downloadList = new ArrayList<>();
		for (ItInternRecruitUploadTbl tbl : uploadTabList) {
			if (tbl.getUploadKbn().equals(fileKbn)) {
				downloadList.add(tbl.getId().getUploadKey());
			}
		}

		dowloadService.downloadZip(request, response, userInfo.getLoginUserKey(),
				itInternRecruitTbl.getId().getInternshipKey(), downloadList);

	}

}
