package jp.co.sraw.dto;

import java.io.Serializable;

public class KjBoardRelUserDto implements Serializable {

	private String boardGroupKey;

	private String userKey;

	private String partyCode;

	private String partyName;

	private String partyNameEn;

	private String partyNameAbbr;

	private String partyNameAbbrEn;

	private String affiliationName;

	private String researchSubject;

	private String researchArea;

	private String userFamilyName;

	private String userFamilyNameEn;

	private String userMiddleName;

	private String userMiddleNameEn;

	private String userName;

	private String userNameEn;

	private String userStatusKbn;

	private String mailAddress;

	public KjBoardRelUserDto() {
		super();
	}

	public KjBoardRelUserDto(String userKey, String partyCode, String partyName, String partyNameEn,
							String partyNameAbbr, String partyNameAbbrEn, String affiliationName,
							String researchSubject, String researchArea, String userFamilyName, String userFamilyNameEn,
							String userMiddleName, String userMiddleNameEn, String userName, String userNameEn, String userStatusKbn) {
		super();
		setUserKey(userKey);
		setPartyCode(partyCode);
		setPartyName(partyName);
		setPartyNameEn(partyNameEn);
		setPartyNameAbbr(partyNameAbbr);
		setPartyNameAbbrEn(partyNameAbbrEn);
		setAffiliationName(affiliationName);
		setResearchSubject(researchSubject);
		setResearchArea(researchArea);
		setUserFamilyName(userFamilyName);
		setUserFamilyNameEn(userFamilyNameEn);
		setUserMiddleName(userMiddleName);
		setUserMiddleNameEn(userMiddleNameEn);
		setUserName(userName);
		setUserNameEn(userNameEn);
		setUserStatusKbn(userStatusKbn);
	}

	public String getBoardGroupKey() {
		return boardGroupKey;
	}

	public void setBoardGroupKey(String boardGroupKey) {
		this.boardGroupKey = boardGroupKey;
	}

	public String getUserKey() {
		return userKey;
	}

	public void setUserKey(String userKey) {
		this.userKey = userKey;
	}

	public String getPartyCode() {
		return partyCode;
	}

	public void setPartyCode(String partyCode) {
		this.partyCode = partyCode;
	}

	public String getPartyName() {
		return partyName;
	}

	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}

	public String getPartyNameEn() {
		return partyNameEn;
	}

	public void setPartyNameEn(String partyNameEn) {
		this.partyNameEn = partyNameEn;
	}

	public String getPartyNameAbbr() {
		return partyNameAbbr;
	}

	public void setPartyNameAbbr(String partyNameAbbr) {
		this.partyNameAbbr = partyNameAbbr;
	}

	public String getPartyNameAbbrEn() {
		return partyNameAbbrEn;
	}

	public void setPartyNameAbbrEn(String partyNameAbbrEn) {
		this.partyNameAbbrEn = partyNameAbbrEn;
	}

	public String getAffiliationName() {
		return affiliationName;
	}

	public void setAffiliationName(String affiliationName) {
		this.affiliationName = affiliationName;
	}

	public String getResearchSubject() {
		return researchSubject;
	}

	public void setResearchSubject(String researchSubject) {
		this.researchSubject = researchSubject;
	}

	public String getResearchArea() {
		return researchArea;
	}

	public void setResearchArea(String researchArea) {
		this.researchArea = researchArea;
	}

	public String getUserFamilyName() {
		return userFamilyName;
	}

	public void setUserFamilyName(String userFamilyName) {
		this.userFamilyName = userFamilyName;
	}

	public String getUserFamilyNameEn() {
		return userFamilyNameEn;
	}

	public void setUserFamilyNameEn(String userFamilyNameEn) {
		this.userFamilyNameEn = userFamilyNameEn;
	}

	public String getUserMiddleName() {
		return userMiddleName;
	}

	public void setUserMiddleName(String userMiddleName) {
		this.userMiddleName = userMiddleName;
	}

	public String getUserMiddleNameEn() {
		return userMiddleNameEn;
	}

	public void setUserMiddleNameEn(String userMiddleNameEn) {
		this.userMiddleNameEn = userMiddleNameEn;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserNameEn() {
		return userNameEn;
	}

	public void setUserNameEn(String userNameEn) {
		this.userNameEn = userNameEn;
	}

	public String getUserStatusKbn() {
		return userStatusKbn;
	}

	public void setUserStatusKbn(String userStatusKbn) {
		this.userStatusKbn = userStatusKbn;
	}

	public String getMailAddress() {
		return mailAddress;
	}

	public void setMailAddress(String mailAddress) {
		this.mailAddress = mailAddress;
	}

}
