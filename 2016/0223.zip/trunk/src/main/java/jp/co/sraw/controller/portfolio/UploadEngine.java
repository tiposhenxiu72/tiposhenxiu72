package jp.co.sraw.controller.portfolio;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import eu.medsea.mimeutil.MimeType;
import eu.medsea.mimeutil.MimeUtil;
import jp.co.sraw.common.CommonConst;
import jp.co.sraw.context.AppContextService;
import jp.co.sraw.controller.portfolio.excel.PortfolioExcelHelper;
import jp.co.sraw.controller.portfolio.form.GyUploadForm;
import jp.co.sraw.controller.portfolio.service.MultiHandleServiceImpl;
import jp.co.sraw.dto.MsCodeDto;
import jp.co.sraw.file.FileDto;
import jp.co.sraw.file.FileService;
import jp.co.sraw.file.UploadCtrlBean;
import jp.co.sraw.file.UploadForm;
import jp.co.sraw.util.DbUtil;
import jp.co.sraw.util.StringUtil;

@SuppressWarnings("rawtypes")
@Component("uengine")
public class UploadEngine<C extends PortfolioController, F extends GyUploadForm, S extends MultiHandleServiceImpl, H extends PortfolioExcelHelper>
		extends PortfolioEngine<C, F, S, H> {

	@Autowired
	private FileService fileService;

	@Autowired
	protected AppContextService appContext;

	@SuppressWarnings("unchecked")
	public String editUpload(C controller, S serviceImpl, F form, Model model, RedirectAttributes attributes, Locale locale) {
		String nextUrl = this.edit(controller, serviceImpl, form, model, attributes, locale);
		Map map = (Map) model.asMap();
		form = (F) map.get(CommonConst.FORM_NAME);
		String uploadKey = form.getUploadKey();
		FileDto fileDto = fileService.getFileUploadDto(uploadKey);
		if (fileDto != null) {
			form.setFileName(fileDto.getUploadName());
		}
		return nextUrl;
	}

	/**
	 *
	 * @param controller
	 * @param serviceImpl
	 * @param form
	 * @param request
	 * @param model
	 * @param result
	 * @param attributes
	 * @param locale
	 * @return
	 */
	public String updateUpload(C controller, S serviceImpl, F form, MultipartHttpServletRequest request, Model model,
			BindingResult result, RedirectAttributes attributes, Locale locale) {

		logger.infoCode("I0001");

		String actionName = CommonConst.FILE_ACTION_NONE;

		String preUploadKey = null;
		String uploadKey = null;
		FileDto preFileDto = null;

		List<MsCodeDto> publicFlagList = DbUtil.getJosuList(CODE_PUBLICCODE, locale);
		model.addAttribute("publicFlagList", publicFlagList);

		this.setListToModel(model, "0024", locale);

		this.setListToModel(model, CODE_COMPETITIONMOVE, locale);

		this.setListToModel(model, CODE_LANGUEGE, locale);

		UploadCtrlBean fileBean = appContext.newUploadCtrlBean();

		try {

			Iterator<String> itrator = request.getFileNames();
			MultipartFile mlf = request.getFile(itrator.next());

			UploadForm uploadForm = new UploadForm();
			uploadForm.setCalcVolumn("1");
			uploadForm.setFileNotNull(true);
			uploadForm.setFileKbn(controller.UPLOAD_FILEKBN);
			uploadForm.setUserInfo(userInfo);
			uploadForm.setPageMode(form.getPageMode());

			// 更新の場合
			if (CommonConst.PAGE_MODE_EDIT.equals(form.getPageMode())) {

				GyUploadForm gyUploadForm = (GyUploadForm) serviceImpl.findOne(userInfo, form);
				//
				if (uploadForm == null) {
					// データは見つけることができません
					throw new Exception();
				}

				preUploadKey = gyUploadForm.getUploadKey();
				preFileDto = fileService.getFileUploadDto(preUploadKey);
				List<FileDto> fileList = new ArrayList<>();
				fileList.add(preFileDto);
				uploadForm.setPreUploadFileList(fileList);
			}
			fileBean.setForm(uploadForm);

			if (mlf != null && mlf.getSize() > 0) {
				long addVolumn = mlf.getSize();
				if (preFileDto != null) {
					addVolumn = mlf.getSize() - preFileDto.getSize();
				}
				// 空きはあるか？
				if (!fileService.checkLeftVolumn(userInfo, addVolumn)) {
					// データは見つけることができません
					// 容量制限オーバー
					attributes.addFlashAttribute(CommonConst.PAGE_WARNING_MESSAGE,
							"error.data.message.file.total.max.size"); // error.data.message.file.total.max.size=ファイル合計容量が制限値を越えました。
					model.addAttribute(CommonConst.PAGE_WARNING_MESSAGE, "error.data.message.file.total.max.size"); // error.data.message.file.total.max.size=ファイル合計容量が制限値を越えました。
					throw new Exception();
				}
			}

			//
			if (fileBean.beoforeProcess(request) > 0) {
				model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.valid.data"); // error.data.message.valid.data=入力項目に誤りがあります。
				throw new Exception();
			}

			List<FileDto> fileList = uploadForm.getUploadFileList();
			if (fileList.size() == 0) {
				model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.valid.data"); // error.data.message.valid.data=入力項目に誤りがあります。
				throw new Exception();
			}
			form.setUploadKey(fileList.get(0).getUploadKey());

			String nextUrl = this.update(controller, serviceImpl, form, result, model, attributes, locale);

			if (nextUrl.equals(controller.EDIT_PAGE)) {
				throw new Exception();
			}

			// 成功するで
			fileBean.afterProcessSuccess();

			attributes.addFlashAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.update.success"); // message.data.update.success=データを更新しました。
			model.addAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.update.success"); // message.data.update.success=データを更新しました。

			logger.infoCode("I0002"); // I0002=メソッド終了:{0}
			return nextUrl;

		} catch (Exception ex) {
			ex.printStackTrace();
		}

		// 失敗した場合
		fileBean.afterProcessFailure();

		// DB更新が失敗した場合
		attributes.addFlashAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.regist"); // error.data.message.db.regist=登録が失敗しました。
		model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.regist"); // error.data.message.db.regist=登録が失敗しました。

		model.addAttribute(CommonConst.FORM_NAME, form);
		logger.errorCode("E0014", "updateUpload"); //

		return controller.EDIT_PAGE;

	}

	/**
	 *
	 * @param controller
	 * @param serviceImpl
	 * @param form
	 * @param model
	 * @param attributes
	 * @param locale
	 * @return
	 */
	public String deleteUpload(C controller, S serviceImpl, F form, Model model, RedirectAttributes attributes,
			Locale locale) {

		@SuppressWarnings("unchecked")
		GyUploadForm f = (GyUploadForm) serviceImpl.findOne(userInfo, form);

		boolean errorFlag = false;

		if (f != null && StringUtil.isNotNull(f.getUploadKey())) {

			int deleteResult = fileService.deleteUploadFile(f.getUploadKey());

			// 削除成功は0
			if (deleteResult > 0) {
				errorFlag = true;
			}
		} else {
			errorFlag = true;
		}

		if (errorFlag) {
			attributes.addFlashAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.remove"); // error.data.message.db.remove=削除が失敗しました。
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.remove"); // error.data.message.db.remove=削除が失敗しました。

			model.addAttribute(CommonConst.FORM_NAME, form);
			logger.errorCode("E0014", "deleteUpload"); //

			return controller.REDIRECT_LIST;
		}

		String nextUrl = this.delete(controller, serviceImpl, form, model, attributes, locale);

		attributes.addFlashAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.delete.success"); // message.data.delete.success=データを削除しました。
		model.addAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.delete.success"); // message.data.delete.success=データを削除しました。

		return nextUrl;
	}



	/**
	 *
	 *
	 * @param controller
	 * @param serviceImpl
	 * @param form
	 * @param request
	 * @param response
	 * @param model
	 * @param attributes
	 * @param locale
	 * @return
	 */
	public void download(C controller, S serviceImpl, F form, HttpServletRequest request,
			HttpServletResponse response, Model model, RedirectAttributes attributes, Locale locale) {
		logger.infoCode("I0001", request.getRequestURI());


		ServletOutputStream responseOutputStream = null;
		InputStream in = null;
		try {

			form = (F) serviceImpl.getPortfolioForm(serviceImpl.findOne(form.getGyosekiKey(), controller.userInfo().getTargetUserKey(), null));

			if (form == null) {
				// 正しくなければ404を返す。
				response.sendError(HttpServletResponse.SC_NOT_FOUND);
				return;
			}
			FileDto fileDto = fileService.getFile(form.getUploadKey());
			if (fileDto != null) {
				form.setFileName(fileDto.getUploadName());
				in = new FileInputStream(fileDto.getUploadPath());
				byte[] fileByte = IOUtils.toByteArray(in);

				if (fileByte == null) { // 失敗?
					// 500エラーとする。
					logger.errorCode("E0014", "failed to prepare file");
					throw new RuntimeException();
				}
				// safariの場合
				if (request.getHeader("User-Agent").toUpperCase().indexOf("SAFARI") > -1) {
					response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + new String(fileDto.getUploadName().getBytes(), "ISO-8859-1"));
				} else {
					response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileDto.getUploadName() +";filename*=utf-8''"+ URLEncoder.encode(fileDto.getUploadName(), "UTF-8"));
				}
				setResponseOutputStream(responseOutputStream, response, fileByte);
			}

		} catch (Exception e) {
			;
		} finally {
			try {
				if (responseOutputStream != null) {
					responseOutputStream.close();
				}
				IOUtils.closeQuietly(in);
				if (in != null) {
					in.close();
				}
			} catch (IOException e) {
				;
			}
		}

		logger.infoCode("I0002");
	}


	/**
	 * ファイルデータ(byte[])をMimeTpe判定してレスポンス設定
	 *
	 * @param responseOutputStream
	 * @param response
	 * @param fileByte
	 * @throws IOException
	 */
	private void setResponseOutputStream(ServletOutputStream responseOutputStream, HttpServletResponse response,
			byte[] fileByte) throws IOException {

		// MimeTpe判定
		MimeUtil.registerMimeDetector("eu.medsea.mimeutil.detector.MagicMimeMimeDetector");
		Collection<?> mimeTypes = MimeUtil.getMimeTypes(fileByte);
		String contentType = "application/octet-stream";
		if (!mimeTypes.isEmpty()) {
			Iterator<?> iterator = mimeTypes.iterator();
			MimeType mimeType = (MimeType) iterator.next();
			contentType = mimeType.getMediaType() + "/" + mimeType.getSubType();
		}

		// レスポンスに設定
		response.setHeader("Cache-Control", "no-store");
		response.setHeader("Pragma", "no-cache");
		response.setDateHeader("Expires", 0);
		response.setContentType(contentType);
		response.setCharacterEncoding("utf-8");
		responseOutputStream = response.getOutputStream();
		responseOutputStream.write(fileByte);
		responseOutputStream.flush();

	}

}