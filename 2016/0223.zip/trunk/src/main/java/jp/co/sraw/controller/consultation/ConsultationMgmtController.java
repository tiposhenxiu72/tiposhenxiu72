/*
* ファイル名：ConsultationMgmtController.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/01/15   matsuo      新規作成
*/
package jp.co.sraw.controller.consultation;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonController;
import jp.co.sraw.dto.ConsultationDto;
import jp.co.sraw.dto.MsCodeDto;
import jp.co.sraw.entity.MsPartyTbl;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.service.ConsultationServiceImpl;
import jp.co.sraw.util.DbUtil;

/**
 * <B>ConsultationMgmtControllerクラス</B>
 * <P>
 * Controllerのメソッドを提供する
 */
@Controller
@RequestMapping(CommonConst.PATH_MGMT + "/consultation")
public class ConsultationMgmtController extends CommonController {

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(ConsultationMgmtController.class);

	@Autowired
	private ConsultationServiceImpl servive;

	// URL
	private static final String LIST_PAGE = "consultation/mgmt/list";

	@PostConstruct
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	@ModelAttribute(CommonConst.FORM_NAME)
	public ConsultationForm setupForm() {
		ConsultationForm form = new ConsultationForm();
		return form;
	}

	/**
	 * 面談一覧画面
	 *
	 * @param form
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping({ "", "/", "/list", "/search"})
	public String list(@ModelAttribute(CommonConst.FORM_NAME) ConsultationForm form, Model model, Locale locale) {
		logger.infoCode("I0001", "list"); // I0001=メソッド開始:{0}

		if (logger.isDebugEnabled() && userInfo != null) {
			logger.debug("LoginUserKey=" + userInfo.getLoginUserKey());
			logger.debug("TargetUserKey=" + userInfo.getTargetUserKey());
		}

		// 事務局以外は自組織のみ
		if (!userInfo.hasMgmt1()) {
			form.setSearchParty(userInfo.getTargetPartyCode());
		}

		// 面談一覧情報の取得
		List<ConsultationDto> consulList = servive.findConsulMgmtList(form, locale);

		// 画面出力情報の編集
		List<ConsultationForm> consultationList = new ArrayList<>();
		if (consulList != null) {
			for (ConsultationDto entity : consulList) {
				consultationList.add(servive.getFormItem(locale, entity));
			}
		}

		// 定数マスタLSIT
		List<MsCodeDto> consulStList = DbUtil.getJosuList(ConsultationServiceImpl.CODE_CONSUL_STATUS_KBN, locale);	// 相談状態
		List<MsPartyTbl> partyUnivList = servive.getPartyUnivList(locale, userInfo);								// 組織情報（大学）

		// modelセット
		model.addAttribute("consulStList", consulStList);
		model.addAttribute("partyUnivList", partyUnivList);
		model.addAttribute("consultationList", consultationList);
		model.addAttribute("form", form);

		// dump
		modelDump(logger, model, "list");
		logger.infoCode("I0002", "list"); // I0002=メソッド終了:{0}

		// 面談一覧画面
		return LIST_PAGE;
	}

	/**
	 * ダイレクトアクセス対策
	 *
	 * @return
	 */
	@RequestMapping(value = {"/setting", "/delete", "/registSetting", "/registDelete"}, method = RequestMethod.GET)
	public String redirect() {
		logger.warnCode("W1009"); // W1009=URLダイレクトアクセスがありました。
		return CommonConst.REDIRECT_INDEX;
	}
}
