package jp.co.sraw.repository;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import jp.co.sraw.entity.GyResearchAreaTbl;

@Scope("prototype")
@Repository
public interface GyResearchAreaTblRepository extends GyRepository<GyResearchAreaTbl> {

}
