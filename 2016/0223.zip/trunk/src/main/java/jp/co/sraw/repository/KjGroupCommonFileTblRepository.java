package jp.co.sraw.repository;

import java.sql.Timestamp;

import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import jp.co.sraw.dto.KjGroupCommonFileDto;
import jp.co.sraw.entity.KjGroupCommonFileTbl;
import jp.co.sraw.entity.KjGroupCommonFileTblPK;

@Scope("prototype")
@Repository
public interface KjGroupCommonFileTblRepository extends JpaRepository<KjGroupCommonFileTbl, KjGroupCommonFileTblPK>, JpaSpecificationExecutor<KjGroupCommonFileTbl> {

	@Query(name="KjGroupCommonFileTbl.findCommonFile")
	public KjGroupCommonFileDto findCommonFile(@Param("boardGroupKey") String boardGroupKey, @Param("uploadKey") String uploadKey);

	@Modifying
	@Query(name = "KjGroupCommonFileTbl.delete")
	public int delete(@Param("boardGroupKey") String boardGroupKey, @Param("uploadKey") String uploadKey, @Param("updDate") Timestamp updDate);

}
