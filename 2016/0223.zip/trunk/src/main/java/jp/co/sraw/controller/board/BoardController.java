/*
* ファイル名：BoardController.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/01/21   mizoguchi      新規作成
*/
package jp.co.sraw.controller.board;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonController;
import jp.co.sraw.dto.KjBoardDto;
import jp.co.sraw.dto.KjBoardRelUserDto;
import jp.co.sraw.dto.KjGroupCommonFileDto;
import jp.co.sraw.dto.KjThredContributionDto;
import jp.co.sraw.entity.KjBoardGroupTbl;
import jp.co.sraw.entity.KjBoardRelUser;
import jp.co.sraw.entity.KjGroupCommonFileTbl;
import jp.co.sraw.entity.KjThredTbl;
import jp.co.sraw.file.FileDto;
import jp.co.sraw.file.FileService;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.service.BoardServiceImpl;
import jp.co.sraw.util.DbUtil;
import jp.co.sraw.util.StringUtil;

/**
 * <B>BoardControllerクラス</B>
 * <P>
 * Controllerのメソッドを提供する
 */
@Controller
@EnableAutoConfiguration
@RequestMapping("/board")
public class BoardController extends CommonController {

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(BoardController.class);

	@PostConstruct
	protected void init() {
		logger.setMessageSource(messageSource);
	}
	@Autowired
	private BoardServiceImpl boardServiceImpl;

	@Autowired
	private FileService fileService;

	@ModelAttribute(CommonConst.FORM_NAME)
	public BoardForm setupForm() {
		BoardForm form = new BoardForm();
		return form;
	}

	private static final String REDIRECT_LOGIN = "redirect:/login";
	private static final String REDIRECT_LIST = "redirect:list";
	private static final String REDIRECT_FILE_LIST = "redirect:/board/file/";
	private static final String REDIRECT_THRED_LIST = "redirect:/board/thread/";
	private static final String REDIRECT_THRED_EDIT = "redirect:/board/thread/edit/";
	private static final String LIST_PAGE = "board/list";
	private static final String EDIT_PAGE = "board/edit";
	private static final String FILE_LIST_PAGE = "board/fileList";
	private static final String FILE_EDIT_PAGE = "board/fileEdit";
	private static final String THRED_LIST_PAGE = "board/thredList";
	private static final String THRED_EDIT_PAGE = "board/thredEdit";
	private static final String THRED_CREATE_PAGE = "board/thredCreate";
	private static final String APPROVAL_PAGE = "board/approval";

	private static final String CODE_SYBCODE = "0040"; //ユーザ状態区分コード
	private static final String CODE_COMMON_FILE = "0049"; //ファイル添付区分

	private static final String CODE_STATUSKBN_0 = "0";  //ユーザ状態区分 = 0：承認待ち
	private static final String CODE_STATUSKBN_1 = "1";  //ユーザ状態区分 = 1：承認済
	private static final String CODE_STATUSKBN_2 = "2";  //ユーザ状態区分 = 2：承認拒否

	private static final String CODE_COMMON_FLG_0 = "0";  //共有情報フラグ = 0：添付しない
	private static final String CODE_PUBLIC_FLG_0 = "0";  //公開フラグ = 0：公開しない

	private static final String UPLOAD_FLG_0 = "0";  //アップロードフラグ = 0：未処理
	private static final String UPLOAD_FLG_1 = "1";  //アップロードフラグ = 1：アップロード済み

	/**
	 * 掲示板グループ管理一覧
	 *
	 * @param form
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = { "", "/", "/list" })
	public String index(@ModelAttribute(CommonConst.FORM_NAME) BoardForm form, Model model, Locale locale) {

		logger.infoCode("I0001", "index"); // I0001=メソッド開始:{0}

		if (logger.isDebugEnabled() && userInfo != null) {
			logger.debug("LoginUserKey=" + userInfo.getLoginUserKey());
			logger.debug("TargetUserKey=" + userInfo.getTargetUserKey());
		}

		// 掲示板グループ一覧取得
		this.setKjGroupInfo(form, model);

		// dump
		modelDump(logger, model, "index");
		logger.infoCode("I0002", "index"); // I0002=メソッド終了:{0}

		return LIST_PAGE;
	}


	/**
	 * 掲示板グループ管理  新規作成、編集画面表示、削除処理
	 *
	 * @param form
	 * @param bindingResult
	 * @param model
	 * @param attributes
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public String edit(@ModelAttribute(CommonConst.FORM_NAME) BoardForm form,
			BindingResult bindingResult, Model model, RedirectAttributes attributes, Locale locale) {

		logger.infoCode("I0001", "edit"); // I0001=メソッド開始:{0}

		// 掲示板グループ一覧取得
		this.setKjGroupInfo(form, model);

		// 掲示板グループが選択されていること
		if (CommonConst.PAGE_MODE_EDIT.equals(form.getPageMode()) || CommonConst.PAGE_MODE_DELETE.equals(form.getPageMode())) {
			if (StringUtil.isNull(form.getBoardGroupKey())) {
				model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.select.group"); // error.data.message.select.group=編集・削除したい掲示板グループを選択してください。
				logger.infoCode("I0002", "edit"); // I0002=メソッド終了:{0}
				return LIST_PAGE;
			}
		}

		// 掲示板グループ管理者であること
		if (CommonConst.PAGE_MODE_DELETE.equals(form.getPageMode())) {
			if (!userInfo.getTargetUserKey().equals(form.getAdminUserKey())) {
				model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.not.admin"); // error.data.message.not.admin=グループの管理者しか編集・削除処理できません。
				logger.infoCode("I0002", "edit"); // I0002=メソッド終了:{0}
				return LIST_PAGE;
			}
		}

		// 掲示板グループ管理  新規・編集画面用データ取得
		this.setKjGroupEditInfo(form, model, locale);

		///////////////////////////////////////////////////////////////////////////////////
		// 編集の場合
		///////////////////////////////////////////////////////////////////////////////////
		if (CommonConst.PAGE_MODE_EDIT.equals(form.getPageMode()) && StringUtil.isNotNull(form.getBoardGroupKey())) {
			KjBoardGroupTbl board = boardServiceImpl.getOne(form.getBoardGroupKey());
			if (board != null) {
				form.setBoardGroupKey(board.getBoardGroupKey());
				form.setBoardName(board.getBoardName());
				form.setCommonFlag(board.getCommonFlag());
				form.setPublicFlag(board.getPublicFlag());
				form.setAdminUserKey(board.getAdminUserKey());
				form.setOutline(board.getOutline());
				form.setUpdDate(board.getUpdDate());
				form.setUpdUserKey(board.getUpdUserKey());
				form.setPageMode(CommonConst.PAGE_MODE_EDIT);
				form.setPageActionUrl(CommonConst.ACTION_URL_UPDATE);
			}
			model.addAttribute(CommonConst.FORM_NAME, form);

			modelDump(logger, model, "index");
			logger.infoCode("I0002", "edit"); // I0002=メソッド終了:{0}
			return EDIT_PAGE;
		}

		///////////////////////////////////////////////////////////////////////////////////
		// 新規登録の場合
		///////////////////////////////////////////////////////////////////////////////////
		if (CommonConst.PAGE_MODE_ADD.equals(form.getPageMode())) {
			form = setupForm();
			form.setCommonFlag(CODE_COMMON_FLG_0);
			form.setPublicFlag(CODE_PUBLIC_FLG_0);
			form.setAdminUserKey(userInfo.getTargetUserKey());
			form.setPageMode(CommonConst.PAGE_MODE_ADD);
			form.setPageActionUrl(CommonConst.ACTION_URL_CREATE);
			model.addAttribute(CommonConst.FORM_NAME, form);

			modelDump(logger, model, "index");
			logger.infoCode("I0002", "edit"); // I0002=メソッド終了:{0}
			return EDIT_PAGE;
		}

		///////////////////////////////////////////////////////////////////////////////////
		// 削除の場合
		///////////////////////////////////////////////////////////////////////////////////
		if (CommonConst.PAGE_MODE_DELETE.equals(form.getPageMode()) && StringUtil.isNotNull(form.getBoardGroupKey())) {
			try {
				if (boardServiceImpl.delete(userInfo, form)) {
					// DB更新が成功した場合
					logger.infoCode("I1003", "edit"); // I1003=削除しました。{0}
					// 操作ログ出力
					super.operationHistory(CommonConst.OP_FUNC_BOARD_GROUP, CommonConst.OP_ACTION_DELETE);
					attributes.addFlashAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.delete.success"); // message.data.delete.success=データを削除しました。
					logger.infoCode("I0002", "edit"); // I0002=メソッド終了:{0}
					return REDIRECT_LIST;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			// DB更新が失敗した場合
			logger.errorCode("E1009", "edit"); // E1009=削除に失敗しました。{0}
			attributes.addFlashAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.remove"); // error.data.message.db.remove=削除が失敗しました。
			logger.errorCode("E0014", "edit"); // E0014=メソッド異常終了:{0}
			return REDIRECT_LIST;
		}
		// 項目が選択されていない場合
		model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.not.select"); // error.data.message.not.select=項目が選択されていません。
		logger.errorCode("E0014", "edit"); // E0014=メソッド異常終了:{0}
		return REDIRECT_LIST;
	}


	/**
	 * 検索結果の配列を返却する。
	 *
	 * @param jsonData
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = { "/search" }, consumes=MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<KjBoardRelUserDto> getJsonData(@RequestBody BoardJsonForm jsonData, Locale locale) {
		logger.infoCode("I0001", "getJsonData"); // I0001=メソッド開始:{0}

		//メンバー検索情報取得
		List<KjBoardRelUserDto> searchList = new ArrayList<KjBoardRelUserDto>();
		searchList = boardServiceImpl.findSearchMemberList(jsonData.getParty(), jsonData.getAffiliation(), jsonData.getName());

		List<KjBoardRelUserDto> userList = new ArrayList<KjBoardRelUserDto>();

		for (int i = 0; i < searchList.size(); i++) {
			KjBoardRelUserDto userDto = new KjBoardRelUserDto();
			userDto.setUserKey(searchList.get(i).getUserKey());
			if (CommonConst.DEFAULT_LOCALE.getLanguage().equals(locale.getLanguage())) {
				userDto.setPartyName(searchList.get(i).getPartyName());
				userDto.setAffiliationName(searchList.get(i).getAffiliationName()+
											searchList.get(i).getResearchSubject()+
											searchList.get(i).getResearchArea());
				userDto.setUserName(searchList.get(i).getUserFamilyName()+
									searchList.get(i).getUserMiddleName()+
									searchList.get(i).getUserName());
			} else {
				userDto.setPartyName(searchList.get(i).getPartyNameEn());
				userDto.setAffiliationName(searchList.get(i).getAffiliationName()+
											searchList.get(i).getResearchSubject()+
											searchList.get(i).getResearchArea());
				userDto.setUserName(searchList.get(i).getUserFamilyNameEn()+
									searchList.get(i).getUserMiddleNameEn()+
									searchList.get(i).getUserNameEn());
			}
			userList.add(userDto);
		}

		logger.infoCode("I0002", "getJsonData"); // I0002=メソッド終了:{0}
		return userList;
	}


	/**
	 * 掲示板グループ管理  登録・更新処理
	 *
	 * @param form
	 * @param bindingResult
	 * @param model
	 * @param attributes
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = { "/regist" }, method = RequestMethod.POST)
	public String create(@Validated(BoardForm.group1.class) @ModelAttribute(CommonConst.FORM_NAME) final BoardForm form,
			BindingResult bindingResult, Model model, RedirectAttributes attributes, Locale locale) {

		logger.infoCode("I0001", "create"); // I0001=メソッド開始:{0}

		// 掲示板グループ管理  新規・編集画面用データ取得
		this.setKjGroupEditInfo(form, model, locale);

		/////////////////////////////////////////////////////////////////////////////////
		// バリデーションエラーがある場合
		if (bindingResult.hasErrors()) {
			if (logger.isDebugEnabled()) {
				logger.debugCode("W1010", bindingResult.getFieldError()); // W1010=Validationチェックエラーがありました。
			}
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.valid.data"); // error.data.message.valid.data=入力項目に誤りがあります。
			logger.infoCode("I0002", "create"); // I0002=メソッド終了:{0}
			return EDIT_PAGE;
		}

		///////////////////////////////////////////////////////////////////////////////////
		// DB登録
		///////////////////////////////////////////////////////////////////////////////////
		try {
			if (boardServiceImpl.update(userInfo, form, locale)) {
				// 更新の場合
				if (CommonConst.PAGE_MODE_EDIT.equals(form.getPageMode())) {
					// DB更新が成功した場合
					logger.infoCode("I1004", "create"); // I1004=更新しました。{0}
					// 操作ログ出力
					super.operationHistory(CommonConst.OP_FUNC_BOARD_GROUP, CommonConst.OP_ACTION_UPDATE);
					attributes.addFlashAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.update.success"); // message.data.update.success=データを更新しました。
				}
				// 新規追加の場合
				if (CommonConst.PAGE_MODE_ADD.equals(form.getPageMode())) {
					// DB更新が成功した場合
					logger.infoCode("I1005", "create"); // I1005=新規作成しました。{0}
					// 操作ログ出力
					super.operationHistory(CommonConst.OP_FUNC_BOARD_GROUP, CommonConst.OP_ACTION_INSERT);
					attributes.addFlashAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.create.success"); // message.data.create.success=データを新規追加しました。
				}

				// メール配信
				if (boardServiceImpl.sendMailKjGroupInvitation(form.getSendMailList(), locale)) {
					// メール配信成功
					logger.infoCode("I0002", "create");		// I0002=メソッド終了:{0}
					// 面談一覧画面に遷移
					return REDIRECT_LIST;
				}else{
					// メール配信失敗
					model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.mail.send"); // error.data.message.mail.send=メール配信が失敗しました。
				}
				logger.infoCode("I0002", "create"); // I0002=メソッド終了:{0}
				return REDIRECT_LIST;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		// DB更新が失敗した場合
		logger.errorCode("E1007", "create"); // E1007=登録に失敗しました。{0}
		model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.regist"); // error.data.message.db.regist=登録が失敗しました。
		logger.errorCode("E0014", "create"); // E0014=メソッド異常終了:{0}
		return EDIT_PAGE;
	}


	/**
	 * 共有情報管理一覧
	 *
	 * @param form
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = { "/file" })
	public String fileList(@ModelAttribute(CommonConst.FORM_NAME) BoardForm form, Model model, Locale locale) {

		logger.infoCode("I0001", "fileList"); // I0001=メソッド開始:{0}

		// 情報共有管理データ取得
		this.setFileListInfo(form, model);

		// dump
		modelDump(logger, model, "index");
		logger.infoCode("I0002", "fileList"); // I0002=メソッド終了:{0}
		return FILE_LIST_PAGE;
	}


	/**
	 * ファイルアップロード(共有情報管理)
	 *
	 * @param form
	 * @param bindingResult
	 * @param model
	 * @param attributes
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = { "/file/upload" }, method = RequestMethod.POST)
	public String fileUpload(@ModelAttribute(CommonConst.FORM_NAME) BoardForm form,
			BindingResult bindingResult, Model model, RedirectAttributes attributes, Locale locale) {

		logger.infoCode("I0001", "fileUpload"); // I0001=メソッド開始:{0}
		///////////////////////////////////////////////////////////////////////////////////
		// アップロードの場合
		///////////////////////////////////////////////////////////////////////////////////
		MultipartFile doc = form.getDoc();
		if (doc != null && doc.getOriginalFilename().length() > 0) {
			String fileName = new File(doc.getOriginalFilename()).getName();
			form.setFileName(fileName);
			form.setTitle(form.getTitle());
			form.setUpdDate(form.getUpdDate());
			try {
				String uploadKey = null;
				uploadKey = boardServiceImpl.fileUpload(userInfo, form);

				if (uploadKey != null) {
					if (CommonConst.PAGE_MODE_ADD.equals(form.getPageMode())) {
						form.setUploadKey(uploadKey);
						form.setUploadFlg(UPLOAD_FLG_1);
					} else if (CommonConst.PAGE_MODE_EDIT.equals(form.getPageMode())) {
						form.setUploadKeyAfter(uploadKey);
						form.setUploadFlgAfter(UPLOAD_FLG_1);
					}
					model.addAttribute(CommonConst.FORM_NAME, form);
					logger.infoCode("I0002", "fileUpload"); // I0002=メソッド終了:{0}
					return FILE_EDIT_PAGE;
				}

				attributes.addFlashAttribute(CommonConst.FORM_NAME, form);
				//model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.message.data.upload"); // error.message.data.upload=ファイルのアップロードに失敗しました。
				logger.errorCode("E1012", "fileUpload"); // E1012=ファイルのアップロードに失敗しました。{0}
				return FILE_EDIT_PAGE;

			} catch (Exception e) {
				e.printStackTrace();
			}
			attributes.addFlashAttribute(CommonConst.FORM_NAME, form);
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.message.data.upload"); // error.message.data.upload=ファイルのアップロードに失敗しました。
			logger.errorCode("E1012", "fileUpload"); // E1012=ファイルのアップロードに失敗しました。{0}
			return FILE_EDIT_PAGE;

		}
		// 項目が選択されていない場合
		model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.not.select"); // error.data.message.not.select=項目が選択されていません。
		attributes.addFlashAttribute(CommonConst.FORM_NAME, form);
		logger.errorCode("E0014", "fileEdit"); // E0014=メソッド異常終了:{0}
		return FILE_EDIT_PAGE;
	}


	/**
	 * 共有管理情報  新規作成、編集画面表示
	 *
	 * @param form
	 * @param bindingResult
	 * @param model
	 * @param attributes
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = { "/file/edit" }, method = RequestMethod.POST)
	public String fileEdit(@ModelAttribute(CommonConst.FORM_NAME) BoardForm form,
			BindingResult bindingResult, Model model, RedirectAttributes attributes, Locale locale) {

		logger.infoCode("I0001", "fileEdit"); // I0001=メソッド開始:{0}

		///////////////////////////////////////////////////////////////////////////////////
		// 新規登録の場合
		///////////////////////////////////////////////////////////////////////////////////
		if (CommonConst.PAGE_MODE_ADD.equals(form.getPageMode())) {
			form.setUploadFlg(UPLOAD_FLG_0);
			form.setUploadFlgAfter(UPLOAD_FLG_0);
			model.addAttribute(CommonConst.FORM_NAME, form);
			logger.infoCode("I0002", "fileEdit"); // I0002=メソッド終了:{0}
			return FILE_EDIT_PAGE;
		}

		///////////////////////////////////////////////////////////////////////////////////
		// 編集の場合
		///////////////////////////////////////////////////////////////////////////////////
		if (CommonConst.PAGE_MODE_EDIT.equals(form.getPageMode()) && StringUtil.isNotNull(form.getBoardGroupKey())
				&& StringUtil.isNotNull(form.getUploadKey())) {

			KjGroupCommonFileTbl entity = new KjGroupCommonFileTbl();
			// 共有情報管理ファイル 取得
			entity = boardServiceImpl.findOneCommonFile(form);
			form.setUpdDate(entity.getUpdDate());
			form.setTitle(entity.getTitle());

			form.setUploadFlg(UPLOAD_FLG_1);
			form.setUploadFlgAfter(UPLOAD_FLG_0);

			//アップロードファイル情報
			KjGroupCommonFileDto commonFile = boardServiceImpl.findCommonFile(form.getBoardGroupKey(), form.getUploadKey());
			form.setFileName(commonFile.getFileName());
			model.addAttribute(CommonConst.FORM_NAME, form);
			logger.infoCode("I0002", "fileEdit"); // I0002=メソッド終了:{0}
			return FILE_EDIT_PAGE;
		}
		// 項目が選択されていない場合
		model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.not.select"); // error.data.message.not.select=項目が選択されていません。
		attributes.addFlashAttribute(CommonConst.FORM_NAME, form);
		logger.errorCode("E0014", "fileEdit"); // E0014=メソッド異常終了:{0}
		return REDIRECT_FILE_LIST;
	}


	/**
	 * 共有管理情報  登録、更新処理
	 *
	 * @param form
	 * @param bindingResult
	 * @param model
	 * @param attributes
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = { "/file/regist" }, method = RequestMethod.POST)
	public String fileRegist(@Validated(BoardForm.group4.class) @ModelAttribute(CommonConst.FORM_NAME) final BoardForm form,
			BindingResult bindingResult, Model model, RedirectAttributes attributes, Locale locale) {

		logger.infoCode("I0001", "fileRegist"); // I0001=メソッド開始:{0}

		model.addAttribute(CommonConst.FORM_NAME, form);

		/////////////////////////////////////////////////////////////////////////////////
		// バリデーションエラーがある場合
		if (bindingResult.hasErrors()) {
			if (logger.isDebugEnabled()) {
				logger.debugCode("W1010", bindingResult.getFieldError()); // W1010=Validationチェックエラーがありました。
			}
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.valid.data"); // error.data.message.valid.data=入力項目に誤りがあります。

			logger.infoCode("I0002", "create"); // I0002=メソッド終了:{0}
			return FILE_EDIT_PAGE;
		}

		///////////////////////////////////////////////////////////////////////////////////
		// DB登録
		///////////////////////////////////////////////////////////////////////////////////
		try {
			if (boardServiceImpl.fileUpdate(userInfo, form)) {
				// 更新の場合
				if (CommonConst.PAGE_MODE_EDIT.equals(form.getPageMode())) {
					// DB更新が成功した場合
					logger.infoCode("I1004", "fileRegist"); // I1004=更新しました。{0}
					// 操作ログ出力
					super.operationHistory(CommonConst.OP_FUNC_BOARD_COMMONFILE, CommonConst.OP_ACTION_UPDATE);
					attributes.addFlashAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.update.success"); // message.data.update.success=データを更新しました。
					attributes.addFlashAttribute(CommonConst.FORM_NAME, form);
					logger.infoCode("I0002", "fileRegist"); // I0002=メソッド終了:{0}
					return REDIRECT_FILE_LIST;
				}

				// 新規追加の場合
				if (CommonConst.PAGE_MODE_ADD.equals(form.getPageMode())) {
					// DB更新が成功した場合
					logger.infoCode("I1005", "fileRegist"); // I1005=新規作成しました。{0}
					// 操作ログ出力
					super.operationHistory(CommonConst.OP_FUNC_BOARD_COMMONFILE, CommonConst.OP_ACTION_INSERT);
					attributes.addFlashAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.create.success"); // message.data.create.success=データを新規追加しました。
					attributes.addFlashAttribute(CommonConst.FORM_NAME, form);
					logger.infoCode("I0002", "fileRegist"); // I0002=メソッド終了:{0}
					return REDIRECT_FILE_LIST;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		// DB更新が失敗した場合
		logger.errorCode("E1007", "fileRegist"); // E1007=登録に失敗しました。{0}
		model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.regist"); // error.data.message.db.regist=登録が失敗しました。
		attributes.addFlashAttribute(CommonConst.FORM_NAME, form);
		logger.errorCode("E0014", "fileRegist"); // E0014=メソッド異常終了:{0}
		return FILE_EDIT_PAGE;
	}


	/**
	 * 共有管理情報  削除
	 *
	 * @param form
	 * @param model
	 * @param attributes
	 * @return
	 */
	@RequestMapping(value = "/file/delete", method = RequestMethod.POST)
	public String fileDelete(@ModelAttribute(CommonConst.FORM_NAME) BoardForm form, Model model,
			RedirectAttributes attributes) {

		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		// 情報共有管理データ取得
		this.setFileListInfo(form, model);

		///////////////////////////////////////////////////////////////////////////////////
		// DB登録
		///////////////////////////////////////////////////////////////////////////////////
		try {
			if (boardServiceImpl.fileDelete(userInfo, form)) {
				// DB更新が成功した場合
				logger.infoCode("I1003"); // I1003=削除しました。{0}
				super.operationHistory(CommonConst.OP_FUNC_BOARD_COMMONFILE, CommonConst.OP_ACTION_DELETE); // 操作ログ保存
				attributes.addFlashAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.delete.success"); // message.data.delete.success=データを削除しました。
				attributes.addFlashAttribute(CommonConst.FORM_NAME, form);
				logger.infoCode("I0002"); // I0002=メソッド終了:{0}
				return REDIRECT_FILE_LIST;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		// DB更新が失敗した場合
		logger.errorCode("E1009"); // E1009=削除に失敗しました。{0}
		model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.remove"); // error.data.message.db.remove=削除が失敗しました。
		attributes.addFlashAttribute(CommonConst.FORM_NAME, form);
		logger.errorCode("E0014"); // E0014=メソッド異常終了:{0}
		return FILE_LIST_PAGE;
	}


	/**
	 * 共有管理情報  編集画面から一覧に戻る処理
	 *
	 * @param form
	 * @param bindingResult
	 * @param model
	 * @param attributes
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = { "/file/back" }, method = RequestMethod.POST)
	public String fileListBack(@ModelAttribute(CommonConst.FORM_NAME) BoardForm form,
			BindingResult bindingResult, Model model, RedirectAttributes attributes, Locale locale) {
		logger.infoCode("I0001", "fileListBack"); // I0001=メソッド開始:{0}

		attributes.addFlashAttribute(CommonConst.FORM_NAME, form);

		if (CommonConst.PAGE_MODE_ADD.contains(form.getPageMode())) {
			// 新規登録時
			if (form.getUploadFlg().equals(UPLOAD_FLG_1)) {
				//ファイルアップロードテーブル削除、ファイル削除
				int res = fileService.deleteUploadFile(form.getUploadKey());
			}
			return REDIRECT_FILE_LIST;
		}

		if (CommonConst.PAGE_MODE_EDIT.contains(form.getPageMode())) {
			// 編集時
			if (form.getUploadFlgAfter().equals(UPLOAD_FLG_1)) {
				//ファイルアップロードテーブル削除、ファイル削除
				int res = fileService.deleteUploadFile(form.getUploadKeyAfter());
			}
			return REDIRECT_FILE_LIST;
		}
		return REDIRECT_FILE_LIST;
	}


	/**
	 * 掲示板グループ管理  ダウンロード
	 *
	 * @param form
	 * @param response
	 */
	@RequestMapping(value = "/file/download", method = RequestMethod.POST)
	public void fileDownload(@ModelAttribute(CommonConst.FORM_NAME) BoardForm form, HttpServletResponse response) {

		logger.infoCode("I0001", "fileDownload"); // I0001=メソッド開始:{0}
		String fileName = "";

		try {
			//ダウンロードファイルの取得(解凍を行ったファイルを取得する)
			FileDto fileDto = fileService.getFile(form.getUploadKey());

			fileName = fileDto.getUploadPath();
			Resource file = new FileSystemResource(fileName);
			response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileDto.getUploadName());
			response.setContentType("text/plain");
			response.setContentLength((int)FileUtils.sizeOf(file.getFile()));
			FileCopyUtils.copy(file.getInputStream(), response.getOutputStream());

		} catch (FileNotFoundException e) {
			try {
				throw new Exception(fileName + " not found");
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		} catch (IOException e) {
			try {
				throw new Exception(e);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
		logger.infoCode("I0002", "fileDownload"); // I0002=メソッド終了:{0}
	}


	/**
	 * 掲示板一覧
	 *
	 * @param form
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping(value =  "/thread" )
	public String thredList(@ModelAttribute(CommonConst.FORM_NAME) BoardForm form, Model model, Locale locale) {

		logger.infoCode("I0001", "thredList"); // I0001=メソッド開始:{0}

		if (logger.isDebugEnabled() && userInfo != null) {
			logger.debug("LoginUserKey=" + userInfo.getLoginUserKey());
			logger.debug("TargetUserKey=" + userInfo.getTargetUserKey());
		}

		// 掲示板一覧情報取得
		this.setKjThredListInfo(form, model, locale);

		// dump
		modelDump(logger, model, "thredList");
		logger.infoCode("I0002", "thredList"); // I0002=メソッド終了:{0}
		return THRED_LIST_PAGE;
	}


	/**
	 * 掲示板スレッド新規登録画面表示
	 *
	 * @param form
	 * @param bindingResult
	 * @param model
	 * @param attributes
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = "/thread/create", method = RequestMethod.POST)
	public String thredAdd(@ModelAttribute(CommonConst.FORM_NAME) BoardForm form,
		BindingResult bindingResult, Model model, RedirectAttributes attributes, Locale locale) {

		logger.infoCode("I0001", "thredAdd"); // I0001=メソッド開始:{0}

		// 掲示板スレッド登録用情報取得
		form.setUploadFlg(UPLOAD_FLG_0);
		this.setKjThredAddInfo(form, model);

		// dump
		modelDump(logger, model, "thredAdd");

		logger.infoCode("I0002", "thredAdd"); // I0002=メソッド終了:{0}

		return THRED_CREATE_PAGE;
	}


	/**
	 * ファイルアップロード(スレッド作成)
	 *
	 * @param form
	 * @param bindingResult
	 * @param model
	 * @param attributes
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = { "/thread/upload" }, method = RequestMethod.POST)
	public String thredUpload(@ModelAttribute(CommonConst.FORM_NAME) BoardForm form,
			BindingResult bindingResult, Model model, RedirectAttributes attributes, Locale locale) {

		logger.infoCode("I0001", "thredUpload"); // I0001=メソッド開始:{0}

		// 掲示板スレッド登録用情報取得
		this.setKjThredAddInfo(form, model);

		///////////////////////////////////////////////////////////////////////////////////
		// アップロードの場合
		///////////////////////////////////////////////////////////////////////////////////
		MultipartFile doc = form.getDoc();
		if (doc != null && doc.getOriginalFilename().length() > 0) {
			String fileName = new File(doc.getOriginalFilename()).getName();
			form.setFileName(fileName);
			try {
				String uploadKey = null;
				uploadKey = boardServiceImpl.thredUpload(userInfo, form);

				if (uploadKey != null) {
					form.setUploadKey(uploadKey);
					form.setUploadFlg(UPLOAD_FLG_1);
				}
				model.addAttribute(CommonConst.FORM_NAME, form);
				logger.infoCode("I0002", "thredUpload"); // I0002=メソッド終了:{0}

				return THRED_CREATE_PAGE;
			} catch (Exception e) {
				e.printStackTrace();
			}

			attributes.addFlashAttribute(CommonConst.FORM_NAME, form);
			//model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.message.data.upload"); // error.message.data.upload=ファイルのアップロードに失敗しました。
			logger.errorCode("E1012", "thredUpload"); // E1012=ファイルのアップロードに失敗しました。{0}
			return THRED_CREATE_PAGE;
		}
		// 項目が選択されていない場合
		model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.not.select"); // error.data.message.not.select=項目が選択されていません。
		attributes.addFlashAttribute(CommonConst.FORM_NAME, form);
		logger.errorCode("E0014", "thredUpload"); // E0014=メソッド異常終了:{0}
		return THRED_CREATE_PAGE;
	}


	/**
	 * 掲示板スレッド新規登録
	 *
	 * @param form
	 * @param bindingResult
	 * @param model
	 * @param attributes
	 * @param locale
	 * @return
	 */
	@RequestMapping(value =  "/thread/insert" , method = RequestMethod.POST)
	public String thredCreate(@Validated(BoardForm.group2.class) @ModelAttribute(CommonConst.FORM_NAME) BoardForm form,
			BindingResult bindingResult, Model model, RedirectAttributes attributes, Locale locale) {

		logger.infoCode("I0001", "thredCreate"); // I0001=メソッド開始:{0}

		// 掲示板スレッド登録用情報取得
		this.setKjThredAddInfo(form, model);

		///////////////////////////////////////////////////////////////////////////////////
		// バリデーションエラーがある場合
		if (bindingResult.hasErrors()) {
			if (logger.isDebugEnabled()) {
				logger.debugCode("W1010", bindingResult.getFieldError()); // W1010=Validationチェックエラーがありました。
			}
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.valid.data"); // error.data.message.valid.data=入力項目に誤りがあります。
			logger.infoCode("I0002", "thredCreate"); // I0002=メソッド終了:{0}
			return THRED_CREATE_PAGE;
		}

		///////////////////////////////////////////////////////////////////////////////////
		// DB登録
		///////////////////////////////////////////////////////////////////////////////////
		try {
			if (boardServiceImpl.thredInsert(userInfo, form)) {
				// DB更新が成功した場合
				logger.infoCode("I1005", "thredCreate"); // I1005=新規作成しました。{0}
				// 一覧画面に戻る
				attributes.addFlashAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.create.success"); // message.data.create.success=データを新規追加しました。
				logger.infoCode("I0002", "thredCreate"); // I0002=メソッド終了:{0}
				// 操作ログ出力
				super.operationHistory(CommonConst.OP_FUNC_BOARD_THRED, CommonConst.OP_ACTION_INSERT);
				return REDIRECT_THRED_LIST;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		// DB更新が失敗した場合
		logger.errorCode("E1007", "thredCreate"); // E1007=登録に失敗しました。{0}
		model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.regist"); // error.data.message.db.regist=登録が失敗しました。
		logger.errorCode("E0014", "thredCreate"); // E0014=メソッド異常終了:{0}
		return THRED_CREATE_PAGE;
	}


	/**
	 * 掲示板スレッド作成画面から一覧に戻る処理
	 *
	 * @param form
	 * @param bindingResult
	 * @param model
	 * @param attributes
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = { "/thread/back" }, method = RequestMethod.POST)
	public String thredListBack(@ModelAttribute(CommonConst.FORM_NAME) BoardForm form,
			BindingResult bindingResult, Model model, RedirectAttributes attributes, Locale locale) {
		logger.infoCode("I0001", "thredListBack"); // I0001=メソッド開始:{0}

		attributes.addFlashAttribute(CommonConst.FORM_NAME, form);

		if (form.getUploadFlg().equals(UPLOAD_FLG_1)) {
			//ファイルアップロードテーブル削除、ファイル削除
			int res = fileService.deleteUploadFile(form.getUploadKey());
		}
		logger.infoCode("I0002", "thredListBack"); // I0002=メソッド終了:{0}
		return REDIRECT_THRED_LIST;
	}


	/**
	 * 掲示板スレッド表示・投稿画面表示
	 *
	 * @param request
	 * @param thredKey
	 * @param model
	 * @param attributes
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = "/thread/edit")
	public String thredEdit(@ModelAttribute(CommonConst.FORM_NAME) BoardForm form,
			BindingResult bindingResult, Model model, RedirectAttributes attributes, Locale locale) {

		logger.infoCode("I0001", "thredEdit"); // I0001=メソッド開始:{0}

		// 掲示板スレッド表示・投稿画面情報取得
		this.setKjThredEditInfo(form, model, locale);
		form.setMemo("");
		form.setFileName("");
		form.setUploadFlg(UPLOAD_FLG_0);
		form.setUploadKey("");

		///////////////////////////////////////////////////////////////////////////////////
		// DB登録
		///////////////////////////////////////////////////////////////////////////////////
		try {
			if (boardServiceImpl.thredReadUpdate(form.getThredKey(), userInfo)) {
				///////////////////////////////////////////////////////////////////////////////////
				// DB更新が成功した場合
				logger.infoCode("I1004", "thredEdit"); // I1005=更新しました。{0}
				attributes.addFlashAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.update.success"); // message.data.update.success=データを更新しました。
				logger.infoCode("I0002", "thredEdit"); // I0002=メソッド終了:{0}
				return THRED_EDIT_PAGE;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		// DB更新が失敗した場合
		logger.errorCode("E1007", "thredEdit"); // E1007=登録に失敗しました。{0}
		model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.regist"); // error.data.message.db.regist=登録が失敗しました。
		logger.errorCode("E0014", "thredEdit"); // E0014=メソッド異常終了:{0}
		return THRED_LIST_PAGE;
	}


	/**
	 * ファイルアップロード(スレッド投稿)
	 *
	 * @param form
	 * @param bindingResult
	 * @param model
	 * @param attributes
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = { "/contribution/upload" }, method = RequestMethod.POST)
	public String contributionUpload(@ModelAttribute(CommonConst.FORM_NAME) BoardForm form,
			BindingResult bindingResult, Model model, RedirectAttributes attributes, Locale locale) {

		logger.infoCode("I0001", "contributionUpload"); // I0001=メソッド開始:{0}

		// 掲示板スレッド表示・投稿画面情報取得
		this.setKjThredEditInfo(form, model, locale);

		///////////////////////////////////////////////////////////////////////////////////
		// アップロードの場合
		///////////////////////////////////////////////////////////////////////////////////
		MultipartFile doc = form.getDoc();
		if (doc != null && doc.getOriginalFilename().length() > 0) {
			String fileName = new File(doc.getOriginalFilename()).getName();
			form.setFileName(fileName);
			try {
				String uploadKey = null;
				uploadKey = boardServiceImpl.thredUpload(userInfo, form);

				if (uploadKey != null) {
					form.setUploadKey(uploadKey);
					form.setUploadFlg(UPLOAD_FLG_1);
				}
				model.addAttribute(CommonConst.FORM_NAME, form);
				logger.infoCode("I0002", "contributionUpload"); // I0002=メソッド終了:{0}

				return THRED_EDIT_PAGE;
			} catch (Exception e) {
				e.printStackTrace();
			}
			logger.errorCode("E1012", "contributionUpload"); // E1012=ファイルのアップロードに失敗しました。{0}
			return THRED_EDIT_PAGE;

		}
		// 項目が選択されていない場合
		model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.not.select"); // error.data.message.not.select=項目が選択されていません。
		attributes.addFlashAttribute(CommonConst.FORM_NAME, form);
		logger.errorCode("E0014", "contributionUpload"); // E0014=メソッド異常終了:{0}
		return THRED_EDIT_PAGE;
	}


	/**
	 * スレッド投稿
	 *
	 * @param form
	 * @param bindingResult
	 * @param model
	 * @param attributes
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = "/thread/regist" , method = RequestMethod.POST)
		public String thredUpdate(@Validated(BoardForm.group3.class) @ModelAttribute(CommonConst.FORM_NAME) final BoardForm form,
			BindingResult bindingResult, Model model, RedirectAttributes attributes, Locale locale) {

		logger.infoCode("I0001", "thredUpdate"); // I0001=メソッド開始:{0}

		// 掲示板スレッド表示・投稿画面情報取得
		this.setKjThredEditInfo(form, model, locale);

		///////////////////////////////////////////////////////////////////////////////////
		// バリデーションエラーがある場合
		if (bindingResult.hasErrors()) {
			if (logger.isDebugEnabled()) {
				logger.debugCode("W1010", bindingResult.getFieldError()); // W1010=Validationチェックエラーがありました。
			}
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.valid.data"); // error.data.message.valid.data=入力項目に誤りがあります。
			logger.infoCode("I0002", "thredUpdate"); // I0002=メソッド終了:{0}
			return THRED_EDIT_PAGE;
		}

		///////////////////////////////////////////////////////////////////////////////////
		// DB登録
		///////////////////////////////////////////////////////////////////////////////////
		try {
			if (boardServiceImpl.thredUpdate(form, userInfo)) {
				// DB更新が成功した場合
				logger.infoCode("I1005", "thredUpdate"); // I1005=新規作成しました。{0}
				// 一覧画面に戻る
				attributes.addFlashAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.create.success"); // message.data.create.success=データを新規追加しました。
				// 操作ログ出力
				super.operationHistory(CommonConst.OP_FUNC_BOARD_CONTRIBUTION, CommonConst.OP_ACTION_INSERT);
				attributes.addFlashAttribute(CommonConst.FORM_NAME, form);
				logger.infoCode("I0002", "thredUpdate"); // I0002=メソッド終了:{0}
				return REDIRECT_THRED_EDIT;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		// DB更新が失敗した場合
		logger.errorCode("E1007", "thredUpdate"); // E1007=登録に失敗しました。{0}
		model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.regist"); // error.data.message.db.regist=登録が失敗しました。
		logger.errorCode("E0014", "thredUpdate"); // E0014=メソッド異常終了:{0}
		return REDIRECT_THRED_EDIT;
	}


	/**
	 * スレッド削除(全体)
	 *
	 * @param form
	 * @param bindingResult
	 * @param model
	 * @param attributes
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = "/thread/delete", method = RequestMethod.POST)
	public String thredDelete(@ModelAttribute(CommonConst.FORM_NAME) @Validated final BoardForm form,
			BindingResult bindingResult, Model model, RedirectAttributes attributes, Locale locale) {
		logger.infoCode("I0001", "thredDelete"); // I0001=メソッド開始:{0}

		// 掲示板一覧情報取得
		this.setKjThredListInfo(form, model, locale);

		// スレッドが選択されていること
		if (StringUtil.isNull(form.getThredKey())) {
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.select.thread"); // error.data.message.select.thread=削除したい掲示板を選択してください。
			logger.infoCode("I0002", "thredDelete"); // I0002=メソッド終了:{0}
			return THRED_LIST_PAGE;
			}
		// 掲示板グループ管理者であること
		if (!userInfo.getTargetUserKey().equals(form.getAdminUserKey())) {
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.not.admin"); // error.data.message.not.admin=グループの管理者しか削除できません。
			logger.infoCode("I0002", "thredDelete"); // I0002=メソッド終了:{0}
			return THRED_LIST_PAGE;
		}

		///////////////////////////////////////////////////////////////////////////////////
		// DB登録
		///////////////////////////////////////////////////////////////////////////////////
		try {
			if (boardServiceImpl.thredDelete(userInfo, form)) {
				// DB更新が成功した場合
				logger.infoCode("I1003", "thredDelete"); // I1003=削除しました。{0}
				attributes.addFlashAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.delete.success"); // message.data.delete.success=データを削除しました。
				// 操作ログ出力
				super.operationHistory(CommonConst.OP_FUNC_BOARD_THRED_LIST, CommonConst.OP_ACTION_DELETE);
				logger.infoCode("I0002", "thredDelete"); // I0002=メソッド終了:{0}
				return REDIRECT_THRED_LIST;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		// DB更新が失敗した場合
		logger.errorCode("E1009", "thredDelete"); // E1009=削除に失敗しました。{0}
		model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.remove"); // error.data.message.db.remove=削除が失敗しました。
		logger.errorCode("E0014", "thredDelete"); // E0014=メソッド異常終了:{0}
		return THRED_LIST_PAGE;
	}


	/**
	 * 投稿実績削除(投稿のみ)
	 *
	 * @param form
	 * @param bindingResult
	 * @param model
	 * @param attributes
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = "/thread/contributionDelete", method = RequestMethod.POST)
	public String contributionDelete(@ModelAttribute(CommonConst.FORM_NAME) final BoardForm form,
			BindingResult bindingResult, Model model, RedirectAttributes attributes, Locale locale) {
		logger.infoCode("I0001", "contributionDelete"); // I0001=メソッド開始:{0}

		// 掲示板スレッド表示・投稿画面情報取得
		this.setKjThredEditInfo(form, model, locale);

		///////////////////////////////////////////////////////////////////////////////////
		// DB登録
		///////////////////////////////////////////////////////////////////////////////////
		try {
			if (boardServiceImpl.contributionDelete(userInfo, form)) {
				// DB更新が成功した場合
				logger.infoCode("I1003", "contributionDelete"); // I1003=削除しました。{0}
				attributes.addFlashAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.delete.success"); // message.data.delete.success=データを削除しました。
				// 操作ログ出力
				super.operationHistory(CommonConst.OP_FUNC_BOARD_CONTRIBUTION, CommonConst.OP_ACTION_DELETE);
				attributes.addFlashAttribute(CommonConst.FORM_NAME, form);
				logger.infoCode("I0002", "contributionDelete"); // I0002=メソッド終了:{0}
				return REDIRECT_THRED_EDIT;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		// DB更新が失敗した場合
		logger.errorCode("E1009", "contributionDelete"); // E1009=削除に失敗しました。{0}
		attributes.addFlashAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.remove"); // error.data.message.db.remove=削除が失敗しました。
		attributes.addFlashAttribute(CommonConst.FORM_NAME, form);
		logger.errorCode("E0014", "contributionDelete"); // E0014=メソッド異常終了:{0}
		return REDIRECT_THRED_EDIT;
	}


	/**
	 * 掲示板メンバー承認画面表示
	 *
	 * @param boardGroupKey
	 * @param userKey
	 * @param form
	 * @param model
	 * @param attributes
	 * @param locale
	 * @return
	 */
	@RequestMapping(value = "/approval/{boardGroupKey}/{userKey}" , method = RequestMethod.GET)
	public String approval(@PathVariable("boardGroupKey") String boardGroupKey, @PathVariable("userKey") String userKey,
							@ModelAttribute(CommonConst.FORM_NAME) BoardForm form,
							BindingResult bindingResult, Model model, RedirectAttributes attributes, Locale locale) {
		logger.infoCode("I0001", "approval"); // I0001=メソッド開始:{0}

		try {

//			if (!userInfo.getTargetUserKey().equals(userKey)) {
//				return REDIRECT_LOGIN;
//			}

			//GETパラメータの掲示板グループキー、ユーザーキーをもとに掲示板ユーザーリレーションデータを取得
			KjBoardRelUser relUserTbl = boardServiceImpl.getOne(boardGroupKey, userKey);

			if (relUserTbl == null) {
				// データが存在しない場合
				model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.board.user.no.data");// error.data.board.user.no.data=掲示板グループに招待されましたが、掲示板グループが削除されているか、メンバーが取消された可能性があります。
				model.addAttribute("disabled", "disabled");
				return APPROVAL_PAGE;
			}

			form = setupForm();
			form.setBoardName(relUserTbl.getKjBoardGroupTbl().getBoardName());
			form.setOutline(relUserTbl.getKjBoardGroupTbl().getOutline());
			form.setBoardGroupKey(boardGroupKey);
			form.setUserKey(userKey);
			form.setUpdDate(relUserTbl.getUpdDate());
			model.addAttribute(CommonConst.FORM_NAME, form);

			if (relUserTbl.getUserStatusKbn().equals(CODE_STATUSKBN_1)) {
				// 既に承認済の場合
				model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.board.user.already.approval");// error.data.board.user.already.approval=既に掲示板グループに承認済です。
				model.addAttribute("disabled", "disabled");
				return APPROVAL_PAGE;
			}

			if (relUserTbl.getUserStatusKbn().equals(CODE_STATUSKBN_2)) {
				// 既に承認拒否の場合
				model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.board.user.already.retraction");// error.data.board.user.already.retraction=既に掲示板グループからの追加承認を取り下げています。
				model.addAttribute("disabled", "disabled");
				return APPROVAL_PAGE;
			}
			logger.infoCode("I0002", "approval"); // I0002=メソッド終了:{0}
			return APPROVAL_PAGE;
		} catch (Exception e) {
			e.printStackTrace();
		}
		// DB更新が失敗した場合
		logger.errorCode("E1007", "approval"); // E1007=登録に失敗しました。{0}
		model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.regist"); // error.data.message.db.regist=登録が失敗しました。
		attributes.addFlashAttribute(CommonConst.FORM_NAME, form);
		logger.errorCode("E0014", "approval"); // E0014=メソッド異常終了:{0}
		return REDIRECT_THRED_EDIT;
	}


	/**
	 * 掲示板メンバー承認
	 *
	 * @param form
	 * @param bindingResult
	 * @param model
	 * @param attributes
	 * @param locale
	 * @return
	 */
	@RequestMapping(value =  "/approval/regist" , method = RequestMethod.POST)
	public String approvalRegist(@ModelAttribute(CommonConst.FORM_NAME) final BoardForm form,
			BindingResult bindingResult, Model model, RedirectAttributes attributes, Locale locale) {
		logger.infoCode("I0001", "approvalRegist"); // I0001=メソッド開始:{0}

		model.addAttribute(CommonConst.FORM_NAME, form);

		///////////////////////////////////////////////////////////////////////////////////
		// DB登録
		///////////////////////////////////////////////////////////////////////////////////
		try {
			if (boardServiceImpl.relUserUpdate(form)) {
				///////////////////////////////////////////////////////////////////////////////////
				// 承認の場合
				if (CommonConst.PAGE_MODE_EDIT.equals(form.getPageMode())) {
					// DB更新が成功した場合
					logger.infoCode("I1004", "approvalRegist"); // I1004=更新しました。{0}
					attributes.addFlashAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.approval.success"); // message.data.approval.success=メンバー追加承認しました。
					return REDIRECT_THRED_LIST;
				}

				// 取り下げの場合
				if (CommonConst.PAGE_MODE_DELETE.equals(form.getPageMode())) {
					// DB更新が成功した場合
					logger.infoCode("I1003", "approvalRegist"); // I1003=削除しました。{0}
					attributes.addFlashAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.retraction.success"); // message.data.retraction.success=メンバー追加取り下げました。
					return REDIRECT_THRED_LIST;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		// DB更新が失敗した場合
		logger.errorCode("E1007", "approvalRegist"); // E1007=登録に失敗しました。{0}
		if (CommonConst.PAGE_MODE_EDIT.equals(form.getPageMode())) {
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.board.user.approval"); // error.data.board.user.approval=メンバー追加承認に失敗しました。
		} else {
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.board.user.retraction"); // error.data.board.user.retraction=メンバーの取り下げに失敗しました。
		}
		attributes.addFlashAttribute(CommonConst.FORM_NAME, form);
		logger.errorCode("E0014", "approvalRegist"); // E0014=メソッド異常終了:{0}
		return APPROVAL_PAGE;
	}


	/**
	 * 掲示板グループ一覧取得
	 *
	 * @param form
	 * @param model
	 */
	private void setKjGroupInfo(BoardForm form, Model model) {
		// 掲示板グループ一覧取得
		List<KjBoardGroupTbl> boardList = new ArrayList<>();
		boardList = boardServiceImpl.findBoardGroupList(userInfo);

		model.addAttribute("targetUserKey", userInfo.getTargetUserKey());
		model.addAttribute("boardList", boardList);
		model.addAttribute(CommonConst.FORM_NAME, form);
	}


	/**
	 * 掲示板グループ管理  新規・編集画面用データ取得
	 *
	 * @param form
	 * @param model
	 */
	private void setKjGroupEditInfo(BoardForm form, Model model,  Locale locale) {
		// 定数コード一覧
		model.addAttribute("Map0040", DbUtil.getJosuMap(CODE_SYBCODE, locale));
		model.addAttribute("List0049", DbUtil.getJosuList(CODE_COMMON_FILE, locale));

		// メンバー検索用リストデータ
		List<KjBoardRelUserDto> userList = boardServiceImpl.findPartyMemberList(userInfo.getTargetPartyCode(), locale);
		model.addAttribute("userList", userList);

		// 掲示板グループのメンバーリストデータ
		List<KjBoardRelUserDto> memberList = new ArrayList<>();
		memberList = boardServiceImpl.findGroupMemberList(form, userInfo, locale);
		model.addAttribute("memberList", memberList);
		model.addAttribute("targetUserKey", userInfo.getTargetUserKey());

		String dispKbn = null;
		String editKbn = null;
		// ファイル添付の表示/非表示の判定
		if (userInfo.hasMgmt1() || userInfo.hasMgmt3() || userInfo.hasMgmt4()) {
			dispKbn = "1"; // ファイル添付あり
		} else {
			dispKbn = "0"; // ファイル添付なし
		}
		if (CommonConst.PAGE_MODE_EDIT.equals(form.getPageMode())) {
			if (userInfo.getTargetUserKey().equals(form.getAdminUserKey())) {
				// 対象ユーザーが掲示板グループの管理者の場合、編集可
				editKbn = "1";
			} else {
				// 対象ユーザーが掲示板グループの管理者でない場合、編集不可
				editKbn = "0";
			}
		}
		if (CommonConst.PAGE_MODE_ADD.equals(form.getPageMode())) {
			editKbn = "1"; //編集可
		}
		model.addAttribute("editKbn", editKbn);
		model.addAttribute("dispKbn", dispKbn);
	}


	/**
	 * 共有情報管理一覧
	 *
	 * @param form
	 * @param model
	 */
	private void setFileListInfo(BoardForm form, Model model) {
		// 情報共有管理データ取得
		List<KjGroupCommonFileTbl> commonFileList = new ArrayList<>();
		commonFileList = boardServiceImpl.findAllCommonFile(form);

		String editKbn = null;
		// ファイル添付の表示/非表示の判定
		if (userInfo.hasMgmt1() || userInfo.hasMgmt3() || userInfo.hasMgmt4()) {
			editKbn = "1"; // 編集可
		} else {
			editKbn = "0"; // 編集不可
		}
		model.addAttribute("editKbn", editKbn);
		model.addAttribute("commonFileList", commonFileList);
		model.addAttribute(CommonConst.FORM_NAME, form);
	}


	/**
	 * 掲示板一覧情報取得
	 *
	 * @param form
	 * @param model
	 */
	private void setKjThredListInfo(BoardForm form, Model model, Locale locale) {
		// 対象ユーザーをもとに掲示板グループリストを取得
		List<KjBoardRelUser> groupList= new ArrayList<>();
		groupList = boardServiceImpl.findGroupList(userInfo);

		List<KjBoardDto> thredList= new ArrayList<>();

		thredList = boardServiceImpl.findThredSearchList(userInfo, form, locale);

		model.addAttribute("groupList", groupList);
		model.addAttribute("thredList", thredList);
		model.addAttribute(CommonConst.FORM_NAME, form);
	}


	/**
	 * 掲示板登録情報取得
	 *
	 * @param form
	 * @param model
	 */
	private void setKjThredAddInfo(BoardForm form, Model model) {
		// 対象ユーザーをもとに掲示板グループリストを取得
		List<KjBoardRelUser> groupList = new ArrayList<>();
		groupList = boardServiceImpl.findGroupList(userInfo);

		String editKbn = null;
		// ファイル添付の表示/非表示の判定
		if (userInfo.hasMgmt1() || userInfo.hasMgmt3() || userInfo.hasMgmt4()) {
			editKbn = "1"; // 編集可
		} else {
			editKbn = "0"; // 編集不可
		}

		model.addAttribute("editKbn", editKbn);
		model.addAttribute("groupList", groupList);
		model.addAttribute(CommonConst.FORM_NAME, form);
	}


	/**
	 * 掲示板編集情報取得
	 *
	 * @param form
	 * @param model
	 */
	private void setKjThredEditInfo(BoardForm form, Model model, Locale locale) {
		// 掲示板グループキー
		KjThredTbl board = new KjThredTbl();
		board = boardServiceImpl.getOneThred(form.getThredKey());

		if (board.getThredKey() != null) {
			form.setBoardName(board.getKjBoardGroupTbl().getBoardName());
			form.setThredName(board.getThredName());
			form.setCommonFlag(board.getKjBoardGroupTbl().getCommonFlag());
		}

		// スレッドキーをもとに掲示板スレッド情報を取得
		List<KjThredContributionDto> contributionList = new ArrayList<>();
		contributionList = boardServiceImpl.findThredDetail(userInfo, form.getThredKey(), locale);

		// アップロード表示/非表示判定
		if (userInfo.hasMgmt1() || userInfo.hasMgmt3() || userInfo.hasMgmt4()) {
			if (form.getCommonFlag().equals("1")) {
				model.addAttribute("dispKbn", "1");
			} else {
				model.addAttribute("dispKbn", "0");
			}
		} else {
			model.addAttribute("dispKbn", "0");
		}

		model.addAttribute("targetUserKey", userInfo.getTargetUserKey());
		model.addAttribute("contributionList", contributionList);
		model.addAttribute(CommonConst.FORM_NAME, form);
	}


	/**
	 * ダイレクトアクセス対策
	 *
	 * @return
	 */
	@RequestMapping(value = {"/edit", "/create", "/update", "/delete"}, method = RequestMethod.GET)
	public String redirect() {
		logger.warnCode("W1009"); // W1009=URLダイレクトアクセスがありました。
		return CommonConst.REDIRECT_INDEX;
	}
}
