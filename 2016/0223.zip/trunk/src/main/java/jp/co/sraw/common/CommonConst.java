/*
* ファイル名：CommonConst.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.common;

import java.util.Locale;

/**
* <B>CommonConstクラス</B>
* <P>
* Constを提供する
*/
public interface CommonConst {

    /** デフォルトロケール */
    public static final Locale DEFAULT_LOCALE = Locale.JAPANESE;

    /** デフォルトエンコーディング */
    public static final String DEFAULT_ENDODEING = "UTF-8";

    /** 内部日付フォーマット */
    public static final String DEFAULT_YYYYMMDD = "yyyy/MM/dd";

    /** 暗号キー */
    public static final String SECRET_KEY = "abyeX#wD97";  // Password用 mkpasswdで生成
    public static final String ACCOUNT_SECRET_KEY = "3Q7qsUt%25";  // 申請用 mkpasswdで生成

    /** 全組織コード */
    public static final String ALL_PARTY_CD = "0000000";
    /** 広島大学 */
    //public static final String HIROSHIMA_U_AC_JP_PARTY_CD = "15401";

	/** パス区切り文字 */
	public static final String PATH_CHAR = "/";

	/** シーケンス(数値)から文字Keyに変換するフォーマット */
	public static final String SEQUENCE_FORMAT = "0000000000";

	/** システム管理者ユーザーキー */
	public static final String USER_KEY_ADMIN = "0000000000";
	/** 内部処理ようの仮想ユーザーキー */
	public static final String USER_KEY_DUMMY = "9999999999";

	/** API向け  */
	public static String PATH_API = "/api";
	/** 管理画面(事務局)向け  */
	public static String PATH_MGMT = "/mgmt";
	/** 管理画面(マスタメンテナンス、スーパーユーザー)向け */
	public static String PATH_ADMIN = "/admin";

	public static final String TEMP_ROOT = "/temp";

	/** ユーザー区分 個人ユーザ（任期付研究員）  */
	public static String USER_KBN_USER3 = "11";
	/** ユーザー区分 個人ユーザ（博士課程後期・一貫）  */
	public static String USER_KBN_USER2 = "12";
	/** ユーザー区分 個人ユーザ（博士課程前期）  */
	public static String USER_KBN_USER1 = "13";
	/** ユーザー区分 個人ユーザ（教職員）  */
	public static String USER_KBN_USER4 = "21";
	/** ユーザー区分 個人ユーザ（相談員）  */
	public static String USER_KBN_USER5 = "31";
	/** ユーザー区分 運営協議会事務局・共同実施機関・連携大学  */
	public static String USER_KBN_MGMT1_3 = "40";
	/** ユーザー区分 連携機関窓口（企業、研究所）  */
	public static String USER_KBN_MGMT4 = "50";

	/** ユーザー区分 個人ユーザ（若手研究者リスト）  */
	public static String[] USER_KBN_USER_LIST = new String[]{USER_KBN_USER3, USER_KBN_USER2, USER_KBN_USER1};

	/** ユーザー区分 個人ユーザ（若手研究者以外リスト）  */
	public static String[] USER_KBN_PARTY_LIST = new String[]{USER_KBN_MGMT1_3, USER_KBN_MGMT4};

	/** 初期ROLE_CODE(システム管理者)  */
	public static String ROLE_CODE_ADMIN = "000000";
	/** 初期ROLE_CODE(個人ユーザ（博士課程前期)  */
	public static String ROLE_CODE_USER1 = "100001";
	/** 初期ROLE_CODE(個人ユーザ（博士課程後期・一貫）)  */
	public static String ROLE_CODE_USER2 = "100002";
	/** 初期ROLE_CODE(個人ユーザ（任期付研究員）)  */
	public static String ROLE_CODE_USER3 = "200001";
	/** 初期ROLE_CODE(個人ユーザ（教職員）)  */
	public static String ROLE_CODE_USER4 = "300001";
	/** 初期ROLE_CODE(個人ユーザ（相談員）)  */
	public static String ROLE_CODE_USER5 = "400001";
	/** 初期ROLE_CODE(HIRAKU 運営協議会事務局)  */
	public static String ROLE_CODE_MGMT1 = "500001";
	/** 初期ROLE_CODE(共同実施機関窓口（山大・徳大）)  */
	public static String ROLE_CODE_MGMT2 = "600001";
	/** 初期ROLE_CODE(連携大学)  */
	public static String ROLE_CODE_MGMT3 = "700001";
	/** 初期ROLE_CODE(連携期間窓口（企業、研究所）)  */
	public static String ROLE_CODE_MGMT4 = "800001";
	/** 初期ROLE_CODE(プラットフォーム以外)  */
	public static String ROLE_CODE_OTHER = "900001";



	/** URLダイレクトアクセス時のリダイレクト先=index */
	public static final String REDIRECT_INDEX = "redirect:";

	/** Action URL */
	public static final String ACTION_URL = "pageActionUrl";
	/** Action URL create */
	public static final String ACTION_URL_CREATE = "create";
	/** Action URL update */
	public static final String ACTION_URL_UPDATE = "update";
	/** Action URL delete */
	public static final String ACTION_URL_DELETE = "delete";

	/** form名 */
	public static final String FORM_NAME = "form";

	/** ページモード */
	public static final String PAGE_MODE = "pageMode";
	/** ページモード 新規追加 */
	public static final String PAGE_MODE_CREATE = "pageModeCreate";
	public static final String PAGE_MODE_ADD = "pageModeAdd";
	/** ページモード コピー */
	public static final String PAGE_MODE_COPY = "pageModeCopy";
	/** ページモード 編集 */
	public static final String PAGE_MODE_EDIT = "pageModeEdit";
	/** ページモード 削除 */
	public static final String PAGE_MODE_DELETE = "pageModeDelete";

	/** 成功メッセージキー */
	public static final String PAGE_SUCCESS_MESSAGE = "page_success_message";
	/** 情報メッセージキー */
	public static final String PAGE_INFO_MESSAGE = "page_info_message";
	/** 情報メッセージキー */
	public static final String PAGE_WARNING_MESSAGE = "page_warning_message";
	/** エラーメッセージキー */
	public static final String PAGE_DANGER_MESSAGE = "page_danger_message";

	/** 有効／無効フラグ 定数区分:0023 */
	public static final String USE_FALG_ACTIVE ="1";  //有効
	public static final String USE_FALG_INACTIVE ="0";  //無効

	/** バッチ実行状況用  0:未処理。1:処理済み 定数区分:---- */
	public static final String BATCH_STATUS_RAN ="1";  //処理済み(runの過去形)
	public static final String BATCH_STATUS_RUN_YET ="0";  //未処理

	/** 性別 定数区分:0025 */
	public static final String SEX_MAN ="1";  //男性
	public static final String SEX_WOMAN ="2";  //女性

	/** ユーザ公開フラグ 定数区分:0024 */
	public static final String USER_PUBLIC_FLAG_NOT ="0";      //非公開
	public static final String USER_PUBLIC_FLAG_INSIDE ="1";   //内部公開
	public static final String USER_PUBLIC_FLAG_OUTSIDE ="2";  //全公開


	/** ファイルアップロードテーブル ファイル区分 */
	public static final String UPLOAD_FILE_KBN_PHOTOGRAPH     ="01"; // 01 顔写真
	public static final String UPLOAD_FILE_KBN_PRMOVIE        ="02"; // 02 ＰＲ動画
	public static final String UPLOAD_FILE_KBN_DOCUMENT       ="03"; // 03 その他成果物
	public static final String UPLOAD_FILE_KBN_SUBJECT        ="04"; // 04 養成能力エビデンス
	public static final String UPLOAD_FILE_KBN_INTERN_RECRUIT ="05"; // 05 インターン募集
	public static final String UPLOAD_FILE_KBN_INTERN_APP     ="06"; // 06 インターン応募
	public static final String UPLOAD_FILE_KBN_BOARD          ="07"; // 07 掲示板共有ファイル
	public static final String UPLOAD_FILE_KBN_EVENT          ="08"; // 08 イベント
	public static final String UPLOAD_FILE_KBN_COMPANY        ="09"; // 09 企業関連

	/** ユーザお知らせ情報テーブル データ区分 */
	public static final String INFO_DATA_KBN_EVENT           ="1"; // 1:イベント、
	public static final String INFO_DATA_KBN_INTERN_RECRUIT  ="2"; // 2:インターン募集
	public static final String INFO_DATA_KBN_INTERVIEW       ="3"; // 3:面談設定
	public static final String INFO_DATA_KBN_TRAINING        ="4"; // 4:トレーニング
	public static final String INFO_DATA_KBN_SUPPORT         ="5"; // 5:支援制度
	public static final String INFO_DATA_KBN_EQUIPMENT       ="6"; // 6:機器設備情報
	public static final String INFO_DATA_KBN_BOARD           ="7"; // 7:掲示板
	public static final String INFO_DATA_KBN_INQUIRY         ="9"; // 9:問合せ


	public static final long MAX_USER_FILE_SIZE = 10L*1024L*1024L*1024L; // ポートフォリオファイルサイズ上限(負値なら無制限)。10GB

	// Excelテンプレートなどの、jarリソース内での置き場。
	public static final String RESPATH_DOC_TEMPLATE = "/doc-templates/";
	public static final String RESPATH_MAIL_TEMPLATE = "/mail-templates/";

	// ルーブリック関連の定数。
	public static final int MIN_PHASERANK = 1; // フェーズの最小値。
	public static final int NUM_PHASES = 5; // フェーズの数。
	public static final int NUM_TARGETS = 3; // 目標値の数。
	public static final int NUM_LENSES = 2; // レンズの数。
	public static final int LENSID_BASIC = 1; // 「研究者基礎能力診断」のビット。JOSU_CODEとしても使う。
	public static final int LENSID_CAREER = 2; // 「キャリアパス診断」のビット。JOSU_CODEとしても使う。
	public static final int LENSID_FULL = 3; // フル診断(これは厳密にはレンズではないが)。JOSU_CODEとしても使う。

	// 能力診断。
	public static final long EVIDENCE_FILE_QUOTA = -1; // エビデンスファイル合計サイズ上限(負値なら無制限)。
	public static final long MAX_EVIDENCE_FILE_SIZE = 50*1024*1024; // エビデンスファイルサイズ上限(負値なら無制限)。

	// 履修状況
	/** 履修状況：参加確定 */
	public static final String COURSE_STATUS_JOIN = "2";
	/** 履修状況：参加予約 */
	public static final String COURSE_STATUS_RESERVE = "1";
	/** 履修状況：参加なし */
	public static final String COURSE_STATUS_NONE = "0";

	// 関連レベル（養成能力と科目のひも付けレベル）
	/** 関連レベル：◎ */
	public static final String RELATION_LEVEL_BEST = "2";
	/** 関連レベル：○ */
	public static final String RELATION_LEVEL_NORMAL = "1";
	/** 関連レベル：◎ */
	public static final String RELATION_LEVEL_BEST_V = "◎";
	/** 関連レベル：○ */
	public static final String RELATION_LEVEL_NORMAL_V = "○";

	// 紐付き画面呼出モード
	/** 呼出モード:インターン */
	public static final String RELATION_MODE_INTERN = "intern";
	/** 呼出モード:イベント */
	public static final String RELATION_MODE_EVENT = "event";
	/** 呼出モード:科目 */
	public static final String RELATION_MODE_LESSON = "lesson";

	// 紐付き画面新規
	public static final String RELATION_KEY_NEW = "new";

	/** 操作ログDB出力 */
	/** operationFuncId 操作機能ID */
	public static final String OP_FUNC_EVENT ="operation.function.event"; //イベント情報
	public static final String OP_FUNC_SUPPORT_SUPPORT ="operation.function.support.support"; //支援制度情報
	public static final String OP_FUNC_SUPPORT_FACILITY ="operation.function.support.facility"; //機器、設備情報
	public static final String OP_FUNC_INTERNSHIP ="operation.function.internship"; //インターンシップ募集情報
	public static final String OP_FUNC_INTERNSHIP_APPLY ="operation.function.internship.apply"; //インターンシップ募集・応募
	public static final String OP_FUNC_INTERNSHIP_REFUSE ="operation.function.internship.refuse"; //インターンシップ募集・辞退
	public static final String OP_FUNC_INTERNSHIP_UPLOAD ="operation.function.internship.upload"; //インターンシップ募集・書類登録
	public static final String OP_FUNC_INTERNSHIP_DISPATCH ="operation.function.internship.dispatch"; //インターンシップ募集・派遣情報
	public static final String OP_FUNC_INTERNSHIP_RESULTS ="operation.function.internship.results"; //インターンシップ募集・合否結果
	public static final String OP_FUNC_MESSAGEBOX ="operation.function.messagebox"; //メッセージ
	public static final String OP_FUNC_USER_BASE ="operation.function.user.base"; //ユーザ基本情報
	public static final String OP_FUNC_USER_CAREER_PAPER ="operation.function.user.career.paper"; //業績情報・論文
	public static final String OP_FUNC_USER_CAREER_CONFERENCE ="operation.function.user.career.conference"; //業績情報・講演・口頭発表等
	public static final String OP_FUNC_USER_CAREER_BIBLIO ="operation.function.user.career.biblio"; //業績情報・書籍
	public static final String OP_FUNC_USER_CAREER_RESEARCH_KEYWORD ="operation.function.user.career.research.keyword"; //業績情報・研究キーワード
	public static final String OP_FUNC_USER_CAREER_RESEARCH_AREA ="operation.function.user.career.research.area"; //業績情報・研究分野
	public static final String OP_FUNC_USER_CAREER_SOCIETY ="operation.function.user.career.society"; //業績情報・所属学協会
	public static final String OP_FUNC_USER_CAREER_WORKS ="operation.function.user.career.works"; //業績情報・Works
	public static final String OP_FUNC_USER_CAREER_PATENT ="operation.function.user.career.patent"; //業績情報・特許
	public static final String OP_FUNC_USER_CAREER_ACADEMIC ="operation.function.user.career.academic"; //業績情報・学歴
	public static final String OP_FUNC_USER_CAREER_CARRER ="operation.function.user.career.carrer"; //業績情報・経歴
	public static final String OP_FUNC_USER_CAREER_PRIZE ="operation.function.user.career.prize"; //業績情報・受賞
	public static final String OP_FUNC_USER_CAREER_OTHERS ="operation.function.user.career.others"; //業績情報・その他
	public static final String OP_FUNC_USER_CAREER_DEGREE ="operation.function.user.career.degree"; //業績情報・学位
	public static final String OP_FUNC_USER_CAREER_COMPETITION ="operation.function.user.career.competition"; //業績情報・競争的資金等の研究課題
	public static final String OP_FUNC_USER_PRMOVIE ="operation.function.user.prmovie"; //ＰＲ動画
	public static final String OP_FUNC_USER_OTHER_DOKYUMENT ="operation.function.user.other.dokyument"; //その他成果物画
	public static final String OP_FUNC_CARRER ="operation.function.carrer"; //キャリア相談
	public static final String OP_FUNC_CARRER_SETTING ="operation.function.carrer.setting"; //キャリア相談・面談設定
	public static final String OP_FUNC_CARRER_RESULTS ="operation.function.carrer.results"; //キャリア相談・面談実績
	public static final String OP_FUNC_SKILL_DIAG_ITEM = "operation.function.skill.diag.item"; // 能力診断・能力別回答
	public static final String OP_FUNC_SKILL_DIAG_SUBCAT = "operation.function.skill.diag.subcat"; // 能力診断・中項目回答
	public static final String OP_FUNC_SKILL_DIAG_EVIDENCE = "operation.function.skill.diag.evidence"; // 能力診断・エビデンスファイル
	public static final String OP_FUNC_SKILL_DIAG_REPORT = "operation.function.skill.diag.report"; // 能力診断・自己評価レポート目標
	public static final String OP_FUNC_SKILL_DIAG_RUBRIC = "operation.function.skill.diag.rubric"; // 能力診断管理・ルーブリック
	public static final String OP_FUNC_BOARD_GROUP = "operation.function.board.group"; //operation.function.board.group=掲示板グループ
	public static final String OP_FUNC_BOARD_COMMONFILE = "operation.function.board.commonfile"; //operation.function.board.commonfile=共有情報管理
	public static final String OP_FUNC_BOARD_THRED_LIST = "operation.function.board.thred.list"; //operation.function.board.thred.list=掲示板
	public static final String OP_FUNC_BOARD_THRED = "operation.function.board.thred"; //operation.function.board.thred=掲示板新規スレッド
	public static final String OP_FUNC_BOARD_CONTRIBUTION = "operation.function.board.contribution"; //operation.function.board.contribution=掲示板スレッド投稿
	public static final String OP_FUNC_BOARD_APPROVAL = "operation.function.board.approval"; //operation.function.board.approval=掲示板グループ・メンバー追加承認

	/** システム管理 */
	public static final String OP_FUNC_ADMIN_MSCODE = "operation.function.admin.mscode"; //operation.function.admin.mscode=定数コードマスタ

	/** operationActionId 操作ID */
	public static final String OP_ACTION_INSERT = "operation.action.insert"; //を追加しました。
	public static final String OP_ACTION_ADDED = "operation.action.added"; //が追加されました。
	public static final String OP_ACTION_UPDATE = "operation.action.update"; //を変更しました。
	public static final String OP_ACTION_UPDATEED = "operation.action.updateed"; //が変更されました。
	public static final String OP_ACTION_DELETE = "operation.action.delete"; //を削除しました。
	public static final String OP_ACTION_DELETEED = "operation.action.deleteed"; //が削除されました。
	public static final String OP_ACTION_REGIST = "operation.action.regist"; //を登録しました。
	public static final String OP_ACTION_REGISTED = "operation.action.registed"; //が登録されました。
	public static final String OP_ACTION_UPLOAD = "operation.action.upload"; //をアップロードしました。
	public static final String OP_ACTION_UPLOADED = "operation.action.uploaded"; //がアップロードされました。
	public static final String OP_ACTION_UPDATE_ALL = "operation.action.update.all"; //を一括変更しました。
	public static final String OP_ACTION_UPDATEED_ALL = "operation.action.updateed.all"; //が一括変更されました。
	public static final String OP_ACTION_INSERT_ALL = "operation.action.insert.all"; //を一括追加しました。
	public static final String OP_ACTION_INSERTED_ALL = "operation.action.inserted.all"; //に一括追加されました。
	public static final String OP_ACTION_APPLYING = "operation.action.applying"; //に応募しました。
	public static final String OP_ACTION_APPLY = "operation.action.apply"; //に応募されました。
	public static final String OP_ACTION_RESULTSING = "operation.action.resultsing"; //の合否情報を更新しました。
	public static final String OP_ACTION_RESULTS = "operation.action.results"; //の合否情報が更新されました。
	public static final String OP_ACTION_DOCUPLOADING = "operation.action.docuploading"; //に合格書類を登録しました。
	public static final String OP_ACTION_DOCUPLOAD = "operation.action.docupload"; //に合格書類が登録されました。
	public static final String OP_ACTION_REFUSEING = "operation.action.refuseing"; //を辞退しました。
	public static final String OP_ACTION_REFUSE = "operation.action.refuse"; //に辞退されました。
	public static final String OP_ACTION_END_ANNOUNCE = "operation.action.end.announce"; //の応募期間がもうすぐ終了します。
	public static final String OP_ACTION_INVITATION = "operation.action.invitation"; //operation.action.invitation=に招待されました。
	public static final String OP_ACTION_APPROVAL = "operation.action.approval"; //operation.action.approval=を承認しました。
	public static final String OP_ACTION_RETRACTION = "operation.action.retraction"; //operation.action.retraction=を取り下げしました。


	/** emailTitle ｅメール送信時のタイトル */
	public static final String EMAIL_TITLE_SUPPORT ="email.title.support"; //支援制度情報が登録されました。
	public static final String EMAIL_TITLE_EVENT ="email.title.event"; //イベント情報が登録されました。
	public static final String EMAIL_TITLE_INTERNSHIP ="email.title.internship"; //インターンシップ情報が登録されました。


	public final static String FILE_ACTION_NONE = "NONE";

	public final static String FILE_ACTION_ADD = "ADD";

	public final static String FILE_ACTION_CHANGE = "CHANGE";

	public final static String FILE_ACTION_DEL = "DEL";

}
