/*
* ファイル名：UserServiceImpl.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.portfolio.service;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.sraw.controller.portfolio.form.ResultUploadForm;
import jp.co.sraw.entity.UsResultUploadTbl;
import jp.co.sraw.file.FileDto;
import jp.co.sraw.file.FileService;
import jp.co.sraw.repository.UsResultUploadTblRepository;

/**
 * <B>ResultUploadServiceImplクラス</B>
 * <P>
 * ユーザーサービスのメソッドを提供する
 */
@Scope("prototype")
@Service
@Transactional(readOnly = true)
public class ResultUploadServiceImpl
		extends MultiHandleServiceImpl<UsResultUploadTbl, ResultUploadForm, UsResultUploadTblRepository> {

	@Autowired
	private FileService fileService;

	@Override
	public ResultUploadForm getPortfolioForm(UsResultUploadTbl tbl) {
		if (tbl == null)
			return null;
		//
		ResultUploadForm dto = new ResultUploadForm();
		dto = (ResultUploadForm) objectUtil.getObjectCopyValue(dto, tbl);
		FileDto fileDto = fileService.getFileUploadDto(dto.getUploadKey());
		if (fileDto != null) {
			dto.setFileName(fileDto.getUploadName());
		}
		return dto;
	}

	public List<FileDto> findAll(String userKey, String[] publicFlags) {
		logger.infoCode("I0001");

		//
		Specification<UsResultUploadTbl> whereUserKey = new Specification<UsResultUploadTbl>() {
			@Override
			public Predicate toPredicate(Root<UsResultUploadTbl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.get("usUserTbl").get("userKey"), userKey);
			}
		};

		// 取得条件：
		Specification<UsResultUploadTbl> wherePublicFlags = publicFlags == null ? null
				: new Specification<UsResultUploadTbl>() {
					@Override
					public Predicate toPredicate(Root<UsResultUploadTbl> root, CriteriaQuery<?> query,
							CriteriaBuilder cb) {
						Predicate predicate = cb.conjunction();
						for (int i = 0; i < publicFlags.length; i++) {
							String keyword = publicFlags[i];
							if (i == 0) {
								predicate = cb.and(predicate, cb.equal(root.get("publicFlag"), keyword));
							} else {
								predicate = cb.or(predicate, cb.equal(root.get("publicFlag"), keyword));
							}
						}
						return predicate;
					}
				};

		@SuppressWarnings("unchecked")
		List<UsResultUploadTbl> list = (List<UsResultUploadTbl>) repository
				.findAll((Specification<UsResultUploadTbl>) Specifications.where(whereUserKey).and(wherePublicFlags));

		List<FileDto> fileList = new ArrayList<>();
		for (UsResultUploadTbl tbl : list) {
			FileDto dto = fileService.getFileUploadDto(tbl.getUploadKey());
			dto.setTitle(tbl.getTitle());
			fileList.add(dto);
		}

		logger.infoCode("I0002");
		return fileList;
	}

}
