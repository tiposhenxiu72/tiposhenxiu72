/*
* ファイル名：IndexController.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.internship;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jp.co.sraw.common.CommonConst;
import jp.co.sraw.common.CommonController;
import jp.co.sraw.dto.MsCodeDto;
import jp.co.sraw.entity.ItInternRecruitTblPK;
import jp.co.sraw.entity.ItInternRecruitView;
import jp.co.sraw.file.DownloadService;
import jp.co.sraw.file.FileDto;
import jp.co.sraw.file.UploadCtrlBean;
import jp.co.sraw.file.UploadForm;
import jp.co.sraw.logger.LoggerWrapper;
import jp.co.sraw.logger.LoggerWrapperFactory;
import jp.co.sraw.service.InternshipServiceImpl;
import jp.co.sraw.util.DbUtil;

/**
 * <B>InternshipApplicationControllerクラス</B>
 * <P>
 * Controllerのメソッドを提供する
 */
@Controller
@RequestMapping("/internship/application")
public class InternshipApplicationController extends CommonController {

	private static final LoggerWrapper logger = LoggerWrapperFactory.getLogger(InternshipController.class);

	@PostConstruct
	protected void init() {
		logger.setMessageSource(messageSource);
	}

	private static final int BUFFER_SIZE = 4096;

	@Autowired
	private InternshipServiceImpl internshipServiceImpl;

	@Autowired
	private DownloadService dowloadService;

	private static final String LIST_PAGE = "internship/application/list";

	private static final String REDIRECT_LIST = "redirect:/internship/application/";

	// インターンシップ区分
	private static final String KBN = "0002"; // インターンシップ区分

	private static final String PUBLIC_FLAG = "1"; // 固定値: 公開

	@ModelAttribute(CommonConst.FORM_NAME)
	public InternshipForm setupForm() {
		InternshipForm form = new InternshipForm();
		return form;
	}

	/**
	 * ３．８．合否結果閲覧（一覧）
	 *
	 * @param model
	 * @param locale
	 * @return
	 */
	@RequestMapping({ "", "/", "/list" })
	public String index(Model model, Locale locale) {

		logger.infoCode("I0001");

		if (logger.isDebugEnabled()) {
			logger.debug("LoginUserKey=" + userInfo.getLoginUserKey());
			logger.debug("TargetUserKey=" + userInfo.getTargetUserKey());
		}

		List<MsCodeDto> kbnList = DbUtil.getJosuList(KBN, locale);

		List<ItInternRecruitView> resultList = internshipServiceImpl.findAllItInternRecruitView(null,
				userInfo.getLoginUserKey());

		Map<String, List<ItInternRecruitView>> mapList = new HashMap<String, List<ItInternRecruitView>>();
		// 区分から一覧を生成
		for (int i = 0; i < kbnList.size(); i++) {
			MsCodeDto dto = kbnList.get(i);
			//
			List<ItInternRecruitView> inteList = new ArrayList<>();
			for (int j = 0; j < resultList.size(); j++) {
				ItInternRecruitView data = resultList.get(j);
				// 区分毎に振り分け
				if (data.getInternshipKbn().contains(dto.getCode())) {
					inteList.add(data);
				}
			}
			mapList.put(dto.getCode(), inteList);
		}

		model.addAttribute("kbnList", kbnList);
		model.addAttribute("mapList", mapList);

		// dump
		modelDump(logger, model, "index");

		return LIST_PAGE;
	}

	/**
	 *
	 * @param form
	 * @param model
	 * @param attributes
	 * @return
	 */
	@RequestMapping(value = "/refuse", method = RequestMethod.POST)
	public String refuse(@ModelAttribute(CommonConst.FORM_NAME) final InternshipForm form, Model model,
			RedirectAttributes attributes) {

		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		String key = "internshipKey=" + form.getInternshipKey() + ", userKey=" + userInfo.getTargetUserKey();

		ItInternRecruitForm recruitForm = new ItInternRecruitForm();
		ItInternRecruitTblPK pk = new ItInternRecruitTblPK();
		pk.setInternshipKey(form.getInternshipKey());
		pk.setUserKey(userInfo.getLoginUserKey());
		recruitForm.setId(pk);
		recruitForm.setUpdDate(form.getUpdDate());

		try {
			// 更新テーブル：インターンシップ応募者テーブル ＆ 削除テーブル：インターンシップ応募者添付ファイル
			if (internshipServiceImpl.refuseInternRecruit(userInfo, recruitForm)) {

				// 操作履歴を出力する。
				this.operationHistory(CommonConst.OP_FUNC_INTERNSHIP_REFUSE, CommonConst.OP_ACTION_REFUSE);
				// DB更新が成功した場合
				logger.infoCode("I1004", key); // I1004=更新しました。{0}
				attributes.addFlashAttribute(CommonConst.PAGE_SUCCESS_MESSAGE, "message.data.update.success"); // message.data.update.success=データを更新しました。
			} else {
				// DB更新が失敗した場合
				logger.errorCode("E1008", key); // E1008=更新に失敗しました。{0}
				model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.regist"); // error.data.message.db.regist=登録が失敗しました。
			}
		} catch (Exception e) {
			// DB更新が失敗した場合
			logger.errorCode("E1008", key); // E1008=更新に失敗しました。{0}
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.regist"); // error.data.message.db.regist=登録が失敗しました。
		}

		return REDIRECT_LIST;
	}

	/**
	 *
	 * @param form
	 * @param model
	 * @param attributes
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/download", method = RequestMethod.POST)
	public void download(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute(CommonConst.FORM_NAME) final ItInternRecruitForm form) throws IOException {

		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		ServletContext context = request.getServletContext();
		String appPath = context.getRealPath("");
		System.out.println("appPath = " + appPath);

		List<FileDto> uploadList = internshipServiceImpl.getRecuritUploadFileList(form, userInfo);
		List<String> downloadList = new ArrayList<>();
		for (FileDto dto : uploadList) {
			// 合格書類（’２’）
			if (dto.getFileKbn().equals("2")) {
				downloadList.add(dto.getUploadKey());
			}
		}

		dowloadService.downloadZip(request, response, userInfo.getLoginUserKey(), form.getInternshipKey(),
				downloadList);

	}

	/**
	 *
	 * @param form
	 * @param request
	 * @param model
	 * @param attributes
	 * @return
	 */
	@RequestMapping(value = "/upload", method = RequestMethod.POST)
	public String upload(@ModelAttribute(CommonConst.FORM_NAME) final InternshipForm form,
			MultipartHttpServletRequest request, Model model, RedirectAttributes attributes) {

		logger.infoCode("I0001"); // I0001=メソッド開始:{0}

		String key = "internshipKey=" + form.getInternshipKey() + ", userKey=" + userInfo.getTargetUserKey();

		ItInternRecruitTblPK pk = new ItInternRecruitTblPK();
		pk.setInternshipKey(form.getInternshipKey());
		pk.setUserKey(userInfo.getTargetUserKey());

		//
		UploadCtrlBean gkFileBean = appContext.newUploadCtrlBean();
		UploadForm uploadForm = new UploadForm();

		// 3-1． 応募済みのチェック
		if (internshipServiceImpl.getOneInternRecruit(pk) != null) {

			uploadForm.setFileNotNull(true);
			// インターンシップ応募（06）
			uploadForm.setFileKbn("6");
			uploadForm.setUserInfo(userInfo);
			uploadForm.setPageMode(CommonConst.PAGE_MODE_ADD);
			gkFileBean.setForm(uploadForm);
			if (gkFileBean.beoforeProcess(request) > 0) {
				//
				model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.valid.data"); // error.data.message.valid.data=入力項目に誤りがあります。
			} else {
				// 登録テーブル：インターンシップ応募者テーブル
				form.setGkFileList(uploadForm.getUploadFileList());
				//
				if (internshipServiceImpl.updateInternRecruitForGohiKeka(userInfo, form)) {
					// DB更新が成功した場合
					gkFileBean.afterProcessSuccess();
					// 操作履歴を出力する。
					this.operationHistory(CommonConst.OP_FUNC_INTERNSHIP_APPLY, CommonConst.OP_ACTION_APPLY);
					logger.infoCode("I1005", key); // I1005=新規作成しました。{0}
				} else {
					// DB更新が失敗した場合
					gkFileBean.afterProcessFailure();
					logger.errorCode("E1007", key); // E1007=登録に失敗しました。{0}
					model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.regist"); // error.data.message.db.regist=登録が失敗しました。
				}
			}

		} else {
			// DB更新が失敗した場合
			logger.errorCode("E1007", key); // E1007=登録に失敗しました。{0}
			model.addAttribute(CommonConst.PAGE_DANGER_MESSAGE, "error.data.message.db.regist"); // error.data.message.db.regist=登録が失敗しました。
		}

		return REDIRECT_LIST;
	}

	/**
	 * ダイレクトアクセス対策
	 *
	 * @return
	 */
	@RequestMapping(value = { "/edit", "/copy", "/create", "/update", "/delete", "/upload", "/refuse",
			"/download" }, method = RequestMethod.GET)
	public String redirect() {
		logger.warnCode("W1009"); // W1009=URLダイレクトアクセスがありました。
		return CommonConst.REDIRECT_INDEX;
	}

}
