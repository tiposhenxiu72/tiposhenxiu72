/*
* ファイル名：GyResearchKeywordForm.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2015/12/01   toishigawa  新規作成
*/
package jp.co.sraw.controller.portfolio.form;

import jp.co.sraw.entity.GyCommonTbl;
import jp.co.sraw.entity.GyResearchKeywordTbl;

/**
 * <B>GyResearchKeywordFormクラス</B>
 * <P>
 * Formのメソッドを提供する
 */
public class GyResearchKeywordForm extends GyHasTitleForm {

	public GyResearchKeywordForm() {
		super();
	}

	public String getResearchKeywordLanguage() {
		return this.getLanguage();
	}

	public void setResearchKeywordLanguage(String researchKeywordLanguage) {
		this.setLanguage(researchKeywordLanguage);
	}

	@Override
	public GyCommonTbl getNewTbl() {
		return new GyResearchKeywordTbl();
	}

}
