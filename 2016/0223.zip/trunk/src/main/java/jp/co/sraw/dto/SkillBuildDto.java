/*
* ファイル名：SkillBuildDto.java
*
* <MODIFICATION HISTORY>
*   (Rev.)     (Date)       (ID/NAME)   (Comment)
*   Rev 1.00   2016/01/18   tsutsumi    新規作成
*/
package jp.co.sraw.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * <B>能力養成科目のDtoクラス</B>
 * <P>
 */
public class SkillBuildDto implements Serializable {

	private static final long serialVersionUID = 1L;

	/** 養成能力コード */
	private String subjectCode;

	/** 能力養成科目キー */
	private String lessonKey;

	/** 能力養成科目名称 */
	private String lessonName;

	/** 組織コード */
	private String partyCode;

	/** 組織名称 */
	private String partyName;

	/** 機関内講義コード */
	private String lessonCode;

	/** 開講部局 */
	private String lessonDepartment;

	/** 担当教員名 */
	private String userName;

	/** 受講対象者 */
	private String lessonTarget;

	/** 学外聴講／傍聴の可否 */
	private String listenFlag;

	/** 開講期 */
	private Date lessonDate;

	/** 曜日・時限 */
	private String lessonPeriod;

	/** 中継の有無 */
	private String relayFlag;

	/** 中継聴講場所 */
	private String relayPlace;

	/** 授業形態 */
	private String lessonKbn;

	/** 単位 */
	private int unit;

	/** 学外受講生の単位互換 */
	private String unitInterchangeable;

	/** 必修選択の別 */
	private String lessonCompulsory;

	/** 成績評価基準 */
	private String lessonBase;

	/** 授業の目的概要 */
	private String lessonIntention;

	/** 授業計画 */
	private String lessonPlan;

	/** 備考 */
	private String lessonMemo;

	/** eラーニングリンク */
	private String eLink;

	/** シラバスリンク */
	private String sLink;

	/** 履修状況 */
	private String courseStatus;

	/** 更新日時 */
	private Date updDate;

	public SkillBuildDto () {
		super();
	}

	public SkillBuildDto(String subjectCode, String lessonKey, String lessonName, String partyCode, String partyName, String lessonCode, String lessonDepartment, String userName, String lessonTarget, String listenFlag, Date lessonDate, String lessonPeriod, String relayFlag, String relayPlace, String lessonKbn, int unit, String unitInterchangeable, String lessonCompulsory, String lessonBase, String lessonIntention, String lessonPlan, String lessonMemo, String eLink, String sLink, String courseStatus, Date updDate) {
		this.subjectCode = subjectCode;
		this.lessonKey = lessonKey;
		this.lessonName = lessonName;
		this.partyCode = partyCode;
		this.partyName = partyName;
		this.lessonCode = lessonCode;
		this.lessonDepartment = lessonDepartment;
		this.userName = userName;
		this.lessonTarget = lessonTarget;
		this.listenFlag = listenFlag;
		this.lessonDate = lessonDate;
		this.lessonPeriod = lessonPeriod;
		this.relayFlag = relayFlag;
		this.relayPlace = relayPlace;
		this.lessonKbn = lessonKbn;
		this.unit = unit;
		this.unitInterchangeable = unitInterchangeable;
		this.lessonCompulsory = lessonCompulsory;
		this.lessonBase = lessonBase;
		this.lessonIntention = lessonIntention;
		this.lessonPlan = lessonPlan;
		this.lessonMemo = lessonMemo;
		this.eLink = eLink;
		this.sLink = sLink;
		this.courseStatus = courseStatus;
		this.updDate = updDate;
	}

	public String getSubjectCode() {
		return subjectCode;
	}

	public void setSubjectCode(String subjectCode) {
		this.subjectCode = subjectCode;
	}

	public String getLessonKey() {
		return lessonKey;
	}

	public void setLessonKey(String lessonKey) {
		this.lessonKey = lessonKey;
	}

	public String getLessonName() {
		return lessonName;
	}

	public void setLessonName(String lessonName) {
		this.lessonName = lessonName;
	}

	public String getPartyCode() {
		return partyCode;
	}

	public void setPartyCode(String partyCode) {
		this.partyCode = partyCode;
	}

	public String getPartyName() {
		return partyName;
	}

	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}

	public String getLessonCode() {
		return lessonCode;
	}

	public void setLessonCode(String lessonCode) {
		this.lessonCode = lessonCode;
	}

	public String getLessonDepartment() {
		return lessonDepartment;
	}

	public void setLessonDepartment(String lessonDepartment) {
		this.lessonDepartment = lessonDepartment;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getLessonTarget() {
		return lessonTarget;
	}

	public void setLessonTarget(String lessonTarget) {
		this.lessonTarget = lessonTarget;
	}

	public String getListenFlag() {
		return listenFlag;
	}

	public void setListenFlag(String listenFlag) {
		this.listenFlag = listenFlag;
	}

	public Date getLessonDate() {
		return lessonDate;
	}

	public void setLessonDate(Date lessonDate) {
		this.lessonDate = lessonDate;
	}

	public String getLessonPeriod() {
		return lessonPeriod;
	}

	public void setLessonPeriod(String lessonPeriod) {
		this.lessonPeriod = lessonPeriod;
	}

	public String getRelayFlag() {
		return relayFlag;
	}

	public void setRelayFlag(String relayFlag) {
		this.relayFlag = relayFlag;
	}

	public String getRelayPlace() {
		return relayPlace;
	}

	public void setRelayPlace(String relayPlace) {
		this.relayPlace = relayPlace;
	}

	public String getLessonKbn() {
		return lessonKbn;
	}

	public void setLessonKbn(String lessonKbn) {
		this.lessonKbn = lessonKbn;
	}

	public int getUnit() {
		return unit;
	}

	public void setUnit(int unit) {
		this.unit = unit;
	}

	public String getUnitInterchangeable() {
		return unitInterchangeable;
	}

	public void setUnitInterchangeable(String unitInterchangeable) {
		this.unitInterchangeable = unitInterchangeable;
	}

	public String getLessonCompulsory() {
		return lessonCompulsory;
	}

	public void setLessonCompulsory(String lessonCompulsory) {
		this.lessonCompulsory = lessonCompulsory;
	}

	public String getLessonBase() {
		return lessonBase;
	}

	public void setLessonBase(String lessonBase) {
		this.lessonBase = lessonBase;
	}

	public String getLessonIntention() {
		return lessonIntention;
	}

	public void setLessonIntention(String lessonIntention) {
		this.lessonIntention = lessonIntention;
	}

	public String getLessonPlan() {
		return lessonPlan;
	}

	public void setLessonPlan(String lessonPlan) {
		this.lessonPlan = lessonPlan;
	}

	public String getLessonMemo() {
		return lessonMemo;
	}

	public void setLessonMemo(String lessonMemo) {
		this.lessonMemo = lessonMemo;
	}

	public String geteLink() {
		return eLink;
	}

	public void seteLink(String eLink) {
		this.eLink = eLink;
	}

	public String getsLink() {
		return sLink;
	}

	public void setsLink(String sLink) {
		this.sLink = sLink;
	}

	public String getCourseStatus() {
		return courseStatus;
	}

	public void setCourseStatus(String courseStatus) {
		this.courseStatus = courseStatus;
	}

	public Date getUpdDate() {
		return updDate;
	}

	public void setUpdDate(Date updDate) {
		this.updDate = updDate;
	}
}
